package com.att.lasr.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.att.lasr.controller.EnvRegionController;
import com.att.lasr.model.AllValidUserData;
import com.att.lasr.model.ErrorCodeData;
import com.att.lasr.model.Header;
import com.att.lasr.model.Login;
import com.att.lasr.model.MQReceivedData;
import com.att.lasr.model.ShowError;
import com.att.lasr.model.SubData;
import com.att.lasr.model.SubHeader;
import com.att.lasr.model.UserProfileData;
import com.att.lasr.utils.FormatUtil;
import com.att.lasr.utils.MQMessageStringBuilder;
import com.att.lasr.utils.MQReadUtil;
import com.att.lasr.utils.MQWriteUtil;
import com.att.lasr.utils.enums.LastInd;
import com.att.lasr.utils.enums.LogInd;
import com.att.lasr.utils.enums.Process;
import com.att.lasr.utils.enums.ProcessGroupInd;
import com.att.lasr.utils.enums.ProcessMode;
import com.att.lasr.utils.enums.RecIdFor12State;

@Service
public class UserProfileService {

	@Autowired
	private MQReadUtil mqReadUtil;

	@Autowired
	private MQWriteUtil mqWriteUtil;
	
	@Autowired
	HttpSession httpSession;
	@Autowired
	private EnvRegionController envRegionCtrl;
	
	

	
	ErrorCodeData errorCodeData = new ErrorCodeData();
	ShowErrorService showErrorService = new ShowErrorService();
	public UserProfileData writeRetrieveUserProfileDataToMQ(UserProfileData userProfileData, String user_id, String object_handle,HttpSession session) {

		List<ShowError> showError = new ArrayList<ShowError>();
		Header header = prepareHeader(user_id,object_handle);
		SubHeader subHeader = prepareSubHeader();

		String dataString = userProfileData.getRetrieveUserProfileDataString();

		MQMessageStringBuilder mqMessageStringBuilder = new MQMessageStringBuilder().addHeaderSubHeaderAndData(header,
				subHeader, dataString);

		boolean isWritten = mqWriteUtil.writeDataToMQ(mqMessageStringBuilder,session);

		UserProfileData userProfileDataFromMQ = userProfileData;

		if (isWritten) {
			MQReceivedData mqReceivedData=null;
			
			try {

			mqReceivedData = mqReadUtil.readSortDataFromMQ(session); 
			 long endTime = System.nanoTime() + TimeUnit.NANOSECONDS.convert(3L, TimeUnit.MINUTES); 
			  Map<String, SubData> subDatas = mqReceivedData.getSubDatas(); 
		//	  Header receivedHeader = mqReceivedData.getHeader(); 
			  while(mqReceivedData.getHeader()==null&& System.nanoTime() < endTime) { 
					System.out.println("*************inside if*************** "); 
					mqReceivedData =	 mqReadUtil.readSortDataFromMQ(session); 
				} 
			  
			  
			  System.out.println(mqReceivedData.getHeader().toString()); 
		} catch (Exception e) { 
			// TODO Auto-generated catch block 
			// mqReceivedData = mqReadUtil.readDataFromMQ(session); 
			e.printStackTrace(); 


		}
			Map<String, SubData> subDatas = mqReceivedData.getSubDatas();
			Header receivedHeader = mqReceivedData.getHeader();
			userProfileDataFromMQ.setHeader(receivedHeader);
			SubData subData = subDatas.get(RecIdFor12State.CS_RECID_USER_PROFILE.getRecIdValue());
			if (subData != null) {
				SubHeader receivedSubHeader = subData.getSubHeader();
				String[] subDataRows = subData.getSubDataRows();

				
				
				String[] attributes = mqReadUtil.getAttributes(subDataRows[0], 26);
				//System.out.println("attributes: 10 Aug" + Arrays.toString(attributes));
			

				setUserProfileDataFromMQ(userProfileDataFromMQ, receivedSubHeader, attributes,session);

			}
		}
		return userProfileDataFromMQ;

	}

	private String getUserName(String userId,HttpSession session) {
		String userName = "";
		if (userId != null && !"".equals(userId)) {
//			Login login = EnvRegionController.getLoginObject();

			Login login =envRegionCtrl.getLoginObjectFromSession(session);

			
			
			List<AllValidUserData> allValidUserDataRows = login.getAllValidUserDataRows();
			for (AllValidUserData allValidUserData : allValidUserDataRows) {
				if (userId.equals(allValidUserData.getUser_id())) {
					userName = allValidUserData.getUser_name();
					break;
				}
			}
		}
		return userName;
	}

	public UserProfileData writeSaveUserProfileDataToMQ(UserProfileData userProfileData, String user_id, String object_handle,HttpSession session) {
		session.removeAttribute("showError");
		List<ShowError> showError = new ArrayList<ShowError>();
		String region =  (String) httpSession.getAttribute("envregion"); 
		System.out.println(region); 
 
		if (region.equals("D3 - 9 states Dev") || region.equals("D5 - SE ST2")|| region.equals("D2 - 9 states Dev")|| region.equals("D8 - SE RS2")|| region.equals("D6 - SE RS1")|| region.equals("D7 - SE ST1")|| region.equals("D9 - SE CAVE/CLEC")|| region.equals("SE Production")) { 
			System.out.println("inside if block"); 
			userProfileData.setSubsidiary("B");
			} 
			else if(region.equals("T3 - MW System Test")|| region.equals("T1 - MW Clec Test")|| region.equals("T2 - MW prod mirror")|| region.equals("MW Production")) { 
				userProfileData.setSubsidiary("A"); 
			} 
			else if (region.equals("B1 - 12 states Dev")|| region.equals("A0 - 12 states Dev")|| region.equals("A2 - SW Clec Test")|| region.equals("AH - SW prod mirror")|| region.equals("A5 - SW System Test")|| region.equals("SW Production")|| region.equals("AA - 12 states Dev")) { 
				userProfileData.setSubsidiary("S"); 
			} 
			else { 
			System.out.println("inside else block"); 
			userProfileData.setSubsidiary("P"); 
		}
		user_id=user_id.toUpperCase();
		Header header = prepareSaveHeader(user_id,object_handle);
		SubHeader subHeader = prepareSaveSubHeader();

		String dataString = userProfileData.getSaveUserProfileDataString();
		System.out.println("DATA STRING" + dataString);

		MQMessageStringBuilder mqMessageStringBuilder = new MQMessageStringBuilder().addHeaderSubHeaderAndData(header,
				subHeader, dataString);
		boolean isWritten = mqWriteUtil.writeDataToMQ(mqMessageStringBuilder,session);
		System.out.println("isWritten: "+ isWritten);
		UserProfileData userProfileDataFromMQ = userProfileData;
		System.out.println("userProfileDataFromMQ1: " + userProfileDataFromMQ.toString());
		
		if (isWritten) {

			MQReceivedData mqReceivedData=null;
			
			try {

			mqReceivedData = mqReadUtil.readSortDataFromMQ(session); 
			 long endTime = System.nanoTime() + TimeUnit.NANOSECONDS.convert(3L, TimeUnit.MINUTES); 
			  Map<String, SubData> subDatas = mqReceivedData.getSubDatas(); 
		//	  Header receivedHeader = mqReceivedData.getHeader(); 
			  while(mqReceivedData.getHeader()==null&& System.nanoTime() < endTime) { 
					System.out.println("*************inside if*************** "); 
					mqReceivedData =	 mqReadUtil.readSortDataFromMQ(session); 
				} 
			  
			  
			  System.out.println(mqReceivedData.getHeader().toString()); 
		} catch (Exception e) { 
			// TODO Auto-generated catch block 
			// mqReceivedData = mqReadUtil.readDataFromMQ(session); 
			e.printStackTrace(); 


		}
			Map<String, SubData> subDatas = mqReceivedData.getSubDatas();
			Header receivedHeader = mqReceivedData.getHeader();
			userProfileDataFromMQ.setHeader(receivedHeader);
			System.out.println("header: "+ receivedHeader.toString());
			
			SubData subData = subDatas.get(RecIdFor12State.CS_RECID_USER_PROFILE.getRecIdValue());
			System.out.println("subData: "+ subData);
			if (subData != null) {
				SubHeader receivedSubHeader = subData.getSubHeader();
				System.out.println("receivedSubHeader: " + receivedSubHeader.toString());
				String[] subDataRows = subData.getSubDataRows();

				String[] attributes = mqReadUtil.getAttributes(subDataRows[0], 26);
				System.out.println("attributes: Aug 10 " + Arrays.toString(attributes));
				System.out.println("recieved subheader" + receivedSubHeader.toString() );
				if(receivedSubHeader.getReturn_code().equals("999")) {
					System.out.println("inside 999");
					String errorData = attributes[0];
					userProfileDataFromMQ.setLg_code(errorData.substring(0,6).trim());
					userProfileDataFromMQ.setField_name(errorData.substring(7,33).trim());
					userProfileDataFromMQ.setField_value(errorData.substring(33,59).trim());
					userProfileDataFromMQ.setProcess_mode(errorData.substring(59,60).trim());
					showError = showErrorService.getErrorList(userProfileDataFromMQ.getLg_code(), userProfileDataFromMQ.getField_name(), userProfileDataFromMQ.getField_value(), userProfileDataFromMQ.getProcess_mode());
					
					session.setAttribute("showError", showError);
					System.out.println("ERRORS ******" + showError.toString());
					/*
					 * for(int i = 0; i < showError.size(); i++) {
					 * System.out.print("Show error: "+(showError.get(i)).toString()); }
					 */
					//userProfileDataFromMQ.setErr_failed(errorData.substring(62,72));
					
					//userProfileDataFromMQ.setLg_code(attributes[0]);
					/*
					 * userProfileDataFromMQ.setField_name(attributes[1]);
					 * userProfileDataFromMQ.setField_value(attributes[2]);
					 * userProfileDataFromMQ.setProcess_mode(attributes[3]);
					 * userProfileDataFromMQ.setErr_failed(attributes[4]);
					 */
					System.out.println("userProfileDataFromMQ: "+ userProfileDataFromMQ.toString());
					
				}
				else {
					session.removeAttribute("showError");
					System.out.println("inside else *******");
					setUserProfileDataFromMQ(userProfileDataFromMQ, receivedSubHeader, attributes,session);
				}
			}
		}
		return userProfileDataFromMQ;

	}
    
	//supriya changes
		public UserProfileData updateUserProfileDataToMQ(UserProfileData saveUserData, UserProfileData retriveUserData, String user_id, String object_handle, HttpSession session) {
			// TODO Auto-generated method stub
			session.removeAttribute("showError");
			List<ShowError> showError = new ArrayList<ShowError>();
			//UserProfileData userProfileData = new UserProfileData();
			String region =  (String) httpSession.getAttribute("envregion"); 
			System.out.println(region); 
	 
			if (region.equals("D3 - 9 states Dev") || region.equals("D5 - SE ST2")|| region.equals("D2 - 9 states Dev")|| region.equals("D8 - SE RS2")|| region.equals("D6 - SE RS1")|| region.equals("D7 - SE ST1")|| region.equals("D9 - SE CAVE/CLEC")|| region.equals("SE Production")) { 
				System.out.println("inside if block"); 
				saveUserData.setSubsidiary("B");
				} 
				else if(region.equals("T3 - MW System Test")|| region.equals("T1 - MW Clec Test")|| region.equals("T2 - MW prod mirror")|| region.equals("MW Production")) { 
					saveUserData.setSubsidiary("A"); 
				} 
				else if (region.equals("B1 - 12 states Dev")|| region.equals("A0 - 12 states Dev")|| region.equals("A2 - SW Clec Test")|| region.equals("AH - SW prod mirror")|| region.equals("A5 - SW System Test")|| region.equals("SW Production")|| region.equals("AA - 12 states Dev")) { 
					saveUserData.setSubsidiary("S"); 
				} 
				else { 
				System.out.println("inside else block"); 
				saveUserData.setSubsidiary("P"); 
			}
									
			saveUserData.setUser_id_attr("N");
			
				if(retriveUserData.getTelephone_number().equals(saveUserData.getTelephone_number())) {
					saveUserData.setTelephone_number_attr("N");
				}else {								
					saveUserData.setTelephone_number_attr("Y");
				}
			
			
				if(retriveUserData.getName().equals(saveUserData.getName())) {
					saveUserData.setName_attr("N");
				}
				else {								
					saveUserData.setName_attr("Y");
				}

				if(retriveUserData.getStatus().equals(saveUserData.getStatus())) {
					saveUserData.setStatus_attr("N");
				}else {								
					saveUserData.setStatus_attr("Y");
				}
				
				if(retriveUserData.getUser_type().equals(saveUserData.getUser_type())) {
					saveUserData.setUser_type_attr("N");
				}else {								
					saveUserData.setUser_type_attr("Y");
				}
				
			//saveUserData.setUser_type_attr("N");
			saveUserData.setSubsidiary_attr("N");
			saveUserData.setTypist_attr("N");
			saveUserData.setSales_code_attr("N");
			saveUserData.setDflt_ims_region_attr("N");
			saveUserData.setManager_attr("R");
			saveUserData.setArea_manager_attr("R");
			
			saveUserData.setMulti_access_ind_attr("N");
			saveUserData.setMulti_access_ind(retriveUserData.getMulti_access_ind());
			
			saveUserData.setLast_updt_dttm(retriveUserData.getLast_updt_dttm());
			saveUserData.setLast_updt_id(getUserid(retriveUserData.getLast_updt_id(), session));
			
			System.out.println("status*******" + saveUserData.getStatus());
			
			user_id=user_id.toUpperCase();
			Header header = prepareUpdateHeader(user_id,object_handle);
			SubHeader subHeader = prepareUpdateSubHeader();

			
			String dataString = saveUserData.geUpdateUserProfileDataString();
			System.out.println("DATA STRING" + dataString);

			MQMessageStringBuilder mqMessageStringBuilder = new MQMessageStringBuilder().addHeaderSubHeaderAndData(header,
					subHeader, dataString);
			
			System.err.println("mqMessageStringBuilder 12 state****** " + mqMessageStringBuilder.getMqMessageString());
			
			boolean isWritten = mqWriteUtil.writeDataToMQ(mqMessageStringBuilder,session);
			System.out.println("isWritten: "+ isWritten);
			UserProfileData userProfileDataFromMQ = saveUserData;
			System.out.println("userProfileDataFromMQ1: " + userProfileDataFromMQ.toString());
			
			if (isWritten) {

				MQReceivedData mqReceivedData=null;
				
				try {

				mqReceivedData = mqReadUtil.readSortDataFromMQ(session); 
				 long endTime = System.nanoTime() + TimeUnit.NANOSECONDS.convert(3L, TimeUnit.MINUTES); 
				  Map<String, SubData> subDatas = mqReceivedData.getSubDatas(); 
			//	  Header receivedHeader = mqReceivedData.getHeader(); 
				  while(mqReceivedData.getHeader()==null&& System.nanoTime() < endTime) { 
						System.out.println("*************inside if*************** "); 
						mqReceivedData =	 mqReadUtil.readSortDataFromMQ(session); 
					} 
				  
				  
				  System.out.println(mqReceivedData.getHeader().toString()); 
			} catch (Exception e) { 
				// TODO Auto-generated catch block 
				// mqReceivedData = mqReadUtil.readDataFromMQ(session); 
				e.printStackTrace(); 


			}
				Map<String, SubData> subDatas = mqReceivedData.getSubDatas();
				Header receivedHeader = mqReceivedData.getHeader();
				userProfileDataFromMQ.setHeader(receivedHeader);
				System.out.println("header: "+ receivedHeader.toString());
				
				SubData subData = subDatas.get(RecIdFor12State.CS_RECID_USER_PROFILE.getRecIdValue());
				System.out.println("subData: "+ subData);
				if (subData != null) {
					SubHeader receivedSubHeader = subData.getSubHeader();
					System.out.println("receivedSubHeader: " + receivedSubHeader.toString());
					String[] subDataRows = subData.getSubDataRows();

					String[] attributes = mqReadUtil.getAttributes(subDataRows[0], 26);
					System.out.println("attributes: Aug 10 " + Arrays.toString(attributes));
					System.out.println("recieved subheader" + receivedSubHeader.toString() );
					if(receivedSubHeader.getReturn_code().equals("999")) {
						System.out.println("inside 999");
						String errorData = attributes[0];
						userProfileDataFromMQ.setLg_code(errorData.substring(0,6).trim());
						userProfileDataFromMQ.setField_name(errorData.substring(7,33).trim());
						userProfileDataFromMQ.setField_value(errorData.substring(33,59).trim());
						userProfileDataFromMQ.setProcess_mode(errorData.substring(59,60).trim());
						showError = showErrorService.getErrorList(userProfileDataFromMQ.getLg_code(), userProfileDataFromMQ.getField_name(), userProfileDataFromMQ.getField_value(), userProfileDataFromMQ.getProcess_mode());
						
						session.setAttribute("showError", showError);
						System.out.println("ERRORS ******" + showError.toString());
						
						System.out.println("userProfileDataFromMQ: "+ userProfileDataFromMQ.toString());
						
					}
					else {
						session.removeAttribute("showError");
						System.out.println("inside else *******");
						setUserProfileDataFromMQ(userProfileDataFromMQ, receivedSubHeader, attributes,session);
					}
					
					System.out.println("userProfileDataFromMQ: "+ userProfileDataFromMQ.toString());
				}
			}
			return userProfileDataFromMQ;
		}
		
		private SubHeader prepareUpdateSubHeader() {

			// Prepare SubHeader
			SubHeader subHeader = new SubHeader();

			subHeader.setLast_ind(LastInd.Y.name());
			subHeader.setProcess_mode(ProcessMode.CS_UPDATE.getProcessModeCode());
			subHeader.setRecord_type(RecIdFor12State.CS_RECID_USER_PROFILE.getRecIdValue());
			subHeader.setReturn_code(null);
			subHeader.setDw_rownum(null);
			subHeader.setEcver(null);

			return subHeader;
		}
		
		private Header prepareUpdateHeader(String user_id, String object_handle) {
			// Prepare Header
			Header header = new Header();

			header.setUser_id(user_id);
			header.setProcess(Process.CS_USER_PROFILE.getProcessCode());
			header.setTab_ind(null);
			header.setProcess_group_ind(ProcessGroupInd.SAVE_IND.getProcessGroupInd());
			header.setObject_handle(object_handle);
			header.setObject_handle2(null);
			header.setLog_ind(LogInd.N.name());
			header.setStarttime(null);
			header.setEndtime(null);
			header.setGuid(null);
			header.setSession_trans_count("0000001");
			header.setHost_trans_seq(null);
			header.setReturn_code(null);
			header.setRead_only_ind(null);
			header.setNum_detail("0001");
			header.setRead_only_user_id(null);
			header.setLasrversion(null);

			return header;
		}
		
		private String getUserid(String userName,HttpSession session) {
			String userId = "";
			if (userName != null && !"".equals(userName)) {
//				Login login = EnvRegionController.getLoginObject();

				Login login =envRegionCtrl.getLoginObjectFromSession(session);

				
				
				List<AllValidUserData> allValidUserDataRows = login.getAllValidUserDataRows();
				for (AllValidUserData allValidUserData : allValidUserDataRows) {
					if (userName.equals(allValidUserData.getUser_name())) {
						userId = allValidUserData.getUser_id();
						break;
					}
				}
			}
			return userId;
		}

		//supriya code changes end

	private void setUserProfileDataFromMQ(UserProfileData userProfileDataFromMQ, SubHeader receivedSubHeader,
			String[] attributes,HttpSession session) {
		userProfileDataFromMQ.setSubHeader(receivedSubHeader);
		
		
		userProfileDataFromMQ.setUser_id_attr(attributes[0]);
		userProfileDataFromMQ.setUser_id(attributes[1]);
		userProfileDataFromMQ.setName_attr(attributes[2]);
		userProfileDataFromMQ.setName(attributes[3]);
		userProfileDataFromMQ.setTelephone_number_attr(attributes[4]);
		userProfileDataFromMQ.setTelephone_number(FormatUtil.getTelephoneNumberWithDashes(attributes[5]));
		userProfileDataFromMQ.setUser_type_attr(attributes[6]);
		userProfileDataFromMQ.setUser_type(attributes[7]);
		userProfileDataFromMQ.setSubsidiary_attr(attributes[8]);
		userProfileDataFromMQ.setSubsidiary(attributes[9]);
		userProfileDataFromMQ.setTypist_attr(attributes[10]);
		userProfileDataFromMQ.setTypist(attributes[11]);
		userProfileDataFromMQ.setSales_code_attr(attributes[12]);
		userProfileDataFromMQ.setSales_code(attributes[13]);
		userProfileDataFromMQ.setDflt_ims_region_attr(attributes[14]);
		userProfileDataFromMQ.setDflt_ims_region(attributes[15]);
		userProfileDataFromMQ.setStatus_attr(attributes[16]);
		userProfileDataFromMQ.setStatus(attributes[17]);
		userProfileDataFromMQ.setManager_attr(attributes[18]);
		userProfileDataFromMQ.setManager(attributes[19]);
		userProfileDataFromMQ.setArea_manager_attr(attributes[20]);
		userProfileDataFromMQ.setArea_manager(attributes[21]);
		userProfileDataFromMQ.setLast_updt_id(getUserName(attributes[22], session));
		userProfileDataFromMQ.setLast_updt_dttm(attributes[23]);
		userProfileDataFromMQ.setMulti_access_ind_attr(attributes[24]);
		userProfileDataFromMQ.setMulti_access_ind(attributes[25]);
		
	}

	private SubHeader prepareSubHeader() {

		// Prepare SubHeader
		SubHeader subHeader = new SubHeader();

		subHeader.setLast_ind(LastInd.Y.name());
		subHeader.setProcess_mode(ProcessMode.CS_RETRIEVE.getProcessModeCode());
		subHeader.setRecord_type(RecIdFor12State.CS_RECID_USER_PROFILE.getRecIdValue());
		subHeader.setReturn_code(null);
		subHeader.setDw_rownum(null);
		subHeader.setEcver(null);

		return subHeader;
	}

	private Header prepareHeader(String user_id, String object_handle) {
		// Prepare Header
		Header header = new Header();

		header.setUser_id(user_id);
		header.setProcess(Process.CS_USER_PROFILE.getProcessCode());
		header.setTab_ind(null);
		header.setProcess_group_ind(ProcessGroupInd.RETRIEVE_IND.getProcessGroupInd());
		header.setObject_handle(object_handle);
		header.setObject_handle2(null);
		header.setLog_ind(LogInd.N.name());
		header.setStarttime(null);
		header.setEndtime(null);
		header.setGuid(null);
		header.setSession_trans_count("0000001");
		header.setHost_trans_seq(null);
		header.setReturn_code(null);
		header.setRead_only_ind(null);
		header.setNum_detail("0001");
		header.setRead_only_user_id(null);
		header.setLasrversion(null);

		return header;
	}

	private SubHeader prepareSaveSubHeader() {

		// Prepare SubHeader
		SubHeader subHeader = new SubHeader();

		subHeader.setLast_ind(LastInd.Y.name());
		subHeader.setProcess_mode(ProcessMode.CS_ADD.getProcessModeCode());
		subHeader.setRecord_type(RecIdFor12State.CS_RECID_USER_PROFILE.getRecIdValue());
		subHeader.setReturn_code(null);
		subHeader.setDw_rownum(null);
		subHeader.setEcver(null);

		return subHeader;
	}

	private Header prepareSaveHeader(String user_id, String object_handle) {
		// Prepare Header
		Header header = new Header();

		header.setUser_id(user_id);
		header.setProcess(Process.CS_USER_PROFILE.getProcessCode());
		header.setTab_ind(null);
		header.setProcess_group_ind(ProcessGroupInd.SAVE_IND.getProcessGroupInd());
		header.setObject_handle(object_handle);
		header.setObject_handle2(null);
		header.setLog_ind(LogInd.N.name());
		header.setStarttime(null);
		header.setEndtime(null);
		header.setGuid(null);
		header.setSession_trans_count("0000001");
		header.setHost_trans_seq(null);
		header.setReturn_code(null);
		header.setRead_only_ind(null);
		header.setNum_detail("0001");
		header.setRead_only_user_id(null);
		header.setLasrversion(null);

		return header;
	}
	
	public UserProfileData writeSlogoffUserProfileDataToMQ(UserProfileData userProfileData, String user_id, String object_handle,HttpSession session) {

		Header header = prepareLogoffHeader(user_id,object_handle);
		SubHeader subHeader = prepareLogoffSubHeader();

		String dataString = userProfileData.getLogoffUserProfileDataString(); // this is same as logoff string 

		MQMessageStringBuilder mqMessageStringBuilder = new MQMessageStringBuilder().addHeaderSubHeaderAndData(header,
				subHeader, dataString);
		boolean isWritten = mqWriteUtil.writeDataToMQ(mqMessageStringBuilder,session);

		UserProfileData userProfileDataFromMQ = userProfileData;

		if (isWritten) {

			MQReceivedData mqReceivedData=null;
			
			try {

			mqReceivedData = mqReadUtil.readSortDataFromMQ(session); 
			 long endTime = System.nanoTime() + TimeUnit.NANOSECONDS.convert(3L, TimeUnit.MINUTES); 
			  Map<String, SubData> subDatas = mqReceivedData.getSubDatas(); 
		//	  Header receivedHeader = mqReceivedData.getHeader(); 
			  while(mqReceivedData.getHeader()==null&& System.nanoTime() < endTime) { 
					System.out.println("*************inside if*************** "); 
					mqReceivedData =	 mqReadUtil.readSortDataFromMQ(session); 
				} 
			  
			  
			  System.out.println(mqReceivedData.getHeader().toString()); 
		} catch (Exception e) { 
			// TODO Auto-generated catch block 
			// mqReceivedData = mqReadUtil.readDataFromMQ(session); 
			e.printStackTrace(); 


		}
			Map<String, SubData> subDatas = mqReceivedData.getSubDatas();
			Header receivedHeader = mqReceivedData.getHeader();
			userProfileDataFromMQ.setHeader(receivedHeader);

			SubData subData = subDatas.get(RecIdFor12State.CS_RECID_USER_PROFILE.getRecIdValue());
			if (subData != null) {
				SubHeader receivedSubHeader = subData.getSubHeader();

				String[] subDataRows = subData.getSubDataRows();

				String[] attributes = mqReadUtil.getAttributes(subDataRows[0], 26);
				System.out.println("attributes in logoff: " + Arrays.toString(attributes));
			}
		}
		return userProfileData;
	}

	
	private Header prepareLogoffHeader(String user_id, String object_handle) {
		Header header = new Header();

		header.setUser_id(user_id);
		header.setProcess(Process.CS_LOGOFF.getProcessCode());
		header.setTab_ind(null);
		header.setProcess_group_ind(ProcessGroupInd.SPECIAL_IND.getProcessGroupInd());
		header.setObject_handle(object_handle);
		header.setObject_handle2(null);
		header.setLog_ind(LogInd.N.name());
		header.setStarttime(null);
		header.setEndtime(null);
		header.setGuid(null);
		header.setSession_trans_count("0000001");
		header.setHost_trans_seq(null);
		header.setReturn_code(null);
		header.setRead_only_ind(null);
		header.setNum_detail("0001");
		header.setRead_only_user_id(null);
		header.setLasrversion(null);

		return header;
		
	}
	
	private SubHeader prepareLogoffSubHeader() {

		// Prepare SubHeader
		SubHeader subHeader = new SubHeader();

		subHeader.setLast_ind(LastInd.Y.name());
		subHeader.setProcess_mode(ProcessMode.CS_SPECIAL.getProcessModeCode());
		subHeader.setRecord_type(null);
		subHeader.setReturn_code(null);
		subHeader.setDw_rownum(null);
		subHeader.setEcver(null);

		return subHeader;
	}

	public boolean isDataUpdated(UserProfileData saveUserData, UserProfileData retriveUserData) {
		
		if(saveUserData.getManager() == null){ 
			saveUserData.setManager(""); 
		} 
		if(saveUserData.getArea_manager() == null) {
			saveUserData.setArea_manager(""); 
		}
		
		
		if(saveUserData.getName().equals(retriveUserData.getName()) && saveUserData.getTelephone_number().equals(retriveUserData.getTelephone_number()) && saveUserData.getTypist().equals(retriveUserData.getTypist())
			&& saveUserData.getSales_code().equals(retriveUserData.getSales_code()) && saveUserData.getUser_type().equals(retriveUserData.getUser_type()) && saveUserData.getDflt_ims_region().equals(retriveUserData.getDflt_ims_region())
			&& saveUserData.getStatus().equals(retriveUserData.getStatus()) && (saveUserData.getManager().equals(retriveUserData.getManager()) && (saveUserData.getArea_manager().equals(retriveUserData.getArea_manager()))))
		{
				System.out.println("*******data is matching******");
				return false;
		}
		else {
			
				System.out.println("*******data is not matching******");
				return true;
		}
		
	}
	
	/*
	 * public List<ShowError> getErrorList(){ return showError; }
	 */
}
