package com.att.lasr.model;

import com.att.lasr.utils.Constants;
import com.att.lasr.utils.FormatUtil;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@ToString

public class CompletionProviderTask {
	
	
	///for 560
	private String cver;
	private String atn;
	private String rt;
	private String ecver;	
	private String d_t_sent_local; 
	private String response_d_t_sent_central_time; 
	private String comp_dt_attr;
	private String comp_dt; 
	private String company_code_attr;  
	private String company_code;
	private String an; 
	
	public String getCompletionProviderTask560() {
		StringBuilder selectRequestDataSb = new StringBuilder();

		
		selectRequestDataSb.append(FormatUtil.getValueWithSpaces(cver, 4)).append(Constants.TAB);
		
		selectRequestDataSb.append(FormatUtil.getValueWithSpaces(atn, 6)).append(Constants.TAB);


		selectRequestDataSb.append(FormatUtil.getValueWithSpaces(rt, 20)).append(Constants.TAB);
		selectRequestDataSb.append(FormatUtil.getValueWithSpaces(ecver, 1)).append(Constants.TAB);
		selectRequestDataSb.append(FormatUtil.getValueWithSpaces(d_t_sent_local, 6)).append(Constants.TAB);
		selectRequestDataSb.append(FormatUtil.getValueWithSpaces(response_d_t_sent_central_time, 1)).append(Constants.TAB);
		
		selectRequestDataSb.append(FormatUtil.getValueWithSpaces(comp_dt_attr, 1)).append(Constants.TAB);
		selectRequestDataSb.append(FormatUtil.getValueWithSpaces(comp_dt, 1)).append(Constants.TAB);
		selectRequestDataSb.append(FormatUtil.getValueWithSpaces(company_code_attr, 1)).append(Constants.TAB);
		selectRequestDataSb.append(FormatUtil.getValueWithSpaces(company_code, 1)).append(Constants.TAB);
		
		selectRequestDataSb.append(FormatUtil.getValueWithSpaces(an, 1)).append(Constants.TAB).append(Constants.TAB);
		
		String selectRequestDataString = FormatUtil.getValueWithSpaces(selectRequestDataSb.toString(), 2400);
		return selectRequestDataString;
	}
	
	//Hrushi - Completion Provider with Loss
	public String getCompletionWithLoss560String() {
		StringBuilder selectRequestDataSb = new StringBuilder();

		
		selectRequestDataSb.append(FormatUtil.getValueWithSpaces(cver, 2)).append(Constants.TAB);
		
		selectRequestDataSb.append(FormatUtil.getValueWithSpaces(atn, 10)).append(Constants.TAB);


		selectRequestDataSb.append(FormatUtil.getValueWithSpaces(rt, 1)).append(Constants.TAB);
		selectRequestDataSb.append(FormatUtil.getValueWithSpaces(ecver, 3)).append(Constants.TAB);
		selectRequestDataSb.append(FormatUtil.getValueWithSpaces(d_t_sent_local, 13)).append(Constants.TAB);
		selectRequestDataSb.append(FormatUtil.getValueWithSpaces(response_d_t_sent_central_time, 13)).append(Constants.TAB);
		
		selectRequestDataSb.append(FormatUtil.getValueWithSpaces(comp_dt_attr, 1)).append(Constants.TAB);
		selectRequestDataSb.append(FormatUtil.getValueWithSpaces(FormatUtil.getMqDateFormatString(comp_dt), 8)).append(Constants.TAB);
		selectRequestDataSb.append(FormatUtil.getValueWithSpaces(company_code_attr, 1)).append(Constants.TAB);
		selectRequestDataSb.append(FormatUtil.getValueWithSpaces(company_code, 4)).append(Constants.TAB);
		
		selectRequestDataSb.append(FormatUtil.getValueWithSpaces(an, 10).trim()).append(Constants.TAB).append(Constants.TAB);
		
		String selectRequestDataString = FormatUtil.getValueWithSpaces(selectRequestDataSb.toString(), 2400);
		return selectRequestDataString;
	}



}



