/**
 * 
 */
package com.att.lasr.model;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

/**
 * @author mk5650
 *
 */

@Getter
@Setter
@NoArgsConstructor
@ToString
public class LASR_Admin_12States {
	
	private String cver_attr;
	private String cver;
	private String sm;
	private String dt_sent;
	private String adm_sc_attr;
	private String adm_sc;
	private String ddd_attr;
	private String ddd;
	private String apptime_ddd_attr;
	private String apptime_ddd;
	private String resid_attr;
	private String resid;
	private String dfdt_attr;
	private String dfdt;
	private String dddo_attr;
	private String dddo;
	private String dfdto_attr;
	private String dfdto;
	private String chc_attr;
	private String chc;
	private String exp_attr;
	private String exp;
	private String exprsn_attr;
	private String exprsn;
	private String act_attr;
	private String act;
	private String sup_attr;
	private String sup;
	private String tos_attr;
	private String tos;
	private String atn_attr;
	private String atn;
	private String rtr_attr;
	private String rtr;
	private String onsp_attr;
	private String onsp;
	private String nnsp_attr;
	private String nnsp;
	private String nor_attr;
	private String nor;
	private String rpon_attr;
	private String rpon;
	private String rord_attr;
	private String rord;
	private String actl_attr;
	private String actl;
	private String lst_attr;
	private String lst;
	private String spec_attr;
	private String spec;
	private String adm_nc_attr;
	private String adm_nc;
	private String adm_nci_attr;
	private String adm_nci;
	private String secnci_attr;
	private String secnci;
	private String atr_attr;
	private String atr;
	private String nena_ecc_attr;
	private String nena_ecc;
	private String albr_attr;
	private String albr;
	private String project_attr;
	private String project;
	private String agauth_attr;
	private String agauth;
	private String ban1_attr;
	private String ban1;
	private String ban2_attr;
	private String ban2;
	private String ebp_attr;
	private String ebp;
	private String vta_attr;
	private String vta;
	private String init_attr;
	private String init;
	private String tel_no_attr;
	private String tel_no;
	private String fax_no;
	private String impcon_attr;
	private String impcon;
	private String tel1_no_attr;
	private String tel1_no;
	private String drc_attr;
	private String drc;
	private String dsgcon;
	private String tel2_no_attr;
	private String tel2_no;
	private String fax1_no_attr;
	private String fax1_no;
	private String activity;
	private String req_type;
	private String pb_sb_ind;
	private String npdi_attr;
	private String npdi;
	private String scd_attr;
	private String scd;
	private String sli_attr;
	private String sli;
	private String qrynbr_attr;
	private String qrynbr;
	private String sactl_attr;
	private String sactl;
	private String adet_attr;
	private String adet;
	private String an_attr;
	private String an;
	private String ccna_attr;
	private String ccna;
	
	
	
	

}
