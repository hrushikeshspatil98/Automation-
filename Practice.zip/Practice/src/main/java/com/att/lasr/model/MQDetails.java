package com.att.lasr.model;

import org.springframework.stereotype.Component;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@ToString
@Component
public class MQDetails {

	private String queueManager;
	private String queueName;
	private String readQueueName;
	private String channel;
	private Integer port;
	private String hostName;
	private String replyToQueueName;
	private String replyToQueueManagerName;
	private String businessUnit;

}
