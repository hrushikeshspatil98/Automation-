package com.att.lasr.model;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@ToString

public class ErrorCodeData {

	private String lg_code;
	private String field_name;
	private String field_value;
	private String process_mode;
	private String err_failed;

}
