package com.att.lasr.model;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@ToString
public class ExceptionHistoryData12State {

	private String supp;
	private String dttm_exception_msg;
	private String exception_code;
	private String text_msg;

}
