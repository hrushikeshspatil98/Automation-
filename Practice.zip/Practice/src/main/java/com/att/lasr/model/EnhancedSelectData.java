package com.att.lasr.model;

import java.util.ArrayList;
import java.util.List;

import com.att.lasr.utils.Constants;
import com.att.lasr.utils.FormatUtil;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@ToString
public class EnhancedSelectData {

	private Header header;
	private SubHeader subHeader;
	
	private String company_code;
	private String sc;
	private String tns;
	private String ecckt;
	private String ord;
	private String ported_nbr;
	private String ordl;
	private String otn;
	private String npord;
	private String date_received_begin_date;
	private String date_received_end_date;
	private String nc;
	private String nci;
	private String total_record;
	private String start_page;
	private String end_page;
	private String prevnext_cde;
	private String begin_time_nextptr;
	private String end_time_nextptr;
	private String begin_time_prevptr;
	private String end_time_prevptr;
	
	private List<EnhancedSelectTableRow> enhancedSelectTableRows = new ArrayList<>();
	
	public String getEnhancedSelectdataString() {
		StringBuilder enhancedSelectDataSb = new StringBuilder();
		enhancedSelectDataSb.append(FormatUtil.getValueWithSpaces(company_code, 4)).append(Constants.TAB);
		enhancedSelectDataSb.append(FormatUtil.getValueWithSpaces(sc, 2)).append(Constants.TAB);
		enhancedSelectDataSb.append(FormatUtil.getValueWithSpaces(FormatUtil.getStringWithoutDashes(tns), 10))
				.append(Constants.TAB);
		enhancedSelectDataSb.append(FormatUtil.getValueWithSpaces(ecckt, 41)).append(Constants.TAB);
		enhancedSelectDataSb.append(FormatUtil.getValueWithSpaces(ord, 14)).append(Constants.TAB);
		enhancedSelectDataSb.append(FormatUtil.getValueWithSpaces(FormatUtil.getStringWithoutDashes(ported_nbr), 10))
				.append(Constants.TAB);
		enhancedSelectDataSb.append(FormatUtil.getValueWithSpaces(ordl, 11)).append(Constants.TAB);
		enhancedSelectDataSb.append(FormatUtil.getValueWithSpaces(FormatUtil.getStringWithoutDashes(otn), 10)).append(Constants.TAB);
		enhancedSelectDataSb.append(FormatUtil.getValueWithSpaces(npord, 11)).append(Constants.TAB);
		enhancedSelectDataSb
				.append(FormatUtil.getValueWithSpaces(FormatUtil.getMqDateFormatString(date_received_begin_date), 8))
				.append(Constants.TAB);
		enhancedSelectDataSb
				.append(FormatUtil.getValueWithSpaces(FormatUtil.getMqDateFormatString(date_received_end_date), 8))
				.append(Constants.TAB);
		enhancedSelectDataSb.append(FormatUtil.getValueWithSpaces(nc, 4)).append(Constants.TAB);
		enhancedSelectDataSb.append(FormatUtil.getValueWithSpaces(nci, 12)).append(Constants.TAB);
		enhancedSelectDataSb.append(FormatUtil.getValueWithSpaces(total_record, 6)).append(Constants.TAB);
		enhancedSelectDataSb.append(FormatUtil.getValueWithSpaces(start_page, 3)).append(Constants.TAB);
		enhancedSelectDataSb.append(FormatUtil.getValueWithSpaces(end_page, 3)).append(Constants.TAB);
		enhancedSelectDataSb.append(FormatUtil.getValueWithSpaces(prevnext_cde, 1)).append(Constants.TAB);
		enhancedSelectDataSb.append(FormatUtil.getValueWithSpaces(begin_time_nextptr, 26)).append(Constants.TAB);
		enhancedSelectDataSb.append(FormatUtil.getValueWithSpaces(end_time_nextptr, 26)).append(Constants.TAB);
		enhancedSelectDataSb.append(FormatUtil.getValueWithSpaces(begin_time_prevptr, 26)).append(Constants.TAB);
		enhancedSelectDataSb.append(FormatUtil.getValueWithSpaces(end_time_prevptr, 26)).append(Constants.TAB)
				.append(Constants.TAB);

		String enhacedSelectDataString = FormatUtil.getValueWithSpaces(enhancedSelectDataSb.toString(), 2400);
		return enhacedSelectDataString;

	}



	
	

}
