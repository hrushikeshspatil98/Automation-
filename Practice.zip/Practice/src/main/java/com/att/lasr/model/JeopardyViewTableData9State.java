package com.att.lasr.model;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@ToString
public class JeopardyViewTableData9State {
	private String ecver_attr;
	private String ecver;
	private String jep_ecckt_attr;
	private String jep_ecckt;
	private String jep_tns_attr;
	private String jep_tns;
	private String jep_cfa_attr;
	private String jep_cfa;
	private String jep_ccea_attr;
	private String jep_ccea;
	private String cbcid_attr;
	private String cbcid;
	private String cableid_attr;
	private String cableid;
	private String chan_pair_attr;
	private String chan_pair;
	private String apptime_attr;
	private String apptime;
	private String clec_note_attr;
	private String clec_note;

}
