package com.att.lasr.controller; 
 
import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.List;
import javax.servlet.http.HttpSession; 
 
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller; 
import org.springframework.ui.ModelMap; 
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping; 
import org.springframework.web.bind.annotation.RequestMethod; 
import org.springframework.web.bind.annotation.RequestParam; 
import org.springframework.web.bind.annotation.SessionAttributes; 

import com.att.lasr.model.ConfirmedByEsddData;
import com.att.lasr.model.CorelationId;
import com.att.lasr.model.EnhancedSelectData;
import com.att.lasr.model.EnvRegion;
import com.att.lasr.model.FupRequestData;
import com.att.lasr.model.IssueProviderData;
import com.att.lasr.model.Login;
import com.att.lasr.model.LossData;
import com.att.lasr.model.MQDetails;
import com.att.lasr.model.RestrictedMismatchData12states;
import com.att.lasr.model.SelectProviderData;
import com.att.lasr.model.SelectRequestData;
import com.att.lasr.model.UnrestrictedMismatchData12states;
import com.att.lasr.model.UserProfileData;
import com.att.lasr.model.WorkloadData;
import com.att.lasr.service.LoginService;
import com.att.lasr.utils.MQReadUtil;
import com.att.lasr.utils.MQWriteUtil;
import com.att.lasr.utils.MockDtoDataUtil;
 
@Controller 
 
@SessionAttributes("region") 
public class EnvRegionController { 
 
	@Autowired 
	HttpSession httpSession; 

	
	@Autowired
	public SecureController secureCtrl;
	
	@Autowired 
	private LoginService loginService;
	
	 
	@Autowired
	MQReadUtil mqReadUtil;
	
	@Autowired
	MQWriteUtil mqWriteUtil;
	
		@Value("${ENVIRONMENT}")
		private String environmentToSelect;
	
	 EnvRegion envregion = new EnvRegion(); 
	 //static EnvRegion envregion2= new EnvRegion(); 
	
//	public String myRegion;
//	public String myEnvi;
//	public String myStateType;
	 
	//public static Login loginObject = new Login(); 
	//public static CorelationId corelationId = new CorelationId(); 
 
//	EnvRegion  envregionobj; 
	@RequestMapping(value = "/envRegion", method = RequestMethod.GET)
	public String showEnvRegionPage(ModelMap model, HttpSession session) {
		System.out.println("User Id in ENV GET"+ httpSession.getAttribute("activeUser"));
		resetDataObjectStorage( session);
		System.out.println("session_id->"+session.getId());
		System.out.println("environment from app config->"+environmentToSelect);
		// NPRD env Development/Test  all dev+alltest+all clec
//		CLEC env CLEC  all dev+alltest+all clec
//		MAT/PRODUCTION env Production  all dev+alltest
		// update app config ENVIRONMENT as DevelopmentTest   CLEC   Production as needed
		session.setAttribute("deployedEnv", environmentToSelect);	

		// Yash changes 
		String attuid =null;
		Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
		if(authentication != null){
		attuid = authentication.getName();
		}
		
		
		 //String activeUser = (String) session.getAttribute("activeUser");
		session.setAttribute("activeUser", attuid);
		model.addAttribute("activeUser", attuid);
		
		CorelationId corelation = new CorelationId();		 
		
		
		byte[] corId= getCorelationIfFromSession(session);
		
		if(corId == null) {
			corelation.setCorelationID(genearteRandom());
			corId= corelation.getCorelationID();
			session.setAttribute("corelationIdSession", corId);
			httpSession.setAttribute("corelationIdSession", corId);
		}
			
		System.out.println("in /envRegion get userId->"+attuid+"sessionId-->"+session.getId()+"corId->"+corId);
		
		
		return "envRegion";
	}
	
	public byte[] getCorelationIfFromSession(HttpSession session) {
//		 byte[] cor= new CorelationId();
			
			
		 byte[] corId=(byte[]) session.getAttribute("corelationIdSession");
			if( corId == null) {
				corId=(byte[]) httpSession.getAttribute("corelationIdSession");
			}
		
		return corId;
			
	}
	
	
	
	@RequestMapping(value = "/envRegion", method = RequestMethod.POST) 
	public String redirectToWelcomePage(ModelMap model, @RequestParam String environment, @RequestParam String region, 
			HttpSession session) { 
		System.out.println("environment in /enRegion post"+environment+"region"+region);
		/* 
		 * boolean isValidEnvRegion = envRegionService.validateEnvRegion(environment, 
		 * region); if (!isValidEnvRegion) { model.put("errorMessage", 
		 * "Invalid Environment Region Selected"); return "envRegion"; } 
		 * model.put("environment", environment); model.put("region", region); 
		 */ 
		String activeUser = (String) session.getAttribute("activeUser"); 
		session.setAttribute("activeUser", activeUser); 
		System.out.println("active user: "+activeUser);
		session.setAttribute("environment", environment); 
		System.out.println("environment: "+environment);
		model.put("region", region); 
		return "redirect:/home"; 
	} 
 
	@RequestMapping(value = "/stateDiv", method = RequestMethod.GET) 
	public String routeToStateDiv(ModelMap model, HttpSession session) {
		System.out.println("in statediv get ");

		resetDataObjectStorage(session);
		String activeUser = (String) session.getAttribute("activeUser");
		
		if(activeUser ==null) {
			activeUser=(String) httpSession.getAttribute("activeUser");
			if(activeUser== null) {
				activeUser=secureCtrl.myUserName;
			}
		}
		session.setAttribute("activeUser", activeUser.toUpperCase());
		EnvRegion envr= new EnvRegion();
		envr= getEnvRegion(session);
		String environment = envr.getEnvironment();
		
		
		//envregion2.setEnvironment(envregion2.getEnvironment());
		//envregion2.setRegion(envregion2.getRegion()); 
		model.addAttribute("envregion", envr); 
		String e = envr.getRegion();
		
		if(e==null) {
			System.out.println("Inside second if of statediv get");
			e= (String) session.getAttribute("envregion");
		}
		model.addAttribute("indicator",false)	;
		model.addAttribute("indicator1",false)	;
		model.addAttribute("indicator2",false)	;
		model.addAttribute("indicator3",false)	;
		model.addAttribute("indicator4",false) ;
		System.out.println("Redirecting to welcome page through /stateDiv GET req"+activeUser+":"+environment);
		System.out.println("active user: "+activeUser);
		//System.out.println("envRegion in home: "+envregion2);
		model.addAttribute("activeUser", activeUser); 
		model.addAttribute("environment", environment); 
		model.addAttribute("envregion", envr) ;
		return "welcome"; 
	} 
	
	@RequestMapping(value = "/home", method = RequestMethod.GET) 
	public String showWelcomePage(ModelMap model, HttpSession session) { 
		System.out.println("in /home get ");

		
		String activeUser = (String) session.getAttribute("activeUser"); 
		String environment = (String) session.getAttribute("environment");
		System.out.println("active user: "+activeUser);
		System.out.println("environment: "+environment);
		model.addAttribute("activeUser", activeUser); 
		model.addAttribute("environment", environment); 
		//WorkloadController.navbarArr.clear();
		System.out.println("NavbarArr is cleared..Tabs set to 0");
		return "welcome"; 
	} 
	
	@RequestMapping(value = "/stateDiv", method = RequestMethod.POST) 
	public String handleform(@ModelAttribute EnvRegion envregion, @ModelAttribute Login login,// final RedirectAttributes redirectAttributes, 
			ModelMap model,HttpSession session) { 

		System.out.println("in statediv post ");
		session.setAttribute("manRejButton", "none");
		
		//secureCtrl.clearSessionStorage(session);
		httpSession.setAttribute("envregion", envregion.getRegion()); 
		 System.out.println("envregion from session in /state div-->"+httpSession.getAttribute("envregion"));
		System.out.println("login data : " + login.toString()); 
		String myUserId=login.getUser_id();
		String attuid =null; 
		Authentication authentication = SecurityContextHolder.getContext().getAuthentication(); 
		if(authentication != null){ 
		attuid = authentication.getName(); 
		} 
		if(!attuid.equals("anonymousUser")) {
			myUserId=attuid; 
		} 
		System.out.println("***********************"+attuid+"**********");
		if(myUserId == null) {
			myUserId = (String) httpSession.getAttribute("activeUser");
			if(myUserId ==null) {
				myUserId=secureCtrl.myUserName;

			}
			
		}
		myUserId=myUserId.toUpperCase();
		login.setUser_id(myUserId);
		session.setAttribute("activeUser", myUserId);
		session.setAttribute("userId", myUserId);
		 
		//envregion2.setEnvironment(envregion.getEnvironment());; 
		//envregion2.setRegion(envregion.getRegion()); 
		
		model.addAttribute("envregion", envregion) ;
		model.addAttribute("indicator",false)	;
		model.addAttribute("indicator1",false)	;
		model.addAttribute("indicator2",false)	;
		model.addAttribute("indicator3",false)	;
		model.addAttribute("indicator4",false) ;
		
		if ((envregion.getRegion().equals("MW Production")) || (envregion.getRegion().equals("SW Production")) 
				|| (envregion.getRegion().equals("W Production")) 
				|| (envregion.getRegion().equals("A0 - 12 states Dev")) 
				|| (envregion.getRegion().equals("AA - 12 states Dev")) 
				|| (envregion.getRegion().equals("B1 - 12 states Dev")) 
				|| (envregion.getRegion().equals("T1 - MW Clec Test")) 
				|| (envregion.getRegion().equals("T2 - MW prod mirror")) 
				|| (envregion.getRegion().equals("T3 - MW System Test")) 
				|| (envregion.getRegion().equals("P1 - W Clec Test")) 
				|| (envregion.getRegion().equals("P2 - W prod mirror")) 
				|| (envregion.getRegion().equals("P3 - W System Test")) 
				|| (envregion.getRegion().equals("A2 - SW Clec Test")) 
				|| (envregion.getRegion().equals("AH - SW prod mirror")) 
				|| (envregion.getRegion().equals("A5 - SW System Test"))) { 
			envregion.setStateType("12 States"); 
			session.setAttribute("myReg", "12 States");
			
		} else {
			envregion.setStateType("9 States"); 
			session.setAttribute("myReg", "9 States");
		}
		//envregion2.setStateType(envregion.getStateType()); 
		
		httpSession.setAttribute("environmentRegion", envregion);
		session.setAttribute("environmentRegion", envregion);
		httpSession.setAttribute("envregion", envregion.getRegion());
		session.setAttribute("envregion", envregion.getRegion()); 
		System.out.println("environment in /statediv post"+envregion.getEnvironment()+"region"+envregion.getRegion()+"stateType"+envregion.getStateType());
		session.setAttribute("environment1", envregion.getEnvironment());
		 MQDetails mqDetLogin= mqWriteUtil.getMQDetails( envregion.getRegion(),  session);
		 Login loginObject = new Login();
		 Login loginWithMQData = loginService.writeLoginToMQ(login,session); 
		model.addAttribute("login", loginWithMQData); 
		loginObject = loginWithMQData;
		
		 session.setAttribute("loginObject", loginObject);
		 httpSession.setAttribute("loginObject", loginObject);
		 System.out.println("session_id in /statediv post->"+session.getId());
		String returnCode=mqReadUtil.getReturncode(session);
		
		if(returnCode == null || returnCode == "555") {

			//System.out.println("insideif " + returnCode );
			session.removeAttribute("return_code");
			model.addAttribute("msg" , "Data Not Retrieved from MQ,Please try Again");
			model.addAttribute("msg1" , "/OneLASRGUI/envRegion");

			return "envRegion";
			}
		else if(returnCode.equals("999")) {
			

			System.out.println("insideif " +returnCode );
			model.addAttribute("msg" , "Select another region. Your User ID does not provide access to the selected region.");
			model.addAttribute("msg1" , "/OneLASRGUI/envRegion");

			return "envRegion";
			}
			else if(returnCode.equals("888")) {

			System.out.println("insideif " + returnCode );
			model.addAttribute("msg" , "888 Return Code");
			model.addAttribute("msg1" , "/OneLASRGUI/envRegion");

			return "envRegion";
			}

			else if(returnCode.equals("887")) {

			System.out.println("insideif " + returnCode );
			model.addAttribute("msg" , "887 Return Code");
			model.addAttribute("msg1" , "/OneLASRGUI/envRegion");

			return "envRegion";
			}

			else if(returnCode.equals("889")) {

			System.out.println("insideif " +returnCode );
			model.addAttribute("msg" , "889 Return Code");
			model.addAttribute("msg1" , "/OneLASRGUI/envRegion");

			return "envRegion";
			}else {
			return "welcome";
			}
		
//		return "welcome"; 
	} 
	
	public EnvRegion getEnvRegion(HttpSession session) {
		EnvRegion envRegion = new EnvRegion();
		envRegion=(EnvRegion) session.getAttribute("environmentRegion");
		
		if(envRegion == null) {
			envRegion=(EnvRegion) httpSession.getAttribute("environmentRegion");
		}
		return envRegion;
	}
	
//	public static Login getLoginObject() { 
//		return loginObject; 
//		} 
	
	public Login getLoginObjectFromSession(HttpSession session) {
		Login loginObj= new Login();
		loginObj=(Login) session.getAttribute("loginObject");
			if(loginObj == null) {
				loginObj=(Login) httpSession.getAttribute("loginObject");
			}
		
		return loginObj;

	}

	public String getUserIdFromSession(HttpSession session) {
		String userId= (String) session.getAttribute("activeUser");
			if(userId == null) {
				userId= (String) httpSession.getAttribute("activeUser");
			}
			
		if(userId != null) {
			userId=userId.toUpperCase();
		}
		return userId;
	}
	
//	public static CorelationId getCorelationobj() { 
//		return corelationId; 
//	} 
	public static byte[] genearteRandom(){ 
		byte[] corId = new byte[24]; 
		SecureRandom random = new SecureRandom();  // Vuln Fix - changed Random to SecureRandom
		for (int i = 0; i < 24; i++) { 
		int rand = 0; 
		while (true) { 
		rand = 1+random.nextInt(9); 
		if (rand != 0) 
		break; 
		} 
		corId[i] = (byte) rand; 
		} 
		return corId; 
		} 
 
	private void resetDataObjectStorage(HttpSession session) {
		List<String> navbarArr = new ArrayList<String>();
		session.setAttribute("navBarArr", navbarArr);
		
		List<String> lsrNoArr = new ArrayList<String>();
		session.setAttribute("lsrNoArr", lsrNoArr);
		
		List<Object> treeViewObjectList= new ArrayList<Object>();
		session.setAttribute("treeViewObjects", treeViewObjectList);
		
		List<WorkloadData> workloadDatalist = new ArrayList<WorkloadData>();
		WorkloadData workloadDto0 = MockDtoDataUtil.getWorkloadMockData();
		WorkloadData workloadDto1 = MockDtoDataUtil.getWorkloadMockData();
		WorkloadData workloadDto2 = MockDtoDataUtil.getWorkloadMockData();
		WorkloadData workloadDto3 = MockDtoDataUtil.getWorkloadMockData();
		WorkloadData workloadDto4 = MockDtoDataUtil.getWorkloadMockData();
		workloadDatalist.add(workloadDto0);
		workloadDatalist.add(workloadDto1);
		workloadDatalist.add(workloadDto2);
		workloadDatalist.add(workloadDto3);
		workloadDatalist.add(workloadDto4);
		session.setAttribute("workloadDataList", workloadDatalist);
		
		List<SelectRequestData> selectRequestDatalist = new ArrayList<SelectRequestData>();
		SelectRequestData selectRequestDto0 = MockDtoDataUtil.getSelectRequestMockDtoData();
		SelectRequestData selectRequestDto1 = MockDtoDataUtil.getSelectRequestMockDtoData();
		SelectRequestData selectRequestDto2 = MockDtoDataUtil.getSelectRequestMockDtoData();
		SelectRequestData selectRequestDto3 = MockDtoDataUtil.getSelectRequestMockDtoData();
		SelectRequestData selectRequestDto4 = MockDtoDataUtil.getSelectRequestMockDtoData();
		selectRequestDatalist.add(selectRequestDto0);
		selectRequestDatalist.add(selectRequestDto1);
		selectRequestDatalist.add(selectRequestDto2);
		selectRequestDatalist.add(selectRequestDto3);
		selectRequestDatalist.add(selectRequestDto4);
		session.setAttribute("selectRequestDatalist", selectRequestDatalist);

		List<EnhancedSelectData> enhancedSelectDatalist = new ArrayList<EnhancedSelectData>();
		EnhancedSelectData enhancedRequestDto0 = new EnhancedSelectData();
		EnhancedSelectData enhancedRequestDto1 = new EnhancedSelectData();
		EnhancedSelectData enhancedRequestDto2 = new EnhancedSelectData();
		EnhancedSelectData enhancedRequestDto3 = new EnhancedSelectData();
		EnhancedSelectData enhancedRequestDto4 = new EnhancedSelectData();
		enhancedSelectDatalist.add(enhancedRequestDto0);
		enhancedSelectDatalist.add(enhancedRequestDto1);
		enhancedSelectDatalist.add(enhancedRequestDto2);
		enhancedSelectDatalist.add(enhancedRequestDto3);
		enhancedSelectDatalist.add(enhancedRequestDto4);
		session.setAttribute("enhancedSelectDatalist", enhancedSelectDatalist);
		

		List<RestrictedMismatchData12states> restrictedMismatchDatalist = new ArrayList<RestrictedMismatchData12states>();
		RestrictedMismatchData12states restrictedMismatchDto0 = MockDtoDataUtil.getRestrictedMismatchkMockData();
		RestrictedMismatchData12states restrictedMismatchDto1 = MockDtoDataUtil.getRestrictedMismatchkMockData();
		RestrictedMismatchData12states restrictedMismatchDto2 = MockDtoDataUtil.getRestrictedMismatchkMockData();
		RestrictedMismatchData12states restrictedMismatchDto3 = MockDtoDataUtil.getRestrictedMismatchkMockData();
		RestrictedMismatchData12states restrictedMismatchDto4 = MockDtoDataUtil.getRestrictedMismatchkMockData();
		restrictedMismatchDatalist.add(restrictedMismatchDto0);
		restrictedMismatchDatalist.add(restrictedMismatchDto1);
		restrictedMismatchDatalist.add(restrictedMismatchDto2);
		restrictedMismatchDatalist.add(restrictedMismatchDto3);
		restrictedMismatchDatalist.add(restrictedMismatchDto4);
		session.setAttribute("restrictedMismatchDatalist", restrictedMismatchDatalist);

		

		List<IssueProviderData> issueProviderDatalist = new ArrayList<IssueProviderData>();
		IssueProviderData issueProviderDto0 = MockDtoDataUtil.getIssueProviderMockData();
		IssueProviderData issueProviderDto1 = MockDtoDataUtil.getIssueProviderMockData();
		IssueProviderData issueProviderDto2 = MockDtoDataUtil.getIssueProviderMockData();
		IssueProviderData issueProviderDto3 = MockDtoDataUtil.getIssueProviderMockData();
		IssueProviderData issueProviderDto4 = MockDtoDataUtil.getIssueProviderMockData();
		issueProviderDatalist.add(issueProviderDto0);
		issueProviderDatalist.add(issueProviderDto1);
		issueProviderDatalist.add(issueProviderDto2);
		issueProviderDatalist.add(issueProviderDto3);
		issueProviderDatalist.add(issueProviderDto4);
		session.setAttribute("issueProviderDatalist", issueProviderDatalist);
		
		
		
		List<UserProfileData> userProfileDatalist = new ArrayList<UserProfileData>();
		UserProfileData userProfileDto0 = MockDtoDataUtil.getUserProfileMockData();
		UserProfileData userProfileDto1 = MockDtoDataUtil.getUserProfileMockData();
		UserProfileData userProfileDto2 = MockDtoDataUtil.getUserProfileMockData();
		UserProfileData userProfileDto3 = MockDtoDataUtil.getUserProfileMockData();
		UserProfileData userProfileDto4 = MockDtoDataUtil.getUserProfileMockData();
		userProfileDatalist.add(userProfileDto0);
		userProfileDatalist.add(userProfileDto1);
		userProfileDatalist.add(userProfileDto2);
		userProfileDatalist.add(userProfileDto3);
		userProfileDatalist.add(userProfileDto4);
		session.setAttribute("userProfileDatalist", userProfileDatalist);
	
		
		List<LossData> lossDatalist = new ArrayList<LossData>();
		LossData lossDto0 = MockDtoDataUtil.getLossData();
		LossData lossDto1 = MockDtoDataUtil.getLossData();
		LossData lossDto2 = MockDtoDataUtil.getLossData();
		LossData lossDto3 = MockDtoDataUtil.getLossData();
		LossData lossDto4 = MockDtoDataUtil.getLossData();
		lossDatalist.add(lossDto0);
		lossDatalist.add(lossDto1);
		lossDatalist.add(lossDto2);
		lossDatalist.add(lossDto3);
		lossDatalist.add(lossDto4);
		session.setAttribute("lossDatalist", lossDatalist);

		

		List<ConfirmedByEsddData> confirmedByEsddDatalist = new ArrayList<ConfirmedByEsddData>();
		ConfirmedByEsddData confirmedByDto0 = new ConfirmedByEsddData();
		ConfirmedByEsddData confirmedByDto1 = new ConfirmedByEsddData();
		ConfirmedByEsddData confirmedByDto2 = new ConfirmedByEsddData();
		ConfirmedByEsddData confirmedByDto3 = new ConfirmedByEsddData();
		ConfirmedByEsddData confirmedByDto4 = new ConfirmedByEsddData();
		confirmedByEsddDatalist.add(confirmedByDto0);
		confirmedByEsddDatalist.add(confirmedByDto1);
		confirmedByEsddDatalist.add(confirmedByDto2);
		confirmedByEsddDatalist.add(confirmedByDto3);
		confirmedByEsddDatalist.add(confirmedByDto4);
		session.setAttribute("confirmedByEsddDatalist", confirmedByEsddDatalist);

		List<FupRequestData> fupRequestDatalist = new ArrayList<FupRequestData>();
		FupRequestData fupRequestDto0 = MockDtoDataUtil.getFupRequestDtoData();
		FupRequestData fupRequestDto1 = MockDtoDataUtil.getFupRequestDtoData();
		FupRequestData fupRequestDto2 = MockDtoDataUtil.getFupRequestDtoData();
		FupRequestData fupRequestDto3 = MockDtoDataUtil.getFupRequestDtoData();
		FupRequestData fupRequestDto4 = MockDtoDataUtil.getFupRequestDtoData();
		fupRequestDatalist.add(fupRequestDto0);
		fupRequestDatalist.add(fupRequestDto1);
		fupRequestDatalist.add(fupRequestDto2);
		fupRequestDatalist.add(fupRequestDto3);
		fupRequestDatalist.add(fupRequestDto4);
		session.setAttribute("fupRequestDatalist", fupRequestDatalist);

		List<UnrestrictedMismatchData12states> unrestrictedMismatchDatalist = new ArrayList<UnrestrictedMismatchData12states>();
		UnrestrictedMismatchData12states unrestrictedMismatchDto0 = MockDtoDataUtil.getUnrestrictedMismatchMockData();
		UnrestrictedMismatchData12states unrestrictedMismatchDto1 = MockDtoDataUtil.getUnrestrictedMismatchMockData();
		UnrestrictedMismatchData12states unrestrictedMismatchDto2 = MockDtoDataUtil.getUnrestrictedMismatchMockData();
		UnrestrictedMismatchData12states unrestrictedMismatchDto3 = MockDtoDataUtil.getUnrestrictedMismatchMockData();
		UnrestrictedMismatchData12states unrestrictedMismatchDto4 = MockDtoDataUtil.getUnrestrictedMismatchMockData();
		unrestrictedMismatchDatalist.add(unrestrictedMismatchDto0);
		unrestrictedMismatchDatalist.add(unrestrictedMismatchDto1);
		unrestrictedMismatchDatalist.add(unrestrictedMismatchDto2);
		unrestrictedMismatchDatalist.add(unrestrictedMismatchDto3);
		unrestrictedMismatchDatalist.add(unrestrictedMismatchDto4);
		session.setAttribute("unrestrictedMismatchDatalist", unrestrictedMismatchDatalist);

		List<SelectProviderData> selectProviderDatalist = new ArrayList<SelectProviderData>();
		SelectProviderData selectProviderDto0 = MockDtoDataUtil.getSelectProviderMockData();
		SelectProviderData selectProviderDto1 = MockDtoDataUtil.getSelectProviderMockData();
		SelectProviderData selectProviderDto2 = MockDtoDataUtil.getSelectProviderMockData();
		SelectProviderData selectProviderDto3 = MockDtoDataUtil.getSelectProviderMockData();
		SelectProviderData selectProviderDto4 = MockDtoDataUtil.getSelectProviderMockData();
		selectProviderDatalist.add(selectProviderDto0);
		selectProviderDatalist.add(selectProviderDto1);
		selectProviderDatalist.add(selectProviderDto2);
		selectProviderDatalist.add(selectProviderDto3);
		selectProviderDatalist.add(selectProviderDto4);
		session.setAttribute("selectProviderDatalist", selectProviderDatalist);

		session.setAttribute("CurrentTab", "NA");
		session.setAttribute("previousTab", "NA");
		session.setAttribute("inputFormData", "NA");
		session.setAttribute("fetchedFormData", "NA");
		session.setAttribute("previousPageIndex", "-1");
		session.setAttribute("curentPageFromFrontend", "NA");
		session.setAttribute("currentPageIndex", "0");
		session.setAttribute("maxNoPage", "-1");
		session.setAttribute("objectHandle", "1");
	}

 
}