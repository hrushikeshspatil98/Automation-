package com.att.lasr.utils.enums;

public enum ReadOnlyInd {
	Y, N
}