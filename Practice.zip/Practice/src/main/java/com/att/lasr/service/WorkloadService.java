package com.att.lasr.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.att.lasr.model.WorkloadTableRow;
import com.att.lasr.utils.MQMessageStringBuilder;
import com.att.lasr.utils.MQReadUtil;
import com.att.lasr.utils.MQWriteUtil;
import com.att.lasr.utils.enums.LastInd;
import com.att.lasr.utils.enums.LogInd;
import com.att.lasr.utils.enums.Process;
import com.att.lasr.utils.enums.ProcessGroupInd;
import com.att.lasr.utils.enums.ProcessMode;
import com.att.lasr.utils.enums.RecIdFor12State;
import com.att.lasr.model.WorkloadData;
import com.att.lasr.model.Header;
import com.att.lasr.model.MQReceivedData;
import com.att.lasr.model.SubData;
import com.att.lasr.model.SubHeader;

@Service
public class WorkloadService {

	@Autowired
	private MQReadUtil mqReadUtil;

	@Autowired
	private MQWriteUtil mqWriteUtil;

	public WorkloadData writeWorkloadDataToMQ(WorkloadData workloadData, String user_id, String object_handle,HttpSession session) {

		Header header = prepareHeader(user_id,object_handle);
		SubHeader subHeader = prepareSubHeader();

		// Customize WorkloadData
		workloadData.setPrevnext_cde("R");

		String dataString = workloadData.getWorkloadDataString();

		MQMessageStringBuilder mqMessageStringBuilder = new MQMessageStringBuilder().addHeaderSubHeaderAndData(header,
				subHeader, dataString);

		boolean isWritten = mqWriteUtil.writeDataToMQ(mqMessageStringBuilder,session);

		WorkloadData workloadDataFromMQ = workloadData;

		if (isWritten) {

			MQReceivedData mqReceivedData=null;
			
			try {

			mqReceivedData = mqReadUtil.readSortDataFromMQ(session); 
			 long endTime = System.nanoTime() + TimeUnit.NANOSECONDS.convert(3L, TimeUnit.MINUTES); 
			  Map<String, SubData> subDatas = mqReceivedData.getSubDatas(); 
		//	  Header receivedHeader = mqReceivedData.getHeader(); 
			  while(mqReceivedData.getHeader()==null&& System.nanoTime() < endTime) { 
					System.out.println("*************inside if*************** "); 
					mqReceivedData =	 mqReadUtil.readSortDataFromMQ(session); 
				} 
			  
			  
			  System.out.println(mqReceivedData.getHeader().toString()); 
		} catch (Exception e) { 
			// TODO Auto-generated catch block 
			// mqReceivedData = mqReadUtil.readDataFromMQ(session); 
			e.printStackTrace(); 


		}
			Map<String, SubData> subDatas = mqReceivedData.getSubDatas();
			Header receivedHeader = mqReceivedData.getHeader();
			workloadDataFromMQ.setHeader(receivedHeader);

			SubData subData = subDatas.get(RecIdFor12State.CS_RECID_WORKLOAD.getRecIdValue());
			if (subData != null) {
				SubHeader receivedSubHeader = subData.getSubHeader();

				String[] subDataRows = subData.getSubDataRows();

				List<WorkloadTableRow> workloadTableRows = new ArrayList<>();

				for (String subDataRow : subDataRows) {
					String[] attributes = mqReadUtil.getAttributes(subDataRow, 28);
//					System.out.println("attributes: " + Arrays.toString(attributes));
					WorkloadTableRow workloadTableRow = new WorkloadTableRow();

					workloadTableRow.setStatus(attributes[0]);
					workloadTableRow.setDate_time_received(attributes[1]);
					workloadTableRow.setCompany_code(attributes[2]);
					workloadTableRow.setExpedite(attributes[3]);
					workloadTableRow.setDdd(attributes[4]);
					workloadTableRow.setRequest_id(attributes[5]);
					workloadTableRow.setPon(attributes[6]);
					workloadTableRow.setRequest_type(attributes[7]);
					workloadTableRow.setTos(attributes[8]);
					workloadTableRow.setActivity(attributes[9]);
					workloadTableRow.setQuantity(attributes[10]);
					workloadTableRow.setSupplement_type(attributes[11]);
					workloadTableRow.setAssigned_user_id_attr(attributes[12]);
					workloadTableRow.setAssigned_user_id(attributes[13]);
					workloadTableRow.setRpon(attributes[14]);
					workloadTableRow.setJep_ind(attributes[15]);
					workloadTableRow.setAging_ind_attc(attributes[16]);
					workloadTableRow.setAging_ind(attributes[17]);
					workloadTableRow.setCoor_hot_cut(attributes[18]);
					workloadTableRow.setPre_assign_user_id(attributes[19]);
					workloadTableRow.setRelease_version(attributes[20]);
					workloadTableRow.setTotal_record(attributes[21]);
					workloadTableRow.setStart_page(attributes[22]);
					workloadTableRow.setEnd_page(attributes[23]);
					workloadTableRow.setBegin_time_nextptr(attributes[24]);
					workloadTableRow.setEnd_time_nextptr(attributes[25]);
					workloadTableRow.setBegin_time_prevptr(attributes[26]);
					workloadTableRow.setEnd_time_prevptr(attributes[27]);

					workloadTableRows.add(workloadTableRow);
				}
				workloadDataFromMQ.setSubHeader(receivedSubHeader);
				workloadDataFromMQ.setWorkloadTableRows(workloadTableRows);
				System.out.println("workloadDataFromMQ.getWorkloadTableRows().size()"+workloadDataFromMQ.getWorkloadTableRows().size());
			}
		}
		return workloadDataFromMQ;

	}

	private SubHeader prepareSubHeader() {

		// Prepare SubHeader
		SubHeader subHeader = new SubHeader();

		subHeader.setLast_ind(LastInd.Y.name());
		subHeader.setProcess_mode(ProcessMode.CS_RETRIEVE.getProcessModeCode());
		subHeader.setRecord_type(RecIdFor12State.CS_RECID_WORKLOAD.getRecIdValue());
		subHeader.setReturn_code(null);
		subHeader.setDw_rownum(null);
		subHeader.setEcver(null);

		return subHeader;
	}

	private Header prepareHeader(String user_id, String object_handle) {
		// Prepare Header
		Header header = new Header();

		header.setUser_id(user_id);
		header.setProcess(Process.CS_WORKLOAD.getProcessCode());
		header.setTab_ind(null);
		header.setProcess_group_ind(ProcessGroupInd.RETRIEVE_IND.getProcessGroupInd());
		header.setObject_handle(object_handle);
		header.setObject_handle2(null);
		header.setLog_ind(LogInd.N.name());
		header.setStarttime(null);
		header.setEndtime(null);
		header.setGuid(null);
		header.setSession_trans_count("0000001");
		header.setHost_trans_seq(null);
		header.setReturn_code(null);
		header.setRead_only_ind(null);
		header.setNum_detail("0001");
		header.setRead_only_user_id(null);
		header.setLasrversion(null);

		return header;
	}
}
