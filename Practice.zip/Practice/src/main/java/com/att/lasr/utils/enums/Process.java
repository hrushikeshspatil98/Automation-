package com.att.lasr.utils.enums;

public enum Process {
	CS_NOSERVERPROG("NOSRV"), CS_LOGON("LGN"), CS_LOGOFF("LGF"), CS_USER_PROFILE("UPR"), CS_SELECT_REQUEST("SRO"),
	CS_SELECT_CONFIRM("SRC"), CS_SELECT_REQUEST_ENH("SRE"), CS_SELREQ_FUP("SRF"), CS_SELECT_JEPS("SEJ"),
	CS_SELECT_LOSS("LOS"), CS_ISSUE_PROVIDER("LOS"), CS_SELECT_PROVIDER("PRV"), CS_SELECT_MISMATCH("SEM"),
	CS_REQUEST("REQ"), CS_WORKLOAD("WKL"), CS_CLOSE_REQUEST("CLS"), CS_JEOPARDY("JPD"), CS_SELECT_ARCHIVE("SRA"), CS_SELECT_REF("REF");

	private final String processCode;

	Process(String processCode) {
		this.processCode = processCode;
	}

	public String getProcessCode() {
		return this.processCode;
	}

}