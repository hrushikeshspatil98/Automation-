package com.att.lasr.model;

import com.att.lasr.utils.Constants;
import com.att.lasr.utils.FormatUtil;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@ToString
public class JeopardyTask12STRechId583 {

	private String ecver_attr;
	private String ecver;
	private String jep_ecckt_attr;
	private String jep_ecckt;
	private String jep_tns_attr;
	private String jep_tns;
	private String jep_cfa_attr;
	private String jep_cfa;
	private String jep_ccea_attr;
	private String jep_ccea;
	private String cbcid_attr;
	private String cbcid;
	private String cableid_attr;
	private String cableid;
	private String chan_pair_attr;
	private String chan_pair;
	private String apptime_attr;
	private String apptime;
	private String clec_note_attr;
	private String clec_note;
	
	public String getJeopardyTask12STRechId583String() {
		StringBuilder selectRequestDataSb = new StringBuilder();

		
		selectRequestDataSb.append(FormatUtil.getValueWithSpaces(ecver_attr, 1)).append(Constants.TAB);
		selectRequestDataSb.append(FormatUtil.getValueWithSpaces(ecver, 4)).append(Constants.TAB);
		selectRequestDataSb.append(FormatUtil.getValueWithSpaces(jep_ecckt_attr, 1)).append(Constants.TAB);
		selectRequestDataSb.append(FormatUtil.getValueWithSpaces(jep_ecckt, 46)).append(Constants.TAB);
		selectRequestDataSb.append(FormatUtil.getValueWithSpaces(jep_tns_attr, 1)).append(Constants.TAB);
		selectRequestDataSb.append(FormatUtil.getValueWithSpaces(jep_tns, 10)).append(Constants.TAB);
		selectRequestDataSb.append(FormatUtil.getValueWithSpaces(jep_cfa_attr, 1)).append(Constants.TAB);
		selectRequestDataSb.append(FormatUtil.getValueWithSpaces(jep_cfa, 42)).append(Constants.TAB);
		selectRequestDataSb.append(FormatUtil.getValueWithSpaces(jep_ccea_attr, 1)).append(Constants.TAB);
		selectRequestDataSb.append(FormatUtil.getValueWithSpaces(jep_ccea, 47)).append(Constants.TAB);
		selectRequestDataSb.append(FormatUtil.getValueWithSpaces(cbcid_attr, 1)).append(Constants.TAB);
		selectRequestDataSb.append(FormatUtil.getValueWithSpaces(cbcid, 5)).append(Constants.TAB);
		selectRequestDataSb.append(FormatUtil.getValueWithSpaces(cableid_attr, 1)).append(Constants.TAB);
		selectRequestDataSb.append(FormatUtil.getValueWithSpaces(cableid, 5)).append(Constants.TAB);
		selectRequestDataSb.append(FormatUtil.getValueWithSpaces(chan_pair_attr, 1)).append(Constants.TAB);
		selectRequestDataSb.append(FormatUtil.getValueWithSpaces(chan_pair, 5)).append(Constants.TAB);
		selectRequestDataSb.append(FormatUtil.getValueWithSpaces(apptime_attr, 1)).append(Constants.TAB);
		selectRequestDataSb.append(FormatUtil.getValueWithSpaces(apptime, 11)).append(Constants.TAB);
		selectRequestDataSb.append(FormatUtil.getValueWithSpaces(clec_note_attr, 1)).append(Constants.TAB);
		selectRequestDataSb.append(FormatUtil.getValueWithSpaces(clec_note, 53)).append(Constants.TAB).append(Constants.TAB);
		
		
		String selectRequestDataString = FormatUtil.getValueWithSpaces(selectRequestDataSb.toString(), 2400);
		return selectRequestDataString;
	}
	
	public String getJeopardyTask9STRechId583String() {
		StringBuilder selectRequestDataSb = new StringBuilder();

		
		selectRequestDataSb.append(FormatUtil.getValueWithSpaces(ecver_attr, 1)).append(Constants.TAB);
		selectRequestDataSb.append(FormatUtil.getValueWithSpaces(ecver, 4)).append(Constants.TAB);
		selectRequestDataSb.append(FormatUtil.getValueWithSpaces(jep_ecckt_attr, 1)).append(Constants.TAB);
		selectRequestDataSb.append(FormatUtil.getValueWithSpaces(jep_ecckt, 46)).append(Constants.TAB);
		selectRequestDataSb.append(FormatUtil.getValueWithSpaces(jep_tns_attr, 1)).append(Constants.TAB);
		selectRequestDataSb.append(FormatUtil.getValueWithSpaces(jep_tns, 10)).append(Constants.TAB);
		selectRequestDataSb.append(FormatUtil.getValueWithSpaces(jep_cfa_attr, 1)).append(Constants.TAB);
		selectRequestDataSb.append(FormatUtil.getValueWithSpaces(jep_cfa, 42)).append(Constants.TAB);
		selectRequestDataSb.append(FormatUtil.getValueWithSpaces(jep_ccea_attr, 1)).append(Constants.TAB);
		selectRequestDataSb.append(FormatUtil.getValueWithSpaces(jep_ccea, 47)).append(Constants.TAB);
		selectRequestDataSb.append(FormatUtil.getValueWithSpaces(cbcid_attr, 1)).append(Constants.TAB);
		selectRequestDataSb.append(FormatUtil.getValueWithSpaces(cbcid, 5)).append(Constants.TAB);
		selectRequestDataSb.append(FormatUtil.getValueWithSpaces(cableid_attr, 1)).append(Constants.TAB);
		selectRequestDataSb.append(FormatUtil.getValueWithSpaces(cableid, 5)).append(Constants.TAB);
		selectRequestDataSb.append(FormatUtil.getValueWithSpaces(chan_pair_attr, 1)).append(Constants.TAB);
		selectRequestDataSb.append(FormatUtil.getValueWithSpaces(chan_pair, 5)).append(Constants.TAB);
		selectRequestDataSb.append(FormatUtil.getValueWithSpaces(apptime_attr, 1)).append(Constants.TAB);
		selectRequestDataSb.append(FormatUtil.getValueWithSpaces(apptime, 11)).append(Constants.TAB);
		selectRequestDataSb.append(FormatUtil.getValueWithSpaces(clec_note_attr, 1)).append(Constants.TAB);
		selectRequestDataSb.append(FormatUtil.getValueWithSpaces(clec_note, 93)).append(Constants.TAB).append(Constants.TAB);
		
		
		String selectRequestDataString = FormatUtil.getValueWithSpaces(selectRequestDataSb.toString(), 2400);
		return selectRequestDataString;
	}
}
