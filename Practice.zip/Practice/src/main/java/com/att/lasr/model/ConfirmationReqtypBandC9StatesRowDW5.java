package com.att.lasr.model;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@ToString
public class ConfirmationReqtypBandC9StatesRowDW5 {

	
	private String itemnum;
	private String lnum;
	private String numname;
	private String num_nbr;
	private String ord_attr;
	private String ord;
	private String lord_attr;
	private String lord;
	private String fdt_attr;
	private String fdt;
	private String dd_attr;
	private String dd;
	private String ecckt_attr;
	private String ecckt;
	private String ckr;
	private String shared_nbr;
	private String disc_nbr;
	private String recckt; 
	private String tns_attr;
	private String tns; 
	private String ters_attr;
	private String ters;
	private String cfa;
	private String ccea;
	private String ispid_attr;
	private String ispid;
	private String fecckt_attr;
	private String fecckt;
	private String npord_attr;
	private String npord;
	private String ported_nbr;
	private String rti_attr;
	private String rti;
	private String cbcid_attr;
	private String cbcid;
	private String cableid_attr;
	private String cableid;
	private String chan_pair_attr;
	private String chain_pair;
	private String old_ord;
	private String old_lord;
	private String old_npord;
	private String loc_seq_num;
}
