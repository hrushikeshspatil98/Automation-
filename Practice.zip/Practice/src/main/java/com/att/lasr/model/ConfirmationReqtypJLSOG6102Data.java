package com.att.lasr.model;
import java.util.ArrayList;
import java.util.List;

import com.att.lasr.utils.Constants;
import com.att.lasr.utils.FormatUtil;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@ToString
public class ConfirmationReqtypJLSOG6102Data {
	private Header header;
	private SubHeader subHeader;
	private String cver;
	private String  dor;
	private String atn;
	private String dinit;
	private String dda;
	private String rt;
	private String ecver;
	private String d_t_sent_local;	
	private String response_d_t_sent_central_time;
	private String an;
	
	private List<ConfirmationReqtypJLSOG6102Row> confirmationReqtypJLSOG6102Row = new ArrayList<>();

	public String getConfirmationReqtypJLSOG6102() {
		StringBuilder ConfirmationReqtypJLSOG6102sb = new StringBuilder();
	
		ConfirmationReqtypJLSOG6102sb.append(FormatUtil.getValueWithSpaces(cver, 2)).append(Constants.TAB);
		ConfirmationReqtypJLSOG6102sb.append(FormatUtil.getValueWithSpaces(dor, 17)).append(Constants.TAB);
		ConfirmationReqtypJLSOG6102sb.append(FormatUtil.getValueWithSpaces(atn, 12)).append(Constants.TAB);
		ConfirmationReqtypJLSOG6102sb.append(FormatUtil.getValueWithSpaces(dinit, 15)).append(Constants.TAB);
		ConfirmationReqtypJLSOG6102sb.append(FormatUtil.getValueWithSpaces(dda, 10)).append(Constants.TAB);
		ConfirmationReqtypJLSOG6102sb.append(FormatUtil.getValueWithSpaces(rt, 1)).append(Constants.TAB);
		ConfirmationReqtypJLSOG6102sb.append(FormatUtil.getValueWithSpaces(ecver, 3)).append(Constants.TAB);
		ConfirmationReqtypJLSOG6102sb.append(FormatUtil.getValueWithSpaces(d_t_sent_local, 17)).append(Constants.TAB);
		ConfirmationReqtypJLSOG6102sb.append(FormatUtil.getValueWithSpaces(response_d_t_sent_central_time, 17)).append(Constants.TAB);
		ConfirmationReqtypJLSOG6102sb.append(FormatUtil.getValueWithSpaces(an, 10)).append(Constants.TAB);
		
		String ConfirmationDataString = FormatUtil.getValueWithSpaces(ConfirmationReqtypJLSOG6102sb.toString(), 2400);
		return ConfirmationDataString;
	}

}
