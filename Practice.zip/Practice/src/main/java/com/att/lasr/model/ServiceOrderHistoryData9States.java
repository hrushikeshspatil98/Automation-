package com.att.lasr.model;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@ToString
public class ServiceOrderHistoryData9States {
	private String supp;
	private String dttm_entered;
	private String ord;
	private String loc;
	private String ord_stat;
	private String date;
	private String ord_dist_dttm;

}
