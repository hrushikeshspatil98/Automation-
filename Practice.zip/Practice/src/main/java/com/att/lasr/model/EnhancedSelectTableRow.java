package com.att.lasr.model;

import com.att.lasr.utils.Constants;
import com.att.lasr.utils.FormatUtil;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@ToString
public class EnhancedSelectTableRow {
	
	private String date_time_received;
	private String cc;
	private String request_id;
	private String status;
	private String pon;
	private String ddd;
	private String reqtyp;
	private String act;
	private String jep;
	private String cancel_ind;
	private String release_version;
	private String work_group_id;
	private String assigned_uid;
	private String rpon;
	private String project;
	private String total_record;
	private String start_page;
	private String end_page;
	private String begin_time_nextptr;
	private String end_time_nextptr;
	private String begin_time_prevptr;
	private String end_time_prevptr;
	public int uniqueId;
	
	public String getEnhanceDataTreeDataString(String tabValue) {
		StringBuilder selectRequestDataSb = new StringBuilder();

		
		selectRequestDataSb.append(FormatUtil.getValueWithSpaces(request_id.substring(0, 14), 14).trim()).append(Constants.TAB);
		selectRequestDataSb.append(FormatUtil.getValueWithSpaces(request_id.substring(15, 17), 2).trim()).append(Constants.TAB);
		selectRequestDataSb.append(FormatUtil.getValueWithSpaces(status, 14)).append(Constants.TAB);
		//selectRequestDataSb.append(FormatUtil.getValueWithSpaces(release_version, 5)).append(Constants.TAB).append(Constants.TAB);
		
		if(tabValue!= null && tabValue.equalsIgnoreCase("Y")) {
			System.out.println("tabValue::::::if:::::::::;"+tabValue);
			selectRequestDataSb.append(FormatUtil.getValueWithSpaces(release_version, 5)).append(Constants.TAB);
			selectRequestDataSb.append(FormatUtil.getValueWithSpaces(pon, 16)).append(Constants.TAB);
			selectRequestDataSb.append(FormatUtil.getValueWithSpaces(cc, 4)).append(Constants.TAB).append(Constants.TAB).append(Constants.TAB).append(Constants.TAB);
		}else {System.out.println("tabValue:::::else::::::::::;"+tabValue);
		selectRequestDataSb.append(FormatUtil.getValueWithSpaces(release_version, 5)).append(Constants.TAB).append(Constants.TAB);
		
		}


		String selectRequestDataString = FormatUtil.getValueWithSpaces(selectRequestDataSb.toString(), 2400);
		return selectRequestDataString;
	}


}
