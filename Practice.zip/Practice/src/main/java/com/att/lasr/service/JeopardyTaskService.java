package com.att.lasr.service;

import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.att.lasr.model.EditEccktData;
import com.att.lasr.model.EditEccktTableRow;
import com.att.lasr.model.FollowUpData;
import com.att.lasr.model.FollowUpData9States;
import com.att.lasr.model.Header;
import com.att.lasr.model.JeopardyListRechId014;
import com.att.lasr.model.JeopardyMain12State;
import com.att.lasr.model.JeopardyTask;
import com.att.lasr.model.JeopardyTask12STRechId582;
import com.att.lasr.model.JeopardyTask12STRechId583;
import com.att.lasr.model.MQReceivedData;
import com.att.lasr.model.NotesFupBindingData12States;
import com.att.lasr.model.ShowError;
import com.att.lasr.model.SubData;
import com.att.lasr.model.SubHeader;
import com.att.lasr.utils.Constants;
import com.att.lasr.utils.FormatUtil;
import com.att.lasr.utils.MQMessageStringBuilder;
import com.att.lasr.utils.MQReadUtil;
import com.att.lasr.utils.MQWriteUtil;
import com.att.lasr.utils.enums.LastInd;
import com.att.lasr.utils.enums.LogInd;
import com.att.lasr.utils.enums.Process;
import com.att.lasr.utils.enums.ProcessGroupInd;
import com.att.lasr.utils.enums.ProcessMode;
import com.att.lasr.utils.enums.RecIdFor12State;
import com.att.lasr.utils.enums.RecIdFor9State;
import com.att.lasr.utils.enums.TabInd;

@Service
public class JeopardyTaskService {

	@Autowired
	private MQReadUtil mqReadUtil;

	@Autowired
	private MQWriteUtil mqWriteUtil;

	@Autowired
	HttpSession httpSession;

	public JeopardyMain12State writeToMQ(JeopardyTask jeopardyTask, String user_id, String object_handle,
			HttpSession session, FollowUpData followUpData) {
		session.removeAttribute("showError");
		List<ShowError> jeopardyErrorList12 = new ArrayList<ShowError>();
		System.out.println("jeopardyTask ******" + jeopardyTask);
		Header header = prepareIssueHeader(user_id, object_handle);
		// System.out.println("My User Id is: " + user_id);
		StringBuilder subHeaderandData = new StringBuilder();

		String dataString = "";
		
		String[] ord1 = jeopardyTask.getOrd().split(",");
		List<String> ord = new ArrayList<String>();
		for (String a : ord1) {
			ord.add(a);
		}

		int numCount=ord.size();
		
		String[] jcode1 = jeopardyTask.getJcode().split(",");
		List<String> jcode = new ArrayList<String>();
		for (String a : jcode1) {
			jcode.add(a);
		}

		for (int i = 0; i < ord.size(); i++) {
			if (jcode.get(i).toString().equals("JC0014") || jcode.get(i).toString().equals("JC0145")
					|| jcode.get(i).toString().equals("JC0148") || jcode.get(i).toString().equals("JC0117")
					|| jcode.get(i).toString().equals("JC0118") || jcode.get(i).toString().equals("JC0119")
					|| jcode.get(i).toString().equals("JC0123")) {
				numCount++;
			}
		}
		
		if (jeopardyTask.getNotes() != "") {
			numCount++;
		}
		
		// 049 RecId code

		List<NotesFupBindingData12States> dataObject_049 = (List<NotesFupBindingData12States>) session
				.getAttribute("treeViewList_049");

		MQMessageStringBuilder mqMessageStringBuilder = new MQMessageStringBuilder();
		SubHeader subHeader049 = prepareSubHeader049();

		for (NotesFupBindingData12States notesFupBindingData12States : dataObject_049) {

			numCount++;
			header.setNum_detail(getNumCount(numCount));
			session.setAttribute("Lrs_No", notesFupBindingData12States.getRequest_id().substring(0, 17).trim());
			dataString = notesFupBindingData12States.getNotesFupBindingData12String();
			subHeaderandData.append(mqMessageStringBuilder.addHeader(header));
			subHeaderandData.append(mqMessageStringBuilder.appendSubHeaderAndData(subHeader049, dataString).toString());
			// System.err.println("mqMessageStringBuilder 049******" +
			// mqMessageStringBuilder.getMqMessageString());
		}

		List<NotesFupBindingData12States> treeViewList = (List<NotesFupBindingData12States>) session
				.getAttribute("treeViewList_049");
		
		String version = treeViewList.get(0).getRequest_id().substring(15, 17);
		// 531 start

		String checkNote = "";
		if (jeopardyTask.getNotes() != "") {

			checkNote = "Y";
			SubHeader subHeader1Editablenotes = prepareSubHeader();

			followUpData.setNotes_attr("Y");
			followUpData.setUser_id(user_id);
			followUpData.setUser_id_attr("Y");
			followUpData.setLasr_ver_attr("Y");
			followUpData.setLasr_ver(version);
			followUpData.setFollow_up_date_attr("Y");
			followUpData.setNotes_attr("Y");
			followUpData.setNotes(jeopardyTask.getNotes());
			String followUpDataString = followUpData.getFollowUpData();

			// System.out.println("followUpDataString 531 " + followUpDataString);

			mqMessageStringBuilder.appendSubHeaderAndData(subHeader1Editablenotes, followUpDataString);
			// System.err.println("mqMessageStringBuilder 531******" +
			// mqMessageStringBuilder.getMqMessageString());
		}
		// 531 end

		// 582 START
		SubHeader subHeader582 = prepareIssueSubHeader(RecIdFor12State.CS_RECID_JEOPARDY_UPDATE.getRecIdValue());

		List<String> rowNum = new ArrayList<String>();

		String[] esdd1 = jeopardyTask.getEsdd().split(",");
		List<String> esdd = new ArrayList<String>();
		for (String a : esdd1) {
			esdd.add(a);
		}

		String[] Clec_note1 = jeopardyTask.getClec_note().split(",");
		List<String> Clec_note = new ArrayList<String>();
		for (String a : Clec_note1) {
			Clec_note.add(a);
			System.out.println("clec note" +Clec_note.toString());
		}

		
		List<String> ecckt = new ArrayList<String>();
		if(jeopardyTask.getJep_ecckt() != null) {
			String[] ecckt1 = jeopardyTask.getJep_ecckt().split(",");
			for (String a : ecckt1) {
				ecckt.add(a);
				}
		}

		List<String> tns = new ArrayList<String>();
		if (jeopardyTask.getTns() != null) {
			String[] tns1 = jeopardyTask.getTns().split(",");
			for (String a : tns1) {
				tns.add(a);
			}
		}

		List<String> apptime = new ArrayList<String>();
		if (jeopardyTask.getTns() != null) {
			String[] apptime1 = jeopardyTask.getApptime().split(",");
			for (String a : apptime1) {
				apptime.add(a);
			}
		}
		List<String> cfa = new ArrayList<String>();
		if (jeopardyTask.getCfa() != null) {
			String[] cfa1 = jeopardyTask.getCfa().split(",");
			for (String a : cfa1) {
				cfa.add(a);
			}
		}

		List<String> ccea = new ArrayList<String>();
		if (jeopardyTask.getCcea() != null) {
			String[] ccea1 = jeopardyTask.getCcea().split(",");
			for (String a : ccea1) {
				ccea.add(a);
			}
		}

		List<String> cableid = new ArrayList<String>();
		if (jeopardyTask.getCableid() != null) {
			String[] cableid1 = jeopardyTask.getCableid().split(",");
			for (String a : cableid1) {
				cableid.add(a);
			}
		}

		List<String> cbcid = new ArrayList<String>();
		if (jeopardyTask.getCbcid() != null) {
			String[] cbcid1 = jeopardyTask.getCbcid().split(",");
			for (String a : cbcid1) {
				cbcid.add(a);
			}
		}

		List<String> chanpair = new ArrayList<String>();
		if (jeopardyTask.getChanpair() != null) {
			String[] chanpair1 = jeopardyTask.getChanpair().split(",");
			for (String a : chanpair1) {
				chanpair.add(a);
			}
		}

		int count = 0000;
		for (int i = 0; i < ord.size(); i++) {
			JeopardyTask12STRechId582 jeopardyTask582 = new JeopardyTask12STRechId582();

			String countVal = "";
			count++;

			if (count < 10) {
				countVal = "000" + count;
			}
			if (count >= 10) {
				countVal = "00" + count;
			}
			
			rowNum.add(countVal);
			
			jeopardyTask582.setEcver_attr("Y");
			jeopardyTask582.setEcver(countVal);
			jeopardyTask582.setOrd_attr("Y");
			jeopardyTask582.setOrd(ord.get(i).toString());
			jeopardyTask582.setLord_attr("Y");
			jeopardyTask582.setLord("");
			jeopardyTask582.setJcode_attr("Y");
			jeopardyTask582.setJcode(jcode.get(i).toString());
			jeopardyTask582.setRcode_attr("Y");
			jeopardyTask582.setRcode(getRcodeRdet(session, jcode.get(i).toString()));
			// jeopardyTask582.setEsdd_attr("Y");
			if (esdd.size() != 0) {
				jeopardyTask582.setEsdd(esdd.get(i).toString());
			}

			String jeopardyTaskData582 = jeopardyTask582.getJeopardyTask12STRechId582String();

			System.err.println("jeopardyTaskData582  " + jeopardyTaskData582.toString());

			mqMessageStringBuilder.appendSubHeaderAndData(subHeader582, jeopardyTaskData582);
			
			System.out.println("jcode" + jcode.get(i).toString());
		}
		// 582 End

		// 583 START
		System.out.println("size of rowNum**********" + rowNum.size());

		SubHeader subHeader583 = prepareIssueSubHeader(RecIdFor12State.CS_RECID_JEOPARDY_DETAIL.getRecIdValue());
		int length=rowNum.size()-1;

		System.out.println("length: " + length);
		for (int i = length; i >=0; i--) {
			System.out.println("inside 583 for loop JCODE VALUE : " + jcode.get(i).toString());
			if (jcode.get(i).toString().equals("JC0014")|| jcode.get(i).toString().equals("JC0145") ||jcode.get(i).toString().equals("JC0148") || jcode.get(i).toString().equals("JC0117") ||
					 jcode.get(i).toString().equals("JC0118") ||jcode.get(i).toString().equals("JC0119") || jcode.get(i).toString().equals("JC0123")) {
				JeopardyTask12STRechId583 jeopardyTask583 = new JeopardyTask12STRechId583();

				System.out.println("inside 583 for loop JCODE VALUE2 : " + jcode.get(i).toString());
				jeopardyTask583.setEcver_attr("Y");
				jeopardyTask583.setEcver(rowNum.get(i).toString());
				jeopardyTask583.setJep_ecckt_attr("Y");
				if (ecckt.size() != 0 && jcode.get(i).toString().equals("JC0118")) {
					jeopardyTask583.setJep_ecckt(ecckt.get(i).toString());
				}
				jeopardyTask583.setJep_tns_attr("Y");
				if (tns.size() != 0
						&& (jcode.get(i).toString().equals("JC0119") || jcode.get(i).toString().equals("JC0123"))) {
					jeopardyTask583.setJep_tns(tns.get(i));
				}
				if (cfa.size() != 0 && jcode.get(i).toString().equals("JC0117")) {
					jeopardyTask583.setJep_cfa(cfa.get(i));
				}
				jeopardyTask583.setJep_cfa_attr("Y");
				if (ccea.size() != 0 && jcode.get(i).toString().equals("JC0117")) {
					jeopardyTask583.setJep_ccea(ccea.get(i));
				}
				jeopardyTask583.setJep_ccea_attr("Y");
				if (cbcid.size() != 0 && jcode.get(i).toString().equals("JC0117")) {
					jeopardyTask583.setCbcid(cbcid.get(i));
				}
				jeopardyTask583.setCbcid_attr("Y");
				if (cableid.size() != 0 && jcode.get(i).toString().equals("JC0117")) {
					jeopardyTask583.setCableid(cableid.get(i));
				}
				jeopardyTask583.setCableid_attr("Y");
				if (chanpair.size() != 0 && jcode.get(i).toString().equals("JC0117")) {
					jeopardyTask583.setChan_pair(chanpair.get(i));
				}
				jeopardyTask583.setChan_pair_attr("Y");
				jeopardyTask583.setApptime_attr("Y");
				if (apptime.size() != 0 && jcode.get(i).toString().equals("JC0148")) {
					jeopardyTask583.setApptime(apptime.get(i));
				}
				jeopardyTask583.setClec_note_attr("Y");
				// System.out.println("Clec_note.size()" + Clec_note.size());

				if (Clec_note.size() != 0
						&& (jcode.get(i).toString().equals("JC0014") || jcode.get(i).toString().equals("JC0145"))) {
					System.out.println("clec note value: " + Clec_note.get(i).toString());
					jeopardyTask583.setClec_note(Clec_note.get(i).toString());
				}

				String jeopardyTaskData583 = jeopardyTask583.getJeopardyTask12STRechId583String();

				System.err.println("jeopardyTaskData583 " + jeopardyTaskData583.toString());

				//numCount++;
				mqMessageStringBuilder.appendSubHeaderAndData(subHeader583, jeopardyTaskData583);
			}
		}
		
		System.out.println("numCount ***: "+ numCount);
		//header.setNum_detail(getNumCount(numCount));
		//subHeaderandData.append(mqMessageStringBuilder.addHeader(header));
		//mqMessageStringBuilder.appendHeaderAndSubData(header, mqMessageStringBuilder.getMqMessageString() );
		System.err.println("mqMessageStringBuilder 12 state****** " + mqMessageStringBuilder.getMqMessageString());
		//System.err.println("mqMessageStringBuilder 12 state header****** " + subHeaderandData.toString());

		JeopardyMain12State jeopardyMain12State = new JeopardyMain12State();

		boolean isWritten = mqWriteUtil.writeDataToMQ(mqMessageStringBuilder, session);

		if (isWritten) {

			MQReceivedData mqReceivedData=null;
			
			try {

			mqReceivedData = mqReadUtil.readSortDataFromMQ(session); 
			 long endTime = System.nanoTime() + TimeUnit.NANOSECONDS.convert(3L, TimeUnit.MINUTES); 
			//  Map<String, SubData> subDatas = mqReceivedData.getSubDatas(); 
		//	  Header receivedHeader = mqReceivedData.getHeader(); 
			  while(mqReceivedData.getHeader()==null&& System.nanoTime() < endTime) { 
					System.out.println("*************inside if*************** "); 
					mqReceivedData =	 mqReadUtil.readSortDataFromMQ(session); 
				} 
			  
			  
			  System.out.println(mqReceivedData.getHeader().toString()); 
		} catch (Exception e) { 
			// TODO Auto-generated catch block 
			// mqReceivedData = mqReadUtil.readDataFromMQ(session); 
			e.printStackTrace(); 


		}

			Map<String, SubData> subDatas = mqReceivedData.getSubDatas();
			Header receivedHeader = mqReceivedData.getHeader();

			jeopardyMain12State.setHeader(receivedHeader);
			System.err.println("mqReceivedData   " + mqReceivedData.toString());

			SubData subData = subDatas.get(RecIdFor12State.CS_RECID_ERROR.getRecIdValue());

			ReadErrorMsgsJson readErrorMsgsJson = new ReadErrorMsgsJson();

			if (receivedHeader.getReturn_code() != null && receivedHeader.getReturn_code().equals("999")) {

				checkNote = "Y";

				ShowErrorService showErrorService = new ShowErrorService();

				if (subData != null) {
					String[] subDataRows = subData.getSubDataRows();

					for (String subDataRow : subDataRows) {
						String[] attributes = mqReadUtil.getAttributes(subDataRow, 4);
						if(attributes[0].equals("LG0272")) {
							jeopardyErrorList12 = showErrorService.getJeopardyErrorList(attributes[0],attributes[1], attributes[2], "", "U",
								jeopardyErrorList12);
						}
						else {
							jeopardyErrorList12 = showErrorService.getErrorListMultiple(attributes[0], attributes[2], "", "U",
									jeopardyErrorList12);
						}

					}

				}
				session.setAttribute("showError", jeopardyErrorList12);
			}
		
			if (receivedHeader.getReturn_code() != null
				&& (receivedHeader.getReturn_code().equals("889") || receivedHeader.getReturn_code().equals("888"))) {

			checkNote = "Y";
			}
		}
		session.setAttribute("checkNote", checkNote);

		return jeopardyMain12State;
	}

	public JeopardyMain12State writeToMQ9State(JeopardyTask jeopardyTask, String user_id, String object_handle,
			HttpSession session, FollowUpData9States followUpData9States) {
		session.removeAttribute("showError");
		List<ShowError> jeopardyErrorList9 = new ArrayList<ShowError>();

		System.out.println("jeopardyTask    ******" + jeopardyTask);
		Header header = prepareIssueHeader(user_id, object_handle);
		// System.out.println("My User Id is: " + user_id);
		StringBuilder subHeaderandData = new StringBuilder();

		String dataString = "";

		String[] ord1 = jeopardyTask.getOrd().split(",");
		List<String> ord = new ArrayList<String>();
		for (String a : ord1) {
			ord.add(a);
		}

		int numCount=ord.size();
		
		String[] rcode1 = jeopardyTask.getRcode().split(",");
		List<String> rcode = new ArrayList<String>();
		for (String a : rcode1) {
			rcode.add(a);
		}

		for (int i = 0; i < ord.size(); i++) {
			if (rcode.get(i).toString().equals("1P")){
				numCount++;
			}
		}
		
		
		if (jeopardyTask.getNotes() != "") {
			numCount++;
		}
		// 049 RecId code

		List<NotesFupBindingData12States> dataObject_049 = (List<NotesFupBindingData12States>) session
				.getAttribute("treeViewList_049");

		MQMessageStringBuilder mqMessageStringBuilder = new MQMessageStringBuilder();
		SubHeader subHeader049 = prepareSubHeader049();

		for (NotesFupBindingData12States notesFupBindingData9States : dataObject_049) {

			numCount++;
			header.setNum_detail(getNumCount(numCount));
			session.setAttribute("Lrs_No", notesFupBindingData9States.getRequest_id().substring(0, 17).trim());
			dataString = notesFupBindingData9States.getNotesFupBindingData9String();
			subHeaderandData.append(mqMessageStringBuilder.addHeader(header));
			subHeaderandData.append(mqMessageStringBuilder.appendSubHeaderAndData(subHeader049, dataString).toString());
		}

		// 049 end
		List<NotesFupBindingData12States> treeViewList = (List<NotesFupBindingData12States>) session
				.getAttribute("treeViewList_049");
		String version = treeViewList.get(0).getRequest_id().substring(15, 17);

		// 531 start

		String checkNote = "";
		if (jeopardyTask.getNotes() != "") {

			checkNote = "Y";
			SubHeader subHeader1Editablenotes = prepareSubHeader();

			String Lsr_number = (String) session.getAttribute("Lrs_No");

			followUpData9States.setLasr_ver(version);// dynamic
			followUpData9States.setUser_id(user_id);
			followUpData9States.setUser_id_attr("Y");
			followUpData9States.setLasr_ver_attr("Y");
			followUpData9States.setFollow_up_date_attr("Y");
			followUpData9States.setNotes_attr("Y");
			followUpData9States.setNotes(jeopardyTask.getNotes());

			String followUpDataString = followUpData9States.getSelectRequestNotesDataString();

			// System.out.println("followUpDataString 531 " + followUpDataString);

			mqMessageStringBuilder.appendSubHeaderAndData(subHeader1Editablenotes, followUpDataString);
			// System.err.println("mqMessageStringBuilder 531******" +
			// mqMessageStringBuilder.getMqMessageString());
		}

		// 531 end

		// 582 START
		SubHeader subHeader582 = prepareIssueSubHeader(RecIdFor12State.CS_RECID_JEOPARDY_UPDATE.getRecIdValue());

		List<String> rowNum = new ArrayList<String>();

		String[] esdd1 = jeopardyTask.getEsdd().split(",");
		List<String> esdd = new ArrayList<String>();
		for (String a : esdd1) {
			esdd.add(a);
		}

		String[] Clec_note1 = jeopardyTask.getClec_note().split(",");
		List<String> Clec_note = new ArrayList<String>();
		for (String a : Clec_note1) {
			Clec_note.add(a);
		}

		int count = 0000;
		for (int i = 0; i < ord.size(); i++) {
			JeopardyTask12STRechId582 jeopardyTask582 = new JeopardyTask12STRechId582();

			String countVal = "";
			count++;

			if (count < 10) {
				countVal = "000" + count;
				rowNum.add(countVal);
			}
			if (count >= 10) {
				countVal = "00" + count;
				rowNum.add(countVal);
			}

			jeopardyTask582.setEcver_attr("Y");
			jeopardyTask582.setEcver(countVal);
			jeopardyTask582.setOrd_attr("Y");
			jeopardyTask582.setOrd(ord.get(i).toString());
			jeopardyTask582.setLord_attr("Y");
			jeopardyTask582.setLord("");
			jeopardyTask582.setJcode_attr("Y");
			jeopardyTask582.setJcode(rcode.get(i).toString());
			jeopardyTask582.setRcode_attr("Y");
			jeopardyTask582.setRcode(rcode.get(i).toString());
			// jeopardyTask582.setEsdd_attr("Y");
			jeopardyTask582.setEsdd(esdd.get(i).toString());

			String jeopardyTaskData582 = jeopardyTask582.getJeopardyTask9STRechId582String();
			System.out.println(" string 582: "+ jeopardyTaskData582.toString());

			mqMessageStringBuilder.appendSubHeaderAndData(subHeader582, jeopardyTaskData582);

		}
		// 582 End

		// 583 START

		SubHeader subHeader583 = prepareIssueSubHeader(RecIdFor12State.CS_RECID_JEOPARDY_DETAIL.getRecIdValue());

		for (int i = rowNum.size()-1; i >=0; i--) {

			if (rcode.get(i).toString().equals("1P")){
			JeopardyTask12STRechId583 jeopardyTask583 = new JeopardyTask12STRechId583();

			jeopardyTask583.setEcver_attr("Y");
			jeopardyTask583.setEcver(rowNum.get(i).toString());
			jeopardyTask583.setJep_ecckt_attr("Y");
			jeopardyTask583.setJep_tns_attr("Y");
			jeopardyTask583.setJep_cfa_attr("Y");
			jeopardyTask583.setJep_ccea_attr("Y");
			jeopardyTask583.setCbcid_attr("Y");
			jeopardyTask583.setCableid_attr("Y");
			jeopardyTask583.setChan_pair_attr("Y");
			jeopardyTask583.setApptime_attr("Y");
			jeopardyTask583.setClec_note_attr("Y");
			jeopardyTask583.setClec_note(Clec_note.get(i).toString());

			String jeopardyTaskData583 = jeopardyTask583.getJeopardyTask9STRechId583String();

			System.out.println("string 583: " + jeopardyTaskData583.toString());
			mqMessageStringBuilder.appendSubHeaderAndData(subHeader583, jeopardyTaskData583);
			}
		}

		System.err.println("mqMessageStringBuilder 12 state****** " + mqMessageStringBuilder.getMqMessageString());

		JeopardyMain12State jeopardyMain12State = new JeopardyMain12State();

		boolean isWritten = mqWriteUtil.writeDataToMQ(mqMessageStringBuilder, session);

		if (isWritten) {

			MQReceivedData mqReceivedData=null;
			
			try {

			mqReceivedData = mqReadUtil.readSortDataFromMQ(session); 
			 long endTime = System.nanoTime() + TimeUnit.NANOSECONDS.convert(3L, TimeUnit.MINUTES); 
			//  Map<String, SubData> subDatas = mqReceivedData.getSubDatas(); 
		//	  Header receivedHeader = mqReceivedData.getHeader(); 
			  while(mqReceivedData.getHeader()==null&& System.nanoTime() < endTime) { 
					System.out.println("*************inside if*************** "); 
					mqReceivedData =	 mqReadUtil.readSortDataFromMQ(session); 
				} 
			  
			  
			  System.out.println(mqReceivedData.getHeader().toString()); 
		} catch (Exception e) { 
			// TODO Auto-generated catch block 
			 //mqReceivedData = mqReadUtil.readDataFromMQ(session); 
			e.printStackTrace(); 


		}

			Map<String, SubData> subDatas = mqReceivedData.getSubDatas();
			Header receivedHeader = mqReceivedData.getHeader();

			jeopardyMain12State.setHeader(receivedHeader);
			System.err.println("mqReceivedData   " + mqReceivedData.toString());

			SubData subData = subDatas.get(RecIdFor12State.CS_RECID_ERROR.getRecIdValue());

			ReadErrorMsgsJson readErrorMsgsJson = new ReadErrorMsgsJson();

			if (receivedHeader.getReturn_code() != null && receivedHeader.getReturn_code().equals("999")) {

				checkNote = "Y";

				ShowErrorService showErrorService = new ShowErrorService();

				if (subData != null) {
					String[] subDataRows = subData.getSubDataRows();

					for (String subDataRow : subDataRows) {
						String[] attributes = mqReadUtil.getAttributes(subDataRow, 4);
						if(attributes[0].equals("LG0272")) {
							jeopardyErrorList9 = showErrorService.getJeopardyErrorList(attributes[0],attributes[1], attributes[2], "", "U",
								jeopardyErrorList9);
						}
						else {
							jeopardyErrorList9 = showErrorService.getErrorListMultiple(attributes[0], attributes[2], "", "U",
									jeopardyErrorList9);
						}

					}

				}
			
				session.setAttribute("showError", jeopardyErrorList9);
			}
		
			if (receivedHeader.getReturn_code() != null
				&& (receivedHeader.getReturn_code().equals("889") || receivedHeader.getReturn_code().equals("888"))) {

			checkNote = "Y";
			}
		}
		session.setAttribute("checkNote", checkNote);
		return jeopardyMain12State;

	}

	private SubHeader prepareIssueSubHeader(String recId) {

		// Prepare SubHeader
		SubHeader subHeader = new SubHeader();

		subHeader.setLast_ind(LastInd.Y.name());
		subHeader.setProcess_mode(ProcessMode.CS_ADD.getProcessModeCode());
		subHeader.setRecord_type(recId);
		subHeader.setReturn_code(null);
		subHeader.setDw_rownum(null);
		subHeader.setEcver(null);

		return subHeader;
	}

	private Header prepareIssueHeader(String user_id, String object_handle) {
		// Prepare Header
		Header header = new Header();

		header.setUser_id(user_id);
		header.setProcess(Process.CS_REQUEST.getProcessCode());
		header.setTab_ind("582");
		header.setProcess_group_ind(ProcessGroupInd.ISSUE_IND.getProcessGroupInd());
		header.setObject_handle(object_handle);
		header.setObject_handle2(null);
		header.setLog_ind(LogInd.N.name());
		header.setStarttime(null);
		header.setEndtime(null);
		header.setGuid(null);
		header.setSession_trans_count("0000001");
		header.setHost_trans_seq(null);
		header.setReturn_code(null);
		header.setRead_only_ind(null);
	//	header.setNum_detail("0006");
		header.setRead_only_user_id(null);
		header.setLasrversion(null);

		return header;
	}

	private SubHeader prepareSubHeader() {

		// Prepare SubHeader
		SubHeader subHeader = new SubHeader();

		subHeader.setLast_ind(LastInd.Y.name());
		subHeader.setProcess_mode(ProcessMode.CS_ADD.getProcessModeCode());
		subHeader.setRecord_type(RecIdFor12State.CS_RECID_NOTES_INPUT.getRecIdValue());
		subHeader.setReturn_code(null);
		subHeader.setDw_rownum(null);
		subHeader.setEcver(null);

		return subHeader;
	}

	private SubHeader prepareSubHeader049() {

		// Prepare SubHeader
		SubHeader subHeader = new SubHeader();

		subHeader.setLast_ind(LastInd.Y.name());
		subHeader.setProcess_mode(ProcessMode.CS_UPDATE.getProcessModeCode());
		subHeader.setRecord_type(RecIdFor12State.CS_RECID_HEADER.getRecIdValue());
		subHeader.setReturn_code(null);
		subHeader.setDw_rownum(null);
		subHeader.setEcver(null);

		return subHeader;
	}

	public String getRcodeRdet(HttpSession session, String jcode) {

		String rcodeData = "";
		List<JeopardyListRechId014> list_014 = (List<JeopardyListRechId014>) (session.getAttribute("JeopardyListRows"));

		for (int i = 0; i < list_014.size(); i++) {

			boolean x = list_014.get(i).getJcode().toString().equals(jcode);

			if (x) {
				rcodeData = list_014.get(i).getRcode().toString();
			}
		}

		return rcodeData;
	}

	public String createdataforMq(List<NotesFupBindingData12States> treeViewList) {
		String cc = treeViewList.get(0).getCompany_code();
		String DTReceived = treeViewList.get(0).getDate_time_received();
		String pon = treeViewList.get(0).getPon();
		String Rver = treeViewList.get(0).getRver();
		String LsrNo = treeViewList.get(0).getRequest_id();
		String ReqTyp = treeViewList.get(0).getReqtype();
		String Status = treeViewList.get(0).getStatus();
		String lspauth_attr = treeViewList.get(0).getLspauth_attr();
		String lspauth = treeViewList.get(0).getLspauth();
		StringBuilder sb = new StringBuilder();
		// sb.append(treeViewList).append(Constants.TAB) .append(Constants.TAB);
		sb.append(FormatUtil.getValueWithSpaces(cc, 4)).append(Constants.TAB);
		sb.append(FormatUtil.getValueWithSpaces(DTReceived, 17)).append(Constants.TAB);
		sb.append(FormatUtil.getValueWithSpaces(pon, 16)).append(Constants.TAB);
		sb.append(FormatUtil.getValueWithSpaces(Rver, 5)).append(Constants.TAB);
		sb.append(FormatUtil.getValueWithSpaces(LsrNo, 18)).append(Constants.TAB);
		sb.append(FormatUtil.getValueWithSpaces(ReqTyp, 2)).append(Constants.TAB);
		sb.append(FormatUtil.getValueWithSpaces(Status, 12)).append(Constants.TAB);
		sb.append(FormatUtil.getValueWithSpaces(lspauth_attr, 1)).append(Constants.TAB);
		sb.append(FormatUtil.getValueWithSpaces(lspauth, 4)).append(Constants.TAB).append(Constants.TAB);
		// sb.append(treeViewList.get(0).getLspAuth()).append(Constants.TAB);

		// sb.append(treeViewList.get(0).getStatus()).append(Constants.TAB).append(Constants.TAB);
		String finalString = FormatUtil.getValueWithSpaces(sb.toString(), 2400);

		return finalString;
	}

	public String createdataforMq9states(List<NotesFupBindingData12States> treeViewList) {
		String cc = treeViewList.get(0).getCompany_code();
		String DTReceived = treeViewList.get(0).getDate_time_received();
		String pon = treeViewList.get(0).getPon();
		String Rver = treeViewList.get(0).getRver();
		String LsrNo = treeViewList.get(0).getRequest_id();
		String ReqTyp = treeViewList.get(0).getReqtype();
		String Status = treeViewList.get(0).getStatus();
		String lspauth_attr = treeViewList.get(0).getLspauth_attr();
		String lspauth = treeViewList.get(0).getLspauth();
		String cvoip = "N";
		String aan = null;
		String atn = null;
		String natn = null;
		String nan = null;
		String an = null;
		StringBuilder sb = new StringBuilder();
		// sb.append(treeViewList).append(Constants.TAB) .append(Constants.TAB);
		sb.append(FormatUtil.getValueWithSpaces(cc, 4)).append(Constants.TAB);
		sb.append(FormatUtil.getValueWithSpaces(DTReceived, 17)).append(Constants.TAB);
		sb.append(FormatUtil.getValueWithSpaces(pon, 16)).append(Constants.TAB);
		sb.append(FormatUtil.getValueWithSpaces(Rver, 5)).append(Constants.TAB);
		sb.append(FormatUtil.getValueWithSpaces(LsrNo, 18)).append(Constants.TAB);
		sb.append(FormatUtil.getValueWithSpaces(ReqTyp, 2)).append(Constants.TAB);
		sb.append(FormatUtil.getValueWithSpaces(Status, 22)).append(Constants.TAB);
		sb.append(FormatUtil.getValueWithSpaces(lspauth_attr, 1)).append(Constants.TAB);
		sb.append(FormatUtil.getValueWithSpaces(lspauth, 4)).append(Constants.TAB);
		sb.append(FormatUtil.getValueWithSpaces(cvoip, 1)).append(Constants.TAB);
		sb.append(FormatUtil.getValueWithSpaces(aan, 13)).append(Constants.TAB);
		sb.append(FormatUtil.getValueWithSpaces(atn, 10)).append(Constants.TAB);
		sb.append(FormatUtil.getValueWithSpaces(natn, 10)).append(Constants.TAB);
		sb.append(FormatUtil.getValueWithSpaces(nan, 10)).append(Constants.TAB);
		sb.append(FormatUtil.getValueWithSpaces(an, 13)).append(Constants.TAB).append(Constants.TAB);
		// sb.append(treeViewList.get(0).getLspAuth()).append(Constants.TAB);

		// sb.append(treeViewList.get(0).getStatus()).append(Constants.TAB).append(Constants.TAB);
		String finalString = FormatUtil.getValueWithSpaces(sb.toString(), 2400);

		return finalString;
	}

	private String getNumCount(int size) {
		String numCount = String.format("%04d", size);
		return numCount;
		}
}
