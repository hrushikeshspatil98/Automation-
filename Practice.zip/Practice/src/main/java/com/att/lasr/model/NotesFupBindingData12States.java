package com.att.lasr.model;

import com.att.lasr.utils.Constants;
import com.att.lasr.utils.FormatUtil;

import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;
@Getter
@Setter
@NoArgsConstructor
@ToString
@Data
public class NotesFupBindingData12States {

	private String company_code;
	private String date_time_received;
	private String pon;
	private String rver;
	private String request_id;
	private String reqtype;
	private String status;
	private String lspauth_attr;
	private String lspauth;
	private String cvoip;

	private String aan;
	private String atn;
	private String natn;
	private String nan;

	private String an;
	public String getNotesFupBindingData12String() {
		StringBuilder selectRequestDataSb = new StringBuilder();

		selectRequestDataSb.append(FormatUtil.getValueWithSpaces(company_code, 4)).append(Constants.TAB);
		selectRequestDataSb.append(FormatUtil.getValueWithSpaces(date_time_received, 17)).append(Constants.TAB);
		selectRequestDataSb.append(FormatUtil.getValueWithSpaces(pon, 16)).append(Constants.TAB);
		selectRequestDataSb.append(FormatUtil.getValueWithSpaces(rver, 5)).append(Constants.TAB);
		selectRequestDataSb.append(FormatUtil.getValueWithSpaces(request_id, 18)).append(Constants.TAB);
		selectRequestDataSb.append(FormatUtil.getValueWithSpaces(reqtype, 2)).append(Constants.TAB);
		selectRequestDataSb.append(FormatUtil.getValueWithSpaces(status, 12)).append(Constants.TAB);
		selectRequestDataSb.append(FormatUtil.getValueWithSpaces(lspauth_attr, 1)).append(Constants.TAB);
		selectRequestDataSb.append(FormatUtil.getValueWithSpaces(lspauth, 4)).append(Constants.TAB).append(Constants.TAB);
		//selectRequestDataSb.append(FormatUtil.getValueWithSpaces(cvoip, 1)).append(Constants.TAB).append(Constants.TAB);

		String selectRequestDataString = FormatUtil.getValueWithSpaces(selectRequestDataSb.toString(), 2400);
		return selectRequestDataString;
		}
	
	public String getNotesFupBindingData9String() {
		StringBuilder selectRequestDataSb = new StringBuilder();

		selectRequestDataSb.append(FormatUtil.getValueWithSpaces(company_code, 4)).append(Constants.TAB);
		selectRequestDataSb.append(FormatUtil.getValueWithSpaces(date_time_received, 17)).append(Constants.TAB);
		selectRequestDataSb.append(FormatUtil.getValueWithSpaces(pon, 16)).append(Constants.TAB);
		selectRequestDataSb.append(FormatUtil.getValueWithSpaces(rver, 5)).append(Constants.TAB);
		selectRequestDataSb.append(FormatUtil.getValueWithSpaces(request_id, 18)).append(Constants.TAB);
		selectRequestDataSb.append(FormatUtil.getValueWithSpaces(reqtype, 2)).append(Constants.TAB);
		selectRequestDataSb.append(FormatUtil.getValueWithSpaces(status, 22)).append(Constants.TAB);
		selectRequestDataSb.append(FormatUtil.getValueWithSpaces(lspauth_attr, 1)).append(Constants.TAB);
		selectRequestDataSb.append(FormatUtil.getValueWithSpaces(lspauth, 4)).append(Constants.TAB);

		selectRequestDataSb.append(FormatUtil.getValueWithSpaces(cvoip, 1)).append(Constants.TAB);
		selectRequestDataSb.append(FormatUtil.getValueWithSpaces(aan, 13)).append(Constants.TAB);
		selectRequestDataSb.append(FormatUtil.getValueWithSpaces(atn, 10)).append(Constants.TAB);
		selectRequestDataSb.append(FormatUtil.getValueWithSpaces(natn, 10)).append(Constants.TAB);
		selectRequestDataSb.append(FormatUtil.getValueWithSpaces(nan, 10)).append(Constants.TAB);



		selectRequestDataSb.append(FormatUtil.getValueWithSpaces(an, 13)).append(Constants.TAB).append(Constants.TAB);

		String selectRequestDataString = FormatUtil.getValueWithSpaces(selectRequestDataSb.toString(), 2400);
		return selectRequestDataString;
		}
	
	
	
}
