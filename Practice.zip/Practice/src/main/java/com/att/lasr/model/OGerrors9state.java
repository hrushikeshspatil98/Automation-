package com.att.lasr.model;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@ToString
public class OGerrors9state {
	
	private String order_num;
	private String location;
	private String error_code;
	private String error_msg;


}
