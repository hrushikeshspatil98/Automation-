package com.att.lasr.model;

import java.util.ArrayList;
import java.util.List;

import com.att.lasr.utils.Constants;
import com.att.lasr.utils.FormatUtil;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@ToString
public class ConfirmedByEsddData {

	private Header header;
	private SubHeader subHeader;

	private String company_code;
	private String begindate;
	private String enddate;
	private String sc;
	private String total_record;
	private String start_page;
	private String end_page;
	private String prevnext_cde;
	private String begin_time_nextptr;
	private String end_time_nextptr;
	private String begin_time_prevptr;
	private String end_time_prevptr;

	private List<ConfirmedByEsddTableRow> ConfirmedByEsddTableRows = new ArrayList<>();

	public String getConfirmedByEsddDataString() {
		StringBuilder ConfirmedByEsddDataSb = new StringBuilder();
		ConfirmedByEsddDataSb.append(FormatUtil.getValueWithSpaces(company_code, 4)).append(Constants.TAB);
		ConfirmedByEsddDataSb.append(FormatUtil.getValueWithSpaces(FormatUtil.getMqDateFormatString(begindate), 8))
				.append(Constants.TAB);
		ConfirmedByEsddDataSb.append(FormatUtil.getValueWithSpaces(FormatUtil.getMqDateFormatString(enddate), 8))
				.append(Constants.TAB);
		ConfirmedByEsddDataSb.append(FormatUtil.getValueWithSpaces(sc, 2)).append(Constants.TAB);

		ConfirmedByEsddDataSb.append(FormatUtil.getValueWithSpaces(total_record, 6)).append(Constants.TAB);
		ConfirmedByEsddDataSb.append(FormatUtil.getValueWithSpaces(start_page, 3)).append(Constants.TAB);
		ConfirmedByEsddDataSb.append(FormatUtil.getValueWithSpaces(end_page, 3)).append(Constants.TAB);
		ConfirmedByEsddDataSb.append(FormatUtil.getValueWithSpaces(prevnext_cde, 1)).append(Constants.TAB);
		ConfirmedByEsddDataSb.append(FormatUtil.getValueWithSpaces(begin_time_nextptr, 26)).append(Constants.TAB);
		ConfirmedByEsddDataSb.append(FormatUtil.getValueWithSpaces(end_time_nextptr, 26)).append(Constants.TAB);

		ConfirmedByEsddDataSb.append(FormatUtil.getValueWithSpaces(begin_time_prevptr, 26)).append(Constants.TAB);
		ConfirmedByEsddDataSb.append(FormatUtil.getValueWithSpaces(end_time_prevptr, 26)).append(Constants.TAB)
				.append(Constants.TAB);

		String ConfirmedByEsddDataString = FormatUtil.getValueWithSpaces(ConfirmedByEsddDataSb.toString(), 2400);
		return ConfirmedByEsddDataString;
	}

}
