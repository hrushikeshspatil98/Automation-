/**
 * 
 */
package com.att.lasr.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

/**
 * @author SL625A
 *
 */
@Setter
@Getter
@NoArgsConstructor
@ToString

public class Correctingconfirmationtaskmain12states implements Serializable {
	private Header header;

	private SubHeader subHeader;
	
	private List<NotesFupBindingData12States> notesFupBindingData12States;
	private List<CorrectingConfirmationLS0G6DW1row> confirmationTask_RecId_850;
	private List<ConfirmationLS0G6DW3Row> confirmationTask_RecId_851;
	private List<Correcting_ConfirmationTask_RecId_858> confirmationTask_RecId_858;
	private List<CorrectingConfirmationLS0G6DW5row> confirmationTask_RecId_852;

}
