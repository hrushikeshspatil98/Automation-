package com.att.lasr.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.att.lasr.model.Confirmation101and102RequestTypeBRow;
import com.att.lasr.model.ConfirmationLS0G6DW1Row;
import com.att.lasr.model.ConfirmationLS0G6DW2Row;
import com.att.lasr.model.ConfirmationLS0G6DW3Row;
import com.att.lasr.model.ConfirmationNonProdLSOG6Row;
import com.att.lasr.model.ConfirmationReqtypBandC9StatesRowDW1;
import com.att.lasr.model.ConfirmationReqtypBandC9StatesRowDW5;
import com.att.lasr.model.ConfirmationReqtypJLSOG6102Row;
import com.att.lasr.model.ConfirmationReqtypRLSOG6102Row;
import com.att.lasr.model.EcverView;
import com.att.lasr.model.Header;
import com.att.lasr.model.MQReceivedData;
import com.att.lasr.model.NotesFupBindingData12States;
import com.att.lasr.model.ShowError;
import com.att.lasr.model.SubData;
import com.att.lasr.model.SubHeader;
import com.att.lasr.utils.MQMessageStringBuilder;
import com.att.lasr.utils.MQReadUtil;
import com.att.lasr.utils.MQWriteUtil;
import com.att.lasr.utils.enums.LastInd;
import com.att.lasr.utils.enums.LogInd;
import com.att.lasr.utils.enums.Process;
import com.att.lasr.utils.enums.ProcessGroupInd;
import com.att.lasr.utils.enums.ProcessMode;
import com.att.lasr.utils.enums.RecIdFor12State;
import com.att.lasr.utils.enums.RecIdFor9State;
import com.att.lasr.utils.enums.TabInd;

@Service
public class CorrectingConfViewService {

	@Autowired
	private MQReadUtil mqReadUtil;

	@Autowired
	private MQWriteUtil mqWriteUtil;

	List<ShowError> showUpdateErrorList = new ArrayList<ShowError>();

	public void writeEcverViewDataToMQ(EcverView ecverView, String userId, String object_handle, HttpSession session,
			String stateType) {
		System.out.println("In Corr.Conf View Service");
		// 049 RecId code
		@SuppressWarnings("unchecked")
		List<NotesFupBindingData12States> dataObject_049 = (List<NotesFupBindingData12States>) session
				.getAttribute("treeViewList_049");
		String numCount = getNumCount(1 + dataObject_049.size());
		System.err.println("numcount: " + numCount);
		Header header = prepareCorrConfViewHeader(userId, object_handle, numCount);
		StringBuilder subHeaderandData = new StringBuilder();

		String dataString = "";

		SubHeader subHeader = null;
		MQMessageStringBuilder mqMessageStringBuilder = new MQMessageStringBuilder();
		if (stateType.equalsIgnoreCase("12 States")) {
			subHeader = prepareCorrConfViewSubHeader(RecIdFor12State.CS_RECID_HEADER.getRecIdValue());

			for (NotesFupBindingData12States notesFupBindingData12States : dataObject_049) {

				session.setAttribute("Lrs_No", notesFupBindingData12States.getRequest_id().substring(0, 17).trim());
				dataString = notesFupBindingData12States.getNotesFupBindingData12String();
				subHeaderandData.append(mqMessageStringBuilder.addHeader(header));
				subHeaderandData
						.append(mqMessageStringBuilder.appendSubHeaderAndData(subHeader, dataString).toString());

			}
		} else {
			subHeader = prepareCorrConfViewSubHeader(RecIdFor9State.CS_RECID_HEADER.getRecIdValue());
			for (NotesFupBindingData12States notesFupBindingData9States : dataObject_049) {
				session.setAttribute("Lrs_No", notesFupBindingData9States.getRequest_id().substring(0, 17).trim());
				dataString = notesFupBindingData9States.getNotesFupBindingData9String();
				subHeaderandData.append(mqMessageStringBuilder.addHeader(header));
				subHeaderandData
						.append(mqMessageStringBuilder.appendSubHeaderAndData(subHeader, dataString).toString());

			}
		}

		subHeader = prepareCorrConfViewSubHeader(RecIdFor12State.CS_RECID_ISSUE_ECVER_VIEW.getRecIdValue());

		dataString = ecverView.getEcverViewString();
		subHeaderandData.append(mqMessageStringBuilder.appendSubHeaderAndData(subHeader, dataString));

		
		// boolean isWritten= false;
		boolean isWritten = mqWriteUtil.writeDataToMQ(mqMessageStringBuilder, session);

		if (isWritten) {

			MQReceivedData mqReceivedData=null;

			try {

				mqReceivedData = mqReadUtil.readSortDataFromMQ(session);
				long endTime = System.nanoTime() + TimeUnit.NANOSECONDS.convert(3L, TimeUnit.MINUTES);
				Map<String, SubData> subDatas = mqReceivedData.getSubDatas();
				// Header receivedHeader = mqReceivedData.getHeader();
				while (mqReceivedData.getHeader() == null && System.nanoTime() < endTime) {
					System.out.println("*************inside if*************** ");
					mqReceivedData = mqReadUtil.readSortDataFromMQ(session);
				}

				System.out.println(mqReceivedData.getHeader().toString());
			} catch (Exception e) {
				// TODO Auto-generated catch block
				//mqReceivedData = mqReadUtil.readDataFromMQ(session);
				e.printStackTrace();

			}

			Map<String, SubData> subDatas = mqReceivedData.getSubDatas();
			Header receivedHeader = mqReceivedData.getHeader();
			System.out.println("mqReceivedData in ecver: " + mqReceivedData.toString());
			
			//SubData subData = subDatas.get(RecIdFor12State.CS_RECID_ERROR.getRecIdValue());
			//SubData subData_542 = subDatas.get(RecIdFor12State.CS_RECID_ISSUE_ECVER_VIEW.getRecIdValue());
			
			if (stateType.equalsIgnoreCase("12 States")) {
				if(session.getAttribute("treeview_880")!= null) {
					session.removeAttribute("treeview_880");
				}
				if(session.getAttribute("treeView881")!= null) {
					session.removeAttribute("treeView881");
				}
				if(session.getAttribute("treeview_882")!= null) {
					session.removeAttribute("treeview_882");
				}
				if(session.getAttribute("treeview_883")!= null) {
					session.removeAttribute("treeview_883");
				}
				if(session.getAttribute("treeview_884")!= null) {
					session.removeAttribute("treeview_884");
				}
				if(session.getAttribute("treeview_886")!= null) {
					session.removeAttribute("treeview_886");
				}
				if(session.getAttribute("treeview_887")!= null) {
					session.removeAttribute("treeview_887");
				}
				if(session.getAttribute("treeview_888")!= null) {
					session.removeAttribute("treeview_888");
				}
				
			} 
			else {
				if(session.getAttribute("treeview880")!= null) {
					session.removeAttribute("treeview880");
				}
				if(session.getAttribute("treeview882")!= null) {
					session.removeAttribute("treeview882");
				}
				if(session.getAttribute("treeview_886")!= null) {
					session.removeAttribute("treeview_886");
				}
				if(session.getAttribute("treeview888")!= null) {
					session.removeAttribute("treeview888");
				} 
			}
			
			ReadErrorMsgsJson readErrorMsgsJson = new ReadErrorMsgsJson();
			

			if (receivedHeader.getReturn_code() != null && receivedHeader.getReturn_code().equals("000")) {
				
			}

			if (receivedHeader.getReturn_code() != null && receivedHeader.getReturn_code().equals("999")) {

			}
			
			if (receivedHeader.getReturn_code() != null && receivedHeader.getReturn_code().equals("889")) {

				String err_ecver = readErrorMsgsJson.getErrorMsg("LG0067");
				session.setAttribute("err_ecver", err_ecver);

			}
			if (receivedHeader.getReturn_code() != null && receivedHeader.getReturn_code().equals("888")) {

				String err_ecver = readErrorMsgsJson.getErrorMsg("LG0022");
				session.setAttribute("err_ecver", err_ecver);

			}

			if (stateType.equalsIgnoreCase("12 States")) {

				SubData subData_880 = subDatas.get(RecIdFor12State.CS_RECID_DISPLAY_CONFIRM_FIX_V6.getRecIdValue());
				SubData subData_881 = subDatas.get(RecIdFor12State.CS_RECID_DISPLAY_CONFIRM_HUNT_V6.getRecIdValue());
				SubData subData_882 = subDatas.get(RecIdFor12State.CS_RECID_DISPLAY_CONFIRM_DTL_V6.getRecIdValue());
				SubData subData_883 = subDatas.get(RecIdFor12State.CS_RECID_DISPLAY_CONFIRM_ACTR_V6.getRecIdValue());
				SubData subData_884 = subDatas.get(RecIdFor12State.CS_RECID_DISPLAY_CONFIRM_DIR_V6.getRecIdValue());
				SubData subData_886 = subDatas.get(RecIdFor12State.CS_RECID_DISPLAY_CONFIRM_NOPROD_V6.getRecIdValue());
				SubData subData_887 = subDatas.get(RecIdFor12State.CS_RECID_DISPLAY_CONFIRM_ACTR_LSC_V6.getRecIdValue());
				SubData subData_888 = subDatas.get(RecIdFor12State.CS_RECID_DISPLAY_CONFIRM_REQORD_V6.getRecIdValue());

				if (subData_880 != null && subData_880.getSubHeader().getRecord_type().equals("880")) {
					String[] subDataRows = subData_880.getSubDataRows();
					List<ConfirmationLS0G6DW1Row> treeview_880 = new ArrayList<ConfirmationLS0G6DW1Row>();
					for (String subDataRow : subDataRows) {
						String[] attributes = mqReadUtil.getAttributes(subDataRow, 20);
						System.err.println("attributes:=880======> " + Arrays.toString(attributes));
						ConfirmationLS0G6DW1Row confirmationLS0G6DW1Row = new ConfirmationLS0G6DW1Row();

						confirmationLS0G6DW1Row.setA_cver(attributes[0]);
						confirmationLS0G6DW1Row.setA_atn_attr(attributes[1]);
						confirmationLS0G6DW1Row.setA_atn(attributes[2]);
						confirmationLS0G6DW1Row.setA_init(attributes[3]);
						confirmationLS0G6DW1Row.setA_rep(attributes[4]);
						confirmationLS0G6DW1Row.setA_tel_no(attributes[5]);
						confirmationLS0G6DW1Row.setA_rt(attributes[6]);
						confirmationLS0G6DW1Row.setA_ecver(attributes[7]);
						confirmationLS0G6DW1Row.setA_d_t_sent_local(attributes[8]);
						confirmationLS0G6DW1Row.setA_response_d_t_sent_cent_time(attributes[9]);
						confirmationLS0G6DW1Row.setA_pia(attributes[10]);
						confirmationLS0G6DW1Row.setA_chc(attributes[11]);
						confirmationLS0G6DW1Row.setA_fdt_attr(attributes[12]);
						confirmationLS0G6DW1Row.setA_fdt(attributes[13]);
						confirmationLS0G6DW1Row.setA_dd_att(attributes[14]);
						confirmationLS0G6DW1Row.setA_dd(attributes[15]);
						confirmationLS0G6DW1Row.setApp_time_attr(attributes[16]);
						confirmationLS0G6DW1Row.setApptime(attributes[17]);
						confirmationLS0G6DW1Row.setA_an_attr(attributes[18]);
						confirmationLS0G6DW1Row.setA_an(attributes[19]);

						treeview_880.add(confirmationLS0G6DW1Row);

					}
					session.setAttribute("treeview_880", treeview_880);
				}
				
				if (subData_881 != null && subData_881.getSubHeader().getRecord_type().equals("881")) {
					String[] subDataRows = subData_881.getSubDataRows();
					List<ConfirmationLS0G6DW3Row> treeView881 = new ArrayList<ConfirmationLS0G6DW3Row>();
					for (String subDataRow : subDataRows) {
						String[] attributes = mqReadUtil.getAttributes(subDataRow, 6);
						System.err.println("attributes:=881======> " + Arrays.toString(attributes));
						ConfirmationLS0G6DW3Row confirmationLS0G6DW3Row = new ConfirmationLS0G6DW3Row();
						confirmationLS0G6DW3Row.setItem_num(attributes[0]);
						confirmationLS0G6DW3Row.setHnum(attributes[1]);
						confirmationLS0G6DW3Row.setHid_attr(attributes[2]);
						confirmationLS0G6DW3Row.setHid(attributes[3]);
						confirmationLS0G6DW3Row.setHunt_tli_attr(attributes[4]);
					
						confirmationLS0G6DW3Row.setHunt_tli(attributes[5]);
				
						treeView881.add(confirmationLS0G6DW3Row);

					}
					session.setAttribute("treeView881", treeView881);
				}

				

				if (subData_882 != null && subData_882.getSubHeader().getRecord_type().equals("882")) {
					String[] subDataRows = subData_882.getSubDataRows();
					List<Confirmation101and102RequestTypeBRow> treeview_882 = new ArrayList<Confirmation101and102RequestTypeBRow>();
					for (String subDataRow : subDataRows) {
						String[] attributes = mqReadUtil.getAttributes(subDataRow, 42);
						System.err.println("attributes:=882======> " + Arrays.toString(attributes));
						Confirmation101and102RequestTypeBRow confirmation101and102RequestTypeBData = new Confirmation101and102RequestTypeBRow();

						confirmation101and102RequestTypeBData.setItemnum(attributes[0]);
						confirmation101and102RequestTypeBData.setLnum(attributes[1]);
						confirmation101and102RequestTypeBData.setNumname(attributes[2]);
						confirmation101and102RequestTypeBData.setNum_nbr(attributes[3]);
						confirmation101and102RequestTypeBData.setOrd_attr(attributes[4]);
						confirmation101and102RequestTypeBData.setOrd(attributes[5]);
						confirmation101and102RequestTypeBData.setLord_attr(attributes[6]);
						confirmation101and102RequestTypeBData.setLord(attributes[7]);
						confirmation101and102RequestTypeBData.setFdt_attr(attributes[8]);
						confirmation101and102RequestTypeBData.setFdt(attributes[9]);
						confirmation101and102RequestTypeBData.setDd_attr(attributes[10]);
						confirmation101and102RequestTypeBData.setDd(attributes[11]);
						confirmation101and102RequestTypeBData.setEcckt_attr(attributes[12]);
						confirmation101and102RequestTypeBData.setEcckt(attributes[13]);
						confirmation101and102RequestTypeBData.setCkr(attributes[14]);
						confirmation101and102RequestTypeBData.setShared_nbr(attributes[15]);
						confirmation101and102RequestTypeBData.setDisc_nbr(attributes[16]);
						confirmation101and102RequestTypeBData.setRecckt(attributes[17]);
						confirmation101and102RequestTypeBData.setTns_attr(attributes[18]);
						confirmation101and102RequestTypeBData.setTns(attributes[19]);
						confirmation101and102RequestTypeBData.setTers_attr(attributes[20]);
						confirmation101and102RequestTypeBData.setTers(attributes[21]);
						confirmation101and102RequestTypeBData.setCfa(attributes[22]);
						confirmation101and102RequestTypeBData.setCcea(attributes[23]);
						confirmation101and102RequestTypeBData.setIspid_attr(attributes[24]);
						confirmation101and102RequestTypeBData.setIspid(attributes[25]);
						confirmation101and102RequestTypeBData.setFecckt_attr(attributes[26]);
						confirmation101and102RequestTypeBData.setFecckt(attributes[27]);
						confirmation101and102RequestTypeBData.setNpord_attr(attributes[28]);
						confirmation101and102RequestTypeBData.setNpord(attributes[29]);
						confirmation101and102RequestTypeBData.setPorted_nbr(attributes[30]);
						confirmation101and102RequestTypeBData.setRti_attr(attributes[31]);
						confirmation101and102RequestTypeBData.setRti(attributes[32]);
						confirmation101and102RequestTypeBData.setCbcid_attr(attributes[33]);
						confirmation101and102RequestTypeBData.setCbcid(attributes[34]);
						confirmation101and102RequestTypeBData.setCableid_attr(attributes[35]);
						confirmation101and102RequestTypeBData.setCableid(attributes[36]);
						confirmation101and102RequestTypeBData.setChan_pair_attr(attributes[37]);
						confirmation101and102RequestTypeBData.setChain_pair(attributes[38]);
						confirmation101and102RequestTypeBData.setOld_ord(attributes[39]);
						confirmation101and102RequestTypeBData.setOld_lord(attributes[40]);
						confirmation101and102RequestTypeBData.setOld_npord(attributes[41]);

						treeview_882.add(confirmation101and102RequestTypeBData);
					}
					session.setAttribute("treeview_882", treeview_882);

				}
				
				if (subData_883 != null && subData_883.getSubHeader().getRecord_type().equals("883")) {

					String[] subDataRows = subData_883.getSubDataRows();

					List<ConfirmationReqtypRLSOG6102Row> treeview_883 = new ArrayList<ConfirmationReqtypRLSOG6102Row>();
					for (String subDataRow : subDataRows) {
						String[] attributes = mqReadUtil.getAttributes(subDataRow, 7);
						System.out.println("attributes:=883======> " + Arrays.toString(attributes));
						ConfirmationReqtypRLSOG6102Row confirmationReqtypRLSOG6102Row = new ConfirmationReqtypRLSOG6102Row();

						confirmationReqtypRLSOG6102Row.setCver(attributes[0]);
						confirmationReqtypRLSOG6102Row.setAtn(attributes[1]);
						confirmationReqtypRLSOG6102Row.setRt(attributes[2]);
						confirmationReqtypRLSOG6102Row.setEcver(attributes[3]);
						confirmationReqtypRLSOG6102Row.setD_t_sent_local(attributes[4]);
						confirmationReqtypRLSOG6102Row.setResponse_d_t_sent_central_time(attributes[5]);
						confirmationReqtypRLSOG6102Row.setAn(attributes[6]);

						treeview_883.add(confirmationReqtypRLSOG6102Row);
					}
					session.setAttribute("treeview_883", treeview_883);
				}
				
				if (subData_884 != null && subData_884.getSubHeader().getRecord_type().equals("884")) {
					String[] subDataRows = subData_884.getSubDataRows();
					List<ConfirmationReqtypJLSOG6102Row> treeview_884 = new ArrayList<ConfirmationReqtypJLSOG6102Row>();
					for (String subDataRow : subDataRows) {
						String[] attributes = mqReadUtil.getAttributes(subDataRow, 10);
						System.out.println("attributes:=884======> " + Arrays.toString(attributes));
						ConfirmationReqtypJLSOG6102Row confirmationReqtypJLSOG6102Row = new ConfirmationReqtypJLSOG6102Row();

						confirmationReqtypJLSOG6102Row.setCver(attributes[0]);
						confirmationReqtypJLSOG6102Row.setDor(attributes[1]);
						confirmationReqtypJLSOG6102Row.setAtn(attributes[2]);
						confirmationReqtypJLSOG6102Row.setDinit(attributes[3]);
						confirmationReqtypJLSOG6102Row.setDda(attributes[4]);
						confirmationReqtypJLSOG6102Row.setRt(attributes[5]);
						confirmationReqtypJLSOG6102Row.setEcver(attributes[6]);
						confirmationReqtypJLSOG6102Row.setD_t_sent_local(attributes[7]);
						confirmationReqtypJLSOG6102Row.setResponse_d_t_sent_central_time(attributes[8]);
						confirmationReqtypJLSOG6102Row.setAn(attributes[9]);

						treeview_884.add(confirmationReqtypJLSOG6102Row);

					}
					session.setAttribute("treeview_884", treeview_884);
					
				}
				
				if (subData_886 != null && subData_886.getSubHeader().getRecord_type().equals("886")) {
					String[] subDataRows = subData_886.getSubDataRows();
					List<ConfirmationNonProdLSOG6Row> treeview_886 = new ArrayList<ConfirmationNonProdLSOG6Row>();
					for (String subDataRow : subDataRows) {
						String[] attributes = mqReadUtil.getAttributes(subDataRow, 14);
						System.err.println("attributes:=886======> " + Arrays.toString(attributes));
						ConfirmationNonProdLSOG6Row confirmationNonProdLSOG6Row = new ConfirmationNonProdLSOG6Row();

						confirmationNonProdLSOG6Row.setCver(attributes[0]);
						confirmationNonProdLSOG6Row.setSvc_rep_tn(attributes[1]);
						confirmationNonProdLSOG6Row.setSvc_rep(attributes[2]);
						confirmationNonProdLSOG6Row.setAtn_attr(attributes[3]);
						confirmationNonProdLSOG6Row.setAtn(attributes[4]);
						confirmationNonProdLSOG6Row.setRt(attributes[5]);
						confirmationNonProdLSOG6Row.setEcver(attributes[6]);
						confirmationNonProdLSOG6Row.setD_t_sent_local(attributes[7]);
						confirmationNonProdLSOG6Row.setResponse_d_t_sent_central_time(attributes[8]);
						confirmationNonProdLSOG6Row.setDd_attr(attributes[9]);
						confirmationNonProdLSOG6Row.setDd(attributes[10]);
						confirmationNonProdLSOG6Row.setPia(attributes[11]);
						confirmationNonProdLSOG6Row.setAn_attr(attributes[12]);
						confirmationNonProdLSOG6Row.setAn(attributes[13]);

						treeview_886.add(confirmationNonProdLSOG6Row);

					}
					session.setAttribute("treeview_886", treeview_886);

				}


				if (subData_887 != null && subData_887.getSubHeader().getRecord_type().equals("887")) {

					String[] subDataRows = subData_887.getSubDataRows();

					List<ConfirmationLS0G6DW2Row> treeview_887 = new ArrayList<ConfirmationLS0G6DW2Row>();
					for (String subDataRow : subDataRows) {
						String[] attributes = mqReadUtil.getAttributes(subDataRow, 14);
						System.out.println("attributes:=887======> " + Arrays.toString(attributes));
						ConfirmationLS0G6DW2Row confirmationLS0G6DW2Row = new ConfirmationLS0G6DW2Row();
						confirmationLS0G6DW2Row.setOrd(attributes[0]);
						confirmationLS0G6DW2Row.setOld_dtm(attributes[1]);
						confirmationLS0G6DW2Row.setOld_ord(attributes[2]);
						confirmationLS0G6DW2Row.setOrd_attr(attributes[3]);

						confirmationLS0G6DW2Row.setFdt_attr(attributes[4]);
						confirmationLS0G6DW2Row.setFdt(attributes[5]);
						confirmationLS0G6DW2Row.setDd_attr(attributes[6]);
						confirmationLS0G6DW2Row.setDd_attr(attributes[7]);
						confirmationLS0G6DW2Row.setComp_dt_attr(attributes[8]);
						confirmationLS0G6DW2Row.setComp_dt(attributes[9]);
						confirmationLS0G6DW2Row.setPosted_date_attr(attributes[0]);
						confirmationLS0G6DW2Row.setPosted_date(attributes[11]);
						confirmationLS0G6DW2Row.setApptime_attr(attributes[12]);
						confirmationLS0G6DW2Row.setApptime(attributes[13]);

						treeview_887.add(confirmationLS0G6DW2Row);
					}
					session.setAttribute("treeview_887", treeview_887);
				}

				if (subData_888 != null && subData_888.getSubHeader().getRecord_type().equals("888")) {
					String[] subDataRows = subData_888.getSubDataRows();
					List<ConfirmationLS0G6DW2Row> treeview_888 = new ArrayList<ConfirmationLS0G6DW2Row>();
					for (String subDataRow : subDataRows) {
						String[] attributes = mqReadUtil.getAttributes(subDataRow, 14);
						System.err.println("attributes:=888======> " + Arrays.toString(attributes));
						ConfirmationLS0G6DW2Row confirmationLS0G6DW2Row = new ConfirmationLS0G6DW2Row();

						confirmationLS0G6DW2Row.setOld_dtm(attributes[0]);
						confirmationLS0G6DW2Row.setOld_ord(attributes[1]);
						confirmationLS0G6DW2Row.setOrd_attr(attributes[2]);
						confirmationLS0G6DW2Row.setOrd(attributes[3]);
						confirmationLS0G6DW2Row.setFdt_attr(attributes[4]);
						confirmationLS0G6DW2Row.setFdt(attributes[5]);
						confirmationLS0G6DW2Row.setDd_attr(attributes[6]);
						confirmationLS0G6DW2Row.setDd(attributes[7]);
						confirmationLS0G6DW2Row.setComp_dt_attr(attributes[8]);
						confirmationLS0G6DW2Row.setComp_dt(attributes[9]);
						confirmationLS0G6DW2Row.setPosted_date_attr(attributes[10]);
						confirmationLS0G6DW2Row.setPosted_date(attributes[11]);
						confirmationLS0G6DW2Row.setApptime_attr(attributes[12]);
						confirmationLS0G6DW2Row.setApptime(attributes[13]);

						treeview_888.add(confirmationLS0G6DW2Row);

					}
					session.setAttribute("treeview_888", treeview_888);
				}
	 

			} 
			else {
				
				SubData subData_880 = subDatas.get(RecIdFor9State.CS_RECID_DISPLAY_CONFIRM_FIX_V6.getRecIdValue());
				SubData subData_888 = subDatas.get(RecIdFor9State.CS_RECID_DISPLAY_CONFIRM_REQORD_V6.getRecIdValue());
				SubData subData_882 = subDatas.get(RecIdFor9State.CS_RECID_DISPLAY_CONFIRM_DTL_V6.getRecIdValue());
				SubData subData_886 = subDatas.get(RecIdFor9State.CS_RECID_DISPLAY_CONFIRM_NOPROD_V6.getRecIdValue());
				
				if (subData_880 != null && subData_880.getSubHeader().getRecord_type().equals("880")) {
					String[] subDataRows = subData_880.getSubDataRows();
					List<ConfirmationReqtypBandC9StatesRowDW1> treeview880 = new ArrayList<ConfirmationReqtypBandC9StatesRowDW1>();
					for (String subDataRow : subDataRows) {
						String[] attributes = mqReadUtil.getAttributes(subDataRow, 27);
						 System.out.println("subData_880Recid:=======> " + Arrays.toString(attributes));
						ConfirmationReqtypBandC9StatesRowDW1 confirmationReqtypBandC9StatesRowDW1 = new ConfirmationReqtypBandC9StatesRowDW1();

						confirmationReqtypBandC9StatesRowDW1.setA_cver(attributes[0]);
						confirmationReqtypBandC9StatesRowDW1.setA_atn_attr(attributes[1]);
						confirmationReqtypBandC9StatesRowDW1.setA_atn(attributes[2]);
						confirmationReqtypBandC9StatesRowDW1.setA_init_attr(attributes[3]);
						confirmationReqtypBandC9StatesRowDW1.setA_init(attributes[4]);
						confirmationReqtypBandC9StatesRowDW1.setA_rep(attributes[5]);
						confirmationReqtypBandC9StatesRowDW1.setA_tel_no(attributes[6]);
						confirmationReqtypBandC9StatesRowDW1.setA_rt(attributes[7]);
						confirmationReqtypBandC9StatesRowDW1.setA_ecver(attributes[8]);

						confirmationReqtypBandC9StatesRowDW1.setA_d_t_sent_local(attributes[9]);
						confirmationReqtypBandC9StatesRowDW1.setA_response_d_t_sent_cent_time(attributes[10]);
						confirmationReqtypBandC9StatesRowDW1.setA_pia(attributes[11]);
						confirmationReqtypBandC9StatesRowDW1.setA_chc(attributes[12]);
						confirmationReqtypBandC9StatesRowDW1.setA_fdt_attr(attributes[13]);
						confirmationReqtypBandC9StatesRowDW1.setA_fdt(attributes[14]);
						confirmationReqtypBandC9StatesRowDW1.setA_dd_attr(attributes[15]);
						confirmationReqtypBandC9StatesRowDW1.setA_dd(attributes[16]);
						confirmationReqtypBandC9StatesRowDW1.setApptime_attr(attributes[17]);
						confirmationReqtypBandC9StatesRowDW1.setApptime(attributes[18]);
						confirmationReqtypBandC9StatesRowDW1.setEbd_attr(attributes[19]);
						confirmationReqtypBandC9StatesRowDW1.setEbd(attributes[20]);
						confirmationReqtypBandC9StatesRowDW1.setBan1_attr(attributes[21]);
						confirmationReqtypBandC9StatesRowDW1.setBan1(attributes[22]);
						confirmationReqtypBandC9StatesRowDW1.setBan2_attr(attributes[23]);
						confirmationReqtypBandC9StatesRowDW1.setBan2(attributes[24]);
						confirmationReqtypBandC9StatesRowDW1.setA_an_attr(attributes[25]);
						confirmationReqtypBandC9StatesRowDW1.setA_an(attributes[26]);

						treeview880.add(confirmationReqtypBandC9StatesRowDW1);


					}

					session.setAttribute("treeview880", treeview880);

				}

				if (subData_882!= null && subData_882.getSubHeader().getRecord_type().equals("882")) {
					String[] subDataRows = subData_882.getSubDataRows();
					List<ConfirmationReqtypBandC9StatesRowDW5> treeview882 = new ArrayList<ConfirmationReqtypBandC9StatesRowDW5>();
					for (String subDataRow : subDataRows) {
						String[] attributes = mqReadUtil.getAttributes(subDataRow, 43);
						 System.out.println("attributes:=882======> " + Arrays.toString(attributes));
						ConfirmationReqtypBandC9StatesRowDW5 confirmationReqtypBandC9StatesRowDW5 = new ConfirmationReqtypBandC9StatesRowDW5();

						confirmationReqtypBandC9StatesRowDW5.setItemnum(attributes[0]);
						confirmationReqtypBandC9StatesRowDW5.setLnum(attributes[1]);
						confirmationReqtypBandC9StatesRowDW5.setNumname(attributes[2]);
						confirmationReqtypBandC9StatesRowDW5.setNum_nbr(attributes[3]);
						confirmationReqtypBandC9StatesRowDW5.setOrd_attr(attributes[4]);
						confirmationReqtypBandC9StatesRowDW5.setOrd(attributes[5]);
						confirmationReqtypBandC9StatesRowDW5.setLord_attr(attributes[6]);
						confirmationReqtypBandC9StatesRowDW5.setLord(attributes[7]);
						confirmationReqtypBandC9StatesRowDW5.setFdt_attr(attributes[8]);
						confirmationReqtypBandC9StatesRowDW5.setFdt(attributes[9]);
						confirmationReqtypBandC9StatesRowDW5.setDd_attr(attributes[10]);
						confirmationReqtypBandC9StatesRowDW5.setDd(attributes[11]);
						confirmationReqtypBandC9StatesRowDW5.setEcckt_attr(attributes[12]);
						confirmationReqtypBandC9StatesRowDW5.setEcckt(attributes[13]);
						confirmationReqtypBandC9StatesRowDW5.setCkr(attributes[14]);
						confirmationReqtypBandC9StatesRowDW5.setShared_nbr(attributes[15]);
						confirmationReqtypBandC9StatesRowDW5.setDisc_nbr(attributes[16]);
						confirmationReqtypBandC9StatesRowDW5.setRecckt(attributes[17]);
						confirmationReqtypBandC9StatesRowDW5.setTns_attr(attributes[18]);
						confirmationReqtypBandC9StatesRowDW5.setTns(attributes[19]);
						confirmationReqtypBandC9StatesRowDW5.setTers_attr(attributes[20]);
						confirmationReqtypBandC9StatesRowDW5.setTers(attributes[21]);
						confirmationReqtypBandC9StatesRowDW5.setCfa(attributes[22]);
						confirmationReqtypBandC9StatesRowDW5.setCcea(attributes[23]);
						confirmationReqtypBandC9StatesRowDW5.setIspid_attr(attributes[24]);
						confirmationReqtypBandC9StatesRowDW5.setIspid(attributes[25]);
						confirmationReqtypBandC9StatesRowDW5.setFecckt_attr(attributes[26]);
						confirmationReqtypBandC9StatesRowDW5.setFecckt(attributes[27]);
						confirmationReqtypBandC9StatesRowDW5.setNpord_attr(attributes[28]);
						confirmationReqtypBandC9StatesRowDW5.setNpord(attributes[29]);
						confirmationReqtypBandC9StatesRowDW5.setPorted_nbr(attributes[30]);
						confirmationReqtypBandC9StatesRowDW5.setRti_attr(attributes[31]);
						confirmationReqtypBandC9StatesRowDW5.setRti(attributes[32]);
						confirmationReqtypBandC9StatesRowDW5.setCbcid_attr(attributes[33]);
						confirmationReqtypBandC9StatesRowDW5.setCbcid(attributes[34]);
						confirmationReqtypBandC9StatesRowDW5.setCableid_attr(attributes[35]);
						confirmationReqtypBandC9StatesRowDW5.setCableid(attributes[36]);
						confirmationReqtypBandC9StatesRowDW5.setChan_pair_attr(attributes[37]);
						confirmationReqtypBandC9StatesRowDW5.setChain_pair(attributes[38]);
						confirmationReqtypBandC9StatesRowDW5.setOld_ord(attributes[39]);
						confirmationReqtypBandC9StatesRowDW5.setOld_lord(attributes[40]);
						confirmationReqtypBandC9StatesRowDW5.setOld_npord(attributes[41]);
						;

						confirmationReqtypBandC9StatesRowDW5.setLoc_seq_num(attributes[42]);
						treeview882.add(confirmationReqtypBandC9StatesRowDW5);

					}
					session.setAttribute("treeview882", treeview882);

				}
				
				if (subData_886 != null && subData_886.getSubHeader().getRecord_type().equals("886")) {
					String[] subDataRows = subData_886.getSubDataRows();

					List<ConfirmationNonProdLSOG6Row> treeview_886 = new ArrayList<ConfirmationNonProdLSOG6Row>();
					for (String subDataRow : subDataRows) {
						String[] attributes = mqReadUtil.getAttributes(subDataRow, 14);
						 System.out.println("attributes:=886======> " + Arrays.toString(attributes));
						ConfirmationNonProdLSOG6Row confirmationNonProdLSOG6Row = new ConfirmationNonProdLSOG6Row();

						confirmationNonProdLSOG6Row.setCver(attributes[0]);
						confirmationNonProdLSOG6Row.setSvc_rep_tn(attributes[1]);
						confirmationNonProdLSOG6Row.setSvc_rep(attributes[2]);
						confirmationNonProdLSOG6Row.setAtn_attr(attributes[3]);
						confirmationNonProdLSOG6Row.setAtn(attributes[4]);
						confirmationNonProdLSOG6Row.setRt(attributes[5]);
						confirmationNonProdLSOG6Row.setEcver(attributes[6]);
						confirmationNonProdLSOG6Row.setD_t_sent_local(attributes[7]);
						confirmationNonProdLSOG6Row.setResponse_d_t_sent_central_time(attributes[8]);
						confirmationNonProdLSOG6Row.setDd_attr(attributes[9]);
						confirmationNonProdLSOG6Row.setDd(attributes[10]);
						confirmationNonProdLSOG6Row.setPia(attributes[11]);
						confirmationNonProdLSOG6Row.setAn_attr(attributes[12]);
						confirmationNonProdLSOG6Row.setAn(attributes[13]);

						treeview_886.add(confirmationNonProdLSOG6Row);

					}
					session.setAttribute("treeview_886", treeview_886);

				}

				if (subData_888!= null && subData_888.getSubHeader().getRecord_type().equals("888")) {
					String[] subDataRows = subData_888.getSubDataRows();
					List<ConfirmationLS0G6DW2Row> treeview888 = new ArrayList<ConfirmationLS0G6DW2Row>();
					for (String subDataRow : subDataRows) {
						String[] attributes = mqReadUtil.getAttributes(subDataRow, 14);
						 System.out.println("attributes:=888======> " + Arrays.toString(attributes));
						ConfirmationLS0G6DW2Row confirmationLS0G6DW2Row = new ConfirmationLS0G6DW2Row();

						confirmationLS0G6DW2Row.setOld_dtm(attributes[0]);
						confirmationLS0G6DW2Row.setOld_ord(attributes[1]);
						confirmationLS0G6DW2Row.setOrd_attr(attributes[2]);
						confirmationLS0G6DW2Row.setOrd(attributes[3]);
						confirmationLS0G6DW2Row.setFdt_attr(attributes[4]);
						confirmationLS0G6DW2Row.setFdt(attributes[5]);
						confirmationLS0G6DW2Row.setDd_attr(attributes[6]);
						confirmationLS0G6DW2Row.setDd(attributes[7]);
						confirmationLS0G6DW2Row.setComp_dt_attr(attributes[8]);
						confirmationLS0G6DW2Row.setComp_dt(attributes[9]);
						confirmationLS0G6DW2Row.setPosted_date_attr(attributes[10]);
						confirmationLS0G6DW2Row.setPosted_date(attributes[11]);
						confirmationLS0G6DW2Row.setApptime_attr(attributes[12]);
						confirmationLS0G6DW2Row.setApptime(attributes[13]);

						treeview888.add(confirmationLS0G6DW2Row);

					}
					session.setAttribute("treeview888", treeview888);
				}

				

			}

		}

		
	}

	private SubHeader prepareCorrConfViewSubHeader(String recId) {

		// Prepare SubHeader
		SubHeader subHeader = new SubHeader();

		subHeader.setLast_ind(LastInd.Y.name());
		subHeader.setProcess_mode(ProcessMode.CS_SPECIAL.getProcessModeCode());
		subHeader.setRecord_type(recId);
		subHeader.setReturn_code(null);
		subHeader.setDw_rownum(null);
		subHeader.setEcver(null);

		return subHeader;
	}

	private Header prepareCorrConfViewHeader(String user_id, String object_handle, String numCount) {
		// Prepare Header
		Header header = new Header();

		header.setUser_id(user_id);
		header.setProcess(Process.CS_REQUEST.getProcessCode());
		header.setTab_ind(TabInd.ECVER_ISSUE.getTabIndCode());
		header.setProcess_group_ind(ProcessGroupInd.ECVER_IND.getProcessGroupInd());
		header.setObject_handle(object_handle);
		header.setObject_handle2(null);
		header.setLog_ind(LogInd.N.name());
		header.setStarttime(null);
		header.setEndtime(null);
		header.setGuid(null);
		header.setSession_trans_count("0000001");
		header.setHost_trans_seq(null);
		header.setReturn_code(null);
		header.setRead_only_ind(null);
		header.setNum_detail(numCount);
		header.setRead_only_user_id(null);
		header.setLasrversion(null);

		return header;
	}

	private String getNumCount(int size) {
		String numCount = String.format("%04d", size);
		return numCount;
	}

}
