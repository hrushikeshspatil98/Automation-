package com.att.lasr.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.SessionAttributes;

import com.att.lasr.model.EnvRegion;
import com.att.lasr.model.RestrictedMismatchData12states;
import com.att.lasr.model.UnrestrictedMismatchData12states;
import com.att.lasr.service.RestrictedMismatchData12statesService;
import com.att.lasr.service.UnRestrictedMismatchData12statesService;
import com.att.lasr.utils.MockDtoDataUtil;
import com.google.gson.Gson;

@Controller
@SessionAttributes("region")
public class MismatchController {

	@Autowired
	HttpSession httpSession;

	@Autowired
	public MismatchController mismatchCtrl;

	@Autowired
	public WorkloadController workloadCtrl;
	
	@Autowired
	EnvRegionController envRegionCtrl;

	@Autowired
	private RestrictedMismatchData12statesService restrictedMismatchData12statesService;

	@Autowired
	private UnRestrictedMismatchData12statesService unRestrictedMismatchData12statesService;

//	EnvRegion e = EnvRegionController.getobj();

	@RequestMapping(value = "/restrictedMismatch", method = RequestMethod.GET)
	public String showEnhancedSelReqPage(ModelMap model, HttpSession session) {
		System.out.println("in /restrictedMismatch get method");
		EnvRegion e = envRegionCtrl.getEnvRegion(session);
		String userId = (String) httpSession.getAttribute("userId");
		String environment = (String) session.getAttribute("environment");
		model.addAttribute("userId", userId);
		model.addAttribute("environment", environment);
//		EnvRegion e = envRegionCtrl.getEnvRegionFromSession(session,model);
		model.addAttribute("envregion", e);
		model.addAttribute("screenObj", workloadCtrl.screenObj);
		model.addAttribute("indicator",false)	;
		model.addAttribute("indicator1",false)	;
		model.addAttribute("indicator2",false)	;
		model.addAttribute("indicator3",false)	;
		model.addAttribute("indicator4",false) ;
		model.addAttribute("navbarArr", session.getAttribute("navBarArr"));
		String currInde = "";
		Object currInd = session.getAttribute("currentPageIndex");
		if (!(currInd == null)) {
			currInde = currInd.toString();
			System.out.println("session -->" + session.getAttribute("currentPageIndex"));
			System.out.println("currInde" + currInde);
		}

		int currIndex = 0;
		if (!checkNullString(currInde)) {
			currIndex = Integer.parseInt(currInde);
			session.setAttribute("currentPageIndex", currIndex + "");
		}
		RestrictedMismatchData12states restrictedMismatchDto = getrestrictedMismatchDataFromSession(session, currIndex);
		//System.out.println("data to display-->" + restrictedMismatchDto.getRestrictedMisTableRows12states().size());
		model.addAttribute("restrictedMismatchData", restrictedMismatchDto);

		return "restrictedMismatch";
	}

	private RestrictedMismatchData12states getrestrictedMismatchDataFromSession(HttpSession session, int currIndex) {

		RestrictedMismatchData12states restrictedMismatchData = new RestrictedMismatchData12states();
		try {

			List<RestrictedMismatchData12states> restrictedMismatchDatalist = (List<RestrictedMismatchData12states>) session
					.getAttribute("restrictedMismatchDatalist");
			System.out.println("restrictedMismatchDatalist size-->" + restrictedMismatchDatalist.size());
			return restrictedMismatchDatalist.get(currIndex);
		} catch (Exception e) {
			System.out.println("got exception" + e.getMessage());
			return restrictedMismatchData;
		}

	}

	@RequestMapping(value = "/restrictedMismatch", method = RequestMethod.POST)
	public String addTabOfSamePageRM(@RequestBody String tab, ModelMap model, HttpSession session) {
		EnvRegion e = envRegionCtrl.getEnvRegion(session);
		System.out.println("in  /restrictedMismatch post method ->>" + tab);
		String userId = (String) httpSession.getAttribute("userId");
		String environment = (String) session.getAttribute("environment");
		System.out.println("User Id in restrictedMismatch POST: " + userId);
		List<String> reqData = new ArrayList<String>();

		String[] sentData = tab.split("\\$");
		System.out.println("sentData after separation" + sentData);
		for (String a : sentData) {
			reqData.add(a);
			System.out.println("send data restrictedMismatch-> " + a);
		}

		if ("F".equalsIgnoreCase(reqData.get(1))) {
			fetchRestrictedMismatchData(reqData, model, session);
		} else {

			workloadCtrl.setDataToCorrespondingDTO(reqData, model, session);
			if ("Y".equalsIgnoreCase(reqData.get(1))) {
				workloadCtrl.getSameTabs(reqData, model, userId, session);
			}
		}
//		EnvRegion e = envRegionCtrl.getEnvRegionFromSession(session,model);
		model.addAttribute("userId", userId);
		model.addAttribute("indicator",false)	;
		model.addAttribute("indicator1",false)	;
		model.addAttribute("indicator2",false)	;
		model.addAttribute("indicator3",false)	;
		model.addAttribute("indicator4",false) ;
		model.addAttribute("environment", environment);
		model.addAttribute("envregion", e);
		return "restrictedMismatch";
	}

	public void fetchRestrictedMismatchData(List<String> sentData, ModelMap model, HttpSession session) {
//		String user_id = EnvRegionController.getLoginObject().getUser_id();
		String user_id=(String) session.getAttribute("activeUser");
		user_id=user_id.toUpperCase();
		int currentIndex = Integer.parseInt(sentData.get(7));
		session.setAttribute("currentPageIndex", currentIndex);
		String objHandle = (String) session.getAttribute("objectHandle");
		int objectHandle = 0;
		if (checkNullString(objHandle)) {
			objHandle = 1 + "";
			objectHandle = Integer.parseInt(objHandle);
			session.setAttribute("objectHandle", objectHandle);
		}
		model.remove("restrictedMismatchData");

		RestrictedMismatchData12states resMisData = new RestrictedMismatchData12states();

		System.out.println("RestrictedMismatchData ->>: " + sentData.get(3));
		Gson gson = new Gson();
		RestrictedMismatchData12states restrictedMismatchData = gson.fromJson(sentData.get(3),
				RestrictedMismatchData12states.class);
		String object_handle = workloadCtrl.getObjectHandle(objectHandle);
		System.out.println("RestrictedMismatchData ->>: " + restrictedMismatchData.toString());

		resMisData = restrictedMismatchData12statesService
				.writeRestrictedMismatchData12statesToMQ(restrictedMismatchData, user_id, object_handle,session);

		setrestrictedMismatchDataObj(resMisData, currentIndex, session);
		model.addAttribute("restrictedMismatchData", resMisData);  
		
		System.out.println(
				"RestrictedMismatchDataWithMQData size-->" + resMisData.getRestrictedMisTableRows12states().size());
		System.out.println("To show object handle in retrieved data w0" + resMisData);
		

	}

	private void setrestrictedMismatchDataObj(RestrictedMismatchData12states resMisData, int currentIndex,
			HttpSession session) {

		System.out.println("resMisData in setrestrictedMismatchDataObj-->" + resMisData);
		List<RestrictedMismatchData12states> restrictedMismatchDatalist = (List<RestrictedMismatchData12states>) session
				.getAttribute("restrictedMismatchDatalist");
		List<RestrictedMismatchData12states> restrictedDataLst = new ArrayList<RestrictedMismatchData12states>();
		if (restrictedMismatchDatalist == null) {

			for (int x = 0; x < 5; x++) {
				RestrictedMismatchData12states restricted = new RestrictedMismatchData12states();
				restricted = MockDtoDataUtil.getRestrictedMismatchkMockData();
				restrictedDataLst.add(restricted);
			}
			session.setAttribute("restrictedMismatchDatalist", restrictedDataLst);
			restrictedMismatchDatalist = (List<RestrictedMismatchData12states>) session
					.getAttribute("restrictedMismatchDatalist");
			System.out.println("restrictedMismatchDatalist from session size" + restrictedMismatchDatalist.size());

			restrictedMismatchDatalist.set(currentIndex, resMisData);
			session.setAttribute("restrictedMismatchDatalist", restrictedDataLst);
		} else {
			restrictedMismatchDatalist.set(currentIndex, resMisData);
			session.setAttribute("restrictedMismatchDatalist", restrictedMismatchDatalist);
		}

	}

	@RequestMapping(value = "/unrestrictedMismatch", method = RequestMethod.GET)
	public String showFupReqPage(ModelMap model, HttpSession session) {
		System.out.println("in /unrestrictedMismatch get method");
		EnvRegion e = envRegionCtrl.getEnvRegion(session);
		String userId = (String) httpSession.getAttribute("userId");
		String environment = (String) session.getAttribute("environment");
//		EnvRegion e = envRegionCtrl.getEnvRegionFromSession(session,model);
		model.addAttribute("userId", userId);
		model.addAttribute("environment", environment);
		model.addAttribute("envregion", e);
		model.addAttribute("screenObj", workloadCtrl.screenObj);
		model.addAttribute("navbarArr", session.getAttribute("navBarArr"));
		model.addAttribute("indicator",false)	;
		model.addAttribute("indicator1",false)	;
		model.addAttribute("indicator2",false)	;
		model.addAttribute("indicator3",false)	;
		model.addAttribute("indicator4",false) ;
		String currInde = "";
		Object currInd = session.getAttribute("currentPageIndex");
		if (!(currInd == null)) {
			currInde = currInd.toString();
			System.out.println("session -->" + session.getAttribute("currentPageIndex"));
			System.out.println("currInde" + currInde);
		}

		int currIndex = 0;
		if (!checkNullString(currInde)) {
			currIndex = Integer.parseInt(currInde);
			session.setAttribute("currentPageIndex", currIndex + "");
		}
		UnrestrictedMismatchData12states unrestrictedMismatchDto = getUnrestrictedMismatchDataFromSession(session,
				currIndex);
		//System.out.println("data to display-->" + unrestrictedMismatchDto.getUnrestrictedMisTableRows12states().size());
		model.addAttribute("unrestrictedMismatchData", unrestrictedMismatchDto);

		return "unrestrictedMismatch";

	}

	private UnrestrictedMismatchData12states getUnrestrictedMismatchDataFromSession(HttpSession session,
			int currIndex) {
		UnrestrictedMismatchData12states unrestrictedMismatchData = new UnrestrictedMismatchData12states();
		try {

			List<UnrestrictedMismatchData12states> unrestrictedMismatchDatalist = (List<UnrestrictedMismatchData12states>) session
					.getAttribute("unrestrictedMismatchDatalist");
			System.out.println("unrestrictedMismatchDatalist size-->" + unrestrictedMismatchDatalist.size());
			return unrestrictedMismatchDatalist.get(currIndex);
		} catch (Exception e) {
			System.out.println("got exception" + e.getMessage());
			return unrestrictedMismatchData;
		}

	}

	@RequestMapping(value = "/unrestrictedMismatch", method = RequestMethod.POST)
	public String addTabOfSamePageUM(@RequestBody String tab, ModelMap model, HttpSession session) {
		
		
		System.out.println("in  /unrestrictedMismatch ====================post method ->>" + tab);
		
		
		EnvRegion e = envRegionCtrl.getEnvRegion(session);
		String userId = (String) session.getAttribute("activeUser");
		String environment = (String) session.getAttribute("environment");
		String activeUser = (String) session.getAttribute("activeUser");
		
		System.out.println("User Id in unrestrictedMismatch POST: " + userId);
		List<String> reqData = new ArrayList<String>();

		String[] sentData = tab.split("\\$");
		System.out.println("sentData after separation" + sentData);
		for (String a : sentData) {
			reqData.add(a);
			System.out.println("send data unrestrictedMismatch-> " + a);
		}

		if ("F".equalsIgnoreCase(reqData.get(1))) {
			fetchUnrestrictedMismatchData(reqData, model, session);
		} else {

			workloadCtrl.setDataToCorrespondingDTO(reqData, model, session);
			if ("Y".equalsIgnoreCase(reqData.get(1))) {
				workloadCtrl.getSameTabs(reqData, model, userId, session);
			}
		}
//		EnvRegion e = envRegionCtrl.getEnvRegionFromSession(session,model);
		model.addAttribute("activeUser", activeUser);
		model.addAttribute("environment", environment);
		model.addAttribute("envregion", e);
		model.addAttribute("indicator",false)	;
		model.addAttribute("indicator1",false)	;
		model.addAttribute("indicator2",false)	;
		model.addAttribute("indicator3",false)	;
		model.addAttribute("indicator4",false) ;
		return "unrestrictedMismatch";
	}

	public void fetchUnrestrictedMismatchData(List<String> sentData, ModelMap model, HttpSession session) {
//		String user_id = EnvRegionController.getLoginObject().getUser_id();
		
		System.out.println("in fetchUnrestricted methd=====");
		String user_id=(String) session.getAttribute("activeUser");
		user_id=user_id.toUpperCase();
		int currentIndex = Integer.parseInt(sentData.get(7));
		session.setAttribute("currentPageIndex", currentIndex);
		String objHandle = (String) session.getAttribute("objectHandle");
		int objectHandle = 0;
		if (checkNullString(objHandle)) {
			objHandle = 1 + "";
			objectHandle = Integer.parseInt(objHandle);
			session.setAttribute("objectHandle", objectHandle);
		}
		model.remove("unrestrictedMismatchData");

		UnrestrictedMismatchData12states unresMisData = new UnrestrictedMismatchData12states();

		System.out.println("UnrestrictedMismatchData ->>: " + sentData.get(3));
		Gson gson = new Gson();
		UnrestrictedMismatchData12states unrestrictedMismatchData = gson.fromJson(sentData.get(3),
				UnrestrictedMismatchData12states.class);
		String object_handle = workloadCtrl.getObjectHandle(objectHandle);
		System.out.println("unRestrictedMismatchData-------- ->>: " + unrestrictedMismatchData.toString());

		unresMisData = unRestrictedMismatchData12statesService.writeUnRestrictedMismatchData12statesToMQ(unrestrictedMismatchData, user_id, object_handle,session);

		setUnrestrictedMismatchDataObj(unresMisData, currentIndex, session);
		model.addAttribute("unrestrictedMismatchData", unresMisData);
		System.out.println("UnrestrictedMismatchDataWithMQData======= size-->"
				+ unresMisData.getUnrestrictedMisTableRows12states().size());
		System.out.println("To show object handle in retrieved data w0" + unresMisData);

	}

	private void setUnrestrictedMismatchDataObj(UnrestrictedMismatchData12states unresMisData, int currentIndex,
			HttpSession session) {

		System.out.println("unresMisData in setUnrestrictedMismatchDataObj-->" + unresMisData);
		List<UnrestrictedMismatchData12states> unrestrictedMismatchDatalist = (List<UnrestrictedMismatchData12states>) session
				.getAttribute("unrestrictedMismatchDatalist");
		List<UnrestrictedMismatchData12states> unrestrictedDataLst = new ArrayList<UnrestrictedMismatchData12states>();
		if (unrestrictedMismatchDatalist == null) {

			for (int x = 0; x < 5; x++) {
				UnrestrictedMismatchData12states unrestricted = new UnrestrictedMismatchData12states();
				unrestricted = MockDtoDataUtil.getUnrestrictedMismatchMockData();
				unrestrictedDataLst.add(unrestricted);
			}
			session.setAttribute("unrestrictedMismatchDatalist", unrestrictedDataLst);
			unrestrictedMismatchDatalist = (List<UnrestrictedMismatchData12states>) session
					.getAttribute("unrestrictedMismatchDatalist");
			System.out.println("unrestrictedMismatchDatalist from session size" + unrestrictedMismatchDatalist.size());

			unrestrictedMismatchDatalist.set(currentIndex, unresMisData);
			session.setAttribute("restrictedMismatchDatalist", unrestrictedDataLst);
		} else {
			unrestrictedMismatchDatalist.set(currentIndex, unresMisData);
			session.setAttribute("restrictedMismatchDatalist", unrestrictedMismatchDatalist);
		}

	}

	public boolean checkNullString(String val) {
		boolean flag = true;
		if ("".equals(val) || val == null) {
			flag = true;
		} else {
			flag = false;
		}
		return flag;
	}

}
