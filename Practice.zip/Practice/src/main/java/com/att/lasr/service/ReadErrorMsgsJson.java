package com.att.lasr.service;

import java.io.FileReader;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;



public class ReadErrorMsgsJson {
 
	public String getErrorMsg(String errCode)
	{
		JSONObject obj2=null;
		JSONParser parser = new JSONParser();
		try {
//			
//			Object obj = parser.parse(new FileReader("//usr//local//tomcat//webapps//OneLASRGUI//WEB-INF//classes//static//errorMsgs.json"));
			Object obj = parser.parse(new FileReader("C:\\Users\\hp959j\\eclipse-workspace\\Q4 Vuln Fix Code\\OneLASRGUI\\src\\main\\resources\\static\\errorMsgs.json"));
			JSONObject obj1 = (JSONObject) obj;
			
			obj2 =(JSONObject) obj1.get(errCode);
			
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		return obj2.get("Message").toString();
	}
	
	/*
	 * Object obj; JSONParser parser; JSONObject obj1; ReadErrorMsgsJson(){
	 * home//site//wwwroot
	 * parser=new JSONParser(); try { obj = parser.parse(new
	 * FileReader("/OneLASRGUI/src/main/resources/static/errorMsgs.json")); obj1 =
	 * (JSONObject) obj; } catch (FileNotFoundException e) { 
	 * catch block e.printStackTrace(); } catch (IOException e) { // TODO
	 * Auto-generated catch block e.printStackTrace(); } catch (ParseException e) {
	 * // TODO Auto-generated catch block e.printStackTrace(); }
	 * 
	 * } public String getErrorMsg(String errCode) { JSONObject obj2=null; try {
	 * obj2 =(JSONObject) obj1.get(errCode);
	 * 
	 * 
	 * } catch (Exception e) { e.printStackTrace(); } return
	 * obj2.get("Message").toString(); }
	 */
	
}
