package com.att.lasr.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.att.lasr.model.FupReqTableRow;
import com.att.lasr.model.FupRequestData;
import com.att.lasr.model.Header;
import com.att.lasr.model.MQReceivedData;
import com.att.lasr.model.SubData;
import com.att.lasr.model.SubHeader;
import com.att.lasr.utils.MQMessageStringBuilder;
import com.att.lasr.utils.MQReadUtil;
import com.att.lasr.utils.MQWriteUtil;
import com.att.lasr.utils.enums.LastInd;
import com.att.lasr.utils.enums.LogInd;
import com.att.lasr.utils.enums.Process;
import com.att.lasr.utils.enums.ProcessGroupInd;
import com.att.lasr.utils.enums.ProcessMode;
import com.att.lasr.utils.enums.RecIdFor12State;

@Service
public class FupRequestService {

	@Autowired
	private MQReadUtil mqReadUtil;

	@Autowired
	private MQWriteUtil mqWriteUtil;

	public FupRequestData writeFupRequestDataToMQ(FupRequestData fupRequestData, String user_id, String object_handle,HttpSession session) {

		Header header = prepareHeader(user_id,object_handle);
		SubHeader subHeader = prepareSubHeader();

		// Customize FupRequestData
		fupRequestData.setPrevnext_cde("R");

		String dataString = fupRequestData.getFupRequestDataString();

		MQMessageStringBuilder mqMessageStringBuilder = new MQMessageStringBuilder().addHeaderSubHeaderAndData(header,
				subHeader, dataString);

		boolean isWritten = mqWriteUtil.writeDataToMQ(mqMessageStringBuilder,session);

		FupRequestData fupRequestDataFromMQ = fupRequestData;

		if (isWritten) {

			MQReceivedData mqReceivedData=null;
			
			try {

			mqReceivedData = mqReadUtil.readSortDataFromMQ(session); 
			 long endTime = System.nanoTime() + TimeUnit.NANOSECONDS.convert(3L, TimeUnit.MINUTES); 
			  Map<String, SubData> subDatas = mqReceivedData.getSubDatas(); 
		//	  Header receivedHeader = mqReceivedData.getHeader(); 
			  while(mqReceivedData.getHeader()==null&& System.nanoTime() < endTime) { 
					System.out.println("*************inside if*************** "); 
					mqReceivedData =	 mqReadUtil.readSortDataFromMQ(session); 
				} 
			  
			  
			  System.out.println(mqReceivedData.getHeader().toString()); 
		} catch (Exception e) { 
			// TODO Auto-generated catch block 
			 //mqReceivedData = mqReadUtil.readDataFromMQ(session); 
			e.printStackTrace(); 


		}
			Map<String, SubData> subDatas = mqReceivedData.getSubDatas();
			Header receivedHeader = mqReceivedData.getHeader();
			fupRequestDataFromMQ.setHeader(receivedHeader);
			SubData subData = subDatas.get(RecIdFor12State.CS_RECID_SELREQ_FUP.getRecIdValue());
			if (subData != null) {
				SubHeader receivedSubHeader = subData.getSubHeader();

				String[] subDataRows = subData.getSubDataRows();

				List<FupReqTableRow> fupRequestTableRows = new ArrayList<>();

				for (String subDataRow : subDataRows) {
					String[] attributes = mqReadUtil.getAttributes(subDataRow, 13);
//					System.out.println("attributes: " + Arrays.toString(attributes));
					FupReqTableRow fupReqTableRow = new FupReqTableRow();

					fupReqTableRow.setCc(attributes[0]);
					fupReqTableRow.setRequest_id(attributes[1]);
					fupReqTableRow.setStatus(attributes[2]);
					fupReqTableRow.setFup_date(attributes[3]);
					fupReqTableRow.setCancel_ind(attributes[4]);
					fupReqTableRow.setRelease_version(attributes[5]);
					fupReqTableRow.setTotal_record(attributes[6]);
					fupReqTableRow.setStart_page(attributes[7]);
					fupReqTableRow.setEnd_page(attributes[8]);
					fupReqTableRow.setBegin_time_nextptr(attributes[9]);
					fupReqTableRow.setEnd_time_nextptr(attributes[10]);
					fupReqTableRow.setBegin_time_prevptr(attributes[11]);
					fupReqTableRow.setEnd_time_prevptr(attributes[12]);

					fupRequestTableRows.add(fupReqTableRow);
				}
				fupRequestDataFromMQ.setSubHeader(receivedSubHeader);
				fupRequestDataFromMQ.setFupRequestTableRows(fupRequestTableRows);
				
				System.out.println("fupRequestDataFromMQ.getFupRequestTableRows size"+fupRequestDataFromMQ.getFupRequestTableRows().size());
			}
		}
		return fupRequestDataFromMQ;

	}

	private SubHeader prepareSubHeader() {

		// Prepare SubHeader
		SubHeader subHeader = new SubHeader();

		subHeader.setLast_ind(LastInd.Y.name());
		subHeader.setProcess_mode(ProcessMode.CS_RETRIEVE.getProcessModeCode());
		subHeader.setRecord_type(RecIdFor12State.CS_RECID_SELREQ_FUP.getRecIdValue());
		subHeader.setReturn_code(null);
		subHeader.setDw_rownum(null);
		subHeader.setEcver(null);

		return subHeader;
	}

	private Header prepareHeader(String user_id, String object_handle) {
		// Prepare Header
		Header header = new Header();

		header.setUser_id(user_id);
		header.setProcess(Process.CS_SELREQ_FUP.getProcessCode());
		header.setTab_ind(null);
		header.setProcess_group_ind(ProcessGroupInd.RETRIEVE_IND.getProcessGroupInd());
		header.setObject_handle(object_handle);
		header.setObject_handle2(null);
		header.setLog_ind(LogInd.N.name());
		header.setStarttime(null);
		header.setEndtime(null);
		header.setGuid(null);
		header.setSession_trans_count("0000001");
		header.setHost_trans_seq(null);
		header.setReturn_code(null);
		header.setRead_only_ind(null);
		header.setNum_detail("0001");
		header.setRead_only_user_id(null);
		header.setLasrversion(null);

		return header;
	}
}
