package com.att.lasr.model;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@ToString
public class FatalErrors9state {
	private String cver;
	private String response_type;
	private String ecver;
	private String dt_sent_local;
	private String response_dt_sent_central_time;
	private String field_name;
	private String item_num;
	private String lnum;
	private String num_name;
	private String num_nbr;
	private String leg_num;
	private String error_code;
	private String error_message;


}
