/**
 * 
 */
package com.att.lasr.model;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@ToString
public class ISDNPort_IUS_ChannelFeaturesGrid_9States {

	
	private String item_num;
	private String channel_fa_attr;
	private String channel_fa;
	private String channel_feature_attr;
	private String channel_feature;
	private String channel_feature_detail_attr;
	private String channel_feature_detail;
	private String line_asgn_attr;
	private String line_asgn;
    private String locnum;
	private String loc_seq_num;
	
	
}
