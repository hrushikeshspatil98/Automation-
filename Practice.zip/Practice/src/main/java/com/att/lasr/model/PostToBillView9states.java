package com.att.lasr.model;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@ToString
public class PostToBillView9states {
	
	private String c_ver_attr;
	private String c_ver;
	private String rt_attr;
	private String rt;
	private String ec_ver_attr;
	private String ec_ver;
	private String dt_sent_local_attr;
	private String dt_sent_local;
	private String response_dt_sent_attr;
	private String response_dt_sent;
	private String pd_attr;
	private String pd;



}
