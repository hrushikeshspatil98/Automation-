package com.att.lasr.model;


import java.util.List;

import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Data
@Setter
@Getter
@NoArgsConstructor
@ToString

public class PostToBillTask {
	private String c_ver_attr;
	private String  c_ver;
	private String rt_attr;
	private String rt;
	private String ec_ver_attr;
	private String ec_ver;
	private String dt_sent_local_attr;
	private String dt_sent_local;
	private String response_dt_sent_attr;
	private String response_dt_sent;
	private String pd_attr;
	private String pd;
	
//	private List<PostToBillTaskLSCInfo> postToBillTaskLSCInfo = new ArrayList<PostToBillTaskLSCInfo>();

}
