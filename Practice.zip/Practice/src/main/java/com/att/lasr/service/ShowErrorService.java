package com.att.lasr.service;

import java.util.ArrayList;
import java.util.List;

import com.att.lasr.model.ShowError;
import com.att.lasr.model.UserProfileData;
import com.att.lasr.service.ReadErrorMsgsJson;

public class ShowErrorService {

	final int row = 1;
	List<ShowError> showErrorMultiple = new ArrayList<>();
	
	public List<ShowError> getErrorList(String error_code, String userIdText, String userId, String action) {

		List<ShowError> showError = new ArrayList<>();
		ReadErrorMsgsJson readErrorMsgsJson = new ReadErrorMsgsJson();

		//row++;
		System.out.println("$$error_code: "+ error_code + " $$userIdText :" +userIdText +"$$userId :" + userId +"$$action: " + action);
		
		String recordKey=null;
		if((error_code.length()>=6) && (error_code != "LG0401")){
			recordKey = formatRecordAction(userIdText, userId, action);
		}
		if((error_code.length()>=6) && (error_code != "LG0136")){
			recordKey = formatRecordAction(userIdText, userId, action);
		}
		String error_msg = readErrorMsgsJson.getErrorMsg(error_code);
		showError.add(new ShowError(row+"", error_code, error_msg, recordKey));
		//showError.add(new ShowError(row, "LG0223", readErrorMsgsJson.getErrorMsg("LG0223"), recordKey));

		// showError.add(readErrorMsgsJson.getErrorMsg("LG0029"));
	//	System.out.println("show error: " + Arrays.toString(showError.toArray()));
		
		return showError;
	}
	
	//Creating duplicate method for multiple error mesages
	
	public List<ShowError> getErrorListMultiple(String error_code, String userIdText, String userId, String action, List<ShowError> focError) {

		
		ReadErrorMsgsJson readErrorMsgsJson = new ReadErrorMsgsJson();

		//row++;
		System.out.println("$$error_code: "+ error_code + " $$userIdText :" +userIdText +"$$userId :" + userId +"$$action: " + action);
		
		String recordKey=null;
		if((error_code.length()>=6) && (error_code != "LG0401")){
			recordKey = formatRecordAction(userIdText, userId, action);
		}
		if((error_code.length()>=6) && (error_code != "LG0136")){
			recordKey = formatRecordAction(userIdText, userId, action);
		}
		String error_msg = readErrorMsgsJson.getErrorMsg(error_code);
		focError.add(new ShowError(row+"", error_code, error_msg, recordKey));
		//showErrorMultiple.add(focError);
		//showError.add(new ShowError(row, "LG0223", readErrorMsgsJson.getErrorMsg("LG0223"), recordKey));

		// showError.add(readErrorMsgsJson.getErrorMsg("LG0029"));
	//	System.out.println("show error: " + Arrays.toString(showError.toArray()));
		
		return focError;
	}
 
	public List<ShowError> getJeopardyErrorList(String error_code,String error_msg, String userIdText, String userId, String action, List<ShowError> focError) {

		String recordKey=null;

		recordKey = formatRecordAction(userIdText, userId, action);

		focError.add(new ShowError(row+"", error_code, error_msg, recordKey));

		return focError;
		}
	
	
	public String formatRecordAction(String userIdText,String userId,String action){
		
		switch(action) { 
				case "A" :
					action = "add" ;
					break;
				case "U" :
					action = "update";
					break;
				case "D":
					action = "delete" ;
					break;
				case "X":
					action = "special";
					break;
				case "": 
					action = "unknown";
					break;
		}
		if(userId.isEmpty())
		{
			return (action + " failed");
		}
		else
		{
		return (userIdText + " = " + userId + " " + action + " failed") ;
		}
		
	}
	
	
	//Get Show Error Message List
			public List<ShowError> getShowErrorList(String error_code, String rowNum, String userId, String action, List<ShowError> showError) {

				
				ReadErrorMsgsJson readErrorMsgsJson = new ReadErrorMsgsJson();

				//row++;
				System.out.println("$$error_code: "+ error_code + " $$userIdText :" +rowNum +"$$userId :" + userId +"$$action: " + action);
				
				String error_msg = readErrorMsgsJson.getErrorMsg(error_code);
				String actionMsg= "";
				if((error_code.length()>=6) && (error_code != "LG0118")){
					actionMsg = formatRecordAction("Lsrn", userId, action);
				}
				else{
					actionMsg= formatActionMessage("","",action);
				}
				showError.add(new ShowError(rowNum, error_code, error_msg, actionMsg));
				
				return showError;
			}
			
			//Get Formatted Action Message
			public String formatActionMessage(String sub1, String sub2, String action){
				
				switch(action) { 
						case "A" :
							action = "add" ;
							break;
						case "U" :
							action = "update";
							break;
						case "D":
							action = "delete" ;
							break;
						case "X":
							action = "special";
							break;
						default: 
							action = "unknown";
				}
				if(sub2.isEmpty())
				{
					return (action + " failed");
				}
				return (sub1+" = "+sub2+ " "+action + " failed") ;
				
			}

}
