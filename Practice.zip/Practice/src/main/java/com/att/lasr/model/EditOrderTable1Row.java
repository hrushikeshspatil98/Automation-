package com.att.lasr.model;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@ToString
public class EditOrderTable1Row {

	private String old_dtm;
	private String old_ord;
	private String ord_attr;
	private String ord;
	private String fdt_attr;
	private String fdt;
	private String dd_attr;
	private String dd;
	private String comp_dt_attr;
	private String comp_dt;
	private String posted_date_attr;
	private String posted_date;
	private String apptime_attr;
	private String apptime;
}
