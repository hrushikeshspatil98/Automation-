package com.att.lasr.model;


import java.util.List;

import com.att.lasr.utils.Constants;
import com.att.lasr.utils.FormatUtil;

import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Data
@Setter
@Getter
@NoArgsConstructor
@ToString

public class PostToBillTask_RecId585 {
	private String c_ver_attr;
	private String  c_ver;
	private String rt_attr;
	private String rt;
	private String ec_ver_attr;
	private String ec_ver;
	private String dt_sent_local_attr;
	private String dt_sent_local;
	private String response_dt_sent_attr;
	private String response_dt_sent;
	private String pd_attr;
	private String pd;
	
	public String getSelectRequest585DataString() {
		StringBuilder selectRequestDataSb = new StringBuilder();

		
		selectRequestDataSb.append(FormatUtil.getValueWithSpaces(c_ver_attr, 1)).append(Constants.TAB);
		selectRequestDataSb.append(FormatUtil.getValueWithSpaces(c_ver, 2)).append(Constants.TAB);
		selectRequestDataSb.append(FormatUtil.getValueWithSpaces(rt_attr, 1)).append(Constants.TAB);
		selectRequestDataSb.append(FormatUtil.getValueWithSpaces(rt, 1)).append(Constants.TAB);
		selectRequestDataSb.append(FormatUtil.getValueWithSpaces(ec_ver_attr, 1)).append(Constants.TAB);
		selectRequestDataSb.append(FormatUtil.getValueWithSpaces(ec_ver, 3)).append(Constants.TAB);
		selectRequestDataSb.append(FormatUtil.getValueWithSpaces(dt_sent_local_attr, 1)).append(Constants.TAB);
		selectRequestDataSb.append(FormatUtil.getValueWithSpaces(dt_sent_local, 13)).append(Constants.TAB);
		selectRequestDataSb.append(FormatUtil.getValueWithSpaces(response_dt_sent_attr, 1)).append(Constants.TAB);
		selectRequestDataSb.append(FormatUtil.getValueWithSpaces(response_dt_sent, 13)).append(Constants.TAB);
		selectRequestDataSb.append(FormatUtil.getValueWithSpaces(pd_attr, 1)).append(Constants.TAB);
		
		selectRequestDataSb.append(FormatUtil.getValueWithSpaces(FormatUtil.getMqDateFormatString(pd), 8)).append(Constants.TAB).append(Constants.TAB);
		
		String selectRequestDataString = FormatUtil.getValueWithSpaces(selectRequestDataSb.toString(), 2400);
		return selectRequestDataString;
	}
	


}
