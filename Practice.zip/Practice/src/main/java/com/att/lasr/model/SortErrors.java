package com.att.lasr.model;

import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Data
@Setter
@Getter
@NoArgsConstructor
public class SortErrors {
	private String order_attr;
	private String service_order;
	private String rule_attr;
	private String rule_name;
	private String error_attr;
	private String error_message;
	private String action_attr;
	private String action;
	private String comment_attr;
	private String comment;
	private String so_msg;

}
