package com.att.lasr.controller;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;
import com.att.lasr.model.Header;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.SessionAttributes;

import com.att.lasr.model.CloseTransaction;
import com.att.lasr.model.EnvRegion;
import com.att.lasr.model.Login;
import com.att.lasr.model.LscNoteDTO;
import com.att.lasr.model.ManualRejectDTO;
import com.att.lasr.model.ManualRejectRec018;
import com.att.lasr.model.RejectManualLoginDto;
import com.att.lasr.model.WorkloadData;
import com.att.lasr.service.CloseTransactionService;
import com.att.lasr.service.ManualRejectTransactionService;
import com.att.lasr.service.WorkloadService;
import com.att.lasr.utils.Constants;
import com.att.lasr.utils.FormatUtil;
import com.att.lasr.utils.MockDtoDataUtil;
import com.google.gson.Gson;

@Controller
@SessionAttributes("region")
public class WorkloadController {

//	EnvRegion e = EnvRegionController.getobj();
	
	@Autowired
	HttpSession httpSession;

	@Autowired
	private WorkloadService workloadService;

	static String flag= "";
	public LinkedList<Object> screenObj = new LinkedList<Object>();
	
	@Autowired
	private EnvRegionController envRegionCtrl;
	
	@Autowired
	private SelectController selectCtrl;
	
	
	@Autowired 
	private CloseTransactionService closeTransactionService;
	
	@Value("${appliction.logout.redirect}")
	 private String logoutGL;

	@Autowired 
	private ManualRejectTransactionService manualRejectTransactionService;
	
	
	
	@RequestMapping(value = "/workload", method = RequestMethod.GET)
	public String showWorkloadPage(ModelMap model, HttpSession session) {
		System.out.println("in /worload get method");
		String userId = (String) httpSession.getAttribute("activeUser");
		String environment = (String) session.getAttribute("environment");
//		EnvRegion e = envRegionCtrl.getEnvRegionFromSession(session,model);
		EnvRegion e = envRegionCtrl.getEnvRegion(session);
//		Login login = EnvRegionController.getLoginObject();

		Login login =envRegionCtrl.getLoginObjectFromSession(session);

		
		
		System.out.println("User Id in Workload GET: "+userId);
		model.addAttribute("userId", userId);
		model.addAttribute("environment", environment);
		model.addAttribute("envregion", e);
		model.addAttribute("login", login);
		model.addAttribute("screenObj", screenObj);
		model.addAttribute("indicator",false)	;
		model.addAttribute("indicator1",false)	;
		model.addAttribute("indicator2",false)	;
		model.addAttribute("indicator3",false)	;
		model.addAttribute("indicator4",false) ;
		model.addAttribute("navbarArr", session.getAttribute("navBarArr"));
		String currInde="";
		Object currInd=  session.getAttribute("currentPageIndex");
		if(!(currInd==null)) {
			 currInde=  currInd.toString();
			System.out.println("session -->"+session.getAttribute("currentPageIndex"));
			System.out.println("currInde"+currInde);
		}
		
		int currIndex=0;
		if(!checkNullString(currInde)) {
			 currIndex=Integer.parseInt(currInde);
			 session.setAttribute("currentPageIndex", currIndex+"");
		}
		WorkloadData workloadDto=  getWorkloadDataFromSession(session,currIndex);
		//System.out.println("data to display-->"+workloadDto.getWorkloadTableRows().size());
		model.addAttribute("workloadData", workloadDto);

		return "workload";
	}
	
	public boolean checkNullString(String val) {
		boolean flag= true;
		if("".equals(val) || val== null) {
			flag=true;
		}else {
			flag=false;
		}
		return flag;
	}
	
	

	private WorkloadData getWorkloadDataFromSession(HttpSession session,int currIndex) {
		WorkloadData myWrkloadObj = new WorkloadData();
		try {
			
		List<WorkloadData>  workloadDatalist= (List<WorkloadData>)session.getAttribute("workloadDataList");
		System.out.println("workloadDatalist size-->"+workloadDatalist.size());
		return workloadDatalist.get(currIndex);
		}catch (Exception e) {
			System.out.println("got exception"+e.getMessage());
			return myWrkloadObj;
			
		}
	}

	@RequestMapping(value = "/workload", method = RequestMethod.POST)
	public String addTabOfSamePageWL(@RequestBody String tab, ModelMap model, HttpSession session) {
		
		System.out.println("in  /workload post method  ->>" + tab);
		String userId = (String) httpSession.getAttribute("userId");
		String environment = (String) session.getAttribute("environment");
//		Login login = EnvRegionController.getLoginObject();

		Login login =envRegionCtrl.getLoginObjectFromSession(session);

		
		
		model.addAttribute("login", login);
		System.out.println("User Id in Workload POST: "+userId);
		List<String> reqData = new ArrayList<String>();

		String[] sentData = tab.split("\\$");
		System.out.println("sentData after separation" + sentData);
		for (String a : sentData) {
			reqData.add(a);
			System.out.println("send data workload-> " + a);
		}

		if ("F".equalsIgnoreCase(reqData.get(1))) {
			fetchWorkloadData(reqData, model,session);
		} else {

			setDataToCorrespondingDTO(reqData, model,session);
			if ("Y".equalsIgnoreCase(reqData.get(1))) {
				getSameTabs(reqData, model, userId,session);
			}
		}
//		EnvRegion e = envRegionCtrl.getEnvRegionFromSession(session,model);
		EnvRegion e = envRegionCtrl.getEnvRegion(session);
		model.addAttribute("userId", userId);
		model.addAttribute("environment", environment);
		model.addAttribute("indicator",false)	;
		model.addAttribute("indicator1",false)	;
		model.addAttribute("indicator2",false)	;
		model.addAttribute("indicator3",false)	;
		model.addAttribute("indicator4",false) ;
		model.addAttribute("envregion", e);
		return "workload";
	}

	public void fetchWorkloadData(List<String> sentData, ModelMap model, HttpSession session) {
//		String user_id = EnvRegionController.getLoginObject().getUser_id();
		String user_id=(String) session.getAttribute("activeUser");
		user_id=user_id.toUpperCase();
		int currentIndex = Integer.parseInt(sentData.get(7));
		session.setAttribute("currentPageIndex",currentIndex);
		String objHandle=(String)session.getAttribute("objectHandle");
		int objectHandle=0;
		if(checkNullString(objHandle)) {
			objHandle=1+"";
			objectHandle=	Integer.parseInt(objHandle);
			session.setAttribute("objectHandle",objectHandle);
		}
			model.remove("workloadData");
		
		WorkloadData wrklod=new WorkloadData();
		
		System.out.println("WorkloadData  ->>: " + sentData.get(3));
		Gson gson = new Gson();
		WorkloadData wrkloadData = gson.fromJson(sentData.get(3), WorkloadData.class);
		String object_handle = getObjectHandle(objectHandle);
		System.out.println("WorkloadData ->>: " + wrkloadData.toString());
		
		
		wrklod = workloadService.writeWorkloadDataToMQ(wrkloadData, user_id, object_handle,session);
		setWorkloadDataObj(wrklod,currentIndex,session);
		System.out.println("workloadDataWithMQData size-->" + wrklod.getWorkloadTableRows().size());
		System.out.println("To show object handle in retrieved data w0" + wrklod);
		
	}

	private void setWorkloadDataObj(WorkloadData wrklod,int currentIndex, HttpSession session) {
		
		System.out.println("wrklod in setWorkloadDataObj-->"+wrklod);
		List<WorkloadData> workloadDatalist = (List<WorkloadData>) session.getAttribute("workloadDataList");
		List<WorkloadData> workloadDataLst=new ArrayList<WorkloadData>();
		if(workloadDatalist==null) {
			
			for(int x=0;x<5;x++) {
				WorkloadData wrk = new WorkloadData();
				wrk=MockDtoDataUtil.getWorkloadMockData();
				workloadDataLst.add(wrk);
			}
			session.setAttribute("workloadDataList", workloadDataLst);
			 workloadDatalist = (List<WorkloadData>) session.getAttribute("workloadDataList");
			 System.out.println("workloadDatalist from session size"+workloadDatalist.size());
			
			workloadDatalist.set(currentIndex, wrklod);
//			workloadDatalist.addAll(workloadDataLst);
			session.setAttribute("workloadDataList", workloadDataLst);
		}else {
			workloadDatalist.set(currentIndex, wrklod);
			session.setAttribute("workloadDataList", workloadDatalist);
		}
		
	}


@RequestMapping(value = "/removeThatTab", method = RequestMethod.POST)
	public String removeThatTab(@RequestBody String tab, ModelMap model, HttpSession session) {
		System.out.println("to /removeThatTab post method ctrl" + tab);
		session.removeAttribute("showError");
		session.removeAttribute("error_msg");
//		EnvRegionController.envregion2.setEnvironment(EnvRegionController.envregion2.getEnvironment());
//		EnvRegionController.envregion2.setRegion(EnvRegionController.envregion2.getRegion());
		String environment = (String) session.getAttribute("environment");
		EnvRegion e = envRegionCtrl.getEnvRegion(session);
		model.addAttribute("environment", environment);
				model.addAttribute("envregion", e);
//		EnvRegion e = envRegionCtrl.getEnvRegionFromSession(session,model);
		//EnvRegion e = envRegionCtrl.getEnvRegion(session);
		//model.addAttribute("envregion", e) ;
		
//		model.addAttribute("envregion", EnvRegionController.envregion2) ;
		System.out.println("In  Remove Tab, env: "+e);
		List<String> reqData = new ArrayList<String>();
		String[] sentData = tab.split("-");
		for (String a : sentData) {
			reqData.add(a);
		}
		List<String> myNavBarArray= (List<String>) session.getAttribute("navBarArr");
		//Hrushikesh - added for multiple treeview
		List<String> myLsrArray= (List<String>) session.getAttribute("lsrNoArr");
		List<Object> treeViewObjectList = (List<Object>) session.getAttribute("treeViewObjects");
		String Lsr_number= myLsrArray.get(Integer.parseInt(reqData.get(1)));
		
		System.out.println("myNavBarArray before removal"+myNavBarArray+ " , LsrArr: "+myLsrArray);
		myNavBarArray.remove(Integer.parseInt(reqData.get(1)));
		//Remove lsr from list on tab close
		myLsrArray.remove(Integer.parseInt(reqData.get(1)));
		session.setAttribute("navBarArr", myNavBarArray);
		session.setAttribute("lsrNoArr", myLsrArray);
		System.out.println("myNavBarArray after removal"+myNavBarArray+ " , LsrArr: "+myLsrArray);
		//screenObj.remove(Integer.parseInt(reqData.get(1)));
		System.out.println("updated navbararr" + myNavBarArray);

	

		
		//////////////////////close tansaction code ///////////// 
		if(reqData.get(0).equals("treeViewDisplay")|| reqData.get(0).equals("treeview9states")){ 
		
		CloseTransaction closetransaction = new CloseTransaction(); 
		String user_id=(String) session.getAttribute("activeUser"); 
		user_id=user_id.toUpperCase(); 
		System.out.println(user_id); 
		//Hrushikesh - Code commented as LSR is fetched from LSR list for closed tab index
		//String Lsr_number = (String) session.getAttribute("LrsNo"); 
		System.out.println(Lsr_number.substring(0,14)); 
		System.out.println(Lsr_number.substring(15,17)); 
		
		closetransaction.setLsr_number(Lsr_number.substring(0,14)); 
		closetransaction.setNext(Lsr_number.substring(15,17)); 
		closetransaction.setUser_id(user_id); 
		
		closeTransactionService.writeCloseTransactionDataToMQ(closetransaction,user_id,session); 
		
		} 
		
	
		model.addAttribute("navbarArr", myNavBarArray);
		model.addAttribute("lsrNoArr", myLsrArray);
		//System.out.println("navbar now directed to" + myNavBarArray.get(myNavBarArray.size() - 1));
		if((myNavBarArray.size()) == 0)
		{
			session.removeAttribute("showError");
			System.out.println("redirecting to home");
			
			//Hrushikesh - If home page is redirected, remove LSR and its object from list
			myLsrArray.clear();
			treeViewObjectList.clear();
			session.setAttribute("lsrNoArr", myLsrArray);
			session.setAttribute("treeViewObjects", treeViewObjectList);
			System.out.println("Redirecting to Home -> LSR arr: "+myLsrArray.toString()+ " , Treeview Objects:"+treeViewObjectList.toString());
			
			return "redirect:/stateDiv";
		}
		else{
			//System.out.println("navbar now directed to" + myNavBarArray.get(myNavBarArray.size() - 1));
			System.out.println("########");
			//return "redirect:" + myNavBarArray.get(myNavBarArray.size() - 1) + "";
			int size = myNavBarArray.size();
			if(size > 0)
			{
				size = size -1;
			}
			String tabName = "";
			try {
			 tabName = myNavBarArray.get(size) != null? myNavBarArray.get(size) : "";  //Vuln Fix 
			}catch(Exception ex)
			{
				System.out.println("In Remove That Tab: "+ex.getMessage());
			}
			if(tabName.matches("[a-zA-Z]+"))
					return tabInWhiteList(tabName.trim());
			return "";
				
		}
		
	}

	private String tabInWhiteList(String tabName) {
		return Arrays.asList(new String[] { "stateDiv", "selectRequest", "enhancedSelReq", "confirmedByDDESDD",
				"fupRequest", "restrictedMismatch", "unrestrictedMismatch", "issueProvider", "selectProvider",
				"userProfile", "loss", "treeViewDisplay", "treeview9states", "workload" }).contains(tabName) ? tabName
						: "";
	}

	public void getSameTabs(List<String> reqData, ModelMap model, String userId, HttpSession session) {
		System.out.println("getSameTabs--> " + reqData + "flag" + reqData.get(1));
		session.removeAttribute("showError");
		session.removeAttribute("error_msg");
		List<String> myNavBarArray= (List<String>) session.getAttribute("navBarArr");
		//Hrushikesh - used to display lsr no on treeview
		List<String> myLsrNoArr= (List<String>) session.getAttribute("lsrNoArr");
		String environment = (String) session.getAttribute("environment");
		EnvRegion e = envRegionCtrl.getEnvRegion(session);
		model.addAttribute("environment", environment);
				model.addAttribute("envregion", e);
		if (!reqData.get(0).equals(null) && !reqData.get(0).equals("") && "Y".equalsIgnoreCase(reqData.get(1))) {
				System.out.println("User Id is session"+httpSession.getAttribute("activeUser"));
				System.out.println("myNavBarArray before addition"+myNavBarArray);
				if(myNavBarArray==null) {
					List<String> newNavArry=new ArrayList<>();
					List<String> newLsrArry=new ArrayList<>();
					newNavArry.add(reqData.get(0));
					session.setAttribute("navBarArr", newNavArry);
					
					//Hrushikesh- Add LSR in LSR navbar list if it's treeview else add empty string
					if(!reqData.get(0).contains("tree"))
						newLsrArry.add("");
					else
						newLsrArry.add(reqData.get(3));
					session.setAttribute("lsrNoArr", newLsrArry);
				}else {
					myNavBarArray.add(reqData.get(0));
					session.setAttribute("navBarArr", myNavBarArray);
					System.out.println("myNavBarArray after addition"+myNavBarArray);
					
					if(!reqData.get(0).contains("tree"))
						myLsrNoArr.add("");
					else
						myLsrNoArr.add(reqData.get(3));
					session.setAttribute("lsrNoArr", myLsrNoArr);
				}
				
			System.out.println("NavbarArr: "+myNavBarArray+"\n User ID: "+httpSession.getAttribute("activeUser"));
			System.out.println("Session ID :"+httpSession.getId());
			System.out.println("ssssion is "+session);
			Object obj=session.getAttribute("objectHandle");
			String objectHandl=(String) obj;
			int objectHandle=0;
			if(checkNullString(objectHandl)) {
				 objectHandle=1;
				session.setAttribute("objectHandle",objectHandle+"");
			}else {
				Object obj1=session.getAttribute("objectHandle");
				String objectHandl1=(String) obj1;
				objectHandle=Integer.parseInt(objectHandl1);
				objectHandle=objectHandle+1;
				session.setAttribute("objectHandle",objectHandle+"");
			}
			

		}

		System.out.println("updated navbarArr is " + myNavBarArray + " , LsrArr: "+myLsrNoArr);
		model.addAttribute("navbarArr", myNavBarArray);
		model.addAttribute("lsrNoArr", myLsrNoArr);

	}

	public void setDataToCorrespondingDTO(List<String> reqData, ModelMap model,HttpSession session) {
		System.out.println("In set previous tab data method");
		
		String environment = (String) session.getAttribute("environment");
		EnvRegion e = envRegionCtrl.getEnvRegion(session);
		model.addAttribute("environment", environment);
				model.addAttribute("envregion", e);
		 session.setAttribute("CurrentTab", reqData.get(0));
		 session.setAttribute("previousTab", reqData.get(2)==null?"NA":reqData.get(2));
		 session.setAttribute("inputFormData", reqData.get(3)==null?"NA":reqData.get(3));
		 session.setAttribute("fetchedFormData", reqData.get(4)==null?"NA":reqData.get(4));
		 session.setAttribute("previousPageIndex", reqData.get(5)==null?"-1":reqData.get(5));
		 session.setAttribute("curentPageFromFrontend", reqData.get(6)==null?"NA":reqData.get(6));
		 session.setAttribute("currentPageIndex", reqData.get(7)==null?"-1":reqData.get(7));
		 session.setAttribute("maxNoPage", reqData.get(8)==null?"-1":reqData.get(8));
		 
	}

	public static String getObjectHandle(int size) {
		String objHandle = String.format("%08d", size);
		System.out.println("objHandle value is " + objHandle);
		return objHandle;
	}
	
	
	@RequestMapping(value = "/logoutWithTreeview", method = RequestMethod.POST)
	public String logoutWithTreeview(@RequestBody String tab1, ModelMap model, HttpSession session) {
		System.out.println("to /logoutWithTreeview post method ctrl" + tab1);

		String[] myTabs = tab1.split("\\$");
		System.out.println("myTabs-0==>"+myTabs[0]+"myTabs-1==>"+myTabs[1]);
		
		//EnvRegion e = envRegionCtrl.getEnvRegion(session);
		String environment = (String) session.getAttribute("environment");
		EnvRegion e = envRegionCtrl.getEnvRegion(session);
		model.addAttribute("environment", environment);
				model.addAttribute("envregion", e);
		System.out.println("In  logoutTreeview"+e);
//		String treeViewName="";
		
//		if(e.getRegion().equalsIgnoreCase("12 States")) {
//			treeViewName="treeViewDisplay";
//			}else {
//				treeViewName="treeview9states";
//			}
		/*//Prev Logoff logic
		CloseTransaction closetransaction = new CloseTransaction();
		String user_id=(String) session.getAttribute("activeUser");
		List<String> reqData = new ArrayList<String>();	
		if(myTabs[0].equalsIgnoreCase("dummy")) {
			System.out.println("In if when tab is blank "+myTabs[0]);
			closeTransactionService.closeTransactionTreeViewOnLogoutDataToMQ(closetransaction,user_id,session);
		}else {

			
		String[] sentData = myTabs[0].split("_");
		for (String a : sentData) {
			if(!reqData.contains(a)) {
				reqData.add(a);
				}
		}	
		
	System.out.println("In else logoutWithTreeview post reqData"+reqData);
		for(int i=0;i<reqData.size();i++) {
			if(reqData.get(i) !="" || reqData.get(i) != null) {
//				if(treeViewName != "") {
				
					String Lsr_number = reqData.get(i); 
					System.out.println(Lsr_number.substring(0,14)); 
					System.out.println(Lsr_number.substring(15,17)); 
					
					closetransaction.setLsr_number(Lsr_number.substring(0,14)); 
					closetransaction.setNext(Lsr_number.substring(15,17)); 
					closetransaction.setUser_id(user_id);
					
					
					closeTransactionService.writeCloseTransactionDataToMQ(closetransaction, user_id, session) ;
					
				
				
				
//				}
			}
		} 
		closeTransactionService.closeTransactionTreeViewOnLogoutDataToMQ(closetransaction,user_id,session);
		}
		System.out.println("close logoutWithTreeview transaction completed"); */
		
		//New: Logoff with Treeview Close Logic 06/15/2022
		String user_id= session.getAttribute("activeUser") == null? "null" : (String) session.getAttribute("activeUser"); 
		//Hrushi logoff code
		CloseTransaction closetransaction = new CloseTransaction(); 
		List<String> myLsrNoArr= (List<String>) session.getAttribute("lsrNoArr");
		if(myLsrNoArr!=null && !myLsrNoArr.isEmpty())
		{
			System.out.println("Closing LSR's List is: "+myLsrNoArr.toString());
			for(String lsr: myLsrNoArr) {
				if(lsr.trim()!="" && lsr.contains("-"))
				{
					System.out.println("Close Transaction for LSR "+lsr+ " started for user "+user_id);
					closetransaction.setLsr_number(lsr.substring(0,14)); 
					closetransaction.setNext(lsr.substring(15,17)); 
					closetransaction.setUser_id(user_id);
					
					closeTransactionService.writeCloseTransactionDataToMQ(closetransaction, user_id, session) ;
				}
			}
		}
		
		System.out.println("close logoutWithTreeview transaction started for "+user_id);
		closeTransactionService.closeTransactionTreeViewOnLogoutDataToMQ(closetransaction,user_id,session);
		System.out.println("close logoutWithTreeview transaction completed for "+user_id);
		 session.  invalidate();
		 
//		 if(myTabs[1].equalsIgnoreCase("onelasrgui-w.stage.az.3pc.att.com")) {
//			 return "redirect:/https://onelasrgui-w.stage.az.3pc.att.com/OneLASRGUI/login/oauth2/code/globallogon_W";
//		 }else if(myTabs[1].equalsIgnoreCase("onelasrgui-se.stage.az.3pc.att.com")) {
//			 return "redirect:/https://onelasrgui-se.stage.az.3pc.att.com/OneLASRGUI/login/oauth2/code/globallogon_SE";
//		 }else if(myTabs[1].equalsIgnoreCase("onelasrgui-sw.stage.az.3pc.att.com")) {
//			 return "redirect:/https://onelasrgui-sw.stage.az.3pc.att.com/OneLASRGUI/login/oauth2/code/globallogon_SW";
//		 }else if(myTabs[1].equalsIgnoreCase("onelasrgui-mw.stage.az.3pc.att.com")) {
//			 return "redirect:/https://onelasrgui-se.stage.az.3pc.att.com/OneLASRGUI/login/oauth2/code/globallogon_MW";
//		 }

			
			return "redirect:/envRegion";
		
	 }
			
		
		
		
		

	 @RequestMapping(value = "/manRejIssueFun", method = RequestMethod.POST)
		public String manRejIssueFun(@RequestBody String manRejRows, ModelMap model, HttpSession session) {
			System.out.println("to /manRejIssueFun post method ctrl" + manRejRows);
			String userId = (String) session.getAttribute("activeUser");
			String environment = (String) session.getAttribute("environment");
			EnvRegion e = envRegionCtrl.getEnvRegion(session);
			model.addAttribute("environment", environment);
					model.addAttribute("envregion", e);
			List<String> reqData = new ArrayList<String>(); 

			 String myLscNote = manRejRows.substring(manRejRows.lastIndexOf("$") + 1);
			System.out.println("lscNotes"+myLscNote);

			
			String[] sentData = manRejRows.split("\\$");
			for (String a : sentData) {
				a.trim();	
				reqData.add(a);
			}
			LscNoteDTO lscNoteData = new LscNoteDTO();
//			System.out.println("reqData(1) lsc notes"+reqData.get(1));
//			System.out.println("sentData(1) lsc notes"+sentData[1]);
			lscNoteData.setNotesDatetime(null);
			lscNoteData.setUserIdAttr("Y");
			lscNoteData.setUserId(userId);
			lscNoteData.setLasrVerAttr("Y");
			lscNoteData.setLasrVer("00");
			lscNoteData.setFollowUpDateAttr("Y");
			lscNoteData.setFollowUpDate(null);
			lscNoteData.setNotesAttr("Y");
			lscNoteData.setNotes(null==myLscNote ? "" : myLscNote);
			 //  qwer !@#$%^*()[]{}|\<>,.?/"';:   
			List<ManualRejectDTO> manualRejectDataList = new ArrayList<ManualRejectDTO>();
			List<String> manualRejectDataRows = new ArrayList<String>();


			
			
			String[] selDataManRej = reqData.get(0).split(",");
			for (String a : selDataManRej) {
				 if(a !="") {
				manualRejectDataRows.add(a); 
				}
					
			}
			//      abcd !@#%^&*()_+=-_+=\|]}[{'";:/?.>,<  aa  
			for(int i=0;i<manualRejectDataRows.size();i++) {
				 List<String> otherField = new ArrayList<String>();
				String[] otherFieldsList=manualRejectDataRows.get(i).split("_");
				for (String a : otherFieldsList) {
					if(a !=null) {
						otherField.add(a);
					}

					
				}  
				
				List<String> fields= new ArrayList<String>();
				String[] fieldsList=otherField.get(1).split("-");

				String itemNum="";
				String numName="";
				String numNbr="";
				String legItemNum="";
				String legNum="";
				
				if(otherField.get(1) !="----") {
					
					
					int myCount=0;
					for (String a : fieldsList) {
						myCount++;
					if(myCount ==1) {
						itemNum=a;
					}else if(myCount ==2) {
						numName=a;
					}else if(myCount ==3) {
						numNbr=a;
					}else if(myCount ==4) {
						legItemNum=a;
					}else if(myCount ==5) {
						legNum=a;
					}	
						
					
				}
				
				}
//				System.out.println("fields" + itemNum+numName+numNbr+legItemNum+legNum);
				
				String[] selDataManRejList = otherField.get(0).split(" ");
				ManualRejectDTO manualRejectDTO = new ManualRejectDTO();
				 List<String> data = new ArrayList<String>();
				
				for (String a : selDataManRejList) {
					if(a !=null) {
					data.add(a.trim());
					}
					
				} 
				String rejMesage="";
				for(int s=2;s<data.size();s++) {
					rejMesage=rejMesage+" "+data.get(s);
				}
				rejMesage=rejMesage.trim();
//				System.out.println("myAllComment"+rejMesage);


				
				String fieldWithdash=data.get(0); 
				if(fieldWithdash.contains("-")) {
					fieldWithdash=fieldWithdash.replace("-", " ");

				}				
				
				
					if(rejMesage.contains("Other")) {				
					String replacementStr=fieldWithdash+" "+"Other;";
					rejMesage=rejMesage.replace("Other ",replacementStr );
				}else {
				rejMesage=fieldWithdash+" "+rejMesage;
			}
				System.out.println("rejMesage-->"+rejMesage);				
				
				// session.setAttribute("LoginManualRejectRec018Data", manualRejectRec018);				

				List<ManualRejectRec018> manualRejectRec018Data= (List<ManualRejectRec018>) session.getAttribute("LoginManualRejectRec018Data");
				String lexFieldId="";
			if( manualRejectRec018Data != null) {
				for(int t=0;t<manualRejectRec018Data.size();t++) {
					if(manualRejectRec018Data.get(t).getName().equalsIgnoreCase(fieldWithdash)) {
						lexFieldId=manualRejectRec018Data.get(t).getType();
					}
				}
			}
				manualRejectDTO.setFieldNameAttr("Y");
				manualRejectDTO.setFiedName(fieldWithdash);
				manualRejectDTO.setRejectCodeAttr("Y");
				manualRejectDTO.setRejectCode(data.get(1));
				manualRejectDTO.setRejectMessageAttr("Y");
				manualRejectDTO.setRejectMessage(rejMesage);
				manualRejectDTO.setItemnumAttr("Y");
				manualRejectDTO.setItemnum(itemNum);
				manualRejectDTO.setSublegnumAttr("Y");
				manualRejectDTO.setSublegnum(legItemNum); //// Sublegnum is actually legitemnum
				manualRejectDTO.setNumnameAttr("Y");
				manualRejectDTO.setNumname(numName);
				manualRejectDTO.setNumnbrAttr("Y");
				manualRejectDTO.setNumnbr(numNbr);
				manualRejectDTO.setLegnumAttr("Y");
				manualRejectDTO.setLegnum(legNum);
				manualRejectDTO.setLexFieldIdAttr("Y");
				manualRejectDTO.setLexFieldId(lexFieldId);
				
				manualRejectDataList.add(manualRejectDTO);
				System.out.println("manualRejectDTO set data"+manualRejectDTO);
				
			}
			lscNoteData.setManualRejectDTOList(manualRejectDataList);
			System.out.println("lscNoteData->"+lscNoteData.toString());
			Header receivedHeader=manualRejectTransactionService.writeManualRejDataToMQ(lscNoteData, userId, session,model);
			String returnValue = "";
			String statesIdentity = (String) session.getAttribute("States");
			System.out.print("statesIdentity:::Controller::::" + statesIdentity);
			if (statesIdentity.equalsIgnoreCase("Y")) {
				returnValue = "redirect:/treeViewDisplay";
			} else {
				returnValue = "redirect:/treeview9states";
			}
			if(receivedHeader !=null) {
				if(receivedHeader.getReturn_code().trim().equalsIgnoreCase("000")) {
					System.out.println("mnual reject transaction done successfully");
					selectCtrl.completionselectOkPopup(model,session);

					session.setAttribute("manRejIssueSuccess", "Updated Successfully");
					model.addAttribute("manRejIssueSuccess", "Updated Successful");
			return returnValue;
				}
			
			}

			
				
				
				System.out.print("returnValue:::Controller::::" + returnValue);

			return returnValue;

		 }
	
		  	
		
	


}
