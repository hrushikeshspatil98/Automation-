package com.att.lasr.model;

import com.att.lasr.utils.Constants;
import com.att.lasr.utils.FormatUtil;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

/**
 * @author sp860u
 *
 */
@Setter
@Getter
@NoArgsConstructor
@ToString
public class ConfirmationTask_RecId_551 {

	private String item_num ;
	private String hnum ;
	private String hid_attr ;
	private String hid ;
	private String hunt_tli_attr ;
	private String hunt_tli ;
	
	public String getSelectRequest551DataString() {
		StringBuilder selectRequestDataSb = new StringBuilder();

		
		selectRequestDataSb.append(FormatUtil.getValueWithSpaces(item_num, 4)).append(Constants.TAB);
		selectRequestDataSb.append(FormatUtil.getValueWithSpaces(hnum, 5)).append(Constants.TAB);
		selectRequestDataSb.append(FormatUtil.getValueWithSpaces(hid_attr, 1)).append(Constants.TAB);
		selectRequestDataSb.append(FormatUtil.getValueWithSpaces(hid, 4)).append(Constants.TAB);
		selectRequestDataSb.append(FormatUtil.getValueWithSpaces(hunt_tli_attr, 1)).append(Constants.TAB);
		
		
		
		selectRequestDataSb.append(FormatUtil.getValueWithSpaces(hunt_tli, 12)).append(Constants.TAB).append(Constants.TAB);;
		
		String selectRequestDataString = FormatUtil.getValueWithSpaces(selectRequestDataSb.toString(), 2400);
		return selectRequestDataString;
	}
	public String getSelectRequest551DataString12() {
		StringBuilder selectRequestDataSb = new StringBuilder();

		
		selectRequestDataSb.append(FormatUtil.getValueWithSpaces(item_num, 4)).append(Constants.TAB);
		selectRequestDataSb.append(FormatUtil.getValueWithSpaces(hnum, 4)).append(Constants.TAB);
		selectRequestDataSb.append(FormatUtil.getValueWithSpaces(hid_attr, 1)).append(Constants.TAB);
		selectRequestDataSb.append(FormatUtil.getValueWithSpaces(hid, 4)).append(Constants.TAB);
		selectRequestDataSb.append(FormatUtil.getValueWithSpaces(hunt_tli_attr, 1)).append(Constants.TAB);
		
		
		
		selectRequestDataSb.append(FormatUtil.getValueWithSpaces(hunt_tli, 12)).append(Constants.TAB).append(Constants.TAB);;
		
		String selectRequestDataString = FormatUtil.getValueWithSpaces(selectRequestDataSb.toString(), 2400);
		return selectRequestDataString;
	}
	
}
