package com.att.lasr.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.SessionAttributes;

import com.att.lasr.model.AttCancelTask;
import com.att.lasr.model.AttCancelTask9;
import com.att.lasr.model.CloseTransaction;
import com.att.lasr.model.CompletionActivityRLSOG6LscInfo;
import com.att.lasr.model.CompletionMainTask;
import com.att.lasr.model.CompletionProviderLoss_578;
import com.att.lasr.model.CompletionProviderTask;
import com.att.lasr.model.CompletionProviderTaskWithLoss;
import com.att.lasr.model.CompletionProviderTaskWithLossLasrInfo;
import com.att.lasr.model.ConfirmationLS0G6DW2Row;
import com.att.lasr.model.ConfirmationLS0G6DW3Row;
import com.att.lasr.model.ConfirmationReqtypRLSOG6102Row;
import com.att.lasr.model.ConfirmationTaskNEmailXMLGW9RecId905;
import com.att.lasr.model.ConfirmationTaskNEmailXMLGW9RecId906;
import com.att.lasr.model.ConfirmationTaskNoProd9Main;
import com.att.lasr.model.ConfirmationTaskNoProd_RecId_556;
import com.att.lasr.model.ConfirmationTask_RecId12_550;
import com.att.lasr.model.ConfirmationTask_RecId_550;
import com.att.lasr.model.ConfirmationTask_RecId_551;
import com.att.lasr.model.ConfirmationTask_RecId_552;
import com.att.lasr.model.ConfirmationTask_RecId_558;
import com.att.lasr.model.Confirmationtaskmain12states;
import com.att.lasr.model.ConfirmedByEsddData;
import com.att.lasr.model.ConformationTaskMain;
import com.att.lasr.model.CorrectingConfTask9Main;
import com.att.lasr.model.CorrectingConfTask9_RecId_850;
import com.att.lasr.model.CorrectingConfTask9_RecId_851;
import com.att.lasr.model.CorrectingConfTask9_RecId_852;
import com.att.lasr.model.CorrectingConfTaskNoProdMain;
import com.att.lasr.model.CorrectingConfirmationLS0G6DW1row;
import com.att.lasr.model.CorrectingConfirmationLS0G6DW5row;
import com.att.lasr.model.Correcting_ConfirmationTask_RecId_856;
import com.att.lasr.model.Correcting_ConfirmationTask_RecId_858;
import com.att.lasr.model.Correctingconfirmationtaskmain12states;
import com.att.lasr.model.EcverView;
import com.att.lasr.model.EditEccktTableRow;
import com.att.lasr.model.EnhancedSelectData;
import com.att.lasr.model.EnhancedSelectTableRow;
import com.att.lasr.model.EnvRegion;
import com.att.lasr.model.FollowUpData;
import com.att.lasr.model.FollowUpData9States;
import com.att.lasr.model.FollowUpTableRow;
import com.att.lasr.model.FupRequestData;
import com.att.lasr.model.Header;
import com.att.lasr.model.JeopardyListRechId014;
import com.att.lasr.model.JeopardyListRechId019;
import com.att.lasr.model.JeopardyMain12State;
import com.att.lasr.model.JeopardyTask;
import com.att.lasr.model.JeopardyTask12STRechId581;
import com.att.lasr.model.JeopardyTask12STRechId582;
import com.att.lasr.model.Login;
import com.att.lasr.model.NotesFupBindingData12States;
import com.att.lasr.model.NotesFupBindingData9States;
import com.att.lasr.model.PostToBillTaskLSCInfo_588;
import com.att.lasr.model.PostToBillTask_RecId585;
import com.att.lasr.model.SelectRequestData;
import com.att.lasr.model.SelectRequestTableRow;
import com.att.lasr.model.SelectRequestTableRow9;
import com.att.lasr.model.ShowError;
import com.att.lasr.model.UpdateOrderNumberData;
import com.att.lasr.model.UpdateOrderNumberRow;
import com.att.lasr.service.AttCancelReqService;
import com.att.lasr.service.AttCancelTaskReqService;
import com.att.lasr.service.AttCancelTask_9StateService;
import com.att.lasr.service.AttCancel_9StateService;
import com.att.lasr.service.CloseTransactionService;
import com.att.lasr.service.CompletionProviderWithLossService;
import com.att.lasr.service.ConfirmedByEsddService;
import com.att.lasr.service.CorrectingConfViewService;
import com.att.lasr.service.EditEccktService;
import com.att.lasr.service.EnhancedSelectService;
import com.att.lasr.service.FollowUpService;
import com.att.lasr.service.FupRequestService;
import com.att.lasr.service.JeopardyTaskService;
import com.att.lasr.service.PreIssueService;
import com.att.lasr.service.ReadErrorMsgsJson;
import com.att.lasr.service.SelectRequestService;
import com.att.lasr.service.TreeView_12StateEnhanceService;
import com.att.lasr.service.TreeView_12StateService;
import com.att.lasr.service.TreeView_9StateEnhanceService;
import com.att.lasr.service.TreeView_9StateService;
import com.att.lasr.service.UpdateOrderNumberService;
import com.att.lasr.service.UserProfileService;
import com.att.lasr.utils.MockDtoDataUtil;
import com.google.gson.Gson;
import com.nimbusds.oauth2.sdk.util.CollectionUtils;

@Controller
@SessionAttributes("region")
public class SelectController {

	// @Autowired
	// HttpSession httpSession;
	@Autowired
	private AttCancelReqService attCancelReqService;

	@Autowired
	private AttCancelTaskReqService attCancelTaskReqService;

	@Autowired
	private AttCancel_9StateService attCancel_9StateService;

	@Autowired
	private AttCancelTask_9StateService attCancelTask_9StateService;

	@Autowired
	private TreeView_12StateEnhanceService treeView_12StateEnhanceService;
	
	@Autowired
	private TreeView_9StateEnhanceService treeView_9StateEnhanceService;
	
	@Autowired
	public WorkloadController workloadCtrl;

	@Autowired
	private FollowUpService followUpService;

	@Autowired
	private SelectRequestService selectRequestService;

	@Autowired
	private TreeView_12StateService treeView_12StateService;
	@Autowired
	private PreIssueService preIssueService;
	@Autowired
	private TreeView_9StateService treeView_9StateService;

	@Autowired
	private CloseTransactionService closeTransactionService;

	@Autowired
	private EnhancedSelectService enhancedSelectService;
	@Autowired
	private UserProfileService userProfileService;

	@Autowired
	private HttpServletResponse response;

	@Autowired
	private ConfirmedByEsddService confirmedByEsddService;

	@Autowired
	private FupRequestService fupRequestService;

	@Autowired
	EnvRegionController envRegionCtrl;
	@Autowired
	private EditEccktService eccktService;

	@Autowired
	private UpdateOrderNumberService updateOrderService;

	@Autowired
	private JeopardyTaskService jeopardyTaskService;
	
	@Autowired
	private CompletionProviderWithLossService completionProviderWithLossService;
	
	@Autowired
	private CorrectingConfViewService correctingConfViewService;

//	EnvRegion e = EnvRegionController.getobj();

@Value("${myApplication.autoGrowCollectionLimit:5000}")
    private int autoGrowCollectionLimit;


    @InitBinder
    public void initBinder(WebDataBinder dataBinder) {
        dataBinder.setAutoGrowCollectionLimit(autoGrowCollectionLimit);
    }


	@RequestMapping(value = "/selectRequest", method = RequestMethod.GET)
	public String showSelectRequestPage(ModelMap model, HttpSession session) {
		System.out.println("in /select get method");

		EnvRegion e = envRegionCtrl.getEnvRegion(session);
		String userId = (String) session.getAttribute("userId");
		String environment = (String) session.getAttribute("environment");
//		EnvRegion e = envRegionCtrl.getEnvRegionFromSession(session,model);
//		Login login = EnvRegionController.getLoginObject();

		Login login =envRegionCtrl.getLoginObjectFromSession(session);

		
		System.out.println("User Id in Workload GET: " + userId);
		model.addAttribute("userId", userId);
		model.addAttribute("environment", environment);
		model.addAttribute("envregion", e);
		model.addAttribute("indicator", false);
		model.addAttribute("indicator1",false)	;
		model.addAttribute("indicator2",false)	;
		model.addAttribute("indicator3",false)	;
		model.addAttribute("indicator4",false) ;
		model.addAttribute("login", login);
		model.addAttribute("screenObj", workloadCtrl.screenObj);
		model.addAttribute("navbarArr", session.getAttribute("navBarArr"));
		String currInde = "";
		Object currInd = session.getAttribute("currentPageIndex");
		if (!(currInd == null)) {
			currInde = currInd.toString();
			System.out.println("session -->" + session.getAttribute("currentPageIndex"));
			System.out.println("currInde" + currInde);
		}

		int currIndex = 0;
		if (!checkNullString(currInde)) {
			currIndex = Integer.parseInt(currInde);
			session.setAttribute("currentPageIndex", currIndex + "");
		}
		SelectRequestData selectRequestData = getSelectRequestDataFromSession(session, currIndex);
		model.addAttribute("selectRequestData", selectRequestData);

		return "selectRequest";
	}

	@RequestMapping(value = "/selectRequest", method = RequestMethod.POST)
	public String addTabOfSamePageSR(@RequestBody String tab, ModelMap model, HttpSession session) {

		System.out.println("in  /selectRequest post method ->>" + tab);
		session.setAttribute("manRejButton", "none");
		EnvRegion e = envRegionCtrl.getEnvRegion(session);
		String activeUser = (String) session.getAttribute("activeUser");
		String environment = (String) session.getAttribute("environment");
		String userId = (String) session.getAttribute("userId");

		List<String> reqData = new ArrayList<String>();
		String[] sentData = tab.split("\\$");
		System.out.println("sentData after separation" + sentData);
		for (String a : sentData) {
			reqData.add(a);
			System.out.println("send data select-> " + a);
		}

		if ("F".equalsIgnoreCase(reqData.get(1))) {
			fetchSelectRequestData(reqData, model, session);
		}else if ("R".equalsIgnoreCase(reqData.get(1))) {
			resetSelectData(reqData, model, session);
		} else {

			workloadCtrl.setDataToCorrespondingDTO(reqData, model, session);
			if ("Y".equalsIgnoreCase(reqData.get(1))) {
				workloadCtrl.getSameTabs(reqData, model, userId, session);
			}
		}
//		EnvRegion e = envRegionCtrl.getEnvRegionFromSession(session,model);
		model.addAttribute("activeUser", activeUser);
		model.addAttribute("environment", environment);
		model.addAttribute("envregion", e);
		model.addAttribute("indicator", false);
		model.addAttribute("indicator1",false)	;
		model.addAttribute("indicator2",false)	;
		model.addAttribute("indicator3",false)	;
		model.addAttribute("indicator4",false) ;
		return "selectRequest";
	}

	private SelectRequestData getSelectRequestDataFromSession(HttpSession session, int currIndex) {

		SelectRequestData myselectReqObj = new SelectRequestData();
		try {

			List<SelectRequestData> selectRequestlist = (List<SelectRequestData>) session
					.getAttribute("selectRequestDatalist");
			System.out.println("selectRequestlist size-->" + selectRequestlist.size());
			return selectRequestlist.get(currIndex);
		} catch (Exception e) {
			System.out.println("got exception" + e.getMessage());
			return myselectReqObj;

		}

	}

	public void fetchSelectRequestData(List<String> sentData, ModelMap model, HttpSession session) {
//	String user_id = EnvRegionController.getLoginObject().getUser_id();
		String user_id = (String) session.getAttribute("activeUser");
		user_id = user_id.toUpperCase();
		int currentIndex = Integer.parseInt(sentData.get(7));
		session.setAttribute("currentPageIndex", currentIndex);
		String objHandle = (String) session.getAttribute("objectHandle");
		int objectHandle = 0;
		if (checkNullString(objHandle)) {
			objHandle = 1 + "";
			objectHandle = Integer.parseInt(objHandle);
			session.setAttribute("objectHandle", objectHandle);
		} else {
			System.out.println("in else objhandle");
		}
		model.remove("selectRequestData");
		String reg = (String) session.getAttribute("myReg");
		SelectRequestData selData = new SelectRequestData();

		System.out.println("selectRequestData ->>: " + sentData.get(3));
		Gson gson = new Gson();
		SelectRequestData selectRequestData = gson.fromJson(sentData.get(3), SelectRequestData.class);
		String object_handle = workloadCtrl.getObjectHandle(objectHandle);
//		System.out.println("selectRequestData ->>: " + selectRequestData.toString());

		selData = selectRequestService.writeSelectRequestDataToMQ(selectRequestData, user_id, object_handle, session);
		session.setAttribute("selData", selData);
		setSelectRequestDataObj(selData, currentIndex, session);
		System.out.println("RestrictedMismatchDataWithMQData size-->" + selData.getSelectRequestTableRows9().size());
//		System.out.println("To show object handle in retrieved data w0" + selData);
		model.addAttribute("selectRequestData", selData);

	}

	private void setSelectRequestDataObj(SelectRequestData selData, int currentIndex, HttpSession session) {

//		System.out.println("selData in selDataDataObj-->" + selData);
		List<SelectRequestData> selectRequestDatalist = (List<SelectRequestData>) session
				.getAttribute("selectRequestDatalist");
		List<SelectRequestData> selectRequestDataLst = new ArrayList<SelectRequestData>();
		if (selectRequestDatalist == null) {

			for (int x = 0; x < 5; x++) {
				SelectRequestData selectReqData = new SelectRequestData();
				selectReqData = MockDtoDataUtil.getSelectRequestMockDtoData();
				selectRequestDataLst.add(selectReqData);
			}
			session.setAttribute("selectRequestDatalist", selectRequestDataLst);
			selectRequestDatalist = (List<SelectRequestData>) session.getAttribute("selectRequestDatalist");
			System.out.println("selectRequestDatalist from session size" + selectRequestDatalist.size());

			selectRequestDatalist.set(currentIndex, selData);
			session.setAttribute("selectRequestDatalist", selectRequestDataLst);
		} else {
			selectRequestDatalist.set(currentIndex, selData);
			session.setAttribute("selectRequestDatalist", selectRequestDatalist);
		}

	}

	public boolean checkNullString(String val) {
		boolean flag = true;
		if ("".equals(val) || val == null) {
			flag = true;
		} else {
			flag = false;
		}
		return flag;
	}

	private void setSelReqData(SelectRequestData selReqData, int currentIndex, HttpSession session) {

		System.out.println("wrklod in setSelReqData-->" + selReqData);
		List<SelectRequestData> selectReqDatalist = (List<SelectRequestData>) session
				.getAttribute("selectRequestDatalist");
		List<SelectRequestData> selectReqDataLst = new ArrayList<SelectRequestData>();
		if (selectReqDatalist == null) {

			for (int x = 0; x < 5; x++) {
				SelectRequestData selReq = new SelectRequestData();
				selReq = MockDtoDataUtil.getSelectRequestMockDtoData();
				selectReqDataLst.add(selReq);
			}
			session.setAttribute("selectRequestDatalist", selectReqDataLst);
			selectReqDatalist = (List<SelectRequestData>) session.getAttribute("selectRequestDatalist");
			System.out.println("selectReqDatalist from session size" + selectReqDatalist.size());

			selectReqDatalist.set(currentIndex, selReqData);
			session.setAttribute("selectRequestDatalist", selectReqDataLst);
		} else {
			selectReqDatalist.set(currentIndex, selReqData);
			session.setAttribute("selectRequestDatalist", selectReqDatalist);
		}
	}

	@RequestMapping(value = "/enhancedSelReq", method = RequestMethod.GET)
	public String showEnhancedSelReqPage(ModelMap model, HttpSession session) {
		System.out.println("in /enhanced get method");
		EnvRegion e = envRegionCtrl.getEnvRegion(session);
		String userId = (String) session.getAttribute("userId");
		String environment = (String) session.getAttribute("environment");
		List<String> myNavBarArray = (List<String>) session.getAttribute("navBarArr");
//	EnvRegion e = envRegionCtrl.getEnvRegionFromSession(session,model);
		model.addAttribute("userId", userId);
		model.addAttribute("environment", environment);
		model.addAttribute("envregion", e);
		model.addAttribute("navbarArr", myNavBarArray);
		model.addAttribute("indicator", false);
		model.addAttribute("indicator1",false)	;
		model.addAttribute("indicator2",false)	;
		model.addAttribute("indicator3",false)	;
		model.addAttribute("indicator4",false) ;
		String currInde = "";
		Object currInd = session.getAttribute("currentPageIndex");
		if (!(currInd == null)) {
			currInde = currInd.toString();
			System.out.println("session -->" + session.getAttribute("currentPageIndex"));
			System.out.println("currInde" + currInde);
		}

		int currIndex = 0;
		if (!workloadCtrl.checkNullString(currInde)) {
			currIndex = Integer.parseInt(currInde);
			session.setAttribute("currentPageIndex", currIndex + "");
		}

		EnhancedSelectData enhancedRequestData = getEnhancedRequestDataFromSession(session, currIndex);
		model.addAttribute("enhancedSelectData", enhancedRequestData);

		return "enhancedSelReq";
	}

	private EnhancedSelectData getEnhancedRequestDataFromSession(HttpSession session, int currIndex) {

		EnhancedSelectData myEnhancedSelectObj = new EnhancedSelectData();
		try {

			List<EnhancedSelectData> enhancedSelectlist = (List<EnhancedSelectData>) session
					.getAttribute("enhancedSelectDatalist");
			System.out.println("enhancedSelectlist size-->" + enhancedSelectlist.size());
			return enhancedSelectlist.get(currIndex);
		} catch (Exception e) {
			System.out.println("got exception" + e.getMessage());
			return myEnhancedSelectObj;

		}

	}

	@RequestMapping(value = "/enhancedSelReq", method = RequestMethod.POST)
	public String addTabOfSamePageER(@RequestBody String tab, ModelMap model, HttpSession session) {
		System.out.println("in  /enhancedSelReq post method ->>" + tab);

		EnvRegion e = envRegionCtrl.getEnvRegion(session);
		String activeUser = (String) session.getAttribute("activeUser");
		String environment = (String) session.getAttribute("environment");
		String userId = (String) session.getAttribute("userId");

		List<String> reqData = new ArrayList<String>();
		String[] sentData = tab.split("\\$");
		System.out.println("sentData after separation" + sentData);
		for (String a : sentData) {
			reqData.add(a);
//			System.out.println("send data enhancedSelReq-> " + a);
		}

		if ("F".equalsIgnoreCase(reqData.get(1))) {
			fetchEnhancedRequestData(reqData, model, session);
		}else if ("R".equalsIgnoreCase(reqData.get(1))) {
			resetSelectData(reqData, model, session);
		}  else {

			workloadCtrl.setDataToCorrespondingDTO(reqData, model, session);
			if ("Y".equalsIgnoreCase(reqData.get(1))) {
				workloadCtrl.getSameTabs(reqData, model, userId, session);
			}
		}
//		EnvRegion e = envRegionCtrl.getEnvRegionFromSession(session,model);
		model.addAttribute("activeUser", activeUser);
		model.addAttribute("environment", environment);
		model.addAttribute("envregion", e);
		model.addAttribute("indicator", false);
		model.addAttribute("indicator1",false)	;
		model.addAttribute("indicator2",false)	;
		model.addAttribute("indicator3",false)	;
		model.addAttribute("indicator4",false) ;
		return "enhancedSelReq";
	}

	public void fetchEnhancedRequestData(List<String> sentData, ModelMap model, HttpSession session) {
//		String user_id = EnvRegionController.getLoginObject().getUser_id();
		String user_id = (String) session.getAttribute("activeUser");
		user_id = user_id.toUpperCase();
		int currentIndex = Integer.parseInt(sentData.get(7));

		session.setAttribute("currentPageIndex", currentIndex);
		String objHandle = (String) session.getAttribute("objectHandle");
		int objectHandle = 0;
		if (workloadCtrl.checkNullString(objHandle)) {
			objHandle = 1 + "";
			objectHandle = Integer.parseInt(objHandle);
			session.setAttribute("objectHandle", objectHandle);
		}

		Gson gson = new Gson();
		EnhancedSelectData enhancedSelectData = gson.fromJson(sentData.get(3), EnhancedSelectData.class);
		String object_handle = workloadCtrl.getObjectHandle(objectHandle);
//		System.out.println("EnhancedSelectData ->>: " + enhancedSelectData.toString());

		EnhancedSelectData enhancedSelData = new EnhancedSelectData();
		enhancedSelData = enhancedSelectService.writeEnhancedSelectDataToMQ(enhancedSelectData, user_id, object_handle,session);

		setEnhancedSelectDataObj(enhancedSelData, currentIndex, session);
		System.out.println("enhancedselDataWithMQData size-->" + enhancedSelData.getEnhancedSelectTableRows().size());
//		System.out.println("To show object handle in retrieved data w0" + enhancedSelData);

	}

	private void setEnhancedSelectDataObj(EnhancedSelectData enhancedSelData, int currentIndex, HttpSession session) {

//		System.out.println("enhancedSelData in setEnhancedSelectDataObj-->" + enhancedSelData);
		List<EnhancedSelectData> enhancedSelectDatalist = (List<EnhancedSelectData>) session
				.getAttribute("enhancedSelectDatalist");
		List<EnhancedSelectData> enhancedSelectDataLst = new ArrayList<EnhancedSelectData>();
		if (enhancedSelectDatalist == null) {

			for (int x = 0; x < 5; x++) {
				EnhancedSelectData enhSel = new EnhancedSelectData();
				enhSel = MockDtoDataUtil.getEnhancedMockSelectData();
				enhancedSelectDataLst.add(enhSel);
			}
			session.setAttribute("enhancedSelectDatalist", enhancedSelectDataLst);
			enhancedSelectDatalist = (List<EnhancedSelectData>) session.getAttribute("enhancedSelectDatalist");
			System.out.println("enhancedSelectDatalist from session size" + enhancedSelectDatalist.size());

			enhancedSelectDatalist.set(currentIndex, enhancedSelData);
			session.setAttribute("enhancedSelectDatalist", enhancedSelectDataLst);
		} else {
			enhancedSelectDatalist.set(currentIndex, enhancedSelData);
			session.setAttribute("enhancedSelectDatalist", enhancedSelectDatalist);
		}

	}

	@RequestMapping(value = "/confirmedByDDESDD", method = RequestMethod.GET)
	public String showConfirmedByDDESDDPage(ModelMap model, HttpSession session) {
		System.out.println("in /confirmedByDD get method");

		EnvRegion e = envRegionCtrl.getEnvRegion(session);
		String userId = (String) session.getAttribute("userId");
		String environment = (String) session.getAttribute("environment");

		List<String> myNavBarArray = (List<String>) session.getAttribute("navBarArr");
//		EnvRegion e = envRegionCtrl.getEnvRegionFromSession(session,model);
		model.addAttribute("userId", userId);
		model.addAttribute("environment", environment);
		model.addAttribute("envregion", e);
		model.addAttribute("navbarArr", myNavBarArray);
		model.addAttribute("indicator", false);
		model.addAttribute("indicator1",false)	;
		model.addAttribute("indicator2",false)	;
		model.addAttribute("indicator3",false)	;
		model.addAttribute("indicator4",false) ;
		String currInde = "";
		Object currInd = session.getAttribute("currentPageIndex");
		if (!(currInd == null)) {
			currInde = currInd.toString();
			System.out.println("session -->" + session.getAttribute("currentPageIndex"));
			System.out.println("currInde" + currInde);
		}

		int currIndex = 0;
		if (!workloadCtrl.checkNullString(currInde)) {
			currIndex = Integer.parseInt(currInde);
			session.setAttribute("currentPageIndex", currIndex + "");
		}

		ConfirmedByEsddData confirmedByData = getconfirmedByDataFromSession(session, currIndex);
		model.addAttribute("confirmedByEsddData", confirmedByData);

		model.addAttribute("navbarArr", myNavBarArray);
		model.addAttribute("envregion", e);
		return "confirmedByDDESDD";
	}

	private ConfirmedByEsddData getconfirmedByDataFromSession(HttpSession session, int currIndex) {

		ConfirmedByEsddData myConfirmedByObj = new ConfirmedByEsddData();
		try {

			List<ConfirmedByEsddData> confirmedBylist = (List<ConfirmedByEsddData>) session
					.getAttribute("confirmedByEsddDatalist");
			System.out.println("confirmedBylist size-->" + confirmedBylist.size());
			return confirmedBylist.get(currIndex);
		} catch (Exception e) {
			System.out.println("got exception" + e.getMessage());
			return myConfirmedByObj;

		}

	}

	@RequestMapping(value = "/confirmedByDDESDD", method = RequestMethod.POST)
	public String addTabOfSamePageCBD(@RequestBody String tab, ModelMap model, HttpSession session) {
		System.out.println("in  /confirmedByDD post method ->>" + tab);
		EnvRegion e = envRegionCtrl.getEnvRegion(session);
		String activeUser = (String) session.getAttribute("activeUser");
		String environment = (String) session.getAttribute("environment");
		String userId = (String) session.getAttribute("userId");

		List<String> reqData = new ArrayList<String>();
		String[] sentData = tab.split("\\$");
		System.out.println("sentData after separation" + sentData);
		for (String a : sentData) {
			reqData.add(a);
			System.out.println("send data confirmedByDD-> " + a);
		}

		if ("F".equalsIgnoreCase(reqData.get(1))) {
			fetchConfirmedByDDRequestData(reqData, model, session);
		} else {

			workloadCtrl.setDataToCorrespondingDTO(reqData, model, session);
			if ("Y".equalsIgnoreCase(reqData.get(1))) {
				workloadCtrl.getSameTabs(reqData, model, userId, session);
			}
		}
//		EnvRegion e = envRegionCtrl.getEnvRegionFromSession(session,model);
		model.addAttribute("activeUser", activeUser);
		model.addAttribute("environment", environment);
		model.addAttribute("envregion", e);
		model.addAttribute("indicator", false);
		model.addAttribute("indicator1",false)	;
		model.addAttribute("indicator2",false)	;
		model.addAttribute("indicator3",false)	;
		model.addAttribute("indicator4",false) ;
		return "confirmedByDDESDD";
	}

	public void fetchConfirmedByDDRequestData(List<String> sentData, ModelMap model, HttpSession session) {
//		String user_id = EnvRegionController.getLoginObject().getUser_id();
		String user_id = (String) session.getAttribute("activeUser");
		user_id = user_id.toUpperCase();
		int currentIndex = Integer.parseInt(sentData.get(7));

		session.setAttribute("currentPageIndex", currentIndex);
		String objHandle = (String) session.getAttribute("objectHandle");
		int objectHandle = 0;
		if (workloadCtrl.checkNullString(objHandle)) {
			objHandle = 1 + "";
			objectHandle = Integer.parseInt(objHandle);
			session.setAttribute("objectHandle", objectHandle);
		}

//		int objectHandle= (int)session.getAttribute("objectHandle");
//		String object_handle = workloadCtrl.getObjectHandle(objectHandle);
		System.out.println("ConfirmBtDDData ->>: " + sentData.get(3));

		Gson gson = new Gson();
		ConfirmedByEsddData confirmedByData = gson.fromJson(sentData.get(3), ConfirmedByEsddData.class);
		String object_handle = workloadCtrl.getObjectHandle(objectHandle);
//		System.out.println("ConfirmBtDDData ->>: " + confirmedByData.toString());

		ConfirmedByEsddData confirmedByEsddData = new ConfirmedByEsddData();

		confirmedByEsddData = confirmedByEsddService.writeConfirmedByEsddDataToMQ(confirmedByData, user_id,
				object_handle,session);

		setconfirmedByEsddData(confirmedByEsddData, currentIndex, session);
		System.out.println("confirmedByEsddData size-->" + confirmedByEsddData.getConfirmedByEsddTableRows().size());
//		System.out.println("To show object handle in retrieved data w0" + confirmedByEsddData);

	}

	private void setconfirmedByEsddData(ConfirmedByEsddData confirmedByEsddData, int currentIndex,
			HttpSession session) {

//		System.out.println("ConfirmedByEsddData in setEnhancedSelectDataObj-->" + confirmedByEsddData);
		List<ConfirmedByEsddData> confirmedByDatalist = (List<ConfirmedByEsddData>) session
				.getAttribute("confirmedByEsddDatalist");
		List<ConfirmedByEsddData> confirmedByDatalst = new ArrayList<ConfirmedByEsddData>();
		if (confirmedByDatalist == null) {

			for (int x = 0; x < 5; x++) {
				ConfirmedByEsddData conBy = new ConfirmedByEsddData();
				conBy = MockDtoDataUtil.getConfirmedByEsddMockData();
				confirmedByDatalst.add(conBy);
			}
			session.setAttribute("confirmedByEsddDatalist", confirmedByDatalst);
			confirmedByDatalist = (List<ConfirmedByEsddData>) session.getAttribute("confirmedByEsddDatalist");
			System.out.println("confirmedByDatalist from session size" + confirmedByDatalist.size());

			confirmedByDatalist.set(currentIndex, confirmedByEsddData);
			session.setAttribute("confirmedByEsddDatalist", confirmedByDatalst);
		} else {
			confirmedByDatalist.set(currentIndex, confirmedByEsddData);
			session.setAttribute("confirmedByEsddDatalist", confirmedByDatalist);
		}

	}

	@RequestMapping(value = "/fupRequest", method = RequestMethod.GET)
	public String showFupReqPage(ModelMap model, HttpSession session) {
		System.out.println("in /fup get method");
		EnvRegion e = envRegionCtrl.getEnvRegion(session);
		String userId = (String) session.getAttribute("userId");
		String environment = (String) session.getAttribute("environment");

		List<String> myNavBarArray = (List<String>) session.getAttribute("navBarArr");
//		EnvRegion e = envRegionCtrl.getEnvRegionFromSession(session,model);
		model.addAttribute("userId", userId);
		model.addAttribute("environment", environment);
		model.addAttribute("envregion", e);
		model.addAttribute("navbarArr", myNavBarArray);
		model.addAttribute("indicator", false);
		model.addAttribute("indicator1",false)	;
		model.addAttribute("indicator2",false)	;
		model.addAttribute("indicator3",false)	;
		model.addAttribute("indicator4",false) ;
//		int currIndex= (int)session.getAttribute("currentPageIndex");

		String currInde = "";

		Object currInd = session.getAttribute("currentPageIndex");
		if (!(currInd == null)) {
			currInde = currInd.toString();
			System.out.println("session -->" + session.getAttribute("currentPageIndex"));
			System.out.println("currInde" + currInde);
		}

		int currIndex = 0;
		if (!workloadCtrl.checkNullString(currInde)) {
			currIndex = Integer.parseInt(currInde);
			session.setAttribute("currentPageIndex", currIndex + "");
		}

		FupRequestData fupRequestData = getFupRequestDataFromSession(session, currIndex);
		model.addAttribute("fupRequestData", fupRequestData);
		model.addAttribute("navbarArr", myNavBarArray);
		model.addAttribute("envregion", e);
		return "fupRequest";
	}

	private FupRequestData getFupRequestDataFromSession(HttpSession session, int currIndex) {
		FupRequestData myFupRequestObj = new FupRequestData();
		try {
			List<FupRequestData> fupRequestDataList = (List<FupRequestData>) session.getAttribute("fupRequestDatalist");
			System.out.println("fupRequestDataList size-->" + fupRequestDataList.size());
			return fupRequestDataList.get(currIndex);
		} catch (Exception e) {
			System.out.println("got exception" + e.getMessage());
			return myFupRequestObj;

		}

	}

	@RequestMapping(value = "/fupRequest", method = RequestMethod.POST)
	public String addTabOfSamePageFR(@RequestBody String tab, ModelMap model, HttpSession session) {
		System.out.println("in  /fup post method ->>" + tab);
		EnvRegion e = envRegionCtrl.getEnvRegion(session);
		String activeUser = (String) session.getAttribute("activeUser");
		String environment = (String) session.getAttribute("environment");
		String userId = (String) session.getAttribute("userId");

		List<String> reqData = new ArrayList<String>();
		String[] sentData = tab.split("\\$");
		System.out.println("sentData after separation" + sentData);
		for (String a : sentData) {
			reqData.add(a);
//			System.out.println("send data fup-> " + a);
		}

		if ("F".equalsIgnoreCase(reqData.get(1))) {
			fetchFupRequestData(reqData, model, session);
		} else {

			workloadCtrl.setDataToCorrespondingDTO(reqData, model, session);
			if ("Y".equalsIgnoreCase(reqData.get(1))) {
				workloadCtrl.getSameTabs(reqData, model, userId, session);
			}
		}
//		EnvRegion e = envRegionCtrl.getEnvRegionFromSession(session,model);
		model.addAttribute("activeUser", activeUser);
		model.addAttribute("environment", environment);
		model.addAttribute("envregion", e);
		model.addAttribute("indicator", false);
		model.addAttribute("indicator1",false)	;
		model.addAttribute("indicator2",false)	;
		model.addAttribute("indicator3",false)	;
		model.addAttribute("indicator4",false) ;
		return "fupRequest";
	}

	public void fetchFupRequestData(List<String> sentData, ModelMap model, HttpSession session) {
//		String user_id = EnvRegionController.getLoginObject().getUser_id();
		String user_id = (String) session.getAttribute("activeUser");
		user_id = user_id.toUpperCase();
		int currentIndex = Integer.parseInt(sentData.get(7));

		session.setAttribute("currentPageIndex", currentIndex);
		String objHandle = (String) session.getAttribute("objectHandle");
		int objectHandle = 0;
		if (workloadCtrl.checkNullString(objHandle)) {
			objHandle = 1 + "";
			objectHandle = Integer.parseInt(objHandle);
			session.setAttribute("objectHandle", objectHandle);
		}
		System.out.println("FupData ->>: " + sentData.get(3));

		Gson gson = new Gson();
		FupRequestData fupRequestData = gson.fromJson(sentData.get(3), FupRequestData.class);
		String object_handle = workloadCtrl.getObjectHandle(objectHandle);
//		System.out.println("FupData ->>: " + fupRequestData.toString());

		FupRequestData fupReqData = new FupRequestData();
		fupReqData = fupRequestService.writeFupRequestDataToMQ(fupRequestData, user_id, object_handle,session);
		setFupReqData(fupReqData, currentIndex, session);
		System.out.println("setFupReqData size-->" + fupReqData.getFupRequestTableRows().size());
//		System.out.println("To show object handle in retrieved data w0" + fupReqData);

	}

	private void setFupReqData(FupRequestData fupReqData, int currentIndex, HttpSession session) {

		System.out.println("fupReqData in setFupReqData-->" + fupReqData);
		List<FupRequestData> fupRequestDatalist = (List<FupRequestData>) session.getAttribute("fupRequestDatalist");
		List<FupRequestData> fupReqDataLst = new ArrayList<FupRequestData>();
		if (fupRequestDatalist == null) {

			for (int x = 0; x < 5; x++) {
				FupRequestData fup = new FupRequestData();
				fup = MockDtoDataUtil.getFupRequestDtoData();
				fupReqDataLst.add(fup);
			}
			session.setAttribute("fupRequestDatalist", fupReqDataLst);
			fupRequestDatalist = (List<FupRequestData>) session.getAttribute("fupRequestDatalist");
			System.out.println("fupRequestDatalist from session size" + fupRequestDatalist.size());

			fupRequestDatalist.set(currentIndex, fupReqData);
			session.setAttribute("fupRequestDatalist", fupReqDataLst);
		} else {
			fupRequestDatalist.set(currentIndex, fupReqData);
			session.setAttribute("fupRequestDatalist", fupRequestDatalist);
		}

	}

	@RequestMapping(value = "/treeViewDisplay", method = RequestMethod.GET)
	public String showTreeViewDisplayPage(ModelMap model, HttpSession session) {
		EnvRegion e = envRegionCtrl.getEnvRegion(session);
		String activeUser = (String) session.getAttribute("activeUser");
		String environment = (String) session.getAttribute("environment");
//		Login login = EnvRegionController.getLoginObject();

		Login login =envRegionCtrl.getLoginObjectFromSession(session);

List filterRecidList = (ArrayList)session.getAttribute("treeViewList_preissue");
		
		if (filterRecidList== null) {
			System.out.println("false for 544");
			model.addAttribute("indicator3",false)	;
			
		}
		else if(!filterRecidList.contains("544")) {
			System.out.println("false for 544");
			model.addAttribute("indicator3",false)	;	}
		//10252021 
				if (filterRecidList== null) { 
					System.out.println("false for 540"); 
					model.addAttribute("indicator1",false)	; 
				} 
				else if(!filterRecidList.contains("540")) { 
					System.out.println("false for 540"); 
					model.addAttribute("indicator1",false)	;	}
		
		List<String> myNavBarArray = (List<String>) session.getAttribute("navBarArr");
//		EnvRegion e = envRegionCtrl.getEnvRegionFromSession(session,model);
		model.addAttribute("activeUser", activeUser);
		model.addAttribute("environment", environment);
		model.addAttribute("envregion", e);
		model.addAttribute("login", login);
		model.addAttribute("navbarArr", myNavBarArray);

		return "treeviewfinal";
	}

	private String setSelectedObj(String uniqueKey, SelectRequestData newSelectRequestData,
			SelectRequestData selectRequestTreeViewData) {
		System.out.println("uniqueKey = " + uniqueKey);

		System.out.println("Treeview Select Data setSelctedObj is: " + selectRequestTreeViewData);
		String recid = "";
		// System.out.println("workloadDataW111111111ithMQData" +
		// selectRequestTreeViewData.getSelectRequestTableRows9());
		for (SelectRequestTableRow9 selectRequestTableRow : selectRequestTreeViewData.getSelectRequestTableRows9()) {
			System.out.println("inside ifff:::::" + selectRequestTableRow.getUniqueId());
			if (selectRequestTableRow.getUniqueId() == Integer.parseInt(uniqueKey)) {
				recid = selectRequestTableRow.getRectyp();
//				System.out.println("inside ifff:::::");
				// session.setAttribute("selectedIndexValue", uniqueKey);
				newSelectRequestData.getSelectRequestTableRows9().add(selectRequestTableRow);
				break;
			}
		}
		return recid;
	}

	private String setSelected12StateObj(String uniqueKey, SelectRequestData newSelectRequestData,
			SelectRequestData selectRequestTreeViewData) {
		System.out.println("uniqueKey = " + uniqueKey);
		String recid = "";
//		System.out.println("workloadDataW111111111ithMQData" + selectRequestTreeViewData.getSelectRequestTableRows());
		for (SelectRequestTableRow selectRequestTableRow : selectRequestTreeViewData.getSelectRequestTableRows()) {
//			System.out.println("inside ifff:::::" + selectRequestTableRow.getUniqueId());
			if (selectRequestTableRow.getUniqueId() == Integer.parseInt(uniqueKey)) {
				recid = selectRequestTableRow.getRectyp();
//				System.out.println("inside ifff:::::");
				newSelectRequestData.getSelectRequestTableRows().add(selectRequestTableRow);
				break;
			}
		}
		return recid;
	}

	@RequestMapping(value = "/treeViewDisplay", method = RequestMethod.POST)
	public String addTabOfSamePageTV(@RequestBody String tab, ModelMap model, HttpSession session) {
		System.out.println("to /treeViewDisplay post method ctrl" + tab);
		String userId = (String) session.getAttribute("userId");
		String activeUser = (String) session.getAttribute("activeUser");
		String environment = (String) session.getAttribute("environment");
		EnvRegion e = envRegionCtrl.getEnvRegion(session);
		model.addAttribute("environment", environment);
				model.addAttribute("envregion", e);
//		String user_id = EnvRegionController.getLoginObject().getUser_id();
//		user_id=user_id.toUpperCase();
		//Hrushikesh - To store treeview LSR objects
		List<Object> treeViewObjectList = (List<Object>) session.getAttribute("treeViewObjects");
		String classType="";
		if(treeViewObjectList.size() >0) {
		System.out.println("treeViewObjectList class is "+treeViewObjectList.get(0).getClass().getName());
		
		if (treeViewObjectList.get(0).getClass().getName() == "com.att.lasr.model.EnhancedSelectData") {
		    //System.out.println("This is an Integer");
		    classType="EnhancedSelectData";
		}else {
			 classType="SelectRequestData";
		}
		}else {
			 classType="SelectRequestData";
		}
		System.out.println("classType"+classType);		
		session.removeAttribute("jspFlag");
				
		String user_id = (String) session.getAttribute("activeUser");
		user_id = user_id.toUpperCase();
		session.setAttribute("jspRender", "C");// missed
		session.setAttribute("States", "Y");
		String objHandle = (String) session.getAttribute("objectHandle");
		int objectHandle = 0;
		
		if (workloadCtrl.checkNullString(objHandle)) {
			objHandle = 1 + "";
			objectHandle = Integer.parseInt(objHandle);
			session.setAttribute("objectHandle", objectHandle);
		}

		String object_handle = workloadCtrl.getObjectHandle(objectHandle);
		// List treeViewListValues = new ArrayList();
		List<String> reqData = new ArrayList<String>();
		String[] sentData = tab.split("\\$");
		for (String a : sentData) {
			reqData.add(a);
//			System.out.println("sent data treeviewDisplay" + a);
		}
		System.out.println("reqData data it sud have row index" + reqData);
		if ("Y".equalsIgnoreCase(reqData.get(1))) {
			workloadCtrl.getSameTabs(reqData, model, userId, session);
		}
		
		String currIndex = "";
		int currentPageIndex = 0;
		if (!(reqData == null) && reqData.size() == 6) {
			currIndex = reqData.get(2);
			currentPageIndex = Integer.parseInt(currIndex);
			session.setAttribute("currentPageIndex", currIndex);
		} else {
			currIndex = (String) session.getAttribute("currentPageIndex");
			System.out.println("session tab currIndex"+currIndex);
			if (!workloadCtrl.checkNullString(currIndex)) {
				currentPageIndex = Integer.parseInt(currIndex);
				session.setAttribute("currentPageIndex", currIndex);
			}

		}
		System.out.println("it sud be tab index index 979-->"+currentPageIndex);
		
		
		//Hrushikesh - To route another treeviewDisplay tab
		
		
		
		
		if ("R".equalsIgnoreCase(reqData.get(1))  && "SelectRequestData".equalsIgnoreCase(classType)  ) {
			
			
			List<String> treeViewList1 = new ArrayList<String>();
			if(treeViewObjectList!=null && !(treeViewObjectList.size()<1)) {
				
				for(int i=0;i<treeViewObjectList.size();i++) {
					
					SelectRequestData srd= (SelectRequestData) treeViewObjectList.get(i);
					String lsr= srd.getSelectRequestTableRows().get(0).getRequest_id();
					if(lsr.equalsIgnoreCase(reqData.get(0))){
						
						closeLsrOpenedBeforeRoute(model, session, lsr);
						session.setAttribute("newSelectRequestData", srd);
						String recTypeValue= srd.getSelectRequestTableRows().get(0).getRectyp();
						session.setAttribute("RecType", recTypeValue);
						List<String> treeViewList = treeView_12StateService.writeSelectedRequestDataToTreeView(srd,
								user_id, session, object_handle, treeViewList1);
						// System.out.println("#"+srd);
//						System.out.println("Hrushi routing treeViewList::::::::::::final::::::" + treeViewList);
						model.addAttribute("treeViewList", treeViewList);
						trigger_12state(session,model,treeViewList);
						return "treeviewfinal";
					}
					
				}
			}
		} else if ("R".equalsIgnoreCase(reqData.get(1))  && "EnhancedSelectData".equalsIgnoreCase(classType)  ) {
			
			
				List<String> treeViewList1 = new ArrayList<String>();
				if(treeViewObjectList!=null && !(treeViewObjectList.size()<1)) {
					
					for(int i=0;i<treeViewObjectList.size();i++) {
						
						EnhancedSelectData srd= (EnhancedSelectData) treeViewObjectList.get(i);
						String lsr= srd.getEnhancedSelectTableRows().get(0).getRequest_id();
						if(lsr.equalsIgnoreCase(reqData.get(0))){
							
							closeLsrOpenedBeforeRoute(model, session, lsr);
							session.setAttribute("newSelectRequestData", srd);
							String recTypeValue= srd.getEnhancedSelectTableRows().get(0).getReqtyp();
							session.setAttribute("RecType", recTypeValue);
							List<String> treeViewList = treeView_12StateEnhanceService.writeSelectedRequestDataToTreeView(srd,
									user_id, session, object_handle, treeViewList1);
							// System.out.println("#"+srd);
//							System.out.println("Hrushi routing treeViewList::::::::::::final::::::" + treeViewList);
							model.addAttribute("treeViewList", treeViewList);
							trigger_12state(session,model,treeViewList);
							return "treeviewfinal";
						}
						
					}
				}
			
		}
		
		
		
		
		List<String> treeViewList= new ArrayList<String>();
		if(reqData.get(4).equalsIgnoreCase("selectRequest")) {
		SelectRequestData selectRequestTreeViewData = (SelectRequestData) getSelectRequestDataFromSession(session,
				currentPageIndex);
		SelectRequestData newSelectRequestData = new SelectRequestData();
		String recid_Value = setSelected12StateObj(sentData[2], newSelectRequestData, selectRequestTreeViewData);
		session.setAttribute("RecType", recid_Value);
		session.setAttribute("newSelectRequestData", newSelectRequestData);
		model.addAttribute("treeViewList");
		if (newSelectRequestData != null) {
			List treeViewList1 = new ArrayList();
			//Hrushikesh - added Treeview LSR object in list
			treeViewObjectList.add(newSelectRequestData);
			session.setAttribute("treeViewObjects", treeViewObjectList);
			
			 treeViewList = treeView_12StateService.writeSelectedRequestDataToTreeView(newSelectRequestData,
					user_id, session, object_handle, treeViewList1);
			 System.out.println("in 12state selReq"+treeViewList);
				
				List<List<String>> namesAndIds= getAllFolders12State(treeViewList);
				
				List<String> treeViewFolders= namesAndIds.get(0);
				System.err.println("treeViewAllFoldersIds"+ namesAndIds.get(1));
				System.err.println("treeViewFolders"+treeViewFolders);
				session.setAttribute("treeViewAllFolders", treeViewFolders);
				session.setAttribute("treeViewAllFoldersIds", namesAndIds.get(1));
				model.addAttribute("treeViewAllFolders", treeViewFolders);
		}
		}else if(reqData.get(4).equalsIgnoreCase("enhancedSelReq")){

			EnhancedSelectData selectRequestTreeViewData = (EnhancedSelectData) getEnhancedRequestDataFromSession(session,
					currentPageIndex);
			EnhancedSelectData newSelectRequestData = new EnhancedSelectData();
			String recid_Value = treeView_12StateEnhanceService.setEnhancedSel12StateObj(sentData[2], newSelectRequestData, selectRequestTreeViewData);
			session.setAttribute("RecType", recid_Value);
			session.setAttribute("newSelectRequestData", newSelectRequestData);
			model.addAttribute("treeViewList");
			if (newSelectRequestData != null) {
				List treeViewList1 = new ArrayList();
				//Hrushikesh - added Treeview LSR object in list
				treeViewObjectList.add(newSelectRequestData);
				session.setAttribute("treeViewObjects", treeViewObjectList);
				
				 treeViewList = treeView_12StateEnhanceService.writeSelectedRequestDataToTreeView(newSelectRequestData,
						user_id, session, object_handle, treeViewList1);
				 System.out.println("in 12state selReq"+treeViewList);
					
					List<List<String>> namesAndIds= getAllFolders12State(treeViewList);
					
					List<String> treeViewFolders= namesAndIds.get(0);
					System.err.println("treeViewAllFoldersIds"+ namesAndIds.get(1));
					System.err.println("treeViewFolders"+treeViewFolders);
					session.setAttribute("treeViewAllFolders", treeViewFolders);
					session.setAttribute("treeViewAllFoldersIds", namesAndIds.get(1));
					model.addAttribute("treeViewAllFolders", treeViewFolders);
			
		}
		}
		
			model.addAttribute("treeViewList", treeViewList);
			session.setAttribute("treeViewList_preissue",treeViewList);
			if(treeViewList.contains("570")){
				session.setAttribute("manRejButton", "inline");

//				System.out.println("presnt");
				
				}else {
					session.setAttribute("manRejButton", "none");
					
				
					}
			// treeViewListValues.
			// treeView_12StateService.writeSelectedRequestDataToTreeView(newSelectRequestData,user_id,session,object_handle);

		
		
		
		
		
		
		
List filterRecidList = (ArrayList)session.getAttribute("treeViewList_preissue");
		
		if (filterRecidList== null) {
			System.out.println("false for 544");
			model.addAttribute("indicator3",false)	;
		}
		else if(!filterRecidList.contains("544")) {
			System.out.println("false for 544");
			model.addAttribute("indicator3",false)	;
			}
		//10252021 
				if (filterRecidList== null) { 
					System.out.println("false for 540"); 
					model.addAttribute("indicator1",false)	; 
				} 
				else if(!filterRecidList.contains("540")) { 
					System.out.println("false for 540"); 
					model.addAttribute("indicator1",false)	;	}
//		EnvRegion e = envRegionCtrl.getEnvRegionFromSession(session,model);
		
		model.addAttribute("activeUser", activeUser);
		model.addAttribute("environment", environment);
		model.addAttribute("envregion", e);
		return "treeviewfinal";
	}

	
	public void trigger_12state(HttpSession session, ModelMap model, List treeViewList)
	{
		session.setAttribute("treeViewList_preissue",treeViewList);
		if(treeViewList.contains("570")){
			session.setAttribute("manRejButton", "inline");

//			System.out.println("presnt");
			
			}else {
				session.setAttribute("manRejButton", "none");
				
			
				}
		// treeViewListValues.
		// treeView_12StateService.writeSelectedRequestDataToTreeView(newSelectRequestData,user_id,session,object_handle);

	
List filterRecidList = (ArrayList)session.getAttribute("treeViewList_preissue");
	
	if (filterRecidList== null) {
		System.out.println("false for 544");
		model.addAttribute("indicator3",false)	;
	}
	else if(!filterRecidList.contains("544")) {
		System.out.println("false for 544");
		model.addAttribute("indicator3",false)	;
		}
	//10252021 
			if (filterRecidList== null) { 
				System.out.println("false for 540"); 
				model.addAttribute("indicator1",false)	; 
			} 
			else if(!filterRecidList.contains("540")) { 
				System.out.println("false for 540"); 
				model.addAttribute("indicator1",false)	;	}
	}

	
	//Hrushikesh - Close LSR before route
	public void closeLsrOpenedBeforeRoute(ModelMap model, HttpSession session, String lsr) {
		// TODO Auto-generated method stub
		
		CloseTransaction closeTransaction= new CloseTransaction();
		String userId= envRegionCtrl.getUserIdFromSession(session);
		
		closeTransaction.setLsr_number(lsr.substring(0,14));
		closeTransaction.setNext(lsr.substring(15,17));	
		closeTransaction.setUser_id(userId);
		
		closeTransactionService.writeCloseTransactionDataToMQ(closeTransaction, userId, session);
		System.out.println("Transaction closed before route");
	}

	@RequestMapping(value = "/treeview9states", method = RequestMethod.GET)
	public String showTreeView9StatesPage(ModelMap model, HttpSession session) {
		List<String> myNavBarArray = (List<String>) session.getAttribute("navBarArr");
		String currentPageInde = (String) session.getAttribute("currentPageIndex");
		int currentPageIndex = 0;
		if (!workloadCtrl.checkNullString(currentPageInde)) {
			currentPageIndex = Integer.parseInt(currentPageInde);
		}
		session.setAttribute("States", "N");
		SelectRequestData fupRequestData = getSelectRequestDataFromSession(session, currentPageIndex);
		String selectRequestId = "selectRequestDto" + currentPageIndex;
		model.addAttribute(selectRequestId, fupRequestData);

		if (currentPageIndex == 0) {
			session.setAttribute("selectRequestDto0", getSelectRequestDataFromSession(session, 0));
		} else if (currentPageIndex == 1) {
			session.setAttribute("selectRequestDto1", getSelectRequestDataFromSession(session, 1));
		} else if (currentPageIndex == 2) {
			session.setAttribute("selectRequestDto2", getSelectRequestDataFromSession(session, 2));
		} else if (currentPageIndex == 3) {
			session.setAttribute("selectRequestDto3", getSelectRequestDataFromSession(session, 3));
		} else if (currentPageIndex == 4) {
			session.setAttribute("selectRequestDto4", getSelectRequestDataFromSession(session, 4));
			;
		}
//		EnvRegion e = envRegionCtrl.getEnvRegionFromSession(session,model);
		EnvRegion e = envRegionCtrl.getEnvRegion(session);
		model.addAttribute("navbarArr", myNavBarArray);
		model.addAttribute("envregion", e);
		List filterRecidList = (ArrayList)session.getAttribute("treeViewList_preissue");
		List filterRecidList1 = (ArrayList)session.getAttribute("treeViewList_preissue1");
		if (filterRecidList== null) {
			System.out.println("false for 549");
			model.addAttribute("indicator",false)	;
		}
		else if(!filterRecidList.contains("549")) {
			System.out.println("false for 549");
			model.addAttribute("indicator",false)	;	}
		if (filterRecidList1== null) {
			System.out.println("false for 540");
			model.addAttribute("indicator1",false)	;
		}
		
		else if(!filterRecidList1.contains("540")) {
			System.out.println("false for 540");
			model.addAttribute("indicator1",false)	;	}
		
		if (filterRecidList== null) {
			System.out.println("false for 547");
			model.addAttribute("indicator2",false)	;
		}
		else if(!filterRecidList.contains("547")) {
			System.out.println("false for 547");
			model.addAttribute("indicator2",false)	;	}
		if (filterRecidList== null) {
			System.out.println("false for 546");
			model.addAttribute("indicator4",false) ;
			}
			else if(!filterRecidList.contains("546")) {
			System.out.println("false for 546");
			model.addAttribute("indicator4",false) ; }
		
		if (filterRecidList== null) {
			System.out.println("false for 544");
			model.addAttribute("indicator3",false)	;
		}
		else if(!filterRecidList.contains("544")) {
			System.out.println("false for 544");
			model.addAttribute("indicator3",false)	;	}
		
		model.addAttribute("treeViewList", session.getAttribute("treeViewList"));
		return "treeview9states";
	}

	@RequestMapping(value = "/treeview9states", method = RequestMethod.POST)
	public String addTabOfSamePageTV9S(@RequestBody String tab, ModelMap model, HttpSession session) {
		System.out.println("to /treeview9states post method ctrl" + tab);
		EnvRegion e = envRegionCtrl.getEnvRegion(session);
//	String user_id = EnvRegionController.getLoginObject().getUser_id();
		//Hrushikesh - To store treeview LSR objects
		List<Object> treeViewObjectList = (List<Object>) session.getAttribute("treeViewObjects");
		
		String classType="";
		if(treeViewObjectList.size() >0) {
		System.out.println("treeViewObjectList class is "+treeViewObjectList.get(0).getClass().getName());
		
		if (treeViewObjectList.get(0).getClass().getName() == "com.att.lasr.model.EnhancedSelectData") {
		    //System.out.println("This is an Integer");
		    classType="EnhancedSelectData";
		}else {
			 classType="SelectRequestData";
		}
		}
		
		
		String objHandle = (String) session.getAttribute("objectHandle");
		int objectHandle = 0;
		
		if (workloadCtrl.checkNullString(objHandle)) {
			objHandle = 1 + "";
			objectHandle = Integer.parseInt(objHandle);
			session.setAttribute("objectHandle", objectHandle);
		}

		String object_handle = workloadCtrl.getObjectHandle(objectHandle);
		
		session.removeAttribute("jspFlag");
		String user_id = (String) session.getAttribute("activeUser");
		user_id = user_id.toUpperCase();

		List<String> reqData = new ArrayList<String>();
		String[] sentData = tab.split("\\$");
		for (String a : sentData) {
			reqData.add(a);
//			System.out.println("sent data treeview9states" + a);
		}
		System.out.println("treeview 9 state data" + reqData);
		if ("Y".equalsIgnoreCase(reqData.get(1))) {
			workloadCtrl.getSameTabs(reqData, model, user_id, session);
		}
		//Hrushikesh - To route another treeview9states tab
		List treeViewList = new ArrayList();


		if ("R".equalsIgnoreCase(reqData.get(1)) &&   "SelectRequestData".equalsIgnoreCase(classType) ) {
			
			if(treeViewObjectList!=null && !(treeViewObjectList.size()<1))
			{
				for(int i=0;i<treeViewObjectList.size();i++) {
					SelectRequestData srd= (SelectRequestData) treeViewObjectList.get(i);
					String lsr= srd.getSelectRequestTableRows9().get(0).getRequest_id();
					if(lsr.equalsIgnoreCase(reqData.get(0))){
						
						closeLsrOpenedBeforeRoute(model, session, lsr);
						session.setAttribute("newSelectRequestData", srd);
						String recTypeValue= srd.getSelectRequestTableRows9().get(0).getRectyp();
						session.setAttribute("RecType", recTypeValue);
						treeViewList = treeView_9StateService.writeSelectedRequestDataToTreeView(srd,
								user_id, session, object_handle, treeViewList);
						model.addAttribute("treeViewList", treeViewList);
						trigger_9state(session,model,treeViewList);
						model.addAttribute("envregion", e);
						return "treeview9states";
					}
					
				}
			}
		}else if ("R".equalsIgnoreCase(reqData.get(1)) &&   "EnhancedSelectData".equalsIgnoreCase(classType) ) {
			
			if(treeViewObjectList!=null && !(treeViewObjectList.size()<1))
			{
				for(int i=0;i<treeViewObjectList.size();i++) {
					EnhancedSelectData srd= (EnhancedSelectData) treeViewObjectList.get(i);
					String lsr= srd.getEnhancedSelectTableRows() .get(0).getRequest_id();
					if(lsr.equalsIgnoreCase(reqData.get(0))){
						
						closeLsrOpenedBeforeRoute(model, session, lsr);
						session.setAttribute("newSelectRequestData", srd);
						String recTypeValue= srd.getEnhancedSelectTableRows() .get(0).getReqtyp();
						session.setAttribute("RecType", recTypeValue);
						treeViewList = treeView_9StateEnhanceService.writeSelectedRequestDataToTreeView(srd,
								user_id, session, object_handle, treeViewList);
						// System.out.println("#"+srd);
//						System.out.println("Hrushi routing treeViewList::::::::::::final::::::" + treeViewList);
						model.addAttribute("treeViewList", treeViewList);
						trigger_9state(session,model,treeViewList);
						model.addAttribute("envregion", e);
						return "treeview9states";
					}
					
				}
			}
		}  
		
		
				

		String currIndex = "";
		int currentPageIndex = 0;
		if (!(reqData == null) && reqData.size() == 6) {
			currIndex = reqData.get(2);
			currentPageIndex = Integer.parseInt(currIndex);
			System.out.println("i if line 1420currentPageIndex+++99+++++++++++ = " + currentPageIndex);
			session.setAttribute("currentPageIndex", currIndex);
		} else {
			currIndex = (String) session.getAttribute("currentPageIndex");
			if (!workloadCtrl.checkNullString(currIndex)) {
				currentPageIndex = Integer.parseInt(currIndex);
				System.out.println("in else line 1426 currentPageIndex+++99+++++++++++ = " + currentPageIndex);
				session.setAttribute("currentPageIndex", currIndex);
			}

		}
//				fffffff;
//	session.setAttribute("currentPageIndex",currentIndex);

		//String object_handle = WorkloadController.getObjectHandle(objectHandle);
		String[] uniqueValue = tab.split("\\$");
		System.out.println("workloadCtrl.currentPageIndex+++99+++++++++++ = " + currIndex+"currentPageIndex"+currentPageIndex);
		
		if(reqData.get(4).equalsIgnoreCase("selectRequest")) {
		SelectRequestData selectRequestTreeViewData = (SelectRequestData) getSelectRequestDataFromSession(session,
				currentPageIndex);
		SelectRequestData newSelectRequestData = new SelectRequestData();
		session.setAttribute("jspRender", "C");// missed
		session.setAttribute("selectedIndexValue", uniqueValue[2]);// missed patch
		String recid_Value = setSelectedObj(uniqueValue[2], newSelectRequestData, selectRequestTreeViewData);
		session.setAttribute("RecType", recid_Value);
		session.setAttribute("newSelectRequestData", newSelectRequestData);
		if (newSelectRequestData != null) {
			System.out.println("treeViewList:::::::999:::::before service::::::");
			//Hrushikesh - added Treeview LSR object in list
			treeViewObjectList.add(newSelectRequestData);
			session.setAttribute("treeViewObjects", treeViewObjectList);
			
			if (currentPageIndex == 0) {
				treeViewList = treeView_9StateService.writeSelectedRequestDataToTreeView(newSelectRequestData, user_id,
						session, object_handle, treeViewList);
			} else if (currentPageIndex == 1) {
				treeViewList = treeView_9StateService.writeSelectedRequestDataToTreeView(newSelectRequestData, user_id,
						session, object_handle, treeViewList);
//				System.out.println("treeViewList:::::99:::::11111::final::::::" + treeViewList);
			} else if (currentPageIndex == 2) {
				treeViewList = treeView_9StateService.writeSelectedRequestDataToTreeView(newSelectRequestData, user_id,
						session, object_handle, treeViewList);
//				System.out.println("treeViewList:::::99::::2222:::final::::::" + treeViewList);
			} else if (currentPageIndex == 3) {
				treeViewList = treeView_9StateService.writeSelectedRequestDataToTreeView(newSelectRequestData, user_id,
						session, object_handle, treeViewList);
//				System.out.println("treeViewList::99::::::33333::::final::::::" + treeViewList);
			} else if (currentPageIndex == 4) {
				treeViewList = treeView_9StateService.writeSelectedRequestDataToTreeView(newSelectRequestData, user_id,
						session, object_handle, treeViewList);
//				System.out.println("treeViewList::::99:::::44444:::final::::::" + treeViewList);
			}
			System.out.println("treeViewList:::::::999:::::final::::::" + treeViewList);
			model.addAttribute("treeViewList", treeViewList);
			List<List<String>> namesAndIds= getAllFolders9State(treeViewList);
			
			List<String> treeViewFolders= namesAndIds.get(0);
			System.err.println("treeViewAllFoldersIds"+ namesAndIds.get(1));
			session.setAttribute("treeViewAllFoldersIds", namesAndIds.get(1));
			 System.err.println("treeViewFolders9State"+treeViewFolders);
				session.setAttribute("treeViewAllFolders", treeViewFolders);
				model.addAttribute("treeViewAllFolders", treeViewFolders);
		}
		
		} else if(reqData.get(4).equalsIgnoreCase("enhancedSelReq")){
			
			System.out.println("currentPageIndex in enhancedSelReq treview"+currentPageIndex);
			EnhancedSelectData selectRequestTreeViewData = (EnhancedSelectData) getEnhancedRequestDataFromSession(session,	currentPageIndex);
			EnhancedSelectData newSelectRequestData = new EnhancedSelectData();
			session.setAttribute("jspRender", "C");// missed
			session.setAttribute("selectedIndexValue", uniqueValue[2]);// missed patch
			String recid_Value = setEnhancedSelectedObj(uniqueValue[2], newSelectRequestData, selectRequestTreeViewData);
			session.setAttribute("RecType", recid_Value);
			session.setAttribute("newSelectRequestData", newSelectRequestData);
			if (newSelectRequestData != null) {
				System.out.println("treeViewList:::::::999:::::before service::::::");
				//Hrushikesh - added Treeview LSR object in list
				treeViewObjectList.add(newSelectRequestData);
				session.setAttribute("treeViewObjects", treeViewObjectList);
				System.out.println("newSelectRequestData 1->"+newSelectRequestData);
				
				System.out.println("treeViewList 4->"+treeViewList);
				
				
				
				
				if (currentPageIndex == 0) {
					treeViewList = treeView_9StateEnhanceService.writeSelectedRequestDataToTreeView(newSelectRequestData, user_id,
							session, object_handle, treeViewList);
				} else if (currentPageIndex == 1) {
					treeViewList = treeView_9StateEnhanceService.writeSelectedRequestDataToTreeView(newSelectRequestData, user_id,
							session, object_handle, treeViewList);
//					System.out.println("treeViewList:::::99:::::11111::final::::::" + treeViewList);
				} else if (currentPageIndex == 2) {
					treeViewList = treeView_9StateEnhanceService.writeSelectedRequestDataToTreeView(newSelectRequestData, user_id,
							session, object_handle, treeViewList);
//					System.out.println("treeViewList:::::99::::2222:::final::::::" + treeViewList);
				} else if (currentPageIndex == 3) {
					treeViewList = treeView_9StateEnhanceService.writeSelectedRequestDataToTreeView(newSelectRequestData, user_id,
							session, object_handle, treeViewList);
//					System.out.println("treeViewList::99::::::33333::::final::::::" + treeViewList);
				} else if (currentPageIndex == 4) {
					treeViewList = treeView_9StateEnhanceService.writeSelectedRequestDataToTreeView(newSelectRequestData, user_id,
							session, object_handle, treeViewList);
//					System.out.println("treeViewList::::99:::::44444:::final::::::" + treeViewList);
				}
				System.out.println("treeViewList:::::::999:::::final::::::" + treeViewList);
				model.addAttribute("treeViewList", treeViewList);
				List<List<String>> namesAndIds= getAllFolders9State(treeViewList);
				
				List<String> treeViewFolders= namesAndIds.get(0);
				System.err.println("treeViewAllFoldersIds"+ namesAndIds.get(1));
				session.setAttribute("treeViewAllFoldersIds", namesAndIds.get(1));
				 System.err.println("treeViewFolders9State"+treeViewFolders);
					session.setAttribute("treeViewAllFolders", treeViewFolders);
					model.addAttribute("treeViewAllFolders", treeViewFolders);
			}
			
			
		}
		
		
		
		
		
		
		
		//rks
		if(treeViewList.contains("570")){
			session.setAttribute("manRejButton", "inline");

			System.out.println("presnt");
			
			}else {
				session.setAttribute("manRejButton", "none");
				
				
				}

		session.setAttribute("treeViewList_preissue",treeViewList);
		session.setAttribute("treeViewList_preissue1",treeViewList);
		List filterRecidList = (ArrayList)session.getAttribute("treeViewList_preissue");
		List filterRecidList1 = (ArrayList)session.getAttribute("treeViewList_preissue1");
		if (filterRecidList== null) {
			System.out.println("false for 549");
			model.addAttribute("indicator",false)	;
		}
		else if(!filterRecidList.contains("549")) {
			System.out.println("false for 549");
			model.addAttribute("indicator",false)	;	}
		if (filterRecidList1== null) {
			System.out.println("false for 540");
			model.addAttribute("indicator1",false)	;
		}
		
		else if(!filterRecidList1.contains("540")) {
			System.out.println("false for 540");
			model.addAttribute("indicator1",false)	;	}
		
		if (filterRecidList== null) {
			System.out.println("false for 547");
			model.addAttribute("indicator2",false)	;
		}
		else if(!filterRecidList.contains("547")) {
			System.out.println("false for 547");
			model.addAttribute("indicator2",false)	;	}
		if (filterRecidList== null) {
			System.out.println("false for 546");
			model.addAttribute("indicator4",false) ;
			}
			else if(!filterRecidList.contains("546")) {
			System.out.println("false for 546");
			model.addAttribute("indicator4",false) ; }
		
		if (filterRecidList== null) {
			System.out.println("false for 544");
			model.addAttribute("indicator3",false)	;
		}
		else if(!filterRecidList.contains("544")) {
			System.out.println("false for 544");
			model.addAttribute("indicator3",false)	;	}
		
		model.remove("sort_info_msg");
		model.remove("sort_err_msg");
		session.removeAttribute("sort_info_msg");
		session.removeAttribute("sort_err_msg");
		
		//EnvRegion e = envRegionCtrl.getEnvRegion(session);
		model.addAttribute("envregion", e);
		String environment = (String) session.getAttribute("environment");
		model.addAttribute("environment", environment);
		
		return "treeview9states";
	}

	public void trigger_9state(HttpSession session, ModelMap model, List treeViewList) {
		// TODO Auto-generated method stub
		if(treeViewList.contains("570")){
			session.setAttribute("manRejButton", "inline");

			System.out.println("presnt");
			
			}else {
				session.setAttribute("manRejButton", "none");
				
				
				}

		session.setAttribute("treeViewList_preissue",treeViewList);
		session.setAttribute("treeViewList_preissue1",treeViewList);
		List filterRecidList = (ArrayList)session.getAttribute("treeViewList_preissue");
		List filterRecidList1 = (ArrayList)session.getAttribute("treeViewList_preissue1");
		if (filterRecidList== null) {
			System.out.println("false for 549");
			model.addAttribute("indicator",false)	;
		}
		else if(!filterRecidList.contains("549")) {
			System.out.println("false for 549");
			model.addAttribute("indicator",false)	;	}
		if (filterRecidList1== null) {
			System.out.println("false for 540");
			model.addAttribute("indicator1",false)	;
		}
		
		else if(!filterRecidList1.contains("540")) {
			System.out.println("false for 540");
			model.addAttribute("indicator1",false)	;	}
		
		if (filterRecidList== null) {
			System.out.println("false for 547");
			model.addAttribute("indicator2",false)	;
		}
		else if(!filterRecidList.contains("547")) {
			System.out.println("false for 547");
			model.addAttribute("indicator2",false)	;	}
		if (filterRecidList== null) {
			System.out.println("false for 546");
			model.addAttribute("indicator4",false) ;
			}
			else if(!filterRecidList.contains("546")) {
			System.out.println("false for 546");
			model.addAttribute("indicator4",false) ; }
		
		if (filterRecidList== null) {
			System.out.println("false for 544");
			model.addAttribute("indicator3",false)	;
		}
		else if(!filterRecidList.contains("544")) {
			System.out.println("false for 544");
			model.addAttribute("indicator3",false)	;	}
		
		model.remove("sort_info_msg");
		model.remove("sort_err_msg");
		session.removeAttribute("sort_info_msg");
		session.removeAttribute("sort_err_msg");
	}

	@RequestMapping(value = "/conftask", method = RequestMethod.POST)
	public String completionTask9(@ModelAttribute("conformationTaskMain") ConformationTaskMain conformationTaskMain,
			ModelMap model, HttpSession session) {
		//System.out.println("conformationTaskMain:::::111::::" + conformationTaskMain);
		String activeUser = (String) session.getAttribute("activeUser");
		String environment = (String) session.getAttribute("environment");
		EnvRegion e = envRegionCtrl.getEnvRegion(session);
		model.addAttribute("environment", environment);
		model.addAttribute("envregion", e);
		String userId =envRegionCtrl.getUserIdFromSession( session);
		String objHandle = (String) session.getAttribute("objectHandle");
		String recIds = "";
		int objectHandle = 0;
		System.out.print("userId:::Controller::::" + userId);
		System.out.print("objHandle:::Controller::::" + objHandle);
		if (workloadCtrl.checkNullString(objHandle)) {
			objHandle = 1 + "";
			objectHandle = Integer.parseInt(objHandle);
			session.setAttribute("objectHandle", objectHandle);
		}
		String object_handle = WorkloadController.getObjectHandle(objectHandle);

		conformationTaskMain.setNotesFupBindingData9States(
				(List<NotesFupBindingData9States>) session.getAttribute("treeViewList_049"));
		//Added susheel start
		
				List<ConfirmationTask_RecId_558> oldList_558 = (List<ConfirmationTask_RecId_558>) (session.getAttribute("treeViewList_558"));
				List<ConfirmationTask_RecId_558> updatedOrderNumberList = treeView_9StateService.getUpdatedRows_558(conformationTaskMain.getTreeViewList_558(), oldList_558);

						if (updatedOrderNumberList.isEmpty()) {
							ReadErrorMsgsJson readErrorMsgsJson = new ReadErrorMsgsJson();
							String uon_msg = readErrorMsgsJson.getErrorMsg("LG0027");
							session.setAttribute("uon_err_msg", uon_msg);
							session.setAttribute("uon_info_msg", "");
						} else {
							conformationTaskMain = treeView_9StateService.writeSelectedRequestConformationData(conformationTaskMain, userId,
									object_handle, session, updatedOrderNumberList);
						}
						
						//Added susheel end

		//conformationTaskMain = treeView_9StateService.writeSelectedRequestConformationData(conformationTaskMain, userId,object_handle, session);

		String error_msg = " ";

		// completionselectOkPopup(model,session);

		if (conformationTaskMain.getHeader().getReturn_code() != null
				&& conformationTaskMain.getHeader().getReturn_code().equals("000")) {

			System.out.print("userId:::error_msg::::" + userId);
			error_msg = "Y";
			session.setAttribute("jspFlag", "conf_task");

		} else if (conformationTaskMain.getHeader().getReturn_code() != null
				&& conformationTaskMain.getHeader().getReturn_code().equals("999")) {
			error_msg = "N";
		} else if (conformationTaskMain.getHeader().getReturn_code() != null
				&& conformationTaskMain.getHeader().getReturn_code().equals("888")) {
			error_msg = "M";
		} else if (conformationTaskMain.getHeader().getReturn_code() != null
				&& conformationTaskMain.getHeader().getReturn_code().equals("889")) {
			error_msg = "U";
		}

		String statesIdentity = (String) session.getAttribute("States");
		System.out.print("statesIdentity:::Controller::::" + statesIdentity);
		String returnValue = "";
		if (statesIdentity.equalsIgnoreCase("Y")) {
			returnValue = "redirect:/treeViewDisplay";
		} else {
			returnValue = "redirect:/treeview9states";
		}
		System.out.print("returnValue:::Controller::::" + returnValue);

		List<ShowError> showErrorList = treeView_9StateService.getUpdatedErrorList();
		// session.setAttribute("showError", showError);

		// System.out.print("showError:::Controller::::"+showError);

		session.setAttribute("error", error_msg);
		session.setAttribute("jspRender", "Y");

		return returnValue;

	}

	@RequestMapping(value = "/conftaskTest", method = RequestMethod.GET)
	public String completionTask9Test(ModelMap model, HttpSession session) {
		List<ConfirmationTask_RecId_558> list_558 = (List<ConfirmationTask_RecId_558>) (session
				.getAttribute("treeViewList_558"));
		List<ConfirmationTask_RecId_552> list_552 = (List<ConfirmationTask_RecId_552>) (session
				.getAttribute("treeViewList_552"));
		
		String environment = (String) session.getAttribute("environment");
		EnvRegion e = envRegionCtrl.getEnvRegion(session);
		model.addAttribute("environment", environment);
				model.addAttribute("envregion", e);

		ConformationTaskMain conformationTaskMain = new ConformationTaskMain();
		if (CollectionUtils.isNotEmpty(list_558)) {
			//System.out.println("list_558 size:: " + list_558);
			conformationTaskMain.setTreeViewList_558(list_558);
		}
		if (CollectionUtils.isNotEmpty(list_552)) {
			//System.out.println("list_552 size:: " + list_552);
			conformationTaskMain.setConfirmationTask_RecId_552List(list_552);
		}

		
		if (CollectionUtils.isNotEmpty((List<NotesFupBindingData9States>) session.getAttribute("treeViewList_551"))) {
			//System.out.println("list 551:: " + session.getAttribute("treeViewList_551"));
			conformationTaskMain.setConfirmationTask_RecId_551(
					(List<ConfirmationTask_RecId_551>) session.getAttribute("treeViewList_551"));
		}
		String statesIdentity = (String) session.getAttribute("States");
	
		if (statesIdentity.equalsIgnoreCase("Y")) {
		if (CollectionUtils.isNotEmpty((List<ConfirmationTask_RecId12_550>) session.getAttribute("treeViewList9_550"))) {
			//System.out.println("list_550:: " + session.getAttribute("treeViewList9_550"));
			conformationTaskMain.setConfirmationTask_RecId12_550(
					(List<ConfirmationTask_RecId12_550>) session.getAttribute("treeViewList9_550"));
		}
		}else {
			if (CollectionUtils.isNotEmpty((List<ConfirmationTask_RecId_550>) session.getAttribute("treeViewList9_550"))) {
				//System.out.println("list_550:: " + session.getAttribute("treeViewList9_550"));
				conformationTaskMain.setConfirmationTask_RecId_550(
						(List<ConfirmationTask_RecId_550>) session.getAttribute("treeViewList9_550"));
			}
		}
		session.setAttribute("jspRender", "C");// missed

		model.addAttribute("conformationTaskMain", conformationTaskMain);
		String returnValue = "";
		if (statesIdentity.equalsIgnoreCase("Y")) {
			returnValue = "ConfTask12";
		} else {
			returnValue = "ConfTaskECXMLGW9";
		}

		return returnValue;
	}

	@RequestMapping(value = "/confnotes", method = RequestMethod.POST)
	public String completionNotes9(@RequestBody String notes, ModelMap modelmap, HttpSession session) {
		System.out.print("userId:::Controller:notes::::::::  " + notes);
		System.out.println(notes);
		String[] arrOfStr = notes.split("&", 2);
		
		
		notes= arrOfStr[0];
		notes=notes.replace("notes=", " ");
		notes=notes.replace("%21","!");
		notes=notes.replace("%40","@");
		notes=notes.replace("%23","#");
		notes=notes.replace("%24","$");
		notes=notes.replace("%25","%");
		notes=notes.replace("%26","&");
		notes=notes.replace("%28","(");
		notes=notes.replace("%29",")");
		notes=notes.replace("%60","`");
		notes=notes.replace("%2C",",");
		notes=notes.replace("%2D","-");
		notes=notes.replace("%2E",".");
		notes=notes.replace("%2F","/");
		notes=notes.replace("%3A",":");
		notes=notes.replace("%3B",";");
		notes=notes.replace("%3C","<");
		notes=notes.replace("%3D","=");
		notes=notes.replace("%3E",">");
		notes=notes.replace("%3F","?");
		notes=notes.replace("%5E","^");
		notes=notes.replace("%7B","{");
		notes=notes.replace("%7C","|");
		notes=notes.replace("%7D","}");
		notes=notes.replace("%5B","[");
		notes=notes.replace("%5C","/");
		notes=notes.replace("%5D","]");
		notes=notes.replace("%0A","");
		notes=notes.replace("%0D","");
		notes=notes.replaceAll("[-+]"," ");
//		System.out.println("=====notes value====after ===="+notes);
		Gson gson = new Gson();

		String activeUser = (String) session.getAttribute("activeUser");
		String environment = (String) session.getAttribute("environment");
		//String environment = (String) session.getAttribute("environment");
		EnvRegion e = envRegionCtrl.getEnvRegion(session);
		modelmap.addAttribute("environment", environment);
		modelmap.addAttribute("envregion", e);
		String userId =envRegionCtrl.getUserIdFromSession( session);
		String objHandle = (String) session.getAttribute("objectHandle");
		int objectHandle = 0;
		System.out.print("userId:::Controller::::" + userId);
		System.out.print("objHandle:::Controller::::" + objHandle);
		if (workloadCtrl.checkNullString(objHandle)) {
			objHandle = 1 + "";
			objectHandle = Integer.parseInt(objHandle);
			session.setAttribute("objectHandle", objectHandle);
		}
		String object_handle = WorkloadController.getObjectHandle(objectHandle);
		List<FollowUpData9States> followUpData9StatesList = (List<FollowUpData9States>) session
				.getAttribute("treeViewList_531");

		FollowUpData9States followUpData9States = treeView_9StateService
				.writeSelectedRequestNotesData(followUpData9StatesList, userId, object_handle, session, notes);
		System.out.print("objHandle:::Controller:DDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDD:::");
		// completionselectOkPopup(modelmap,session);

		  if(followUpData9States.getHeader().getReturn_code() != null &&
		  followUpData9States.getHeader().getReturn_code().equals("000")) 
		  {
//		if (true) {
			completionselectOkPopup(modelmap, session);
			session.removeAttribute("error");
		}
		String statesIdentity = (String) session.getAttribute("States");
		String returnValue = "";
		if (statesIdentity.equalsIgnoreCase("Y")) {
			returnValue = "redirect:/treeViewDisplay";
		} else {
			returnValue = "redirect:/treeview9states";
		}

		return returnValue;
	}

	// 3rd hit controller

	public void completionselectOkPopup(ModelMap modelmap, HttpSession session) {
		String environment = (String) session.getAttribute("environment");
		EnvRegion e = envRegionCtrl.getEnvRegion(session);
		modelmap.addAttribute("environment", environment);
		modelmap.addAttribute("envregion", e);
		String Lsr_number = (String) session.getAttribute("Lrs_No");
		// System.out.println("Lsr_number:::1::::::::"+Lsr_number);

		CloseTransaction closetransaction = new CloseTransaction();
		String userId =envRegionCtrl.getUserIdFromSession( session);
		System.out.println(userId);

		closetransaction.setLsr_number(Lsr_number.substring(0, 14));
		closetransaction.setNext(Lsr_number.substring(15, 17));

		closetransaction.setUser_id(userId);

		closeTransactionService.writeCloseTransactionDataToMQ(closetransaction, userId,session);
		// setSelectRequestDataBeforeRefresh(modelmap,session);
		refreshSamePage9States(modelmap, session);
		session.setAttribute("jspRender", "N");
	//	session.setAttribute("error", "N");

	}

	/*
	 * //4 hit controller
	 * 
	 * public String setSelectRequestDataBeforeRefresh(ModelMap modelmap,
	 * HttpSession session) { String activeUser = (String)
	 * session.getAttribute("activeUser"); String environment = (String)
	 * session.getAttribute("environment"); String userId =
	 * EnvRegionController.getLoginObject().getUser_id(); String
	 * objHandle=(String)session.getAttribute("objectHandle"); int objectHandle=0;
	 * System.out.print("userId:::Controller:refresh11:::"+userId);
	 * System.out.print("objHandle:::Controller::::"+objHandle);
	 * if(workloadCtrl.checkNullString(objHandle)) { objHandle=1+""; objectHandle=
	 * Integer.parseInt(objHandle);
	 * session.setAttribute("objectHandle",objectHandle); }
	 * 
	 * String object_handle=WorkloadController.getObjectHandle(objectHandle);
	 * 
	 * 
	 * System.out.println("session.getAttribute(\"newSelectRequestData\")::::::::"+
	 * session.getAttribute("newSelectRequestData"));
	 * 
	 * String status =
	 * treeView_9StateService.writeSelectedRequestPopup((SelectRequestData)session.
	 * getAttribute("newSelectRequestData"),userId,session,object_handle);
	 * session.setAttribute("jspRender","N");// missed
	 * refreshSamePage9States(modelmap, session); String statesIdentity =
	 * (String)session.getAttribute("States"); String returnValue = "";
	 * if(statesIdentity.equalsIgnoreCase("Y")) { returnValue =
	 * "redirect:/treeViewDisplay"; } else { returnValue =
	 * "redirect:/treeview9states"; } return returnValue; }
	 */
	public void refreshSamePage9States(ModelMap map, HttpSession session) {
		String environment = (String) session.getAttribute("environment");
		EnvRegion e = envRegionCtrl.getEnvRegion(session);
		map.addAttribute("environment", environment);
		map.addAttribute("envregion", e);
		System.out.println(
				"################Data:**refreshhh******************* " + session.getAttribute("selectRequestDatalist"));
		// List<SelectRequestData> selectRequestlist=
		// (List<SelectRequestData>)session.getAttribute("selectRequestDatalist");
		String currentPageVal = (String) session.getAttribute("currentPageIndex");
		SelectRequestData selectRequestTreeViewData = (SelectRequestData) getSelectRequestDataFromSession(session,
				Integer.parseInt(currentPageVal));
//		System.out.println("##########refreshhh######Data: " + selectRequestTreeViewData);
		// SelectRequestData selectRequestTreeViewData =
		// (SelectRequestData)session.getAttribute("selData");
//		System.out.println("Treeview Select Data is: " + selectRequestTreeViewData);
		SelectRequestData newSelectRequestData = new SelectRequestData();
		// System.out.println("selectRequestTreeViewData.getSelectRequestTableRows()++++++++++++++
		// = " +selectRequestTreeViewData.getSelectRequestTableRows());
		String user_id =envRegionCtrl.getUserIdFromSession( session);
		String objHandle = (String) session.getAttribute("objectHandle");
		String objectHandle = "0";
		if (checkNullString(objHandle)) {
			objHandle = 1 + "";
			objectHandle = objHandle;
			session.setAttribute("objectHandle", objectHandle);
		}
		setSelectedObj((String) session.getAttribute("selectedIndexValue"), newSelectRequestData,
				selectRequestTreeViewData);
//		System.out.println("newSelectRequestData+++refreshhh++999+++++++++ = " + newSelectRequestData);
		// System.out.println("newSelectRequestData++++++++++++++ = "
		// +newSelectRequestData);
		// session.setAttribute("newSelectRequestData", newSelectRequestData);
		// System.out.println("workloadDataWithMQData = "+workloadDataWithMQData);
		List treeViewList = new ArrayList();
		if (newSelectRequestData != null) {

			System.out.println("treeViewList::::refreshhh:::999:::::before service::::::");
			// treeViewList =
			// treeView_9StateService.writeSelectedRequestDataToTreeView(newSelectRequestData,user_id,session,objectHandle,treeViewList);
			String statesIdentity = (String) session.getAttribute("States");
			if (statesIdentity.equalsIgnoreCase("N")) {
				try {
				treeViewList = treeView_9StateService.writeSelectedRequestDataToTreeView(
						(SelectRequestData) session.getAttribute("newSelectRequestData"), user_id, session,
						objectHandle, treeViewList);
						
			}catch(Exception  exc) {
				System.out.println("classcate exception during flag N selreq refresh page"+exc);
				treeViewList = treeView_9StateEnhanceService.writeSelectedRequestDataToTreeView(
						(EnhancedSelectData) session.getAttribute("newSelectRequestData"), user_id, session,
						objectHandle, treeViewList);
				
			}
			} else {
				try {
				treeViewList = treeView_12StateService.writeSelectedRequestDataToTreeView(
						(SelectRequestData) session.getAttribute("newSelectRequestData"), user_id, session,
						objectHandle, treeViewList);
				}catch(Exception  exc) {
					System.out.println("classcate exception during else selreq refresh page"+exc);
					treeViewList = treeView_12StateEnhanceService.writeSelectedRequestDataToTreeView(
							(EnhancedSelectData) session.getAttribute("newSelectRequestData"), user_id, session,
							objectHandle, treeViewList);
					
				}
			}
//			System.out.println("treeViewList:::::::999:::::refreshhh::::::" + treeViewList);
			map.addAttribute("treeViewList", treeViewList);
		}
		System.out.println("model.getAttribute(\"treeViewList_558\")" + map.getAttribute("treeViewList_558"));

		// return "treeview9states";

	}

	// ---------------------------Shalu code start-------------------------

	@RequestMapping(value = "/conftask1", method = RequestMethod.POST)
	public String confirmationActivityR(
			@ModelAttribute("confirmationtaskmain12states") Confirmationtaskmain12states confirmationtaskmain12states,
			ModelMap model, HttpSession session) {
		// public String confirmationTask12(@RequestBody String formData, ModelMap
		// model, HttpSession session) {
		// System.out.println("formData:::::111::::"+formData);

		// Confirmationtaskmain12states wrklod=new Confirmationtaskmain12states();

		// System.out.println("WorkloadData ->>: " + sentData.get(3));
		// Gson gson = new Gson();
		// Confirmationtaskmain12states confirmationtaskmain12states =
		// gson.fromJson(formData, Confirmationtaskmain12states.class);

		System.out.println("confirmationtaskmain12states:::::111::::" + confirmationtaskmain12states);
		String activeUser = (String) session.getAttribute("activeUser");
		String environment = (String) session.getAttribute("environment");
		EnvRegion e = envRegionCtrl.getEnvRegion(session);
		model.addAttribute("environment", environment);
				model.addAttribute("envregion", e);
		String userId =envRegionCtrl.getUserIdFromSession( session);
		String objHandle = (String) session.getAttribute("objectHandle");
		String recIds = "";
		int objectHandle = 0;
		System.out.print("userId:::Controller::::" + userId);
		System.out.print("objHandle:::Controller::::" + objHandle);
		if (workloadCtrl.checkNullString(objHandle)) {
			objHandle = 1 + "";
			objectHandle = Integer.parseInt(objHandle);
			session.setAttribute("objectHandle", objectHandle);
		}
		String object_handle = WorkloadController.getObjectHandle(objectHandle);

		confirmationtaskmain12states.setNotesFupBindingData12States(
				(List<NotesFupBindingData12States>) session.getAttribute("treeViewList_049"));

		confirmationtaskmain12states = treeView_12StateService
				.writeSelectedRequestConformationData(confirmationtaskmain12states, userId, object_handle, session);
		String error_msg = " ";
		if (confirmationtaskmain12states.getHeader().getReturn_code() != null
				&& confirmationtaskmain12states.getHeader().getReturn_code().equals("000")) {
			error_msg = "Y";
			session.setAttribute("jspFlag", "conf_task");
		} else if (confirmationtaskmain12states.getHeader().getReturn_code() != null
				&& confirmationtaskmain12states.getHeader().getReturn_code().equals("999")) {
			error_msg = "N";
		} else if (confirmationtaskmain12states.getHeader().getReturn_code() != null
				&& confirmationtaskmain12states.getHeader().getReturn_code().equals("888")) {
			error_msg = "M";
		} else if (confirmationtaskmain12states.getHeader().getReturn_code() != null
				&& confirmationtaskmain12states.getHeader().getReturn_code().equals("889")) {
			error_msg = "U";
		}

		String statesIdentity = (String) session.getAttribute("States");
		String returnValue = "";
		if (statesIdentity.equalsIgnoreCase("Y")) {
			returnValue = "redirect:/treeViewDisplay";
		} else {
			returnValue = "redirect:/treeview9states";
		}
		List<ShowError> showErrorList = treeView_12StateService.getUpdatedErrorList();
		model.addAttribute("showError", showErrorList);
		System.out.print("showError:::Controller::::" + showErrorList);
		session.setAttribute("error", error_msg);
		session.setAttribute("jspRender", "conftask1");

		return returnValue;

	}

	@RequestMapping(value = "/conftaskTest1", method = RequestMethod.GET)
	public String completionTask9Test1(ModelMap model, HttpSession session) {
		
		String environment = (String) session.getAttribute("environment");
		EnvRegion e = envRegionCtrl.getEnvRegion(session);
		model.addAttribute("environment", environment);
				model.addAttribute("envregion", e);
		List<ConfirmationReqtypRLSOG6102Row> list_553 = (List<ConfirmationReqtypRLSOG6102Row>) (session
				.getAttribute("treeViewList_553"));
		List<ConfirmationLS0G6DW2Row> list_557 = (List<ConfirmationLS0G6DW2Row>) (session
				.getAttribute("treeViewList_557"));

		Confirmationtaskmain12states confirmationtaskmain12states = new Confirmationtaskmain12states();
		if (CollectionUtils.isNotEmpty(list_553)) {
			System.out.println("list_553 size:: " + list_553);
			confirmationtaskmain12states.setConfirmationReqtypRLSOG6102Row(list_553);
		}
		if (CollectionUtils.isNotEmpty(list_557)) {
			System.out.println("list_557 size:: " + list_557);
			confirmationtaskmain12states.setTreeViewList_557(list_557);
		}
		if (CollectionUtils.isNotEmpty((List<NotesFupBindingData12States>) session.getAttribute("treeViewList_049"))) {
			System.out.println("list 049:: " + session.getAttribute("treeViewList_049"));
			confirmationtaskmain12states.setNotesFupBindingData12States(
					(List<NotesFupBindingData12States>) session.getAttribute("treeViewList_049"));
		}

		session.setAttribute("jspRender", "C");// missed
		model.addAttribute("confirmationtaskmain12states", confirmationtaskmain12states);
		return "Confirmationtask12states";
	}

	// Shalu-changes start done for correcting confirmation task
//Ruby's changes start
	@RequestMapping(value = "/corrconftask", method = RequestMethod.POST)
	public String corrconftask12(
			@ModelAttribute("correctingconfirmationtaskmain12states") Correctingconfirmationtaskmain12states correctingconfirmationtaskmain12states,
			ModelMap model, HttpSession session) {
		//System.out
			//	.println("correctingconfirmationtaskmain12states:::::111::::" + correctingconfirmationtaskmain12states);
		String activeUser = (String) session.getAttribute("activeUser");
		String environment = (String) session.getAttribute("environment");
		EnvRegion e = envRegionCtrl.getEnvRegion(session);
		model.addAttribute("environment", environment);
				model.addAttribute("envregion", e);
		String userId =envRegionCtrl.getUserIdFromSession( session);
		String objHandle = (String) session.getAttribute("objectHandle");
		String recIds = "";
		int objectHandle = 0;
		System.out.print("userId:::Controller::::" + userId);
		System.out.print("objHandle:::Controller::::" + objHandle);
		if (workloadCtrl.checkNullString(objHandle)) {
			objHandle = 1 + "";
			objectHandle = Integer.parseInt(objHandle);
			session.setAttribute("objectHandle", objectHandle);
		}
		String object_handle = WorkloadController.getObjectHandle(objectHandle);

		correctingconfirmationtaskmain12states.setNotesFupBindingData12States(
				(List<NotesFupBindingData12States>) session.getAttribute("treeViewList_049"));
		
		//Added Ruby start
		String error_msg = " ";
				List<Correcting_ConfirmationTask_RecId_858> oldList_858 = (List<Correcting_ConfirmationTask_RecId_858>) (session.getAttribute("treeViewList_858"));
				List<CorrectingConfirmationLS0G6DW5row> oldList_852 = (List<CorrectingConfirmationLS0G6DW5row>)(session.getAttribute("treeViewList_852"));
				List<Correcting_ConfirmationTask_RecId_858> updatedOrderNumberList= new ArrayList<Correcting_ConfirmationTask_RecId_858>();
				List<CorrectingConfirmationLS0G6DW5row> updatedOrderNumberList852 = treeView_12StateService.getUpdatedRows852(correctingconfirmationtaskmain12states.getConfirmationTask_RecId_852(), oldList_852);
				if(correctingconfirmationtaskmain12states.getConfirmationTask_RecId_858()!=null) {
					updatedOrderNumberList = treeView_12StateService.getUpdatedRows858(correctingconfirmationtaskmain12states.getConfirmationTask_RecId_858(), oldList_858);
				}
				
				
						if (updatedOrderNumberList.isEmpty() && updatedOrderNumberList852.isEmpty() ) {
							System.out.println("In controller before if part");
							error_msg="O";
						} else {
							correctingconfirmationtaskmain12states = treeView_12StateService.writeSelectedRequestCorrConformationData(correctingconfirmationtaskmain12states, userId,
									object_handle, session, updatedOrderNumberList);
							
							System.out.println("In controller else part");
						}
							Header header=correctingconfirmationtaskmain12states.getHeader();
		//System.out.println("header::"+header.getReturn_code()+"    header String::"+header.toString());
		if(header != null) {
			System.out.println("In controller header part");
		if (correctingconfirmationtaskmain12states.getHeader().getReturn_code() != null
				&& correctingconfirmationtaskmain12states.getHeader().getReturn_code().equals("000")) {
			// if(true) {
			error_msg = "Y";
			session.setAttribute("jspFlag", "conf_task");

		} else if (correctingconfirmationtaskmain12states.getHeader().getReturn_code() != null
				&& correctingconfirmationtaskmain12states.getHeader().getReturn_code().equals("999")) {
			error_msg = "N";
		} else if (correctingconfirmationtaskmain12states.getHeader().getReturn_code() != null
				&& correctingconfirmationtaskmain12states.getHeader().getReturn_code().equals("888")) {
			error_msg = "M";
		} else if (correctingconfirmationtaskmain12states.getHeader().getReturn_code() != null
				&& correctingconfirmationtaskmain12states.getHeader().getReturn_code().equals("889")) {
			error_msg = "U";
		}
	}
		
		String statesIdentity = (String) session.getAttribute("States");
		String returnValue = "";
		if (statesIdentity.equalsIgnoreCase("Y")) {
			returnValue = "redirect:/treeViewDisplay";
		} else {
			returnValue = "redirect:/treeview9states";
		}
		List<ShowError> showErrorList = treeView_12StateService.getUpdatedErrorList();
		model.addAttribute("showError", showErrorList);
		System.out.print("showError:::Controller::::" + showErrorList);
		session.setAttribute("error", error_msg);
		session.setAttribute("jspRender", "corrconftask");
		// completionselectReqPopup(model,session);
		System.out.print("I am here at post methid" + returnValue);
		return returnValue;

	}
	@RequestMapping(value = "/corrconftaskTest", method = RequestMethod.GET)
	public String corrconftask12test(ModelMap model, HttpSession session) {
		String environment = (String) session.getAttribute("environment");
		EnvRegion e = envRegionCtrl.getEnvRegion(session);
		model.addAttribute("environment", environment);
				model.addAttribute("envregion", e);
		List<Correcting_ConfirmationTask_RecId_858> list_858 = (List<Correcting_ConfirmationTask_RecId_858>) (session
				.getAttribute("treeViewList_858"));
		List<CorrectingConfirmationLS0G6DW5row> list_852 = (List<CorrectingConfirmationLS0G6DW5row>) (session
				.getAttribute("treeViewList_852"));

		Correctingconfirmationtaskmain12states correctingconfirmationtaskmain12states = new Correctingconfirmationtaskmain12states();
		if (CollectionUtils.isNotEmpty(list_858)) {
//			System.out.println("list_858 size:: " + list_858);
			correctingconfirmationtaskmain12states.setConfirmationTask_RecId_858(list_858);
		}
		if (CollectionUtils.isNotEmpty(list_852)) {
//			System.out.println("list_852 size:: " + list_852);
			correctingconfirmationtaskmain12states.setConfirmationTask_RecId_852(list_852);
		}
		if (CollectionUtils.isNotEmpty((List<NotesFupBindingData12States>) session.getAttribute("treeViewList_049"))) {
//			System.out.println("list 049:: " + session.getAttribute("treeViewList_049"));
			correctingconfirmationtaskmain12states.setNotesFupBindingData12States(
					(List<NotesFupBindingData12States>) session.getAttribute("treeViewList_049"));
		}
		if (CollectionUtils
				.isNotEmpty((List<CorrectingConfirmationLS0G6DW1row>) session.getAttribute("treeViewList_850"))) {
//			System.out.println("list_850:: " + session.getAttribute("treeViewList_850"));
			correctingconfirmationtaskmain12states.setConfirmationTask_RecId_850(
					(List<CorrectingConfirmationLS0G6DW1row>) session.getAttribute("treeViewList_850"));
		}
		if (CollectionUtils.isNotEmpty((List<ConfirmationLS0G6DW3Row>) session.getAttribute("treeViewList_851"))) {
//			System.out.println("list 851:: " + session.getAttribute("treeViewList_851"));
			correctingconfirmationtaskmain12states.setConfirmationTask_RecId_851(
					(List<ConfirmationLS0G6DW3Row>) session.getAttribute("treeViewList_851"));
		}
		session.setAttribute("jspRender", "C");

		model.addAttribute("correctingconfirmationtaskmain12states", correctingconfirmationtaskmain12states);
		return "CorrectingConf_LSOG6";
	}

	// Shalu-changes end

	// Hrushi
	@RequestMapping(value = "/editEcckt", method = RequestMethod.POST)
	public String processEditEccktData(@RequestBody String input, ModelMap model, HttpSession session) {
		// System.out.println("in /editEcckt post method ->>" + input);
		EnvRegion e = envRegionCtrl.getEnvRegion(session);
		String activeUser = (String) session.getAttribute("activeUser");
		String environment = (String) session.getAttribute("environment");
		session.removeAttribute("jspFlag");
		session.removeAttribute("ecckt_info_msg");
		session.removeAttribute("ecckt_err_msg");
		session.setAttribute("ecckt_info_msg", "");
		session.setAttribute("ecckt_err_msg", "");
		model.remove("ecckt_err_msg");
		model.remove("ecckt_info_msg");
		// String userId = (String) session.getAttribute("userId");
		String userId =envRegionCtrl.getUserIdFromSession( session);
		String objHandle = (String) session.getAttribute("objectHandle");
		int objectHandle = 0;
		if (workloadCtrl.checkNullString(objHandle)) {
			objHandle = 1 + "";
			objectHandle = Integer.parseInt(objHandle);
			session.setAttribute("objectHandle", objectHandle);
		}
		String object_handle = WorkloadController.getObjectHandle(objectHandle);

		List<String> reqData = new ArrayList<String>();
		String[] sentData = input.split("$");
		for (String a : sentData) {
			reqData.add(a);
		}

		List<EditEccktTableRow> updatedEccktList = eccktService.getInpuDataObject(input, session);
		if (updatedEccktList.isEmpty()) {
			ReadErrorMsgsJson readErrorMsgsJson = new ReadErrorMsgsJson();
			String ecckt_msg = readErrorMsgsJson.getErrorMsg("LG0027");
			session.setAttribute("ecckt_err_msg", ecckt_msg);
			session.setAttribute("ecckt_info_msg", "");
		} else {
			eccktService.writeSaveEditEccktDataToMQ(updatedEccktList, userId, object_handle, session, model);
		}

		List<ShowError> showError = eccktService.getEccktErrorList();

		model.addAttribute("ecckt_err_msg", session.getAttribute("ecckt_err_msg"));
		model.addAttribute("ecckt_info_msg", session.getAttribute("ecckt_info_msg"));
		model.addAttribute("showError", showError);
		session.setAttribute("jspRender", "editEcckt");
		model.addAttribute("activeUser", activeUser);
		model.addAttribute("environment", environment);
		model.addAttribute("envregion", e);

		return "redirect:/treeViewDisplay";
	}

	@RequestMapping(value = "/updatePostSoc", method = RequestMethod.GET)
	public String updatePostSoc(ModelMap model, HttpSession session) {
		String environment = (String) session.getAttribute("environment");
		EnvRegion e = envRegionCtrl.getEnvRegion(session);
		model.addAttribute("environment", environment);
				model.addAttribute("envregion", e);
		List<UpdateOrderNumberRow> list_668 = (List<UpdateOrderNumberRow>) (session.getAttribute("treeViewList_668"));

		UpdateOrderNumberData updateOrderData = new UpdateOrderNumberData();
		if (CollectionUtils.isNotEmpty(list_668)) {
			System.out.println("list_668 size:: " + list_668);
			updateOrderData.setUpdateOrderNumberTableRows(list_668);
		}

		// model.addAttribute("ref",list_668.get(0));
		model.addAttribute("updateOrderData", updateOrderData);
		return "updatePostSoc";
	}

	@RequestMapping(value = "/updateOrderNumber", method = RequestMethod.POST)
	public String processUpdateOrderNumberData(@ModelAttribute("updateOrderData") UpdateOrderNumberData updateOrderData,
			ModelMap model, HttpSession session) {
		System.out.println("In udpateOrderNumber post method ->>" + updateOrderData.toString());
		String returnCode="",error_msg= "";
		EnvRegion e = envRegionCtrl.getEnvRegion(session);
		String activeUser = (String) session.getAttribute("activeUser");
		String environment = (String) session.getAttribute("environment");
		session.removeAttribute("jspFlag");
		
		String userId =envRegionCtrl.getUserIdFromSession( session);
		String objHandle = (String) session.getAttribute("objectHandle");
		int objectHandle = 0;
		if (workloadCtrl.checkNullString(objHandle)) {
			objHandle = 1 + "";
			objectHandle = Integer.parseInt(objHandle);
			session.setAttribute("objectHandle", objectHandle);
		}
		String object_handle = WorkloadController.getObjectHandle(objectHandle);
		@SuppressWarnings("unchecked")
		List<UpdateOrderNumberRow> oldOrdList = (List<UpdateOrderNumberRow>) (session.getAttribute("treeViewList_668"));
		if(oldOrdList == null)
		{
			oldOrdList = new ArrayList<UpdateOrderNumberRow>();
		}
		List<UpdateOrderNumberRow> newOrdList = updateOrderData.getUpdateOrderNumberTableRows();
		if(newOrdList == null)
		{
			newOrdList = new ArrayList<UpdateOrderNumberRow>();
		}
		
		List<UpdateOrderNumberRow> updatedOldDataRowsList = updateOrderService.getUpdatedRows(newOrdList, oldOrdList);
		List<UpdateOrderNumberRow> updatedNewDataRowsList = updateOrderService.getUpdatedNewRowsData(
				newOrdList.subList(oldOrdList.size(), newOrdList.size()));
		if (updatedOldDataRowsList.isEmpty() && updatedNewDataRowsList.isEmpty()) {
			error_msg = "NS";
		} else {
			// passing existing updated rows and newly added rows list to service
			returnCode = updateOrderService.writeSaveUpdateOrderDataToMQ(updatedOldDataRowsList, updatedNewDataRowsList,
					userId, object_handle, session);
			if (returnCode.equals("000")) {
				completionselectOkPopup(model, session);
			}
		}
		
		if (returnCode != null && returnCode.equals("000")) {
			error_msg = "Y";
		} else if (returnCode != null && returnCode.equals("999")) {
			error_msg = "N";
		} else if (returnCode != null && returnCode.equals("888")) {
			error_msg = "M";
		} else if (returnCode != null && returnCode.equals("889")) {
			error_msg = "U";
		}

		session.setAttribute("jspRender", "updateOrderNumber");
		session.setAttribute("error", error_msg);
		model.addAttribute("activeUser", activeUser);
		model.addAttribute("environment", environment);
		model.addAttribute("envregion", e);

		return "redirect:/treeViewDisplay";

	}
	

	// mahendra
	@RequestMapping(value = "/attcanceltask12", method = RequestMethod.POST)
	public String addAttCancelTask(@RequestBody String input, AttCancelTask attCancelTask, ModelMap model,
			HttpSession session) {
		String environment = (String) session.getAttribute("environment");
		EnvRegion e = envRegionCtrl.getEnvRegion(session);
		model.addAttribute("environment", environment);
				model.addAttribute("envregion", e);
				session.removeAttribute("jspFlag");
		ArrayList<AttCancelTask> listRecords = (ArrayList) session.getAttribute("treeViewList_543");
//		System.out.println("display the list of records" + listRecords.get(0));
		String user_id =envRegionCtrl.getUserIdFromSession( session);
		if (input.equals("yes")) {
			attCancelReqService.attCancelTransactionDataToMQ(listRecords, user_id, session);
		} else if (input.equals("no")) {
			attCancelTaskReqService.attCancelTaskReqService(listRecords, user_id, session);
		}
		session.setAttribute("jspRender", "attTask12");
		return "redirect:/treeViewDisplay";

	}

	// mahendra
	@RequestMapping(value = "/attcanceltask9", method = RequestMethod.POST)
	public String addAttCancelTask9(@RequestBody String input, AttCancelTask9 attCancelTask9, ModelMap model,
			HttpSession session) {
		String environment = (String) session.getAttribute("environment");
		EnvRegion e = envRegionCtrl.getEnvRegion(session);
		model.addAttribute("environment", environment);
				model.addAttribute("envregion", e);
				session.removeAttribute("jspFlag");
		ArrayList<AttCancelTask9> listRecords = (ArrayList) session.getAttribute("treeViewList9_543");
//		System.out.println("display the list of records" + listRecords.get(0));
		String user_id =envRegionCtrl.getUserIdFromSession( session);
		if (input.equals("yes")) {
			attCancel_9StateService.attCancelTransaction_9StateDataToMQ(listRecords, user_id, session);
		} else if (input.equals("no")) {
			attCancelTask_9StateService.attCancelTask_9StateDataToMQ(listRecords, user_id, session);
		}

		session.setAttribute("jspRender", "attTask");
		return "redirect:/treeview9states";

	}

	// kiran
	@RequestMapping(value = "/focTest", method = RequestMethod.GET)
	public String focTest9Sates(Model model, HttpSession session) {
		String environment = (String) session.getAttribute("environment");
		EnvRegion e = envRegionCtrl.getEnvRegion(session);
		model.addAttribute("environment", environment);
				model.addAttribute("envregion", e);
		List<ConfirmationTaskNEmailXMLGW9RecId906> list_906 = (List<ConfirmationTaskNEmailXMLGW9RecId906>) (session
				.getAttribute("treeViewList_906"));
		List<ConfirmationTaskNEmailXMLGW9RecId905> list_905 = (List<ConfirmationTaskNEmailXMLGW9RecId905>) (session
				.getAttribute("treeViewList_905"));

		ConformationTaskMain conformationTaskMain = new ConformationTaskMain();
		if (CollectionUtils.isNotEmpty(list_906)) {
//			System.out.println("list_906 size:: " + list_906);
			conformationTaskMain.setConfirmationTaskNEmailXMLGW9RecId906(list_906);
		}
		if (CollectionUtils.isNotEmpty(list_905)) {
//			System.out.println("list_905 size:: " + list_905);
			conformationTaskMain.setConfirmationTaskNEmailXMLGW9RecId905(list_905);
		}
		if (CollectionUtils.isNotEmpty((List<NotesFupBindingData9States>) session.getAttribute("treeViewList_049"))) {
//			System.out.println("list 049:: " + session.getAttribute("treeViewList_049"));
			conformationTaskMain.setNotesFupBindingData9States(
					(List<NotesFupBindingData9States>) session.getAttribute("treeViewList_049"));
		}
		session.setAttribute("jspRender", "C");
		model.addAttribute("conformationTaskMain", conformationTaskMain);
		System.out.println("model.getAttribute(\"treeViewList_905\")" + model.getAttribute("treeViewList_905"));
		return "focTask9";
	}

	@RequestMapping(value = "/focTesttask", method = RequestMethod.POST)
	public String writefocTest9Sates(@ModelAttribute("conformationTaskMain") ConformationTaskMain conformationTaskMain,
			ModelMap model, HttpSession session) {

		System.out.println("In foc test task");
		String activeUser = (String) session.getAttribute("activeUser");
		//String environment = (String) session.getAttribute("environment");
		String environment = (String) session.getAttribute("environment");
		EnvRegion e = envRegionCtrl.getEnvRegion(session);
		model.addAttribute("environment", environment);
				model.addAttribute("envregion", e);
		session.removeAttribute("jspFlag");
		String userId =envRegionCtrl.getUserIdFromSession( session);
		String objHandle = (String) session.getAttribute("objectHandle");
		String recIds = "";
		int objectHandle = 0;
		System.out.print("userId:::Controller::::" + userId);
		System.out.print("objHandle:::Controller::::" + objHandle);
		if (workloadCtrl.checkNullString(objHandle)) {
			objHandle = 1 + "";
			objectHandle = Integer.parseInt(objHandle);
			session.setAttribute("objectHandle", objectHandle);
		}
		String object_handle = WorkloadController.getObjectHandle(objectHandle);

		conformationTaskMain.setNotesFupBindingData9States(
				(List<NotesFupBindingData9States>) session.getAttribute("treeViewList_049"));
		List<ConfirmationTask_RecId_558> oldList_558 = (List<ConfirmationTask_RecId_558>) (session.getAttribute("treeViewList_558"));
		conformationTaskMain = treeView_9StateService.writeSelectedRequestConformationData(conformationTaskMain, userId,
				object_handle, session, oldList_558);

		String error_msg = " ";

		// completionselectOkPopup(model,session);

		if (conformationTaskMain.getHeader().getReturn_code() != null
				&& conformationTaskMain.getHeader().getReturn_code().equals("000")) {

			error_msg = "Y";

		} else if (conformationTaskMain.getHeader().getReturn_code() != null
				&& conformationTaskMain.getHeader().getReturn_code().equals("999")) {
			error_msg = "N";
		} else if (conformationTaskMain.getHeader().getReturn_code() != null
				&& conformationTaskMain.getHeader().getReturn_code().equals("888")) {
			error_msg = "M";
		} else if (conformationTaskMain.getHeader().getReturn_code() != null
				&& conformationTaskMain.getHeader().getReturn_code().equals("889")) {
			error_msg = "U";
		}
		String returnValue = "";
		returnValue = "redirect:/treeview9states";

		/*
		 * String statesIdentity = (String) session.getAttribute("States"); String
		 * returnValue = ""; if (statesIdentity.equalsIgnoreCase("Y")) { returnValue =
		 * "redirect:/treeviewfinal"; } else { returnValue =
		 * "redirect:/treeview9states"; }
		 */

		List<ShowError> showErrorList = treeView_9StateService.getUpdatedErrorList();

		model.addAttribute("showError", showErrorList);
		System.out.print("showError:::Controller::::" + showErrorList);

		session.setAttribute("error", error_msg);
		System.out.println("Eroor --->>" + error_msg);
		session.setAttribute("jspRender", "foctask");

		return returnValue;

	}
	// kiran Task End

	// ***********************************Saurabh Sprint 11 code
	// start*****************************

	@RequestMapping(value = "/conftasknoprod9", method = RequestMethod.POST)
	public String confTaskNoProd9(
			@ModelAttribute("confTaskNoProd9Main") ConfirmationTaskNoProd9Main confTaskNoProd9Main, ModelMap model,
			HttpSession session) {
		String environment = (String) session.getAttribute("environment");
		EnvRegion e = envRegionCtrl.getEnvRegion(session);
		model.addAttribute("environment", environment);
				model.addAttribute("envregion", e);
		System.out.println("correctingConfTask:::::111::::" + confTaskNoProd9Main);
		String activeUser = (String) session.getAttribute("activeUser");
		//String environment = (String) session.getAttribute("environment");
		String userId =envRegionCtrl.getUserIdFromSession( session);
		String objHandle = (String) session.getAttribute("objectHandle");
		String recIds = "";
		int objectHandle = 0;
		System.out.print("userId:::Controller::::" + userId);
		System.out.print("objHandle:::Controller::::" + objHandle);
		if (workloadCtrl.checkNullString(objHandle)) {
			objHandle = 1 + "";
			objectHandle = Integer.parseInt(objHandle);
			session.setAttribute("objectHandle", objectHandle);
		}

		String object_handle = WorkloadController.getObjectHandle(objectHandle);
		confTaskNoProd9Main.setNotesFupBindingData9States(
				(List<NotesFupBindingData12States>) session.getAttribute("treeViewList_049"));
		//Added kiran start
		List<ConfirmationTask_RecId_558> oldList_558 = (List<ConfirmationTask_RecId_558>) (session.getAttribute("treeViewList_558"));
		List<ConfirmationTask_RecId_558> updatedOrderNumberList = selectRequestService.getUpdatedRows(confTaskNoProd9Main.getConfirmationTask_RecId_558(), oldList_558);
		
//				if (updatedOrderNumberList.isEmpty()) {
//					ReadErrorMsgsJson readErrorMsgsJson = new ReadErrorMsgsJson();
//					String uon_msg = readErrorMsgsJson.getErrorMsg("LG0027");
//				     String returnValue = "";
//						returnValue = "redirect:/treeview9states";
//				        session.setAttribute("update_msg", uon_msg);
//						System.out.println("Eroor --->>" + uon_msg);
//						session.setAttribute("jspRender", "ConfTaskNoProd9b_s");
//						return returnValue;
//				} else {
					confTaskNoProd9Main = treeView_9StateService.writeSelectedRequestConfTaskNoProd9MainData(confTaskNoProd9Main,
							userId, object_handle, session,updatedOrderNumberList);
//			}
				
//Added kiran end
		/*
		 * confTaskNoProd9Main =
		 * treeView_9StateService.writeSelectedRequestConfTaskNoProd9MainData(
		 * confTaskNoProd9Main, userId, object_handle, session);
		 */

		
				String error_msg = " ";
		if (confTaskNoProd9Main.getHeader().getReturn_code() != null
				&& confTaskNoProd9Main.getHeader().getReturn_code().equals("000")) {

			// if(true) {
			error_msg = "Y";
			session.setAttribute("jspFlag", "conf_task");

		} else if (confTaskNoProd9Main.getHeader().getReturn_code() != null
				&& confTaskNoProd9Main.getHeader().getReturn_code().equals("999")) {
			error_msg = "N";
		} else if (confTaskNoProd9Main.getHeader().getReturn_code() != null
				&& confTaskNoProd9Main.getHeader().getReturn_code().equals("888")) {
			error_msg = "M";
		} else if (confTaskNoProd9Main.getHeader().getReturn_code() != null
				&& confTaskNoProd9Main.getHeader().getReturn_code().equals("889")) {
			error_msg = "U";
		}
		String returnValue = "";
		returnValue = "redirect:/treeview9states";

		/*
		 * String statesIdentity = (String) session.getAttribute("States"); String
		 * returnValue = ""; if (statesIdentity.equalsIgnoreCase("Y")) { returnValue =
		 * "redirect:/treeviewfinal"; } else { returnValue =
		 * "redirect:/treeview9states"; }
		 */

		List<ShowError> showErrorList = treeView_9StateService.getUpdatedErrorList();

		model.addAttribute("showError", showErrorList);
		System.out.print("showError:::Controller::::" + showErrorList);

		session.setAttribute("error", error_msg);
		System.out.println("Eroor --->>" + error_msg);
		session.setAttribute("jspRender", "ConfTaskNoProd9b_s");

		return returnValue;

	}

	@RequestMapping(value = "/conftasknoprodTest", method = RequestMethod.GET)
	public String confTaskNoProd9Test(Model model, HttpSession session) {
		String environment = (String) session.getAttribute("environment");
		EnvRegion e = envRegionCtrl.getEnvRegion(session);
		model.addAttribute("environment", environment);
				model.addAttribute("envregion", e);
		ConfirmationTaskNoProd9Main confTaskNoProd9Main = new ConfirmationTaskNoProd9Main();

		if (CollectionUtils.isNotEmpty((List<NotesFupBindingData9States>) session.getAttribute("treeViewList_049"))) {
//			System.out.println("list 049:: " + session.getAttribute("treeViewList_049"));
			confTaskNoProd9Main.setNotesFupBindingData9States(
					(List<NotesFupBindingData12States>) session.getAttribute("treeViewList_049"));
		}

		if (CollectionUtils
				.isNotEmpty((List<ConfirmationTaskNoProd_RecId_556>) session.getAttribute("treeViewList_556"))) {
//			System.out.println("list 556:: " + session.getAttribute("treeViewList_556"));
			confTaskNoProd9Main.setConfirmationTaskNoProd_RecId_556(
					(List<ConfirmationTaskNoProd_RecId_556>) session.getAttribute("treeViewList_556"));
		}
		if (CollectionUtils.isNotEmpty((List<NotesFupBindingData12States>) session.getAttribute("treeViewList_558"))) {
//			System.out.println("list 558:: " + session.getAttribute("treeViewList_558"));
			confTaskNoProd9Main.setConfirmationTask_RecId_558(
					(List<ConfirmationTask_RecId_558>) session.getAttribute("treeViewList_558"));
		}
		model.addAttribute("confTaskNoProd9Main", confTaskNoProd9Main);
		return "ConfTaskNoProd9b_s";
	}
  //yash's code changes start
	@RequestMapping(value = "/correctconftask9", method = RequestMethod.POST)
	public String correctingConfTask9State(
			@ModelAttribute("correctingConfTask9Main") CorrectingConfTask9Main correctingConfTask9Main, ModelMap model,
			HttpSession session) {
		String environment = (String) session.getAttribute("environment");
		EnvRegion e = envRegionCtrl.getEnvRegion(session);
		model.addAttribute("environment", environment);
				model.addAttribute("envregion", e);
		
//				System.out.println("correctingConfTask:::::111::::" + correctingConfTask9Main);
		String activeUser = (String) session.getAttribute("activeUser");
	//	String environment = (String) session.getAttribute("environment");
		String userId =envRegionCtrl.getUserIdFromSession( session);
		String objHandle = (String) session.getAttribute("objectHandle");
		String recIds = "";
		int objectHandle = 0;
		System.out.print("userId:::Controller::::" + userId);
		System.out.print("objHandle:::Controller::::" + objHandle);
		if (workloadCtrl.checkNullString(objHandle)) {
			objHandle = 1 + "";
			objectHandle = Integer.parseInt(objHandle);
			session.setAttribute("objectHandle", objectHandle);
		}

		String object_handle = WorkloadController.getObjectHandle(objectHandle);

		correctingConfTask9Main.setNotesFupBindingData9States(
				(List<NotesFupBindingData12States>) session.getAttribute("treeViewList_049"));
		String error_msg = " ";
		List<Correcting_ConfirmationTask_RecId_858> oldList_858 = (List<Correcting_ConfirmationTask_RecId_858>) (session.getAttribute("treeViewList_858"));
		List<CorrectingConfTask9_RecId_852> oldList_852 = (List<CorrectingConfTask9_RecId_852>)(session.getAttribute("treeViewList9_852"));
		List<Correcting_ConfirmationTask_RecId_858> updatedOrderNumberList= new ArrayList<Correcting_ConfirmationTask_RecId_858>();
		List<CorrectingConfTask9_RecId_852> updatedOrderNumberList852 = treeView_9StateService.getUpdatedRowsForCCT_852(correctingConfTask9Main.getCorrectingConfTask9_RecId_852(),oldList_852);
				//.getUpdatedRowsForCCT_852(correctingConfTask9Main.getCorrectingConfTask9_RecId_852(), oldList_852);
	
		List<CorrectingConfTask9_RecId_850> oldList_850 = (List<CorrectingConfTask9_RecId_850>)(session.getAttribute("treeViewList9_850"));

		List<CorrectingConfTask9_RecId_850> updatedOrderNumberList850 = treeView_9StateService.getUpdatedRowsForCCT_850(correctingConfTask9Main.getCorrectingConfTask9_RecId_850(),oldList_850);
		
		if(correctingConfTask9Main.getCorrecting_ConfirmationTask_RecId_858()!=null) {
			updatedOrderNumberList = treeView_9StateService.getUpdatedRowsForCCT_858(correctingConfTask9Main.getCorrecting_ConfirmationTask_RecId_858(), oldList_858);
		}
		
		
		if (updatedOrderNumberList.isEmpty() && updatedOrderNumberList852.isEmpty() && updatedOrderNumberList850.isEmpty() ) {
			System.out.println("In controller before if part");
			error_msg="O";
		} else {
			correctingConfTask9Main = treeView_9StateService
					.writeSelectedRequestCorrectingConfTask9Data(correctingConfTask9Main,updatedOrderNumberList850, userId, object_handle, session);
			
			System.out.println("In controller else part");
		}
		

		
		Header header=correctingConfTask9Main.getHeader();
		if(header!=null) {
		if (correctingConfTask9Main.getHeader().getReturn_code() != null
				&& correctingConfTask9Main.getHeader().getReturn_code().equals("000")) {
			// if(true) {
			error_msg = "Y";
			session.setAttribute("jspFlag", "conf_task");

		} else if (correctingConfTask9Main.getHeader().getReturn_code() != null
				&& correctingConfTask9Main.getHeader().getReturn_code().equals("999")) {
			error_msg = "N";
		} else if (correctingConfTask9Main.getHeader().getReturn_code() != null
				&& correctingConfTask9Main.getHeader().getReturn_code().equals("888")) {
			error_msg = "M";
		} else if (correctingConfTask9Main.getHeader().getReturn_code() != null
				&& correctingConfTask9Main.getHeader().getReturn_code().equals("889")) {
			error_msg = "U";
		}
		}
		String returnValue = "";
		returnValue = "redirect:/treeview9states";

		/*
		 * String statesIdentity = (String) session.getAttribute("States"); String
		 * returnValue = ""; if (statesIdentity.equalsIgnoreCase("Y")) { returnValue =
		 * "redirect:/treeviewfinal"; } else { returnValue =
		 * "redirect:/treeview9states"; }
		 */

		List<ShowError> showErrorList = treeView_9StateService.getUpdatedErrorList();

		model.addAttribute("showError", showErrorList);
		System.out.print("showError:::Controller::::" + showErrorList);

		session.setAttribute("error", error_msg);
		System.out.println("Eroor --->>" + error_msg);
		session.setAttribute("jspRender", "CorrectingConfirmationTask9");

		return returnValue;
	}

	@RequestMapping(value = "/correctingconftask9test", method = RequestMethod.GET)
	public String correctingConfTask9_StateTest(Model model, HttpSession session) {
		String environment = (String) session.getAttribute("environment");
		EnvRegion e = envRegionCtrl.getEnvRegion(session);
		model.addAttribute("environment", environment);
				model.addAttribute("envregion", e);
		CorrectingConfTask9Main correctingConfTask9Main = new CorrectingConfTask9Main();

		if (CollectionUtils.isNotEmpty((List<NotesFupBindingData9States>) session.getAttribute("treeViewList_049"))) {
			System.out.println("list 049:: " + session.getAttribute("treeViewList_049"));
			correctingConfTask9Main.setNotesFupBindingData9States(
					(List<NotesFupBindingData12States>) session.getAttribute("treeViewList_049"));
		}

		if (CollectionUtils
				.isNotEmpty((List<CorrectingConfTask9_RecId_850>) session.getAttribute("treeViewList9_850"))) {
//			System.out.println("list 850:: " + session.getAttribute("treeViewList9_850"));
			correctingConfTask9Main.setCorrectingConfTask9_RecId_850(
					(List<CorrectingConfTask9_RecId_850>) session.getAttribute("treeViewList9_850"));
		}
		if (CollectionUtils
				.isNotEmpty((List<CorrectingConfTask9_RecId_851>) session.getAttribute("treeViewList9_851"))) {
			System.out.println("list 851:: " + session.getAttribute("treeViewList9_851"));
			correctingConfTask9Main.setCorrectingConfTask9_RecId_851(
					(List<CorrectingConfTask9_RecId_851>) session.getAttribute("treeViewList9_851"));
		}
		if (CollectionUtils
				.isNotEmpty((List<CorrectingConfTask9_RecId_852>) session.getAttribute("treeViewList9_852"))) {
//			System.out.println("list 852:: " + session.getAttribute("treeViewList9_852"));
			correctingConfTask9Main.setCorrectingConfTask9_RecId_852(
					(List<CorrectingConfTask9_RecId_852>) session.getAttribute("treeViewList9_852"));
		}

		if (CollectionUtils
				.isNotEmpty((List<Correcting_ConfirmationTask_RecId_858>) session.getAttribute("treeViewList_858"))) {
			System.out.println("list 858:: " + session.getAttribute("treeViewList_858"));
			correctingConfTask9Main.setCorrecting_ConfirmationTask_RecId_858(
					(List<Correcting_ConfirmationTask_RecId_858>) session.getAttribute("treeViewList_858"));
		}
		model.addAttribute("correctingConfTask9Main", correctingConfTask9Main);
		return "CorrectingConfirmationTask9";
	}

	@RequestMapping(value = "/correctconftask", method = RequestMethod.POST)
	public String correctingConfTask9(
			@ModelAttribute("correctingConfTask") CorrectingConfTaskNoProdMain correctingConfTask, ModelMap model,
			HttpSession session) {
		String environment = (String) session.getAttribute("environment");
		EnvRegion e = envRegionCtrl.getEnvRegion(session);
		model.addAttribute("environment", environment);
				model.addAttribute("envregion", e);
		System.out.println("correctingConfTask:::::111::::" + correctingConfTask);
		String activeUser = (String) session.getAttribute("activeUser");
		//String environment = (String) session.getAttribute("environment");
		String userId =envRegionCtrl.getUserIdFromSession( session);
		String objHandle = (String) session.getAttribute("objectHandle");
		String recIds = "";
		int objectHandle = 0;
		System.out.print("userId:::Controller::::" + userId);
		System.out.print("objHandle:::Controller::::" + objHandle);
		if (workloadCtrl.checkNullString(objHandle)) {
			objHandle = 1 + "";
			objectHandle = Integer.parseInt(objHandle);
			session.setAttribute("objectHandle", objectHandle);
		}

		String object_handle = WorkloadController.getObjectHandle(objectHandle);

		correctingConfTask.setNotesFupBindingData9States(
				(List<NotesFupBindingData12States>) session.getAttribute("treeViewList_049"));
		List<Correcting_ConfirmationTask_RecId_858> correctingList_858 = (correctingConfTask.getCorrecting_ConfirmationTask_RecId_858());
		
		
		List<Correcting_ConfirmationTask_RecId_858> conformationList_858_old = (List<Correcting_ConfirmationTask_RecId_858>) (session.getAttribute("treeViewList_858"));
		
		List<Correcting_ConfirmationTask_RecId_858> updatedList_858 = treeView_9StateService.getUpdatedRowsForCCTNP_858(correctingList_858, conformationList_858_old);
		
		if (updatedList_858.isEmpty()) {
			ReadErrorMsgsJson readErrorMsgsJson = new ReadErrorMsgsJson();
			String uon_msg = readErrorMsgsJson.getErrorMsg("LG0027");
		     String returnValue = "";
				returnValue = "redirect:/treeview9states";
		        session.setAttribute("update_msg", uon_msg);
				System.out.println("Eroor --->>" + uon_msg);
				session.setAttribute("jspRender", "correctionConfTaskNoProd9");
				return returnValue;
		} else {
		correctingConfTask = treeView_9StateService.writeSelectedRequestCorrectingConfNoProdData(correctingConfTask,
				userId, object_handle, session,updatedList_858);
		}

		String error_msg = " ";

		if (correctingConfTask.getHeader().getReturn_code() != null
				&& correctingConfTask.getHeader().getReturn_code().equals("000")) {
			// if(true) {
			error_msg = "Y";
			session.setAttribute("jspFlag", "conf_task");

		} else if (correctingConfTask.getHeader().getReturn_code() != null
				&& correctingConfTask.getHeader().getReturn_code().equals("999")) {
			error_msg = "N";
		} else if (correctingConfTask.getHeader().getReturn_code() != null
				&& correctingConfTask.getHeader().getReturn_code().equals("888")) {
			error_msg = "M";
		} else if (correctingConfTask.getHeader().getReturn_code() != null
				&& correctingConfTask.getHeader().getReturn_code().equals("889")) {
			error_msg = "U";
		}
		String returnValue = "";
		returnValue = "redirect:/treeview9states";

		/*
		 * String statesIdentity = (String) session.getAttribute("States"); String
		 * returnValue = ""; if (statesIdentity.equalsIgnoreCase("Y")) { returnValue =
		 * "redirect:/treeviewfinal"; } else { returnValue =
		 * "redirect:/treeview9states"; }
		 */
		List<ShowError> showErrorList = treeView_9StateService.getUpdatedErrorList();

		model.addAttribute("showError", showErrorList);
		System.out.print("showError:::Controller::::" + showErrorList);

		session.setAttribute("error", error_msg);
		System.out.println("Eroor --->>" + error_msg);
		session.setAttribute("jspRender", "correctionConfTaskNoProd9");
	//	session.removeAttribute("error");	
		return returnValue;
	}

	@RequestMapping(value = "/correctconftaskTest", method = RequestMethod.GET)
	public String correctingConfTask9Test(Model model, HttpSession session) {
		CorrectingConfTaskNoProdMain correctingConfTask = new CorrectingConfTaskNoProdMain();
		String environment = (String) session.getAttribute("environment");
		EnvRegion e = envRegionCtrl.getEnvRegion(session);
		model.addAttribute("environment", environment);
				model.addAttribute("envregion", e);
		if (CollectionUtils.isNotEmpty((List<NotesFupBindingData9States>) session.getAttribute("treeViewList_049"))) {
//			System.out.println("list 049:: " + session.getAttribute("treeViewList_049"));
			correctingConfTask.setNotesFupBindingData9States(
					(List<NotesFupBindingData12States>) session.getAttribute("treeViewList_049"));
		}

		if (CollectionUtils
				.isNotEmpty((List<Correcting_ConfirmationTask_RecId_856>) session.getAttribute("treeViewList_856"))) {
//			System.out.println("list 856:: " + session.getAttribute("treeViewList_856"));
			correctingConfTask.setCorrecting_ConfirmationTask_RecId_856(
					(List<Correcting_ConfirmationTask_RecId_856>) session.getAttribute("treeViewList_856"));
		}
		if (CollectionUtils
				.isNotEmpty((List<Correcting_ConfirmationTask_RecId_858>) session.getAttribute("treeViewList_858"))) {
//			System.out.println("list 858:: " + session.getAttribute("treeViewList_858"));
			correctingConfTask.setCorrecting_ConfirmationTask_RecId_858(
					(List<Correcting_ConfirmationTask_RecId_858>) session.getAttribute("treeViewList_858"));
		}
		model.addAttribute("correctingConfTask", correctingConfTask);
		return "correctionConfTaskNoProd9";
	}

//---------------------------------Saurabh 12 State code--------------------------------------------->

	@RequestMapping(value = "/correctconftask12", method = RequestMethod.POST)
	public String correctingConfTask12(
			@ModelAttribute("correctingConfTask") CorrectingConfTaskNoProdMain correctingConfTask, ModelMap model,
			HttpSession session) {
		String environment = (String) session.getAttribute("environment");
		EnvRegion e = envRegionCtrl.getEnvRegion(session);
		model.addAttribute("environment", environment);
				model.addAttribute("envregion", e);
		System.out.println("correctingConfTask:::::111::::" + correctingConfTask);
		String activeUser = (String) session.getAttribute("activeUser");
		//String environment = (String) session.getAttribute("environment");
		String userId =envRegionCtrl.getUserIdFromSession( session);
		String objHandle = (String) session.getAttribute("objectHandle");
		String recIds = "";
		int objectHandle = 0;
		System.out.print("userId:::Controller::::" + userId);
		System.out.print("objHandle:::Controller::::" + objHandle);
		if (workloadCtrl.checkNullString(objHandle)) {
			objHandle = 1 + "";
			objectHandle = Integer.parseInt(objHandle);
			session.setAttribute("objectHandle", objectHandle);
		}

		String object_handle = WorkloadController.getObjectHandle(objectHandle);

		correctingConfTask.setNotesFupBindingData9States(
				(List<NotesFupBindingData12States>) session.getAttribute("treeViewList_049"));
		/*
		 * correctingConfTask =
		 * treeView_12StateService.writeSelectedRequestCorrectingConfNoProdData12(
		 * correctingConfTask, userId, object_handle, session);
		 */
		//Added kiran start
        List<Correcting_ConfirmationTask_RecId_858> correctingList_858 = (correctingConfTask.getCorrecting_ConfirmationTask_RecId_858());
		
		List<Correcting_ConfirmationTask_RecId_858> conformationList_858_old = (List<Correcting_ConfirmationTask_RecId_858>) (session.getAttribute("treeViewList_858"));
		
		List<Correcting_ConfirmationTask_RecId_858> updatedList_858 = treeView_12StateService.getUpdatedRowsForCCTNP12_858(correctingList_858, conformationList_858_old);
        
				if (updatedList_858.isEmpty()) {
					ReadErrorMsgsJson readErrorMsgsJson = new ReadErrorMsgsJson();
					String uon_msg = readErrorMsgsJson.getErrorMsg("LG0027");
				     String returnValue = "";
						returnValue = "redirect:/treeViewDisplay";
				        session.setAttribute("update_msg", uon_msg);
						System.out.println("Eroor --->>" + uon_msg);
						session.setAttribute("jspRender", "CorrectionNoProd_LSOG6");
						return returnValue;
				} else {
							correctingConfTask = treeView_12StateService.writeSelectedRequestCorrectingConfNoProdData12(correctingConfTask,
									userId, object_handle, session,updatedList_858);
							
						}
						
			//Added kiran end

		String error_msg = " ";

				 if (correctingConfTask.getHeader().getReturn_code() != null &&
						 correctingConfTask.getHeader().getReturn_code().equals("000")) {
			error_msg = "Y";
			session.setAttribute("jspFlag", "conf_task");

		} else if (correctingConfTask.getHeader().getReturn_code() != null
				&& correctingConfTask.getHeader().getReturn_code().equals("999")) {
			error_msg = "N";
		} else if (correctingConfTask.getHeader().getReturn_code() != null
				&& correctingConfTask.getHeader().getReturn_code().equals("888")) {
			error_msg = "M";
		} else if (correctingConfTask.getHeader().getReturn_code() != null
				&& correctingConfTask.getHeader().getReturn_code().equals("889")) {
			error_msg = "U";
		}
		String returnValue = "";
		returnValue = "redirect:/treeViewDisplay";

		/*
		 * String statesIdentity = (String) session.getAttribute("States"); String
		 * returnValue = ""; if (statesIdentity.equalsIgnoreCase("Y")) { returnValue =
		 * "redirect:/treeviewfinal"; } else { returnValue =
		 * "redirect:/treeview9states"; }
		 */

		List<ShowError> showErrorList = treeView_9StateService.getUpdatedErrorList();

		model.addAttribute("showError", showErrorList);
		System.out.print("showError:::Controller::::" + showErrorList);

		session.setAttribute("error", error_msg);
		System.out.println("Eroor --->>" + error_msg);
		session.setAttribute("jspRender", "CorrectionNoProd_LSOG6");

		return returnValue;
	}

	@RequestMapping(value = "/correctconftaskTest12", method = RequestMethod.GET)
	public String correctingConfTask12Test(Model model, HttpSession session) {
		CorrectingConfTaskNoProdMain correctingConfTask = new CorrectingConfTaskNoProdMain();
		String environment = (String) session.getAttribute("environment");
		EnvRegion e = envRegionCtrl.getEnvRegion(session);
		model.addAttribute("environment", environment);
				model.addAttribute("envregion", e);
		if (CollectionUtils.isNotEmpty((List<NotesFupBindingData9States>) session.getAttribute("treeViewList_049"))) {
//			System.out.println("list 049:: " + session.getAttribute("treeViewList_049"));
			correctingConfTask.setNotesFupBindingData9States(
					(List<NotesFupBindingData12States>) session.getAttribute("treeViewList_049"));
		}

		if (CollectionUtils
				.isNotEmpty((List<Correcting_ConfirmationTask_RecId_856>) session.getAttribute("treeViewList_856"))) {
//			System.out.println("list 856:: " + session.getAttribute("treeViewList_856"));
			correctingConfTask.setCorrecting_ConfirmationTask_RecId_856(
					(List<Correcting_ConfirmationTask_RecId_856>) session.getAttribute("treeViewList_856"));
		}
		if (CollectionUtils
				.isNotEmpty((List<Correcting_ConfirmationTask_RecId_858>) session.getAttribute("treeViewList_858"))) {
//			System.out.println("list 858:: " + session.getAttribute("treeViewList_858"));
			correctingConfTask.setCorrecting_ConfirmationTask_RecId_858(
					(List<Correcting_ConfirmationTask_RecId_858>) session.getAttribute("treeViewList_858"));
		}
		model.addAttribute("correctingConfTask", correctingConfTask);
		return "CorrectionNoProd_LSOG6";
	}

	@RequestMapping(value = "/conftasknoprod12", method = RequestMethod.POST)
	public String confirmationTaskNoProd12(
			@ModelAttribute("confTaskNoProd9Main") ConfirmationTaskNoProd9Main confTaskNoProd9Main, ModelMap model,
			HttpSession session) {
		String environment = (String) session.getAttribute("environment");
		EnvRegion e = envRegionCtrl.getEnvRegion(session);
		model.addAttribute("environment", environment);
				model.addAttribute("envregion", e);
		System.out.println("correctingConfTask:::::111::::" + confTaskNoProd9Main);
		String activeUser = (String) session.getAttribute("activeUser");
		//String environment = (String) session.getAttribute("environment");
		String userId =envRegionCtrl.getUserIdFromSession( session);
		String objHandle = (String) session.getAttribute("objectHandle");
		String recIds = "";
		int objectHandle = 0;
		System.out.print("userId:::Controller::::" + userId);
		System.out.print("objHandle:::Controller::::" + objHandle);
		if (workloadCtrl.checkNullString(objHandle)) {
			objHandle = 1 + "";
			objectHandle = Integer.parseInt(objHandle);
			session.setAttribute("objectHandle", objectHandle);
		}

		String object_handle = WorkloadController.getObjectHandle(objectHandle);
		confTaskNoProd9Main.setNotesFupBindingData9States(
				(List<NotesFupBindingData12States>) session.getAttribute("treeViewList_049"));
		// confTaskNoProd9Main = treeView_12StateService.writeSelectedRequestConfTaskNoProd12MainData(confTaskNoProd9Main, userId, object_handle, session);
		//Added kiran start
		List<ConfirmationTask_RecId_558> oldList_558 = (List<ConfirmationTask_RecId_558>) (session.getAttribute("treeViewList_558"));
		List<ConfirmationTask_RecId_558> updatedOrderNumberList = selectRequestService.getUpdatedRows12(confTaskNoProd9Main.getConfirmationTask_RecId_558(), oldList_558);

//		if (updatedOrderNumberList.isEmpty()) {
//			ReadErrorMsgsJson readErrorMsgsJson = new ReadErrorMsgsJson();
//			String uon_msg = readErrorMsgsJson.getErrorMsg("LG0027");
//		     String returnValue = "";
//				returnValue = "redirect:/treeViewDisplay";
//		        session.setAttribute("update_msg", uon_msg);
//				System.out.println("Eroor --->>" + uon_msg);
//				session.setAttribute("jspRender", "ConfirmTaskNoProd_12states");
//				return returnValue;
//		} else {
					confTaskNoProd9Main = treeView_12StateService.writeSelectedRequestConfTaskNoProd12MainData(confTaskNoProd9Main,
							userId, object_handle, session,updatedOrderNumberList);
//				}
				
//Added kiran end

		String error_msg = " ";
		 if (confTaskNoProd9Main.getHeader().getReturn_code() != null &&
		 confTaskNoProd9Main.getHeader().getReturn_code().equals("000")) {

			error_msg = "Y";
			session.setAttribute("jspFlag", "conf_task");

		} else if (confTaskNoProd9Main.getHeader().getReturn_code() != null
				&& confTaskNoProd9Main.getHeader().getReturn_code().equals("999")) {
			error_msg = "N";
		} else if (confTaskNoProd9Main.getHeader().getReturn_code() != null
				&& confTaskNoProd9Main.getHeader().getReturn_code().equals("888")) {
			error_msg = "M";
		} else if (confTaskNoProd9Main.getHeader().getReturn_code() != null
				&& confTaskNoProd9Main.getHeader().getReturn_code().equals("889")) {
			error_msg = "U";
		}
		String returnValue = "";
		returnValue = "redirect:/treeViewDisplay";

		List<ShowError> showErrorList = treeView_12StateService.getErrorList();

		model.addAttribute("showError", showErrorList);
		System.out.print("showError:::Controller::::" + showErrorList);

		session.setAttribute("error", error_msg);
		System.out.println("Eroor --->>" + error_msg);
		session.setAttribute("jspRender", "ConfirmTaskNoProd_12states");

		return returnValue;
	}
	@RequestMapping(value = "/conftasknoprodTest12", method = RequestMethod.GET)
	public String confTaskNoProd12Test(Model model, HttpSession session) {
		ConfirmationTaskNoProd9Main confTaskNoProd9Main = new ConfirmationTaskNoProd9Main();
		String environment = (String) session.getAttribute("environment");
		EnvRegion e = envRegionCtrl.getEnvRegion(session);
		model.addAttribute("environment", environment);
				model.addAttribute("envregion", e);
		if (CollectionUtils.isNotEmpty((List<NotesFupBindingData9States>) session.getAttribute("treeViewList_049"))) {
//			System.out.println("list 049:: " + session.getAttribute("treeViewList_049"));
			confTaskNoProd9Main.setNotesFupBindingData9States(
					(List<NotesFupBindingData12States>) session.getAttribute("treeViewList_049"));
		}

		if (CollectionUtils
				.isNotEmpty((List<ConfirmationTaskNoProd_RecId_556>) session.getAttribute("treeViewList_556"))) {
//			System.out.println("list 556:: " + session.getAttribute("treeViewList_556"));
			confTaskNoProd9Main.setConfirmationTaskNoProd_RecId_556(
					(List<ConfirmationTaskNoProd_RecId_556>) session.getAttribute("treeViewList_556"));
		}
		if (CollectionUtils.isNotEmpty((List<NotesFupBindingData12States>) session.getAttribute("treeViewList_558"))) {
//			System.out.println("list 558:: " + session.getAttribute("treeViewList_558"));
			confTaskNoProd9Main.setConfirmationTask_RecId_558(
					(List<ConfirmationTask_RecId_558>) session.getAttribute("treeViewList_558"));
		}
		model.addAttribute("confTaskNoProd9Main", confTaskNoProd9Main);
		return "ConfirmTaskNoProd_12states";
	}

	// ***********************************Saurabh Sprint 11 code
	// end*****************************

	// Anjali Start
	@RequestMapping(value = "/completaionGTaskTest", method = RequestMethod.GET)
	public String correctionTaskNoProd12Test(Model model, HttpSession session) {
		List<CompletionProviderTask> list_560 = (List<CompletionProviderTask>) (session
				.getAttribute("treeViewList560"));
		String environment = (String) session.getAttribute("environment");
		EnvRegion e = envRegionCtrl.getEnvRegion(session);
		model.addAttribute("environment", environment);
				model.addAttribute("envregion", e);
		List<CompletionActivityRLSOG6LscInfo> list_568 = (List<CompletionActivityRLSOG6LscInfo>) (session
				.getAttribute("treeViewList568"));

		CompletionMainTask completionMainTask = new CompletionMainTask();
		if (CollectionUtils.isNotEmpty(list_560)) {
//			System.out.println("list_858 size:: " + list_560);
			completionMainTask.setCompletionTask_RecID_560(list_560);
		}
		if (CollectionUtils.isNotEmpty(list_568)) {
//			System.out.println("list_856 size:: " + list_568);
			completionMainTask.setCompletionTask_RecID_568(list_568);
		}

		if (CollectionUtils.isNotEmpty((List<NotesFupBindingData12States>) session.getAttribute("treeViewList_049"))) {
//			System.out.println("list 049:: " + session.getAttribute("treeViewList_049"));
			completionMainTask.setNotesFupBindingData12States(
					(List<NotesFupBindingData12States>) session.getAttribute("treeViewList_049"));
		}
		if (CollectionUtils.isNotEmpty((List<CompletionProviderTask>) session.getAttribute("treeViewList560"))) {
//			System.out.println("list 0560:: " + session.getAttribute("treeViewList560"));
			completionMainTask.setCompletionTask_RecID_560(
					(List<CompletionProviderTask>) session.getAttribute("treeViewList560"));
		}
		if (CollectionUtils
				.isNotEmpty((List<CompletionActivityRLSOG6LscInfo>) session.getAttribute("treeViewList568"))) {
//			System.out.println("list 568:: " + session.getAttribute("treeViewList568"));
			completionMainTask.setCompletionTask_RecID_568(
					(List<CompletionActivityRLSOG6LscInfo>) session.getAttribute("treeViewList568"));
		}

		session.setAttribute("jspRendercompletion", "C");

		model.addAttribute("completionMainTask", completionMainTask);
		return "CompletionProviderTask12states";
	}

	@RequestMapping(value = "/completaionG", method = RequestMethod.POST)
	public String completionTask12(@ModelAttribute("completionMainTask") CompletionMainTask completionMainTask,
			ModelMap model, HttpSession session) {
		String environment = (String) session.getAttribute("environment");
		EnvRegion e = envRegionCtrl.getEnvRegion(session);
		model.addAttribute("environment", environment);
				model.addAttribute("envregion", e);
				session.removeAttribute("jspFlag");
		// System.out.println("CompletionMainTask:::::111::::"+completionMainTask);
		String activeUser = (String) session.getAttribute("activeUser");
		//String environment = (String) session.getAttribute("environment");
		String userId = envRegionCtrl.getUserIdFromSession( session);
		String objHandle = (String) session.getAttribute("objectHandle");
		String recIds = "";
		int objectHandle = 0;
		System.out.print("Inside Post method ::Controller::::" + userId);
		System.out.print("objHandle:::Controller::::" + objHandle);
		if (workloadCtrl.checkNullString(objHandle)) {
			objHandle = 1 + "";
			objectHandle = Integer.parseInt(objHandle);
			session.setAttribute("objectHandle", objectHandle);
		}
		String object_handle = WorkloadController.getObjectHandle(objectHandle);

		completionMainTask.setNotesFupBindingData12States(
				(List<NotesFupBindingData12States>) session.getAttribute("treeViewList_049"));
		//Rashmita's changes start
		//System.out.println(session.getAttribute("treeViewList568"));
		List<CompletionActivityRLSOG6LscInfo> oldList_568 = (List<CompletionActivityRLSOG6LscInfo>) (session
				.getAttribute("treeViewList568"));
		//System.out.println("newList" + completionMainTask.getCompletionTask_RecID_568());
		//System.out.println("oldList_568" + oldList_568);

		List<CompletionActivityRLSOG6LscInfo> updatedOrderNumberList = treeView_12StateService
				.getUpdatedRows(completionMainTask.getCompletionTask_RecID_568(), oldList_568);
		//System.out.println("updatedOrderNumberList" + updatedOrderNumberList);
		//Hrushikesh- 20/04/2022 
		completionMainTask = treeView_12StateService.writeSelectedRequestConformationDataMethod(completionMainTask,
				userId, object_handle, session, updatedOrderNumberList);

		String error_msg = " ";
		//Hrushikesh- 20/04/2022
		Header header = completionMainTask.getHeader() == null ? new Header() : completionMainTask.getHeader();
		if (header.getReturn_code() != null && header.getReturn_code().equals("000")) {
			error_msg = "Y";
		} else if (header.getReturn_code() != null && header.getReturn_code().equals("999")) {
			error_msg = "N";
		} else if (header.getReturn_code() != null && header.getReturn_code().equals("888")) {
			error_msg = "M";
		} else if (header.getReturn_code() != null && header.getReturn_code().equals("889")) {
			error_msg = "U";
		}
		String returnValue = "";
		returnValue = "redirect:/treeViewDisplay";

		List<ShowError> showError = treeView_12StateService.getUpdatedErrorList();

		System.err.print("RC: "+header.getReturn_code() +"showError:" + showError);

		session.setAttribute("error", error_msg);
		session.setAttribute("jspRender", "completiontaskbg");
		model.addAttribute("showError", showError);

		return returnValue;

	}

	@RequestMapping(value = "/completaionG9", method = RequestMethod.POST)
	public String completionTask9State(@ModelAttribute("completionMainTask9") CompletionMainTask completionMainTask9,
			ModelMap model, HttpSession session) {
		// System.out.println("CompletionMainTask:::::111::::"+completionMainTask);
		String activeUser = (String) session.getAttribute("activeUser");
		//String environment = (String) session.getAttribute("environment");
		String environment = (String) session.getAttribute("environment");
		EnvRegion e = envRegionCtrl.getEnvRegion(session);
		model.addAttribute("environment", environment);
				model.addAttribute("envregion", e);
				session.removeAttribute("jspFlag");
		String userId = envRegionCtrl.getUserIdFromSession( session);
		String objHandle = (String) session.getAttribute("objectHandle");
		String recIds = "";
		int objectHandle = 0;
		System.out.print("Inside Post method ::Controller::::" + userId);
		System.out.print("objHandle:::Controller::::" + objHandle);
		if (workloadCtrl.checkNullString(objHandle)) {
			objHandle = 1 + "";
			objectHandle = Integer.parseInt(objHandle);
			session.setAttribute("objectHandle", objectHandle);
		}
		String object_handle = WorkloadController.getObjectHandle(objectHandle);

		completionMainTask9.setNotesFupBindingData12States(
				(List<NotesFupBindingData12States>) session.getAttribute("treeViewList_049"));

		completionMainTask9 = treeView_9StateService.writeSelectedRequestConformationDataMethod9(completionMainTask9,
				userId, object_handle, session);

		String error_msg = " ";
		Header header = completionMainTask9.getHeader() == null ? new Header() : completionMainTask9.getHeader();
		if (header.getReturn_code() != null && header.getReturn_code().equals("000")) {
			error_msg = "Y";
		} else if (header.getReturn_code() != null && header.getReturn_code().equals("999")) {
			error_msg = "N";
		} else if (header.getReturn_code() != null && header.getReturn_code().equals("888")) {
			error_msg = "M";
		} else if (header.getReturn_code() != null && header.getReturn_code().equals("889")) {
			error_msg = "U";
		}
		String returnValue = "";
		returnValue = "redirect:/treeview9states";

		List<ShowError> showError = treeView_12StateService.getUpdatedErrorList();

		System.err.print("RC: "+header.getReturn_code() +"showError:" + showError);

		session.setAttribute("error", error_msg);
		session.setAttribute("jspRender", "completiontaskbg9");
		model.addAttribute("showError", showError);

		return returnValue;

	}

/// End code by Anjali

	// ********************************************yash*********************
	@RequestMapping(value = "/follow_Up12", method = RequestMethod.POST)
	public String addFollowUpData(FollowUpData followUpData, ModelMap model, HttpSession session) {
		String environment = (String) session.getAttribute("environment");
		EnvRegion e = envRegionCtrl.getEnvRegion(session);
		model.addAttribute("environment", environment);
				model.addAttribute("envregion", e);
		System.out.println("******************************" + followUpData.toString());
		// session.setAttribute("followUpData", followUpData.getNotes());
		// ArrayList<FollowUpData> listRecords
		// =(ArrayList<FollowUpData>)session.getAttribute("treeViewList_531");
		// System.out.println(listRecords.get(0));
		ArrayList<FollowUpTableRow> listRecords1 = (ArrayList<FollowUpTableRow>) session
				.getAttribute("treeViewList_532");
		// System.out.println(listRecords1.get(0));
		session.removeAttribute("jspFlag");
		String user_id = envRegionCtrl.getUserIdFromSession( session);

		if (followUpData.getNotes() == null || followUpData.getNotes() == "" && followUpData.getWorked_ind() == null
				&& followUpData.getCancel_ind() == null) {
			String error = "Enter Notes";
			String error1 = "Enter Date";
			model.addAttribute("Field1", error);
			model.addAttribute("Field2", error1);
		} else {
			followUpService.writeCloseTransactionDataToMQ(followUpData, listRecords1, user_id, session);
		}
		return "redirect:/treeViewDisplay";

	}
	// end code

	
	// *********************************** pre issue *********************
	
	
	@ResponseBody
	@RequestMapping(value = "/preIssue", method = RequestMethod.POST)
	public String addFollowUpData1(Model model,HttpSession session) {
		String environment = (String) session.getAttribute("environment");
		EnvRegion e = envRegionCtrl.getEnvRegion(session);
		model.addAttribute("environment", environment);
				model.addAttribute("envregion", e);
				session.removeAttribute("jspFlag");
		System.out.println("pre issue called ");
		String userId = envRegionCtrl.getUserIdFromSession(session);
		String returncode=	preIssueService.writePreIssueDataToMQ(userId, session);		
		/*
		 * String returncode = (String) session.getAttribute("returncode") ; String
		 * errorcode ="Update Successful"; String errorcode1 ="Update not Successful";
		 * if(returncode.equals("000")){
		 * 
		 * System.out.println("inside if"); model.addAttribute("errorcode", errorcode )
		 * ;}
		 * 
		 * else { model.addAttribute("errorcode", errorcode1 ) ; }
		 * 
		 * //session.removeAttribute("treeViewList_preissue"); //
		 * session.removeAttribute("treeViewList_preissue1");
		 * //session.removeAttribute("returncode"); System.out.println(returncode);
		 */
		String returnValue = "";
		returnValue = "redirect:/treeview9states";
		return returncode;
		}
	
	
	///////////////////////////just go//////////////////////
	@ResponseBody
	@RequestMapping(value = "/justGo", method = RequestMethod.POST)
	public String justGo(Model model,HttpSession session) {
		String environment = (String) session.getAttribute("environment");
		EnvRegion e = envRegionCtrl.getEnvRegion(session);
		model.addAttribute("environment", environment);
				model.addAttribute("envregion", e);
				session.removeAttribute("jspFlag");
		System.out.println("Just Go called ");
		String userId = envRegionCtrl.getUserIdFromSession(session);
		String returncode=	preIssueService.writeJustGoDataToMQ(userId, session);	
		/*
		 * String returncode = (String) session.getAttribute("returncode1") ; String
		 * errorcode ="Update Successful"; String errorcode1 ="Update not Successful";
		 * 
		 * for(int i = 0; returncode ==null;i++) { returncode = (String)
		 * session.getAttribute("returncode1") ; System.out.println(i); } if(
		 * returncode.equals("999")) { System.out.println("inside iff");
		 * model.addAttribute("errorcode", errorcode1); } else {
		 * System.out.println("inside elseeeee"); model.addAttribute("errorcode",
		 * errorcode); }
		 */
		 
		String returnValue = "";
		returnValue = "redirect:/treeview9states";
		return returncode;
		
             // model.addAttribute("indicator1",false)	;
			//session.removeAttribute("treeViewList_preissue");
		//	session.removeAttribute("treeViewList_preissue1");
		
		//System.out.println(returncode);
	
		/*
		 * returnValue = "redirect:/treeview9states"; return returnValue;
		 */
		}
	
	
	
	//////////////resend////////////////
	
	@ResponseBody 
	@RequestMapping(value = "/resend", method = RequestMethod.POST) 
	public String resend(Model model,HttpSession session) { 
		String environment = (String) session.getAttribute("environment");
		EnvRegion e = envRegionCtrl.getEnvRegion(session);
		model.addAttribute("environment", environment);
				model.addAttribute("envregion", e);
		System.out.println("pre issue called "); 
		String userId = envRegionCtrl.getUserIdFromSession(session); 
	String returncode=	preIssueService.writeResendDataToMQ(userId, session); 
	session.removeAttribute("jspFlag");
		/* 
		 * for(int i = 0; returncode ==null;i++) { returncode = (String) 
		 * session.getAttribute("returncode1") ; System.out.println(i); } if( 
		 * returncode.equals("999")) { System.out.println("inside iff"); 
		 * model.addAttribute("errorcode", errorcode1); } else { 
		 * System.out.println("inside elseeeee"); model.addAttribute("errorcode", 
		 * errorcode); } 
		 */ 
 
		String returnValue = ""; 
		returnValue = "redirect:/treeview9states"; 
		return returncode; 
 
             // model.addAttribute("indicator1",false)	; 
			//session.removeAttribute("treeViewList_preissue"); 
		//	session.removeAttribute("treeViewList_preissue1"); 
 
		//System.out.println(returncode); 
 
		/* 
		 * returnValue = "redirect:/treeview9states"; return returnValue; 
		 */ 
		}
	
	////////////////////////////////////resubmit//////////////////
	@ResponseBody
	@RequestMapping(value = "/resubmit", method = RequestMethod.POST)
	public String resubmit(Model model,HttpSession session) throws IOException {
		String environment = (String) session.getAttribute("environment");
		EnvRegion e = envRegionCtrl.getEnvRegion(session);
		model.addAttribute("environment", environment);
				model.addAttribute("envregion", e);
		System.out.println("resubmit called ");
		String userId = envRegionCtrl.getUserIdFromSession(session);
		String returncode=	preIssueService.writeResubmitDataToMQ(userId, session);
		
		session.removeAttribute("jspFlag");
		String returnValue = "";
		returnValue = "redirect:/treeview9states";
		return returncode;}
	
	
	
	
	
	
	
	// ============================Sneha
	// start=======================================

	@RequestMapping(value = "/GetPostToBillTask", method = RequestMethod.GET)
	public String PostToBillTask9Sates(Model model, HttpSession session) {
		String environment = (String) session.getAttribute("environment");
		EnvRegion e = envRegionCtrl.getEnvRegion(session);
		model.addAttribute("environment", environment);
				model.addAttribute("envregion", e);
		List<PostToBillTask_RecId585> list_585 = (List<PostToBillTask_RecId585>) (session
				.getAttribute("treeViewList_585"));
		List<PostToBillTaskLSCInfo_588> list_588 = (List<PostToBillTaskLSCInfo_588>) (session
				.getAttribute("treeViewList_588"));

		ConformationTaskMain conformationTaskMain = new ConformationTaskMain();

		if (CollectionUtils.isNotEmpty(list_585)) {
//			System.out.println("list_585 size:: " + list_585);
			conformationTaskMain.setPostToBillTask_RecId585(list_585);
		}
		if (CollectionUtils.isNotEmpty(list_588)) {
//			System.out.println("list_588 size:: " + list_588);
			conformationTaskMain.setPostToBillTaskLSCInfo_588(list_588);
		}
		if (CollectionUtils.isNotEmpty((List<NotesFupBindingData9States>) session.getAttribute("treeViewList_049"))) {
//			System.out.println("list 049:: " + session.getAttribute("treeViewList_049"));
			conformationTaskMain.setNotesFupBindingData9States(
					(List<NotesFupBindingData9States>) session.getAttribute("treeViewList_049"));
		}
		model.addAttribute("conformationTaskMain", conformationTaskMain);
		String statesIdentity = (String) session.getAttribute("States");
		String returnValue = "";

		returnValue = "postToBill_task9";

//		System.out.println("model.getAttribute(\"treeViewList_585\")" + model.getAttribute("treeViewList_585"));

		return returnValue;
	}

	@RequestMapping(value = "/PostToBillTask9", method = RequestMethod.POST)
	public String writeSelectedPostToBill_Task(
			@ModelAttribute("conformationTaskMain") ConformationTaskMain conformationTaskMain, ModelMap model,
			HttpSession session) {
		String environment = (String) session.getAttribute("environment");
		EnvRegion e = envRegionCtrl.getEnvRegion(session);
		model.addAttribute("environment", environment);
				model.addAttribute("envregion", e);
		String activeUser = (String) session.getAttribute("activeUser");
		//String environment = (String) session.getAttribute("environment");
		String userId = envRegionCtrl.getUserIdFromSession( session);
		session.removeAttribute("jspFlag");
		String objHandle = (String) session.getAttribute("objectHandle");
		String recIds = "";
		int objectHandle = 0;
		System.out.print("userId:::Controller::::" + userId);
		System.out.print("objHandle:::Controller::::" + objHandle);
		if (workloadCtrl.checkNullString(objHandle)) {
			objHandle = 1 + "";
			objectHandle = Integer.parseInt(objHandle);
			session.setAttribute("objectHandle", objectHandle);
		}
		String object_handle = WorkloadController.getObjectHandle(objectHandle);
		conformationTaskMain.setNotesFupBindingData9States(
				(List<NotesFupBindingData9States>) session.getAttribute("treeViewList_049"));
//		System.out.println("111::Sneha" + conformationTaskMain);
		treeView_9StateService.writeSelectedRequestPostToBill(conformationTaskMain, userId, object_handle, session);
		String error_msg = " ";

		// completionselectOkPopup(model,session);

		if (conformationTaskMain.getHeader().getReturn_code() != null
				&& conformationTaskMain.getHeader().getReturn_code().equals("000")) {

			error_msg = "Y";
			// Sneha done changes on 02_Nov
			session.setAttribute("jspFlag","postToBillTask9");

		} else if (conformationTaskMain.getHeader().getReturn_code() != null
				&& conformationTaskMain.getHeader().getReturn_code().equals("999")) {
			error_msg = "N";
		} else if (conformationTaskMain.getHeader().getReturn_code() != null
				&& conformationTaskMain.getHeader().getReturn_code().equals("888")) {
			error_msg = "M";
		} else if (conformationTaskMain.getHeader().getReturn_code() != null
				&& conformationTaskMain.getHeader().getReturn_code().equals("889")) {
			error_msg = "U";
		}
		String returnValue = "";
		returnValue = "redirect:/treeview9states";

		/*
		 * String statesIdentity = (String) session.getAttribute("States"); String
		 * returnValue = ""; if (statesIdentity.equalsIgnoreCase("Y")) { returnValue =
		 * "redirect:/treeviewfinal"; } else { returnValue =
		 * "redirect:/treeview9states"; }
		 */

		List<ShowError> showErrorList = treeView_9StateService.getUpdatedErrorList();

		model.addAttribute("showError", showErrorList);
		System.out.print("showError:::Controller::::" + showErrorList);

		session.setAttribute("error", error_msg);
		System.out.println("Eroor --->>" + error_msg);
		session.setAttribute("jspRender", "PostToBillTask");

		return returnValue;

	}

	@RequestMapping(value = "/GetPostToBillTask12", method = RequestMethod.GET)
	public String PostToBillTask12Sates(Model model, HttpSession session) {
		String environment = (String) session.getAttribute("environment");
		EnvRegion e = envRegionCtrl.getEnvRegion(session);
		model.addAttribute("environment", environment);
				model.addAttribute("envregion", e);
		List<PostToBillTask_RecId585> list_585 = (List<PostToBillTask_RecId585>) (session
				.getAttribute("treeViewList_585"));
		List<PostToBillTaskLSCInfo_588> list_588 = (List<PostToBillTaskLSCInfo_588>) (session
				.getAttribute("treeViewList_588"));

		ConformationTaskMain conformationTaskMain = new ConformationTaskMain();

		if (CollectionUtils.isNotEmpty(list_585)) {
//			System.out.println("list_585 size:: " + list_585);
			conformationTaskMain.setPostToBillTask_RecId585(list_585);
		}
		if (CollectionUtils.isNotEmpty(list_588)) {
//			System.out.println("list_588 size:: " + list_588);
			conformationTaskMain.setPostToBillTaskLSCInfo_588(list_588);
		}
		if (CollectionUtils.isNotEmpty((List<NotesFupBindingData9States>) session.getAttribute("treeViewList_049"))) {
//			System.out.println("list 049:: " + session.getAttribute("treeViewList_049"));
			conformationTaskMain.setNotesFupBindingData12States(
					(List<NotesFupBindingData12States>) session.getAttribute("treeViewList_049"));
		}
		model.addAttribute("conformationTaskMain", conformationTaskMain);
		String statesIdentity = (String) session.getAttribute("States");
		String returnValue = "";

		returnValue = "postToBill_task";

		System.out.println("model.getAttribute(\"treeViewList_585\")" + model.getAttribute("treeViewList_585"));

		return returnValue;
	}

	@RequestMapping(value = "/PostToBillTask12_Post", method = RequestMethod.POST)
	public String writeSelectedPostToBill12_Task(
			@ModelAttribute("conformationTaskMain") ConformationTaskMain conformationTaskMain, ModelMap model,
			HttpSession session) {
		String environment = (String) session.getAttribute("environment");
		EnvRegion e = envRegionCtrl.getEnvRegion(session);
		model.addAttribute("environment", environment);
				model.addAttribute("envregion", e);
		String activeUser = (String) session.getAttribute("activeUser");
		//String environment = (String) session.getAttribute("environment");
		String userId = envRegionCtrl.getUserIdFromSession( session);
		String objHandle = (String) session.getAttribute("objectHandle");
		session.removeAttribute("jspFlag");
		String recIds = "";
		int objectHandle = 0;
		System.out.print("userId:::Controller::::" + userId);
		System.out.print("objHandle:::Controller::::" + objHandle);
		if (workloadCtrl.checkNullString(objHandle)) {
			objHandle = 1 + "";
			objectHandle = Integer.parseInt(objHandle);
			session.setAttribute("objectHandle", objectHandle);
		}
		String object_handle = WorkloadController.getObjectHandle(objectHandle);
		conformationTaskMain.setNotesFupBindingData12States(
				(List<NotesFupBindingData12States>) session.getAttribute("treeViewList_049"));
//		System.out.println("111::Sneha" + conformationTaskMain);
		treeView_12StateService.writeSelectedRequestPostToBill(conformationTaskMain, userId, object_handle, session);
		String error_msg = " ";

		// completionselectOkPopup(model,session);

		if (conformationTaskMain.getHeader().getReturn_code() != null
				&& conformationTaskMain.getHeader().getReturn_code().equals("000")) {

			error_msg = "Y";
			//Sneha changes done on 02_Nov 
			session.setAttribute("jspFlag","postToBillTask");

		} else if (conformationTaskMain.getHeader().getReturn_code() != null
				&& conformationTaskMain.getHeader().getReturn_code().equals("999")) {
			error_msg = "N";
		} else if (conformationTaskMain.getHeader().getReturn_code() != null
				&& conformationTaskMain.getHeader().getReturn_code().equals("888")) {
			error_msg = "M";
		} else if (conformationTaskMain.getHeader().getReturn_code() != null
				&& conformationTaskMain.getHeader().getReturn_code().equals("889")) {
			error_msg = "U";
		}
		String returnValue = "";
		returnValue = "redirect:/treeViewDisplay";

		/*
		 * String statesIdentity = (String) session.getAttribute("States"); String
		 * returnValue = ""; if (statesIdentity.equalsIgnoreCase("Y")) { returnValue =
		 * "redirect:/treeviewfinal"; } else { returnValue =
		 * "redirect:/treeview9states"; }
		 */

		List<ShowError> showErrorList = treeView_12StateService.getUpdatedErrorList();

		model.addAttribute("showError", showErrorList);
		System.out.print("showError:::Controller::::" + showErrorList);

		session.setAttribute("error", error_msg);
		System.out.println("Eroor --->>" + error_msg);
		session.setAttribute("jspRender", "PostToBillTask12");

		return returnValue;

	}
	// ============================Sneha End=======================================

	// *********Supriya******************
	@RequestMapping(value = "/jeopardyTask9", method = RequestMethod.GET)
	public String jeopardyTask9Test(ModelMap model, HttpSession session) {
		String environment = (String) session.getAttribute("environment");
		EnvRegion e = envRegionCtrl.getEnvRegion(session);
		model.addAttribute("environment", environment);
				model.addAttribute("envregion", e);
		List<JeopardyTask12STRechId581> list_581 = (List<JeopardyTask12STRechId581>) (session
				.getAttribute("treeViewList_581"));
		List<JeopardyTask12STRechId582> list_582 = (List<JeopardyTask12STRechId582>) (session
				.getAttribute("treeViewList_582"));

		List<JeopardyListRechId014> list_014 = (List<JeopardyListRechId014>) (session.getAttribute("JeopardyListRows"));


		JeopardyMain12State jeopardyMain12State = new JeopardyMain12State();
		if (CollectionUtils.isNotEmpty(list_581)) {
			
			jeopardyMain12State.setJeopardyTask12STRechId581(list_581);

		}
		if (CollectionUtils.isNotEmpty(list_014)) {
			
			jeopardyMain12State.setJeopardyListRows(list_014);

		}

		model.addAttribute("jeopardyMain12State", jeopardyMain12State);

		model.addAttribute("jeopardyTask12STRechId581", list_581);

		return "JeopardyTask9";
	}

	@RequestMapping(value = "/jeopardyTask9", method = RequestMethod.POST)
	public String processJeopardyTask9Data(@RequestBody String input, ModelMap model, HttpSession session,
			JeopardyTask jeopardyTask) {
		String environment = (String) session.getAttribute("environment");
		EnvRegion e = envRegionCtrl.getEnvRegion(session);
		model.addAttribute("environment", environment);
				model.addAttribute("envregion", e);
		List<JeopardyListRechId014> list_014 = (List<JeopardyListRechId014>) (session.getAttribute("JeopardyListRows"));

		JeopardyMain12State jeopardyMain12State = new JeopardyMain12State();

		//EnvRegion e = envRegionCtrl.getEnvRegion(session);
		String activeUser = (String) session.getAttribute("activeUser");
		//String environment = (String) session.getAttribute("environment");
		session.removeAttribute("jspFlag");
		String userId = envRegionCtrl.getUserIdFromSession( session);
		String objHandle = (String) session.getAttribute("objectHandle");
		int objectHandle = 0;
		if (workloadCtrl.checkNullString(objHandle)) {
			objHandle = 1 + "";
			objectHandle = Integer.parseInt(objHandle);
			session.setAttribute("objectHandle", objectHandle);
		}
		String object_handle = WorkloadController.getObjectHandle(objectHandle);

		FollowUpData9States followUpData9States = new FollowUpData9States();
		jeopardyMain12State= jeopardyTaskService.writeToMQ9State(jeopardyTask, userId, object_handle, session, followUpData9States);
		
		String error_msg="";
		if (jeopardyMain12State.getHeader().getReturn_code() != null
				&& jeopardyMain12State.getHeader().getReturn_code().equals("000")) {

			System.out.print("userId:::error_msg::::" + userId);
			error_msg = "Y";

		} else if (jeopardyMain12State.getHeader().getReturn_code() != null
				&& jeopardyMain12State.getHeader().getReturn_code().equals("999")) {
			error_msg = "N";
		} else if (jeopardyMain12State.getHeader().getReturn_code() != null
				&& jeopardyMain12State.getHeader().getReturn_code().equals("888")) {
			error_msg = "M";
		} else if (jeopardyMain12State.getHeader().getReturn_code() != null
				&& jeopardyMain12State.getHeader().getReturn_code().equals("889")) {
			error_msg = "U";
		}

		session.setAttribute("error", error_msg);
		
		session.setAttribute("jspRender", "jeopardyTask9State");
		model.addAttribute("activeUser", activeUser);
		//code change start Supriya- Date 9 nov code fix for Read only Jeopardy
				String Lsr_number = (String) session.getAttribute("Lrs_No");
				// System.out.println("Lsr_number:::1::::::::"+Lsr_number);

				CloseTransaction closetransaction = new CloseTransaction();
				//String userId =envRegionCtrl.getUserIdFromSession( session);
//				System.out.println(userId);

				closetransaction.setLsr_number(Lsr_number.substring(0, 14));
				closetransaction.setNext(Lsr_number.substring(15, 17));

				closetransaction.setUser_id(userId);

				closeTransactionService.writeCloseTransactionDataToMQ(closetransaction, userId,session);
			//code change start Supriya- Date 9 nov code fix for Read only Jeopardy	
		
		refreshSamePage9States(model, session);

		return "redirect:/treeview9states";
	}
	
	@RequestMapping(value = "/jeopardyTask12", method = RequestMethod.GET)
	public String jeopardyTask12Test(ModelMap model, HttpSession session) {
		String environment = (String) session.getAttribute("environment");
		EnvRegion e = envRegionCtrl.getEnvRegion(session);
		model.addAttribute("environment", environment);
				model.addAttribute("envregion", e);
		List<JeopardyTask12STRechId581> list_581 = (List<JeopardyTask12STRechId581>) (session
				.getAttribute("treeViewList_581"));
		List<JeopardyTask12STRechId582> list_582 = (List<JeopardyTask12STRechId582>) (session
				.getAttribute("treeViewList_582"));

		List<JeopardyListRechId014> list_014 = (List<JeopardyListRechId014>) (session.getAttribute("JeopardyListRows"));
		List<JeopardyListRechId019> list_019 = (List<JeopardyListRechId019>) (session.getAttribute("JeopardyListRows019"));
		JeopardyMain12State jeopardyMain12State = new JeopardyMain12State();
		if (CollectionUtils.isNotEmpty(list_581)) {
			//System.out.println("list_581 :: " + list_581);
			jeopardyMain12State.setJeopardyTask12STRechId581(list_581);

		}
		if (CollectionUtils.isNotEmpty(list_014)) {
			//System.out.println("list_014 :: " + list_014);
			jeopardyMain12State.setJeopardyListRows(list_014);

		}

		model.addAttribute("jeopardyMain12State", jeopardyMain12State);
		model.addAttribute("jeopardyTask12STRechId581", list_581);

		return "JeopardyTask12";
	}

	@RequestMapping(value = "/jeopardyTask12", method = RequestMethod.POST)
	public String processJeopardyTaskData(@RequestBody String input, ModelMap model, HttpSession session,
			JeopardyTask jeopardyTask) {

		
		List<JeopardyListRechId014> list_014 = (List<JeopardyListRechId014>) (session.getAttribute("JeopardyListRows"));

		JeopardyMain12State jeopardyMain12State = new JeopardyMain12State();

		EnvRegion e = envRegionCtrl.getEnvRegion(session);
		String activeUser = (String) session.getAttribute("activeUser");
		String environment = (String) session.getAttribute("environment");
		/*
		 * session.removeAttribute("jeopardy_info_msg");
		 * session.removeAttribute("jeopardy_err_msg");
		 * session.setAttribute("jeopardy_info_msg", "");
		 * session.setAttribute("jeopardy_err_msg", "");
		 * model.remove("jeopardy_err_msg"); model.remove("jeopardy_info_msg");
		 */
		session.removeAttribute("jspFlag");
		String userId = envRegionCtrl.getUserIdFromSession( session);
		String objHandle = (String) session.getAttribute("objectHandle");
		int objectHandle = 0;
		if (workloadCtrl.checkNullString(objHandle)) {
			objHandle = 1 + "";
			objectHandle = Integer.parseInt(objHandle);
			session.setAttribute("objectHandle", objectHandle);
		}
		String object_handle = WorkloadController.getObjectHandle(objectHandle);

		FollowUpData followUpData = new FollowUpData();
		jeopardyMain12State= jeopardyTaskService.writeToMQ(jeopardyTask, userId, object_handle, session, followUpData);
		
		String error_msg="";
		if (jeopardyMain12State.getHeader().getReturn_code() != null
				&& jeopardyMain12State.getHeader().getReturn_code().equals("000")) {

			System.out.print("userId:::error_msg::::" + userId);
			error_msg = "Y";

		} else if (jeopardyMain12State.getHeader().getReturn_code() != null
				&& jeopardyMain12State.getHeader().getReturn_code().equals("999")) {
			error_msg = "N";
		} else if (jeopardyMain12State.getHeader().getReturn_code() != null
				&& jeopardyMain12State.getHeader().getReturn_code().equals("888")) {
			error_msg = "M";
		} else if (jeopardyMain12State.getHeader().getReturn_code() != null
				&& jeopardyMain12State.getHeader().getReturn_code().equals("889")) {
			error_msg = "U";
		}

		session.setAttribute("error", error_msg);
	
		session.setAttribute("jspRender", "jeopardyTask12State");
		model.addAttribute("activeUser", activeUser);
		model.addAttribute("environment", environment);
		model.addAttribute("envregion", e);
		//code change start Supriya- Date 9 nov code fix for Read only Jeopardy
				String Lsr_number = (String) session.getAttribute("Lrs_No");
				// System.out.println("Lsr_number:::1::::::::"+Lsr_number);

				CloseTransaction closetransaction = new CloseTransaction();
				//String userId =envRegionCtrl.getUserIdFromSession( session);
//				System.out.println(userId);

				closetransaction.setLsr_number(Lsr_number.substring(0, 14));
				closetransaction.setNext(Lsr_number.substring(15, 17));

				closetransaction.setUser_id(userId);

				closeTransactionService.writeCloseTransactionDataToMQ(closetransaction, userId,session);
			//code change start Supriya- Date 9 nov code fix for Read only Jeopardy	
		//jeopardyRefresh(model,session);
		refreshSamePage9States(model, session);


		return "redirect:/treeViewDisplay";
	}
	
	// Hrushikesh -- Completion Provider Task With Loss
	@RequestMapping(value = "/completionProviderWithLoss", method = RequestMethod.GET)
	public String getCompletionProviderWithLoss(ModelMap model, HttpSession session) {
		String environment = (String) session.getAttribute("environment");
		EnvRegion e = envRegionCtrl.getEnvRegion(session);
		model.addAttribute("environment", environment);
				model.addAttribute("envregion", e);
		List<CompletionActivityRLSOG6LscInfo> list_568 = (List<CompletionActivityRLSOG6LscInfo>) session.getAttribute("treeViewList568");
		List<CompletionProviderTaskWithLossLasrInfo> list_577 = (List<CompletionProviderTaskWithLossLasrInfo>) (session
				.getAttribute("treeViewList577"));
		List<CompletionProviderTask> list_560 = (List<CompletionProviderTask>) (session
				.getAttribute("treeViewList560"));

		CompletionProviderTaskWithLoss completionWithLossData = new CompletionProviderTaskWithLoss();
		if (CollectionUtils.isNotEmpty(list_568)) {
//			System.out.println("list_568 size:: " + list_568);
			completionWithLossData.setCploss_568(list_568);
		}
		if (CollectionUtils.isNotEmpty(list_577)) {
//			System.out.println("list_577 size:: " + list_577);
			completionWithLossData.setCploss_577(list_577);
		}
		if (CollectionUtils.isNotEmpty(list_560)) {
//			System.out.println("list_560 size:: " + list_560);
			completionWithLossData.setCploss_560(list_560);
		}
		
		String losing_cc = (String) session.getAttribute("cpl_losing_cc");
		if (losing_cc != null) {
			List<CompletionProviderTask> new_list_560 = new ArrayList<CompletionProviderTask>();
			for (CompletionProviderTask task : completionWithLossData.getCploss_560()) {
				task.setCompany_code(losing_cc);
				new_list_560.add(task);
			}
			completionWithLossData.setCploss_560(new_list_560);
		}
		 
		model.addAttribute("completionWithLossData", completionWithLossData);
		session.setAttribute("jspRender", "completionWithLoss");
		String info_msg_cploss= (String) session.getAttribute("info_msg_cploss");
		model.addAttribute("info_msg_cploss",info_msg_cploss);
		return "completionProviderWithLoss";
	}

	
	@RequestMapping(value = "/validateccForComplWithLoss", method = RequestMethod.POST)
	public String processValidateCCForCompletionWithLoss(@ModelAttribute("completionWithLossData") CompletionProviderTaskWithLoss completionProviderWithLossData, ModelMap model, HttpSession session) {
		
		System.err.println("In Validate CC post call");
		EnvRegion e = envRegionCtrl.getEnvRegion(session);
		String activeUser = (String) session.getAttribute("activeUser");
		String environment = (String) session.getAttribute("environment");
		String userId = envRegionCtrl.getUserIdFromSession(session);
		String objHandle = (String) session.getAttribute("objectHandle");
		session.setAttribute("info_msg_574", "");
		session.setAttribute("cc_info_msg_574", "");
		session.removeAttribute("jspFlag");
		int objectHandle = 0;
		if (workloadCtrl.checkNullString(objHandle)) {
			objHandle = 1 + "";
			objectHandle = Integer.parseInt(objHandle);
			session.setAttribute("objectHandle", objectHandle);
		}
		String object_handle = WorkloadController.getObjectHandle(objectHandle);
		String stateType = e.getStateType();
	
		if(stateType!=null)
		{
			try {
				completionProviderWithLossService.writeCPLossValidateDataToMQ(completionProviderWithLossData.getCploss_560(),userId, object_handle, session, stateType);
			}
			catch(Exception exp)
			{
				System.out.println("Action - Validate CC, Exception in Completion Provider with Loss : " + exp.toString());
			}
		}
		
		String info_msg_574 = (String) session.getAttribute("info_msg_574");
		String cc_info_msg_574 = (String) session.getAttribute("cc_info_msg_574");
		model.addAttribute("info_msg_574", info_msg_574);
		model.addAttribute("cc_info_msg_574", cc_info_msg_574);
		session.setAttribute("jspRender", "completionWithLoss");
		model.addAttribute("activeUser", activeUser);
		model.addAttribute("environment", environment);
		model.addAttribute("envregion", e);

		return "redirect:/treeViewDisplay";
	}
	
	
	@RequestMapping(value = "/setLossInfoTableData", method = RequestMethod.POST)
	public String viewSetLoss(@RequestBody String request, ModelMap model, HttpSession session) {
		String environment = (String) session.getAttribute("environment");
		EnvRegion e = envRegionCtrl.getEnvRegion(session);
		model.addAttribute("environment", environment);
		session.removeAttribute("jspFlag");
				model.addAttribute("envregion", e);
		List<CompletionProviderLoss_578> updatedList= completionProviderWithLossService.getCompletionProvider578Data(request,session);
		session.setAttribute("lossInfoTableData",updatedList);
		return "redirect:/treeViewDisplay";
		
	}
	
	@RequestMapping(value = "/issueForComplWithLoss", method = RequestMethod.POST)
	public String processIssueForCompletionWithLoss(@ModelAttribute("completionWithLossData") CompletionProviderTaskWithLoss completionProviderWithLossData, ModelMap model, HttpSession session) {
		
		EnvRegion e = envRegionCtrl.getEnvRegion(session);
		String activeUser = (String) session.getAttribute("activeUser");
		String environment = (String) session.getAttribute("environment");
		String userId = envRegionCtrl.getUserIdFromSession(session);
		String objHandle = (String) session.getAttribute("objectHandle");
		session.removeAttribute("cc_info_msg_574");
		session.removeAttribute("jspFlag");
		model.remove("cc_info_msg_574");
		model.remove("info_msg_cploss");
		model.remove("err_msg_cploss");
		int objectHandle = 0;
		if (workloadCtrl.checkNullString(objHandle)) {
			objHandle = 1 + "";
			objectHandle = Integer.parseInt(objHandle);
			session.setAttribute("objectHandle", objectHandle);
		}
		String object_handle = WorkloadController.getObjectHandle(objectHandle);
		String stateType = e.getStateType();
		List<CompletionProviderLoss_578> loss578= (List<CompletionProviderLoss_578>) session.getAttribute("lossInfoTableData");
		if(loss578 == null)
		{
			loss578 = new ArrayList<CompletionProviderLoss_578>();
		}
		completionProviderWithLossData.setCploss_578(loss578);
		String rc="";
		if(stateType!=null)
		{
			try {
				rc= completionProviderWithLossService.writeCPLossIssueDataToMQ(completionProviderWithLossData,userId, object_handle, session, stateType);
			}
			catch(Exception exp)
			{
				System.out.println("Action - Issue, Exception in Completion Provider with Loss : " + exp.toString());
			}
		}
		
		if(rc.equals("000")){
			session.setAttribute("error", "Y");
		}
		List<ShowError> showError = completionProviderWithLossService.getUpdatedErrorList();
		String info_msg_574 = (String) session.getAttribute("info_msg_574");
		String cc_info_msg_574 = (String) session.getAttribute("cc_info_msg_574");
		String err_msg_cploss= (String) session.getAttribute("err_msg_cploss");

		model.addAttribute("info_msg_574",info_msg_574);
		model.addAttribute("cc_info_msg_574",cc_info_msg_574);
		model.addAttribute("err_msg_cploss",err_msg_cploss);
		model.addAttribute("showError",showError);
		model.addAttribute("activeUser", activeUser);
		model.addAttribute("environment", environment);
		model.addAttribute("envregion", e);
		session.setAttribute("jspRender", "completionWithLoss");
		

		return "redirect:/treeViewDisplay";
	}
	@RequestMapping(value = "/issueEcverView", method = RequestMethod.POST)
	public String processIssueEcverView(@RequestBody String ecver, ModelMap model, HttpSession session) {
		//System.out.println("Ecver is: "+ecver);
		EnvRegion e = envRegionCtrl.getEnvRegion(session);
		String activeUser = (String) session.getAttribute("activeUser");
		String environment = (String) session.getAttribute("environment");
		session.removeAttribute("jspFlag");
		String userId = envRegionCtrl.getUserIdFromSession(session);
		String objHandle = (String) session.getAttribute("objectHandle");
		int objectHandle = 0;
		if (workloadCtrl.checkNullString(objHandle)) {
			objHandle = 1 + "";
			objectHandle = Integer.parseInt(objHandle);
			session.setAttribute("objectHandle", objectHandle);
		}
		String object_handle = WorkloadController.getObjectHandle(objectHandle);
		String stateType = e.getStateType();
		EcverView ecverView= new EcverView(); 
		ecverView.setUserID(userId);
		ecverView.setEcver(ecver.trim());
		
		
		String rc="";
		if(stateType!=null)
		{
			try {
				correctingConfViewService.writeEcverViewDataToMQ(ecverView,userId, object_handle, session, stateType);
			}
			catch(Exception exp)
			{
				System.out.println("Action - ECVER, Exception in Corr Conf Ecver View : " + exp.toString());
			}
		}
		
		String msg = (String) session.getAttribute("err_ecver");
		session.setAttribute("err_ecver", msg);
		model.addAttribute("activeUser", activeUser);
		model.addAttribute("environment", environment);
		model.addAttribute("envregion", e);
		session.setAttribute("jspRender", ecver);
		
		if (stateType.equalsIgnoreCase("12 States")) 
		{
			return "redirect:/treeViewDisplay";
		}
		else
		{
			return "redirect:/treeview9states";
		}
	}


	private String setEnhancedSelectedObj(String uniqueKey, EnhancedSelectData newSelectRequestData,
			EnhancedSelectData selectRequestTreeViewData) {
		System.out.println("uniqueKey = " + uniqueKey);

		System.out.println("Treeview enhance Data setEnhancedSelectedObj is: " + selectRequestTreeViewData.getEnhancedSelectTableRows().size());
		String recid = "";
		// System.out.println("workloadDataW111111111ithMQData" +
		// selectRequestTreeViewData.getSelectRequestTableRows9());
		for (EnhancedSelectTableRow selectRequestTableRow : selectRequestTreeViewData.getEnhancedSelectTableRows()) {
			System.out.println("inside ifff:::::" + selectRequestTableRow.getUniqueId());
			if (selectRequestTableRow.getUniqueId() == Integer.parseInt(uniqueKey)) {
				recid = selectRequestTableRow.getReqtyp();
				System.out.println("selectRequestTableRow:::::"+selectRequestTableRow);
				// session.setAttribute("selectedIndexValue", uniqueKey);
				newSelectRequestData.getEnhancedSelectTableRows().add(selectRequestTableRow);	
				break;
			}
		}
		
		System.out.println("recid"+recid);
		return recid;
	}

	private void resetSelectData(List<String> reqData, ModelMap model, HttpSession session) {
		session.removeAttribute("showError");
		System.err.println("In Reset Data: " + reqData.toString());
		if (reqData.get(0).equals("selectRequest")) {
			SelectRequestData data = new SelectRequestData();
			int currentIndex = Integer.parseInt(reqData.get(2));
			setSelectRequestDataObj(data, currentIndex, session);
			System.out.println("select data: " + data.toString());
			
		} else if (reqData.get(0).equals("enhancedSelReq")) {
			EnhancedSelectData data = new EnhancedSelectData();
			int currentIndex = Integer.parseInt(reqData.get(2));
			setEnhancedSelectDataObj(data, currentIndex, session);
			System.out.println("enhanced select data: " + data.toString());
		}
	}
	
	private List<List<String>> getAllFolders9State(List treeViewList) {
		System.err.println("treeViewList"+treeViewList);
		List<String> treeViewvFolderList= new ArrayList<String>();
		List<String> treeViewvFolderIdsList= new ArrayList<String>();
		List<List<String>> nameAndIds= new ArrayList<List<String>>();
		
		//LSR
		if(treeViewList.contains("154") || treeViewList.contains("050")){
			treeViewvFolderList.add("LSR Admin");
			treeViewvFolderIdsList.add("154");
		}
		if(treeViewList.contains("050")){
			treeViewvFolderList.add("Bill & Contact");
			treeViewvFolderIdsList.add("050");
		}
		//Hunting
		if(treeViewList.contains("160") || treeViewList.contains("161")){
			treeViewvFolderList.add("Hunting");
			treeViewvFolderIdsList.add("160");
		}
		//End User
		if(treeViewList.contains("100") || treeViewList.contains("161")){
			treeViewvFolderList.add("End User");
			treeViewvFolderIdsList.add("100");
		}
		

		if(treeViewList.contains("105") || treeViewList.contains("106")){
			treeViewvFolderList.add("End User Disc/TC");
			treeViewvFolderIdsList.add("105");
		}
		
		if(treeViewList.contains("102")){
			treeViewvFolderList.add("Bill");
			treeViewvFolderIdsList.add("102");
		}
		
		
		//Directory
		if(treeViewList.contains("430")){
			treeViewvFolderList.add("Listing");
			treeViewvFolderIdsList.add("430");
		}

		if(treeViewList.contains("435") || treeViewList.contains("436")){
			treeViewvFolderList.add("Listing Text");
			treeViewvFolderIdsList.add("435");
		}

		if(treeViewList.contains("440") ){
			treeViewvFolderList.add("Caption");
			treeViewvFolderIdsList.add("440");
		}

		if(treeViewList.contains("420") ){
			treeViewvFolderList.add("Delivery Address");
			treeViewvFolderIdsList.add("420");
		}
		if(treeViewList.contains("430")){
			treeViewvFolderList.add("Advertising/YPH");
			treeViewvFolderIdsList.add("430A");
		}
		
		//product
		if(treeViewList.contains("200") ){
			treeViewvFolderList.add("Loop");
			treeViewvFolderIdsList.add("200");
		}

		if(treeViewList.contains("300") ){
			treeViewvFolderList.add("Loop w/NP");
			treeViewvFolderIdsList.add("300");
		}

		if((treeViewList.contains("107") || treeViewList.contains("108")) && treeViewList.contains("300")){
			treeViewvFolderList.add("TC");
			treeViewvFolderIdsList.add("107");
		}
		if((treeViewList.contains("107") || treeViewList.contains("108")) && treeViewList.contains("200")){
			treeViewvFolderList.add("Dist/TC");
			treeViewvFolderIdsList.add("108");
		}

		if(treeViewList.contains("250")){
			treeViewvFolderList.add("Number Portability");
			treeViewvFolderIdsList.add("250");
		}

		if(treeViewList.contains("275")){
			treeViewvFolderList.add("Loop w/Port");
			treeViewvFolderIdsList.add("275");
		}

		if(treeViewList.contains("350")){
			treeViewvFolderList.add("Port");
			treeViewvFolderIdsList.add("350");
		}

		if(treeViewList.contains("150")){
			treeViewvFolderList.add("Resale");
			treeViewvFolderIdsList.add("150");
		}
		if(((treeViewList.contains("107") || treeViewList.contains("108")) &&(treeViewList.contains("150") || treeViewList.contains("275") || 
				treeViewList.contains("350")))) {
			treeViewvFolderList.add("TC");
			treeViewvFolderIdsList.add("107TC");
		}
		
		if((treeViewList.contains("500") || treeViewList.contains("510") || treeViewList.contains("511"))) {
			
				if(treeViewList.contains("500")){
					treeViewvFolderList.add("Circuit");
					treeViewvFolderIdsList.add("500");
				}
		
				if(treeViewList.contains("510") || treeViewList.contains("156")){
					treeViewvFolderList.add("Primary Location");
					treeViewvFolderIdsList.add("510");
				}
		
				if(treeViewList.contains("511") || treeViewList.contains("109")){
					treeViewvFolderList.add("Secondary Location");
					treeViewvFolderIdsList.add("511");
				}
		}
		
		if(treeViewList.contains("680")) {
			
				if(treeViewList.contains("683") || treeViewList.contains("684")){
					treeViewvFolderList.add("Common Block Detail Section");
					treeViewvFolderIdsList.add("680_683");
				}
		
				if (((treeViewList.contains("680")) || (treeViewList.contains("155")) || (treeViewList.contains("211"))
						|| (treeViewList.contains("108")))) {
					treeViewvFolderList.add("CRS Station");
					treeViewvFolderIdsList.add("680_155");
					
					if(treeViewList.contains("211") || treeViewList.contains("108")){
						treeViewvFolderList.add("Disconnect/TC");
						treeViewvFolderIdsList.add("680_211");
					}
				}
		
				treeViewvFolderList.add("CRS LOCATION");
				treeViewvFolderIdsList.add("680");
				
		}
		
		///681 recid - 25/02/2022
		if (treeViewList.contains("681")) {

			if (treeViewList.contains("683") || treeViewList.contains("684")) {
				treeViewvFolderList.add("Common Block Detail Section");
				treeViewvFolderIdsList.add("681_683");
			}

			if (((treeViewList.contains("681")) || (treeViewList.contains("155")) || (treeViewList.contains("211"))
					|| (treeViewList.contains("108")))) {
				treeViewvFolderList.add("CUS Station");
				treeViewvFolderIdsList.add("681_681");
				if (treeViewList.contains("211") || treeViewList.contains("108")) {
					treeViewvFolderList.add("Disconnect/TC");
					treeViewvFolderIdsList.add("681_211");
				}

			}
	
			
			
			treeViewvFolderList.add("CUS Location");
			treeViewvFolderIdsList.add("681");
			
	}
		
		
	if(treeViewList.contains("682")) {
			
			if(treeViewList.contains("683") || treeViewList.contains("684")){
				treeViewvFolderList.add("Common Block Detail Section");
				treeViewvFolderIdsList.add("682_683");
			}

			if(((treeViewList.contains("682")) || (treeViewList.contains("155")) || (treeViewList.contains("211")) || (treeViewList.contains("108")))){
				treeViewvFolderList.add("CUS Station");
				treeViewvFolderIdsList.add("682_682");
				
				if(treeViewList.contains("211") || treeViewList.contains("108")){
					treeViewvFolderList.add("Disconnect/TC");
					treeViewvFolderIdsList.add("682_211");
				}
			}
	
			
			
			treeViewvFolderList.add("CUS Location");
			treeViewvFolderIdsList.add("682");
			
	}
	
	if(treeViewList.contains("800")) {
		
		if(treeViewList.contains("800") || treeViewList.contains("157")){
			treeViewvFolderList.add("DTR CKT Location");
			treeViewvFolderIdsList.add("800_157");
		}
		if(treeViewList.contains("800") || treeViewList.contains("158")){
			treeViewvFolderList.add("DTR Trunk Group");
			treeViewvFolderIdsList.add("800_158");
		} 
			if(treeViewList.contains("800")) {	
				treeViewvFolderList.add("DTR DID TN");
				treeViewvFolderIdsList.add("800DTR");
				
				if(treeViewList.contains("212") || treeViewList.contains("213")){
					treeViewvFolderList.add("TGRP Disc/TC");
					treeViewvFolderIdsList.add("800_212");
				}
		
			}
		
		if(treeViewList.contains("800") || treeViewList.contains("155")){
			treeViewvFolderList.add("DTR Trunk");
			treeViewvFolderIdsList.add("800");
			if(treeViewList.contains("211") || treeViewList.contains("108")){
				treeViewvFolderList.add("Disconnect/TC");
				treeViewvFolderIdsList.add("800_211");
			}
			
		}

	}

	// 801 Rec id : 25/02
	if (treeViewList.contains("801")) {

		if (treeViewList.contains("801") || treeViewList.contains("157")) {
			treeViewvFolderList.add("DTU CKT Location");
			treeViewvFolderIdsList.add("801_157");
		}

		if (treeViewList.contains("801") || treeViewList.contains("158")) {
			treeViewvFolderList.add("DTU Trunk Group");
			treeViewvFolderIdsList.add("801_158");
		}

		treeViewvFolderList.add("DTU DID TN");
		treeViewvFolderIdsList.add("801");
		if (treeViewList.contains("212") || treeViewList.contains("213")) {
			treeViewvFolderList.add("TGRP Disc/TC");
			treeViewvFolderIdsList.add("801_212");
		}

		if (treeViewList.contains("801") || treeViewList.contains("155")) {
			treeViewvFolderList.add("DTU Trunk");
			treeViewvFolderIdsList.add("801_155");

			if (treeViewList.contains("211") || treeViewList.contains("108")) {
				treeViewvFolderList.add("Disconnect/TC");
				treeViewvFolderIdsList.add("801_211");
			}

		}

	}

//802 rec id for req type s : 25/02
	if (treeViewList.contains("802")) {

		if (treeViewList.contains("802") || treeViewList.contains("157")) {
			treeViewvFolderList.add("DTU CKT Location");
			treeViewvFolderIdsList.add("802_157");
		}

		if (treeViewList.contains("802") || treeViewList.contains("158")) {
			treeViewvFolderList.add("DTU Trunk Group");
			treeViewvFolderIdsList.add("802_158");
		}

		treeViewvFolderList.add("DTU DID TN");
		treeViewvFolderIdsList.add("802");
		if (treeViewList.contains("212") || treeViewList.contains("213")) {
			treeViewvFolderList.add("TGRP Disc/TC");
			treeViewvFolderIdsList.add("802_212");
		}

		if (treeViewList.contains("802") || treeViewList.contains("155")) {
			treeViewvFolderList.add("DTU Trunk");
			treeViewvFolderIdsList.add("802_155");

			if (treeViewList.contains("211") || treeViewList.contains("108")) {
				treeViewvFolderList.add("Disconnect/TC");
				treeViewvFolderIdsList.add("802_211");
			}

		}

	}
		
		
		
		if(treeViewList.contains("640")) {
			
			if((treeViewList.contains("640") || treeViewList.contains("212") || treeViewList.contains("213"))){
				treeViewvFolderList.add("DPR Trunk Group");
				treeViewvFolderIdsList.add("640_640");
				
				if(treeViewList.contains("212") || treeViewList.contains("213")){
					treeViewvFolderList.add("TGRP Disc/TC");
					treeViewvFolderIdsList.add("640_212");
				}
				
			}
			
			if((treeViewList.contains("640") || treeViewList.contains("108") || treeViewList.contains("211") || treeViewList.contains("155"))){
				treeViewvFolderList.add("DPR Trunk");
				treeViewvFolderIdsList.add("640_155");
				
				if(treeViewList.contains("108") || treeViewList.contains("211")){
					treeViewvFolderList.add("Disconnect/TC");
					treeViewvFolderIdsList.add("640_211");
				}
				
			}
			
		}
		
		
	if(treeViewList.contains("641")) {
		
		treeViewvFolderList.add("DPU Trunk Group");
		treeViewvFolderIdsList.add("641");
		
			if( treeViewList.contains("212") || treeViewList.contains("213")){
				treeViewvFolderList.add("TGRP Disc/TC");
				treeViewvFolderIdsList.add("641_212");
				
			}
			
			if( treeViewList.contains("641") || treeViewList.contains("155")){
				treeViewvFolderList.add("DPU Trunk");
				treeViewvFolderIdsList.add("641_155");
				
				if(treeViewList.contains("211") || treeViewList.contains("108")){
					treeViewvFolderList.add("Disconnect/TC");
					treeViewvFolderIdsList.add("641_211");
				}
				
			}
			
		}

	if(treeViewList.contains("642")) {
		
		treeViewvFolderList.add("DPU Trunk Group");
		treeViewvFolderIdsList.add("642");
			if( treeViewList.contains("212") || treeViewList.contains("213")){
				treeViewvFolderList.add("TGRP Disc/TC");
				treeViewvFolderIdsList.add("642_212");
				
			}
			
			if( treeViewList.contains("642") || treeViewList.contains("155")){
				treeViewvFolderList.add("DPU Trunk");
				treeViewvFolderIdsList.add("642_155");
				
				if(treeViewList.contains("211") || treeViewList.contains("108")){
					treeViewvFolderList.add("Disconnect/TC");
					treeViewvFolderIdsList.add("642_211");
				}
				
			}
			
		}
	
	if(treeViewList.contains("840")) {
		
		
			if( treeViewList.contains("840") || treeViewList.contains("159")){
				treeViewvFolderList.add("IRS Channel");
				treeViewvFolderIdsList.add("840_159");
				
			}
			
			if( treeViewList.contains("840") || treeViewList.contains("157")){
				treeViewvFolderList.add("IRS CKT Location");
				treeViewvFolderIdsList.add("840_157");
				
			}
			
			if((treeViewList.contains("840") || treeViewList.contains("210") || treeViewList.contains("108"))){
				treeViewvFolderList.add("IRS PRI TN");
				treeViewvFolderIdsList.add("840_840");
				
				if(treeViewList.contains("210") || treeViewList.contains("108")){
					treeViewvFolderList.add("TN Disc/TC");
					treeViewvFolderIdsList.add("840_210");
				}
				
			}
			
			if( treeViewList.contains("840") || treeViewList.contains("158")){
				treeViewvFolderList.add("IRS Trunk Group");
				treeViewvFolderIdsList.add("840_158");
				
			}
			
		}
	
	
	if(treeViewList.contains("841")) {
		
		
		if( treeViewList.contains("841") || treeViewList.contains("159")){
			treeViewvFolderList.add("IUS Channel");
			treeViewvFolderIdsList.add("841_159");
			
		}
		
		if( treeViewList.contains("841") || treeViewList.contains("157")){
			treeViewvFolderList.add("IUS CKT Location");
			treeViewvFolderIdsList.add("841_157");
			
		}
		
		treeViewvFolderList.add("IUS PRI TN");
		treeViewvFolderIdsList.add("841");
		if(treeViewList.contains("210") || treeViewList.contains("108")){
			treeViewvFolderList.add("TN Disc/TC");
			treeViewvFolderIdsList.add("841_210");
		}
		
		if(treeViewList.contains("841") || treeViewList.contains("158")){
			treeViewvFolderList.add("IUS Trunk Group");
			treeViewvFolderIdsList.add("841_158");
		}
		
	}
	
		if(treeViewList.contains("842")) {
				
				
				if( treeViewList.contains("842") || treeViewList.contains("159")){
					treeViewvFolderList.add("IUS Channel");
					treeViewvFolderIdsList.add("842_159");
					
				}
				
				if( treeViewList.contains("842") || treeViewList.contains("157")){
					treeViewvFolderList.add("IUS CKT Location");
					treeViewvFolderIdsList.add("842_157");
					
				}
				
				treeViewvFolderList.add("IUS PRI TN");
				treeViewvFolderIdsList.add("842");
				if(treeViewList.contains("210") || treeViewList.contains("108")){
					treeViewvFolderList.add("TN Disc/TC");
					treeViewvFolderIdsList.add("842_210");
				}
				
				if(treeViewList.contains("842") || treeViewList.contains("158")){
					treeViewvFolderList.add("IUS Trunk Group");
					treeViewvFolderIdsList.add("842_158");
				}
				
		}
	
	
		//remark
		if(treeViewList.contains("065") ){
			treeViewvFolderList.add("Remarks");
			treeViewvFolderIdsList.add("065");
		}
		if(treeViewList.contains("601") ){
			treeViewvFolderList.add("OG Errors");
			treeViewvFolderIdsList.add("601");
		}

		//response
		if(treeViewList.contains("534") ){
			treeViewvFolderList.add("Summary");
			treeViewvFolderIdsList.add("534");
		}
		if(treeViewList.contains("602") ){
			treeViewvFolderList.add("Fatal Errors/Manual Rejects");
			treeViewvFolderIdsList.add("602");
		}
		
		if((treeViewList.contains("880") || treeViewList.contains("882") || treeViewList.contains("888") || treeViewList.contains("889") || treeViewList.contains("654"))){
			treeViewvFolderList.add("Confirmation");
			treeViewvFolderIdsList.add("880");
			
			if(treeViewList.contains("654") ){
				treeViewvFolderList.add("Confirmation Remarks View");
				treeViewvFolderIdsList.add("654");
			}
			
		}
		
		
		if(treeViewList.contains("895") && treeViewList.contains("925")){
			treeViewvFolderList.add("Directory FOC View");
			treeViewvFolderIdsList.add("895");
		}
		if(treeViewList.contains("929") || treeViewList.contains("930")){
			treeViewvFolderList.add("Hunting FOC View");
			treeViewvFolderIdsList.add("929");
		}
		if(treeViewList.contains("926") && treeViewList.contains("927")){
			treeViewvFolderList.add("LSR/EU FOC View");
			treeViewvFolderIdsList.add("926");
		}
		if(treeViewList.contains("928") ){
			treeViewvFolderList.add("Service Section FOC View");
			treeViewvFolderIdsList.add("928");
		}
		
		if(treeViewList.contains("586") ){
			treeViewvFolderList.add("Post To Bill View");
			treeViewvFolderIdsList.add("586");
		}
		if(treeViewList.contains("603R") ){
			treeViewvFolderList.add("Sort Errors");
			treeViewvFolderIdsList.add("603R");
		}
		
		
		if(treeViewList.contains("890") && treeViewList.contains("898")){
			treeViewvFolderList.add("Completion");
			treeViewvFolderIdsList.add("890");
		}
//		if(treeViewList.contains("893") && treeViewList.contains("897")){
//			treeViewvFolderList.add("Completion");
//		}
		if(treeViewList.contains("584") ){
			treeViewvFolderList.add("Jeopardy R/C View");
			treeViewvFolderIdsList.add("584");
		}
		
		
		
		if(treeViewList.contains("583") || treeViewList.contains("584")){
				treeViewvFolderList.add("Jeopardy View");
				treeViewvFolderIdsList.add("583");
		}
		
		/*
		some remaining
		*/
		
		if(treeViewList.contains("543") ){
			treeViewvFolderList.add("AT&#38T Initiated Cancel Task");
			treeViewvFolderIdsList.add("543");
		}
		
//		if(treeViewList.contains("531") ){
//			treeViewvFolderList.add("Follow Up");
//		}
		
		
		if(treeViewList.contains("530") ){
			treeViewvFolderList.add("Notes/FUP");
			treeViewvFolderIdsList.add("530");
		}
		
		//history
		if(treeViewList.contains("535") ){
			treeViewvFolderList.add("Field Data Changes");
			treeViewvFolderIdsList.add("535");
		}
		if(treeViewList.contains("536") ){
			treeViewvFolderList.add("Interface Messages");
			treeViewvFolderIdsList.add("536");
		}
		if(treeViewList.contains("537") ){
			treeViewvFolderList.add("Service Order History");
			treeViewvFolderIdsList.add("537");
		}
		if(treeViewList.contains("538") ){
			treeViewvFolderList.add("Exception Messages");
			treeViewvFolderIdsList.add("538");
		}
		if(treeViewList.contains("539") ){
			treeViewvFolderList.add("Addl Info");
			treeViewvFolderIdsList.add("539");
		}
		if(treeViewList.contains("548") ){
			treeViewvFolderList.add("Audit Messages");
			treeViewvFolderIdsList.add("548");
		}
		
		
		//Follow Up
		
		
		nameAndIds.add(treeViewvFolderList)	;
		nameAndIds.add(treeViewvFolderIdsList);
		return nameAndIds;
	}
	
	private List<List<String>> getAllFolders12State(List<String> treeViewList) {
		System.err.println("treeViewList"+treeViewList);
		List<String> treeViewvFolderList= new ArrayList<String>();
		List<String> treeViewvFolderIdsList= new ArrayList<String>();
		List<List<String>> nameAndIds= new ArrayList<List<String>>();
		
		//LSR
		if(treeViewList.contains("154") || treeViewList.contains("050")){
			treeViewvFolderList.add("LSR Admin");
			treeViewvFolderIdsList.add("154");
		}
		if(treeViewList.contains("050")){
			treeViewvFolderList.add("Bill & Contact");
			treeViewvFolderIdsList.add("050");
		}
		//Hunting
		if(treeViewList.contains("160") || treeViewList.contains("161")){
			treeViewvFolderList.add("Hunting");
			treeViewvFolderIdsList.add("160");
		}
		//End User
		if(treeViewList.contains("100") || treeViewList.contains("161")){
			treeViewvFolderList.add("End User");
			treeViewvFolderIdsList.add("100");
		}
		

		if(treeViewList.contains("105") || treeViewList.contains("106")){
			treeViewvFolderList.add("End User Disc/TC");
			treeViewvFolderIdsList.add("105");
		}
		//Directory
		if(treeViewList.contains("430")){
			treeViewvFolderList.add("Listing");
			treeViewvFolderIdsList.add("430");
		}

		if(treeViewList.contains("435") || treeViewList.contains("436")){
			treeViewvFolderList.add("Listing Text");
			treeViewvFolderIdsList.add("435");
		}

		if(treeViewList.contains("440") ){
			treeViewvFolderList.add("Caption");
			treeViewvFolderIdsList.add("440");
		}

		if(treeViewList.contains("420") ){
			treeViewvFolderList.add("Delivery Address");
			treeViewvFolderIdsList.add("420");
		}
		
		if(treeViewList.contains("430")){
			treeViewvFolderList.add("Advertising/YPH");
			treeViewvFolderIdsList.add("430A");
		}
		
		
		//product
		if(treeViewList.contains("200") ){
			treeViewvFolderList.add("Loop");
			treeViewvFolderIdsList.add("200");
		}

		if(treeViewList.contains("300") ){
			treeViewvFolderList.add("Loop w/NP");
			treeViewvFolderIdsList.add("300");
		}

		if((treeViewList.contains("107") || treeViewList.contains("108")) && treeViewList.contains("300")){
			treeViewvFolderList.add("TC");
			treeViewvFolderIdsList.add("107");
		}
		if((treeViewList.contains("107") || treeViewList.contains("108")) && treeViewList.contains("200")){
			treeViewvFolderList.add("Dist/TC");
			treeViewvFolderIdsList.add("108");
		}

		if(treeViewList.contains("250")){
			treeViewvFolderList.add("Number Portability");
			treeViewvFolderIdsList.add("250");
		}

		if(treeViewList.contains("275")){
			treeViewvFolderList.add("Loop w/Port");
			treeViewvFolderIdsList.add("275");
		}

		if(treeViewList.contains("350")){
			treeViewvFolderList.add("Port");
			treeViewvFolderIdsList.add("350");
		}

		if(treeViewList.contains("150")){
			treeViewvFolderList.add("Resale");
			treeViewvFolderIdsList.add("150");
		}
		if(((treeViewList.contains("107") || treeViewList.contains("108")) &&(treeViewList.contains("275") ||treeViewList.contains("350") ||treeViewList.contains("150")))) {
			treeViewvFolderList.add("TC");
			treeViewvFolderIdsList.add("107TC");
		}
		
		if((treeViewList.contains("500") || treeViewList.contains("510") || treeViewList.contains("511"))) {
			
				if(treeViewList.contains("500")){
					treeViewvFolderList.add("Circuit");
					treeViewvFolderIdsList.add("500");
				}
		
				if(treeViewList.contains("510") || treeViewList.contains("156")){
					treeViewvFolderList.add("Primary Location");
					treeViewvFolderIdsList.add("510");
				}
		
				if(treeViewList.contains("511") || treeViewList.contains("109")){
					treeViewvFolderList.add("Secondary Location");
					treeViewvFolderIdsList.add("511");
				}
		}
		
		if(treeViewList.contains("680")) {
			
				if(treeViewList.contains("683") || treeViewList.contains("684")){
					treeViewvFolderList.add("Common Block Detail Section");
					treeViewvFolderIdsList.add("680_683");
				}
		
				if(treeViewList.contains("680") || treeViewList.contains("155")){
					treeViewvFolderList.add("CRS Station");
					treeViewvFolderIdsList.add("680_155");
					
					if(treeViewList.contains("211") || treeViewList.contains("108")){
						treeViewvFolderList.add("Disconnect/TC");
						treeViewvFolderIdsList.add("680_211");
					}
				}
				
				
				
				treeViewvFolderList.add("CRS LOCATION");
				treeViewvFolderIdsList.add("680");
				
		}
		
		if(treeViewList.contains("681")) {
			
			if(treeViewList.contains("683") || treeViewList.contains("684")){
				treeViewvFolderList.add("Common Block Detail Section");
				treeViewvFolderIdsList.add("681_683");
			}
	
			if(((treeViewList.contains("681")) || (treeViewList.contains("155")) || (treeViewList.contains("211")) || (treeViewList.contains("108")))){
				treeViewvFolderList.add("CUS Station");
				treeViewvFolderIdsList.add("681_681");
				if(treeViewList.contains("211") || treeViewList.contains("108")){
					treeViewvFolderList.add("Disconnect/TC");
					treeViewvFolderIdsList.add("681_211");
				}
			
			}		
			
			treeViewvFolderList.add("CUS Location");
			treeViewvFolderIdsList.add("681");
			
	}
	if(treeViewList.contains("682")) {
		
		
		
			if(treeViewList.contains("683") || treeViewList.contains("684")){
				treeViewvFolderList.add("Common Block Detail Section");
				treeViewvFolderIdsList.add("682_683");
			}

			if(((treeViewList.contains("682")) || (treeViewList.contains("155")) || (treeViewList.contains("211")) || (treeViewList.contains("108")))){
				treeViewvFolderList.add("CUS Station");
				treeViewvFolderIdsList.add("682_682");
				
				if(treeViewList.contains("211") || treeViewList.contains("108")){
					treeViewvFolderList.add("Disconnect/TC");
					treeViewvFolderIdsList.add("682_211");
				}
			}
	
			
			
			treeViewvFolderList.add("CUS Location");
			treeViewvFolderIdsList.add("682");
			
	}
	
	if(treeViewList.contains("800")) {
		treeViewvFolderList.add("DTR DID TN");
		treeViewvFolderIdsList.add("800DTR");
		
		if(treeViewList.contains("800") || treeViewList.contains("157")){
			treeViewvFolderList.add("DTR CKT Location");
			treeViewvFolderIdsList.add("800_157");
		}
		if(treeViewList.contains("800") || treeViewList.contains("158")){
			treeViewvFolderList.add("DTR Trunk Group");
			treeViewvFolderIdsList.add("800_158");
		} 
		if(treeViewList.contains("212") || treeViewList.contains("213")){
			treeViewvFolderList.add("TGRP Disc/TC");
			treeViewvFolderIdsList.add("800_212");
		}
		
		if(treeViewList.contains("800") || treeViewList.contains("155")){
			treeViewvFolderList.add("DTR Trunk");
			treeViewvFolderIdsList.add("800");
			if(treeViewList.contains("211") || treeViewList.contains("108")){
				treeViewvFolderList.add("Disconnect/TC");
				treeViewvFolderIdsList.add("800_211");
			}
			
		}

	}
	
	// 801 Rec id : 25/02
		if (treeViewList.contains("801")) {

			if (treeViewList.contains("801") || treeViewList.contains("157")) {
				treeViewvFolderList.add("DTU CKT Location");
				treeViewvFolderIdsList.add("801_157");
			}

			if (treeViewList.contains("801") || treeViewList.contains("158")) {
				treeViewvFolderList.add("DTU Trunk Group");
				treeViewvFolderIdsList.add("801_158");
			}

			treeViewvFolderList.add("DTU DID TN");
			treeViewvFolderIdsList.add("801");
			if (treeViewList.contains("212") || treeViewList.contains("213")) {
				treeViewvFolderList.add("TGRP Disc/TC");
				treeViewvFolderIdsList.add("801_212");
			}

			if (treeViewList.contains("801") || treeViewList.contains("155")) {
				treeViewvFolderList.add("DTU Trunk");
				treeViewvFolderIdsList.add("801_155");

				if (treeViewList.contains("211") || treeViewList.contains("108")) {
					treeViewvFolderList.add("Disconnect/TC");
					treeViewvFolderIdsList.add("801_211");
				}

			}

		}
		
		
		if(treeViewList.contains("802")) {
			
				if(treeViewList.contains("802") || treeViewList.contains("157")){
					treeViewvFolderList.add("DTU CKT Location");
					treeViewvFolderIdsList.add("802_157");
				}
				
				
				if(treeViewList.contains("802") || treeViewList.contains("158")){
					treeViewvFolderList.add("DTU Trunk Group");
					treeViewvFolderIdsList.add("802_158");
				}
				
				
				treeViewvFolderList.add("DTU DID TN");
				treeViewvFolderIdsList.add("802");
				if(treeViewList.contains("212") || treeViewList.contains("213")){
					treeViewvFolderList.add("TGRP Disc/TC");
					treeViewvFolderIdsList.add("802_212");
				}
				
				if(treeViewList.contains("802") || treeViewList.contains("155")){
					treeViewvFolderList.add("DTU Trunk");
					treeViewvFolderIdsList.add("802_155");
					
					if(treeViewList.contains("211") || treeViewList.contains("108")){
						treeViewvFolderList.add("Disconnect/TC");
						treeViewvFolderIdsList.add("802_211");
					}
					
				}
				
			}
		
		
		
		if(treeViewList.contains("640")) {
			
			if((treeViewList.contains("640") || treeViewList.contains("212") || treeViewList.contains("213"))){
				treeViewvFolderList.add("DPR Trunk Group");
				treeViewvFolderIdsList.add("640_640");
				
				if(treeViewList.contains("212") || treeViewList.contains("213")){
					treeViewvFolderList.add("TGRP Disc/TC");
					treeViewvFolderIdsList.add("640_212");
				}
				
			}
			
			if((treeViewList.contains("640") || treeViewList.contains("108") || treeViewList.contains("211") || treeViewList.contains("155"))){
				treeViewvFolderList.add("DPR Trunk");
				treeViewvFolderIdsList.add("640_155");
				
				if(treeViewList.contains("108") || treeViewList.contains("211")){
					treeViewvFolderList.add("Disconnect/TC");
					treeViewvFolderIdsList.add("640_211");
				}
				
			}
			
		}
		
		
	if(treeViewList.contains("641")) {
		
		treeViewvFolderList.add("DPU Trunk Group");
		treeViewvFolderIdsList.add("641");
		
			if( treeViewList.contains("212") || treeViewList.contains("213")){
				treeViewvFolderList.add("TGRP Disc/TC");
				treeViewvFolderIdsList.add("641_212");
				
				
			}
			
			if( treeViewList.contains("641") || treeViewList.contains("155")){
				treeViewvFolderList.add("DPU Trunk");
				treeViewvFolderIdsList.add("641_155");
				
				if(treeViewList.contains("211") || treeViewList.contains("108")){
					treeViewvFolderList.add("Disconnect/TC");
					treeViewvFolderIdsList.add("641_211");
				}
				
			}
			
		}

	if(treeViewList.contains("642")) {
		
		treeViewvFolderList.add("DPU Trunk Group");
		treeViewvFolderIdsList.add("642");
			if( treeViewList.contains("212") || treeViewList.contains("213")){
				treeViewvFolderList.add("TGRP Disc/TC");
				treeViewvFolderIdsList.add("642_212");
				
			}
			
			if( treeViewList.contains("642") || treeViewList.contains("155")){
				treeViewvFolderList.add("DPU Trunk");
				treeViewvFolderIdsList.add("642_155");
				
				if(treeViewList.contains("211") || treeViewList.contains("108")){
					treeViewvFolderList.add("Disconnect/TC");
					treeViewvFolderIdsList.add("642_211");
				}
				
			}
			
		}
	
	if(treeViewList.contains("840")) {
		
		
			if( treeViewList.contains("840") || treeViewList.contains("159")){
				treeViewvFolderList.add("IRS Channel");
				treeViewvFolderIdsList.add("840_159");
				
			}
			
			if( treeViewList.contains("840") || treeViewList.contains("157")){
				treeViewvFolderList.add("IRS CKT Location");
				treeViewvFolderIdsList.add("840_157");
				
			}
			
			if((treeViewList.contains("840") || treeViewList.contains("210") || treeViewList.contains("108"))){
				treeViewvFolderList.add("IRS PRI TN");
				treeViewvFolderIdsList.add("840_840");
				
				if(treeViewList.contains("210") || treeViewList.contains("108")){
					treeViewvFolderList.add("TN Disc/TC");
					treeViewvFolderIdsList.add("840_210");
				}
				
			}
			
			if( treeViewList.contains("840") || treeViewList.contains("158")){
				treeViewvFolderList.add("IRS Trunk Group");
				treeViewvFolderIdsList.add("840_158");
				
			}
			
		}
	
	
	if(treeViewList.contains("841")) {
		
		
		if( treeViewList.contains("841") || treeViewList.contains("159")){
			treeViewvFolderList.add("IUS Channel");
			treeViewvFolderIdsList.add("841_159");
			
		}
		
		if( treeViewList.contains("841") || treeViewList.contains("157")){
			treeViewvFolderList.add("IUS CKT Location");
			treeViewvFolderIdsList.add("841_157");
			
		}
		
		treeViewvFolderList.add("IUS PRI TN");
		treeViewvFolderIdsList.add("841");
		
		if(treeViewList.contains("210") || treeViewList.contains("108")){
			treeViewvFolderList.add("TN Disc/TC");
			treeViewvFolderIdsList.add("841_210");
		}
		
		if(treeViewList.contains("841") || treeViewList.contains("158")){
			treeViewvFolderList.add("IUS Trunk Group");
			treeViewvFolderIdsList.add("841_158");
		}
		
	}
	
		if(treeViewList.contains("842")) {
				
				
				if( treeViewList.contains("842") || treeViewList.contains("159")){
					treeViewvFolderList.add("IUS Channel");
					treeViewvFolderIdsList.add("842_159");
					
				}
				
				if( treeViewList.contains("842") || treeViewList.contains("157")){
					treeViewvFolderList.add("IUS CKT Location");
					treeViewvFolderIdsList.add("842_157");
					
				}
				
				treeViewvFolderList.add("IUS PRI TN");
				treeViewvFolderIdsList.add("842");
				
				if(treeViewList.contains("210") || treeViewList.contains("108")){
					treeViewvFolderList.add("TN Disc/TC");
					treeViewvFolderIdsList.add("842_210");
				}
				
				if(treeViewList.contains("842") || treeViewList.contains("158")){
					treeViewvFolderList.add("IUS Trunk Group");
					treeViewvFolderIdsList.add("842_158");
				}
				
		}
	
	
		//remark
		if(treeViewList.contains("065") ){
			treeViewvFolderList.add("Remarks");
			treeViewvFolderIdsList.add("065");
		}
		if(treeViewList.contains("601") ){
			treeViewvFolderList.add("OG Errors");
			treeViewvFolderIdsList.add("601");
		}

		//response
		if(treeViewList.contains("534") ){
			treeViewvFolderList.add("Summary");
			treeViewvFolderIdsList.add("534");
		}
		if(treeViewList.contains("602") ){
			treeViewvFolderList.add("Fatal Errors/Manual Rejects");
			treeViewvFolderIdsList.add("602");
		}
		
		if(treeViewList.contains("880") || treeViewList.contains("881") || treeViewList.contains("882") || treeViewList.contains("883") || treeViewList.contains("884") || treeViewList.contains("885") || treeViewList.contains("886") ){
			treeViewvFolderList.add("Confirmation");
			treeViewvFolderIdsList.add("880");
		}
		if(treeViewList.contains("894") && treeViewList.contains("895")){
			treeViewvFolderList.add("Completion");
			treeViewvFolderIdsList.add("894");
		}
		if(treeViewList.contains("890") && treeViewList.contains("898")){
			treeViewvFolderList.add("Completion");
			treeViewvFolderIdsList.add("890");
		}
		if(treeViewList.contains("893") && treeViewList.contains("897")){
			treeViewvFolderList.add("Completion");
			treeViewvFolderIdsList.add("893");
		}
		
		if(treeViewList.contains("586") ){
			treeViewvFolderList.add("Post To Bill View");
			treeViewvFolderIdsList.add("586");
		}
		
		
		if(treeViewList.contains("583") || treeViewList.contains("584")){
				treeViewvFolderList.add("Jeopardy View");
				treeViewvFolderIdsList.add("583");
		}
		
		/*
		some remaining
		*/
		
		if(treeViewList.contains("543") ){
			treeViewvFolderList.add("AT&#38T Initiated Cancel Task");
			treeViewvFolderIdsList.add("543");
		}
		if(treeViewList.contains("530") ){
			treeViewvFolderList.add("Notes/FUP");
			treeViewvFolderIdsList.add("530");
		}
		
		//history
		if(treeViewList.contains("535") ){
			treeViewvFolderList.add("Field Data Changes");
			treeViewvFolderIdsList.add("535");
		}
		if(treeViewList.contains("536") ){
			treeViewvFolderList.add("Interface Messages");
			treeViewvFolderIdsList.add("536");
		}
		if(treeViewList.contains("537") ){
			treeViewvFolderList.add("Service Order History");
			treeViewvFolderIdsList.add("537");
		}
		if(treeViewList.contains("538") ){
			treeViewvFolderList.add("Exception Messages");
			treeViewvFolderIdsList.add("538");
		}
		if(treeViewList.contains("539") ){
			treeViewvFolderList.add("Addl Info");
			treeViewvFolderIdsList.add("539");
		}
		
		//Follow Up
		
		nameAndIds.add(treeViewvFolderList);
		nameAndIds.add(treeViewvFolderIdsList);
		
		return nameAndIds;
	}

	@RequestMapping(value = "/treeviewRefresh",method = RequestMethod.POST)
	public String refreshTreeview(@RequestBody String lsr,HttpSession session,ModelMap model)
	{
		String statesIdentity = session.getAttribute("States") == null ? "":  (String) session.getAttribute("States");
		System.out.println();
		session.setAttribute("Lrs_No", lsr);
		System.out.print("In Refresh: " + statesIdentity);
		treeView_12StateService.clearMQResponse(session);
		completionselectOkPopup(model, session);
		if (statesIdentity.equalsIgnoreCase("Y")) {
			return "redirect:/treeViewDisplay";
		} else {
			return "redirect:/treeview9states";
		}
	}
}