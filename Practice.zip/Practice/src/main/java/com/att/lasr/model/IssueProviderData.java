package com.att.lasr.model;

import java.util.ArrayList;
import java.util.List;

import com.att.lasr.utils.Constants;
import com.att.lasr.utils.FormatUtil;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@ToString
public class IssueProviderData {
	private Header header;
	private SubHeader subHeader;
	private String losing_cc;
	private String lsr_no;
	private String gaining_cc;
	private String message;

	private List<IssueProviderTableRow> IssueProviderTableRows = new ArrayList<>();

	public String getIssueProviderDataString() {
		StringBuilder IssueProviderDataSb = new StringBuilder();
		IssueProviderDataSb.append(FormatUtil.getValueWithSpaces(losing_cc, 4)).append(Constants.TAB);
		IssueProviderDataSb.append(FormatUtil.getValueWithSpaces(lsr_no, 14)).append(Constants.TAB);

		IssueProviderDataSb.append(FormatUtil.getValueWithSpaces(gaining_cc, 4)).append(Constants.TAB);
		IssueProviderDataSb.append(FormatUtil.getValueWithSpaces(message, 6)).append(Constants.TAB);

		String IssueProviderDataString = FormatUtil.getValueWithSpaces(IssueProviderDataSb.toString(), 2400);
		return IssueProviderDataString;

	}

}
