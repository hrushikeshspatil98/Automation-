package com.att.lasr.model;

import java.util.List;

import com.att.lasr.utils.Constants;
import com.att.lasr.utils.FormatUtil;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@ToString
public class LscNoteDTO {
	private String notesDatetime;
	private String userIdAttr;
	private String userId;
	private String lasrVerAttr;
	private String lasrVer;
	private String followUpDateAttr;
	private String followUpDate;
	private String notesAttr;
	private String notes; 
	private List<ManualRejectDTO> manualRejectDTOList;


	public String getLscNoteDTODataString() {
		StringBuilder lscNoteDTODataSb = new StringBuilder();
		lscNoteDTODataSb.append(FormatUtil.getValueWithSpaces(notesDatetime, 17)).append(Constants.TAB);
		lscNoteDTODataSb.append(FormatUtil.getValueWithSpaces(userIdAttr, 1)).append(Constants.TAB);
		lscNoteDTODataSb.append(FormatUtil.getValueWithSpaces(userId, 7)).append(Constants.TAB);
		lscNoteDTODataSb.append(FormatUtil.getValueWithSpaces(lasrVerAttr, 1)).append(Constants.TAB);
		lscNoteDTODataSb.append(FormatUtil.getValueWithSpaces(lasrVer, 2)).append(Constants.TAB);
		lscNoteDTODataSb.append(FormatUtil.getValueWithSpaces(followUpDateAttr, 1)).append(Constants.TAB);		
		lscNoteDTODataSb.append(FormatUtil.getValueWithSpaces(followUpDate, 8)).append(Constants.TAB);		
		lscNoteDTODataSb.append(FormatUtil.getValueWithSpaces(notesAttr, 1)).append(Constants.TAB);
		
		
		lscNoteDTODataSb.append(FormatUtil.getValueWithSpaces(notes, 2300)).append(Constants.TAB).append(Constants.TAB);
		String lscNoteRequestDataString = FormatUtil.getValueWithSpaces(lscNoteDTODataSb.toString(), 2400);
		return lscNoteRequestDataString;
	}

}
