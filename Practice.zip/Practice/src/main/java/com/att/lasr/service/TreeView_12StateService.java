/**
 * 
 */
package com.att.lasr.service;

import java.util.ArrayList;
import java.util.Enumeration;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.nimbusds.oauth2.sdk.util.CollectionUtils;

import com.att.lasr.model.*;
import com.att.lasr.utils.FormatUtil;
import com.att.lasr.utils.MQMessageStringBuilder;
import com.att.lasr.utils.MQReadUtil;
import com.att.lasr.utils.MQWriteUtil;
import com.att.lasr.utils.enums.LastInd;
import com.att.lasr.utils.enums.LogInd;
import com.att.lasr.utils.enums.Process;
import com.att.lasr.utils.enums.ProcessGroupInd;
import com.att.lasr.utils.enums.ProcessMode;
import com.att.lasr.utils.enums.RecIdFor12State;
import com.att.lasr.utils.enums.RecIdFor9State;
import com.att.lasr.utils.enums.TabInd;

@Service
public class TreeView_12StateService {
	@Autowired
	private MQReadUtil mqReadUtil;

	@Autowired
	private MQWriteUtil mqWriteUtil;

	List<ShowError> showError = new ArrayList<ShowError>();
	ErrorCodeData errorCodeData = new ErrorCodeData();
	ShowErrorService showErrorService = new ShowErrorService();
	List<ShowError> focError = new ArrayList<ShowError>();

	// =============================sneha ================================

	public ConformationTaskMain writeSelectedRequestPostToBill(ConformationTaskMain conformationTaskMain,
			String user_id, String object_handle, HttpSession session) {

		Header header = null;
		SubHeader subHeader = null;
		StringBuilder subHeaderandData = new StringBuilder();
		System.out.println("Service:::111:inside:user_id::user_id::::" + user_id);
		String dataString049 = "";

		int count = 0000;
		focError.clear();
		List<NotesFupBindingData9States> conformationList_049 = conformationTaskMain.getNotesFupBindingData9States();

		List<NotesFupBindingData12States> conformationList_12States = (List<NotesFupBindingData12States>) session
				.getAttribute("treeViewList_049");

		String dataString585 = "";
		String dataString588 = "";
		List<PostToBillTask_RecId585> postToBillTask9_585 = conformationTaskMain.getPostToBillTask_RecId585();

		List filterRecidList = (ArrayList) session.getAttribute("treeViewList");
		MQMessageStringBuilder mqMessageStringBuilder = new MQMessageStringBuilder();
		String statesIdentity = (String) session.getAttribute("States");
		if (filterRecidList.contains("049")) {

			if (statesIdentity.equalsIgnoreCase("Y")) {
				for (NotesFupBindingData12States notesFupBindingData9States : conformationList_12States) {
					count++;
					session.setAttribute("Lrs_No", notesFupBindingData9States.getRequest_id().substring(0, 17).trim());
//			                System.out.println("::::::susheel:val 999999inside for:LrsNo:session::"+session.getAttribute("Lrs_No"));
					dataString049 = notesFupBindingData9States.getNotesFupBindingData12String();
//			                System.out.println("::::::dataString: confirmationTask_RecId_049_new for::::"+dataString049);

				}
			} else {

				for (NotesFupBindingData12States notesFupBindingData9States : conformationList_12States) {
					count++;
					session.setAttribute("Lrs_No", notesFupBindingData9States.getRequest_id().substring(0, 17).trim());
//					System.out.println("::::::susheel:val 999999inside for:LrsNo:session::"+session.getAttribute("Lrs_No"));
					dataString049 = notesFupBindingData9States.getNotesFupBindingData9String();
//					System.out.println("::::::dataString: confirmationTask_RecId_049_new for::::"+dataString049);

				}
			}
		}

		if (filterRecidList.contains("585")) {

			for (PostToBillTask_RecId585 postToBillTask_RecId585_New : postToBillTask9_585) {
				count++;
			}
		}

		if (filterRecidList.contains("049")) {
			String countVal = "";

//				System.out.println("Count:::"+count);
			if (count < 10) {
				System.out.println("less:::");
				countVal = "000" + count;
			}
			if (count >= 10) {
				System.out.println("greater:::");
				countVal = "00" + count;
			}
			System.err.println("::::::Heade count for::::" + countVal);

			header = preparePostToBillHeader(user_id, object_handle, countVal);

			subHeader = prepareSubHeader(RecIdFor9State.CS_RECID_HEADER.getRecIdValue());
			subHeaderandData.append(mqMessageStringBuilder.addHeader(header));
			subHeaderandData.append(mqMessageStringBuilder.appendSubHeaderAndData(subHeader, dataString049.toString()));
		}

		if (filterRecidList.contains("585")) {
			for (PostToBillTask_RecId585 postToBillTask_RecId585_New : postToBillTask9_585) {
				count++;
				if (postToBillTask_RecId585_New.getPd_attr().contains("U")) {
					postToBillTask_RecId585_New.setPd_attr("Y");
				}

				dataString585 = postToBillTask_RecId585_New.getSelectRequest585DataString();

//					System.out.println("::::::dataString: postToBillTask_RecId585 for::::"+dataString585);
				subHeader = prepareSubHeader(RecIdFor9State.CS_RECID_POST_TO_BILL.getRecIdValue());
				subHeaderandData
						.append(mqMessageStringBuilder.appendSubHeaderAndData(subHeader, dataString585.toString()));
			}
		}

//			System.out.println("::::::subHeaderandData:::: for::::"+subHeaderandData.toString());
		String mqMessageString = mqMessageStringBuilder.getMqMessageString();
//			System.out.println("::::::58144444 formqMessageString::::"+mqMessageString);
		boolean isWritten = mqWriteUtil.writeDataToMQString(mqMessageString, session);
		// boolean isWritten = false;
		// String reg= (String) session.getAttribute("myReg");

		if (isWritten) {
			MQReceivedData mqReceivedData = null;

			try {

				mqReceivedData = mqReadUtil.readSortDataFromMQ(session);
				long endTime = System.nanoTime() + TimeUnit.NANOSECONDS.convert(3L, TimeUnit.MINUTES);
				Map<String, SubData> subDatas = mqReceivedData.getSubDatas();
				// Header receivedHeader = mqReceivedData.getHeader();
				while (mqReceivedData.getHeader() == null && System.nanoTime() < endTime) {
//							System.out.println("*************inside if*************** "); 
					mqReceivedData = mqReadUtil.readSortDataFromMQ(session);
				}

//					  System.out.println(mqReceivedData.getHeader().toString()); 
			} catch (Exception e) {
				// TODO Auto-generated catch block
				// mqReceivedData = mqReadUtil.readDataFromMQ(session);
				e.printStackTrace();

			}

			// MQReceivedData mqReceivedData = mqReadUtil.readDataFromMQ(session);
//				System.out.println("::::::mqReceivedData for::::"+mqReceivedData);
			Map<String, SubData> subDatas = mqReceivedData.getSubDatas();
//				System.out.println("::::::subDatas for::::"+subDatas);
			Header receivedHeader = mqReceivedData.getHeader();
			conformationTaskMain.setHeader(receivedHeader);
//				System.out.println("::::::receivedHeader for::::returncode::::"+receivedHeader.getReturn_code());
			SubData subData = subDatas.get(RecIdFor12State.CS_RECID_ERROR.getRecIdValue());
			SubData subData585 = subDatas.get(RecIdFor12State.CS_RECID_POST_TO_BILL.getRecIdValue());
			SubData subData588 = subDatas.get(RecIdFor12State.CS_RECID_POST_TO_BILL_ORD.getRecIdValue());
			SubData subData550 = subDatas.get(RecIdFor9State.CS_RECID_CONFIRM.getRecIdValue());
//				System.out.println("subData: "+ subData);
			if (subData != null) {

				String[] subDataRows = subData.getSubDataRows();
				if (receivedHeader.getReturn_code() != null && receivedHeader.getReturn_code().equals("999")) {
					for (String subDataRow : subDataRows) {

						String[] sentData = subDataRow.split(",");
//					System.out.println("sentData after separation" + sentData);
						for (String a : sentData) {

							ShowErrorService showErrorService = new ShowErrorService();
							ReadErrorMsgsJson readErrorMsgsJson = new ReadErrorMsgsJson();
							String uon_msg = readErrorMsgsJson.getErrorMsg(a.substring(0, 6).trim());

							focError = showErrorService.getErrorListMultiple(a.substring(0, 6).trim(), uon_msg, "", "U",
									focError);

							// focMulipleError.add(focError);
							// session.setAttribute("showError", focError);
//					System.err.println("ERRORS 600*****" + focError.toString());
						}
					}
				}
			}
			if (subData585 != null) {
				String[] subDataRows585 = subData585.getSubDataRows();
				if (receivedHeader.getReturn_code() != null && receivedHeader.getReturn_code().equals("999")) {
					for (String subDataRow : subDataRows585) {

						String[] sentData = subDataRow.split(",");
//					System.out.println("sentData after separation" + sentData);
						for (String a : sentData) {

							ShowErrorService showErrorService = new ShowErrorService();
							ReadErrorMsgsJson readErrorMsgsJson = new ReadErrorMsgsJson();
							String uon_msg = readErrorMsgsJson.getErrorMsg(a.substring(0, 6).trim());

							focError = showErrorService.getErrorListMultiple(a.substring(0, 6).trim(), uon_msg, "", "U",
									focError);

							// focMulipleError.add(focError);
							// session.setAttribute("showError", focError);
//					System.err.println("ERRORS * inside 560" + focError.toString());
						}
					}
				}
			}
			if (subData588 != null) {
				String[] subDataRows588 = subData588.getSubDataRows();
				if (receivedHeader.getReturn_code() != null && receivedHeader.getReturn_code().equals("999")) {
					for (String subDataRow : subDataRows588) {

						String[] sentData = subDataRow.split(",");
//					System.out.println("sentData after separation" + sentData);
						for (String a : sentData) {

							ShowErrorService showErrorService = new ShowErrorService();
							ReadErrorMsgsJson readErrorMsgsJson = new ReadErrorMsgsJson();
							String uon_msg = readErrorMsgsJson.getErrorMsg(a.substring(0, 6).trim());

							focError = showErrorService.getErrorListMultiple(a.substring(0, 6).trim(), uon_msg, "", "U",
									focError);

							// focMulipleError.add(focError);
							// session.setAttribute("showError", focError);
//					System.err.println("ERRORS Inside 568 ******" + focError.toString());
						}
					}
				}
			}
			if (subData550 != null) {
				String[] subDataRows550 = subData550.getSubDataRows();
				if (receivedHeader.getReturn_code() != null && receivedHeader.getReturn_code().equals("999")) {
					for (String subDataRow : subDataRows550) {

						String[] sentData = subDataRow.split(",");
//								System.out.println("sentData after separation" + sentData);
						for (String a : sentData) {

							ShowErrorService showErrorService = new ShowErrorService();
							ReadErrorMsgsJson readErrorMsgsJson = new ReadErrorMsgsJson();
							String uon_msg = readErrorMsgsJson.getErrorMsg(a.substring(0, 6).trim());
							String Lsr_no = (String) session.getAttribute("Lrs_No");
//								System.out.println("LSR no==="+Lsr_no);

							focError = showErrorService.getErrorListMultiple(a.substring(0, 6).trim(), uon_msg, "",
									"lsrn=" + Lsr_no + " " + "unknown", focError);

							// focMulipleError.add(focError);
							// session.setAttribute("showError", focError);
//								System.err.println("ERRORS *550*****" + focError.toString());
						}
					}
				}
			}

			session.setAttribute("showError", focError);

		}
		return conformationTaskMain;

	}
	// =============================sneha End===================

	public List<String> writeSelectedRequestDataToTreeView(SelectRequestData selectRequestData, String user_id,
			HttpSession session, String object_handle, List treeViewList) {
		// Added By Hrushi- To remove session objects
		clearTreeviewSessionObjects(session);
		// treeViewList
		Header header = prepareTreeHeader(user_id, object_handle, Process.CS_REQUEST.getProcessCode());
		SubHeader subHeader = prepareTreeSubHeader();
		selectRequestData.setPrevnext_cde("R");
		List<SelectRequestTableRow> selectedRequestTableRow = selectRequestData.getSelectRequestTableRows();
		// String dataString = selectRequestData.getSelectRequestDataString();
		String dataString = "";
		// List<String> treeViewList = new ArrayList<String>();
		MQMessageStringBuilder mqMessageStringBuilder = new MQMessageStringBuilder();
		for (SelectRequestTableRow selectRequestTableRow : selectedRequestTableRow) {
			String tabValue = "N";
			dataString = selectRequestTableRow.getSelectRequestTreeDataString(tabValue);

			mqMessageStringBuilder.addHeaderSubHeaderAndData(header, subHeader, dataString);

		}

		// Start: Clear Old Response in Q if exists - Hrushikesh
		MQDetails mqDetFromSession = mqWriteUtil.getMqDetailsFromSession(session);
		ClearUserMQResponse readQ = new ClearUserMQResponse();
		try {
			boolean isRespCleared = readQ.read(session, mqDetFromSession);
			long endTime = System.nanoTime() + TimeUnit.NANOSECONDS.convert(1L, TimeUnit.MINUTES);
			while (isRespCleared && System.nanoTime() < endTime) {
				System.out.println("Treeview - Inside Clear... User ID is: " + user_id == null ? "" : user_id);
				isRespCleared = readQ.read(session, mqDetFromSession);
			}
		} catch (Exception e) {
			System.out.println("Treeview - Clear Response Exp: " + e.getMessage());
		} // end
		
		boolean isWritten = mqWriteUtil.writeDataToMQ(mqMessageStringBuilder, session);
		System.out.println("++++isWritten++++++" + isWritten);
		if (isWritten) {

			MQReceivedData mqReceivedData = null;
			try {

				mqReceivedData = mqReadUtil.readSortDataFromMQ(session);
				long endTime = System.nanoTime() + TimeUnit.NANOSECONDS.convert(3L, TimeUnit.MINUTES);
				Map<String, SubData> subDatas = mqReceivedData.getSubDatas();
				// Header receivedHeader = mqReceivedData.getHeader();
				while (mqReceivedData.getHeader() == null && System.nanoTime() < endTime) {
					System.out.println("*************inside if*************** ");
					mqReceivedData = mqReadUtil.readSortDataFromMQ(session);
				}

//			  System.out.println(mqReceivedData.getHeader().toString()); 
			} catch (Exception e) {
				e.printStackTrace();
			}
			Map<String, SubData> subDatas = mqReceivedData.getSubDatas();
			Header receivedHeader = mqReceivedData.getHeader();
			selectRequestData.setHeader(receivedHeader);
			
			if(receivedHeader == null)
			{
				receivedHeader = new Header();
				receivedHeader.setReturn_code("555");
			}
			if(receivedHeader.getReturn_code()!=null && receivedHeader.getReturn_code().equals("888") || receivedHeader.getReturn_code().equals("889") || receivedHeader.getReturn_code().equals("555"))
			{
				String returnCode = receivedHeader.getReturn_code();
				System.out.println("returnCode: "+returnCode);
				session.setAttribute("err_rc", returnCode);
				session.setAttribute("LrsNo", selectedRequestTableRow.get(0).getRequest_id());
				session.setAttribute("status", selectedRequestTableRow.get(0).getStatus());
				return new ArrayList<String>();
			}
			else
			{
				session.setAttribute("err_rc", "");
			}
			
			// vipul
			SubData subData_049Recid = subDatas.get(RecIdFor12State.CS_RECID_HEADER.getRecIdValue());
			// Rupa
			List treeViewList160 = new ArrayList();
			List treeViewList161 = new ArrayList();
			List treeViewList105 = new ArrayList();
			List treeViewList106 = new ArrayList();
			List treeViewList050 = new ArrayList();
			List treeViewList100 = new ArrayList();
			List treeViewList154 = new ArrayList();
			List treeViewList570 = new ArrayList();
			SubData subData_570Recid = subDatas.get(RecIdFor12State.CS_RECID_REJECT_SUMM.getRecIdValue());

			SubData subData_105Recid = subDatas.get(RecIdFor12State.CS_RECID_DISCONNECT.getRecIdValue());
			SubData subData_106Recid = subDatas.get(RecIdFor12State.CS_RECID_TC.getRecIdValue());
			SubData subData_154Recid = subDatas.get(RecIdFor12State.CS_RECID_ACCT_FEATURES.getRecIdValue());
			SubData subData_160Recid = subDatas.get(RecIdFor12State.CS_RECID_HUNTING.getRecIdValue());
			SubData subData_161Recid = subDatas.get(RecIdFor12State.CS_RECID_HUNTING_DETAIL.getRecIdValue());
			SubData subData_050Recid = subDatas.get(RecIdFor12State.CS_RECID_LSR.getRecIdValue());
			SubData subData_060Recid = subDatas.get(RecIdFor12State.CS_RECID_LSR_SUPP.getRecIdValue());
			SubData subData_100Recid = subDatas.get(RecIdFor12State.CS_RECID_END_USER.getRecIdValue());

			// Amit
			SubData subData_420Recid = subDatas.get(RecIdFor12State.CS_RECID_DELIVERY_ADDRESS.getRecIdValue());
			SubData subData_430Recid = subDatas.get(RecIdFor12State.CS_RECID_LISTING.getRecIdValue());
			SubData subData_435Recid = subDatas.get(RecIdFor12State.CS_RECID_LISTING_TEXT.getRecIdValue());
			SubData subData_436Recid = subDatas.get(RecIdFor12State.CS_RECID_LISTING_TEXT_DTL.getRecIdValue());
			SubData subData_440Recid = subDatas.get(RecIdFor12State.CS_RECID_CAPTION.getRecIdValue());

			// Shalu
			List treeViewList_150 = new ArrayList();
			List treeViewList_107 = new ArrayList();
			List treeViewList_350 = new ArrayList();
			List treeViewList_275 = new ArrayList();

			SubData subData_107Recid = subDatas.get(RecIdFor12State.CS_RECID_PRODUCT_DISCONNECT.getRecIdValue());
			SubData subData_150Recid = subDatas.get(RecIdFor12State.CS_RECID_RESALE.getRecIdValue());
			SubData subData_350Recid = subDatas.get(RecIdFor12State.CS_RECID_PORT.getRecIdValue());
			SubData subData_275Recid = subDatas.get(RecIdFor12State.CS_RECID_LOOPPORT.getRecIdValue());

			// susheel
			SubData subData_500Recid = subDatas.get(RecIdFor12State.CS_RECID_RPL_CKT.getRecIdValue());
			SubData subData_510Recid = subDatas.get(RecIdFor12State.CS_RECID_RPL_PRILOC.getRecIdValue());
			SubData subData_156Recid = subDatas.get(RecIdFor12State.CS_RECID_RPL_FEATURES.getRecIdValue());
			SubData subData_511Recid = subDatas.get(RecIdFor12State.CS_RECID_RPL_SECLOC.getRecIdValue());
			SubData subData_109Recid = subDatas.get(RecIdFor12State.CS_RECID_RPL_SEC_FEATURES.getRecIdValue());
			SubData subData_683Recid = subDatas.get(RecIdFor12State.CS_RECID_CENTREX_COMMONBLOCK.getRecIdValue());
			SubData subData_684Recid = subDatas.get(RecIdFor12State.CS_RECID_CENTREX_STATIONNUMBER.getRecIdValue());
			SubData subData_680Recid = subDatas.get(RecIdFor12State.CS_RECID_CENTREX_RESALE.getRecIdValue());
			SubData subData_155Recid = subDatas.get(RecIdFor12State.CS_RECID_FEATURES.getRecIdValue());
			SubData subData_108Recid = subDatas.get(RecIdFor12State.CS_RECID_PRODUCT_TC.getRecIdValue());
			SubData subData_211Recid = subDatas.get(RecIdFor12State.CS_RECID_TRANS_CALL_TC.getRecIdValue());
			// Rejashekhar
			SubData subData_602Recid = subDatas.get(RecIdFor12State.CS_RECID_LASR_ERRORS.getRecIdValue());
			SubData subData_530Recid = subDatas.get(RecIdFor12State.CS_RECID_NOTES.getRecIdValue());
			SubData subData_250Recid = subDatas.get(RecIdFor12State.CS_RECID_NP.getRecIdValue());
			SubData subData_601Recid = subDatas.get(RecIdFor12State.CS_RECID_ERRORS_MOGAOG.getRecIdValue());
			SubData subData_586Recid = subDatas.get(RecIdFor12State.CS_RECID_POST_TO_BILL_VIEW.getRecIdValue());
			SubData subData_065Recid = subDatas.get(RecIdFor12State.CS_RECID_REMARKS.getRecIdValue());
			SubData subData_534Recid = subDatas.get(RecIdFor12State.CS_RECID_RESPONSE_SUMMARY.getRecIdValue());
			// sneha
			SubData subData_681Recid = subDatas.get(RecIdFor12State.CS_RECID_CENTREX_PORT.getRecIdValue());
			SubData subData_682Recid = subDatas.get(RecIdFor12State.CS_RECID_CENTREX_LOOPPORT.getRecIdValue());
			SubData subData12_585Recid = subDatas.get(RecIdFor12State.CS_RECID_POST_TO_BILL.getRecIdValue());
			SubData subData12_588Recid = subDatas.get(RecIdFor12State.CS_RECID_POST_TO_BILL_ORD.getRecIdValue());

			// Supriya
			SubData subData_800Recid = subDatas.get(RecIdFor12State.CS_RECID_TRUNK_RESALE.getRecIdValue());
			SubData subData_801Recid = subDatas.get(RecIdFor12State.CS_RECID_TRUNK_PORT.getRecIdValue());

			// Rashmita
			SubData subData_802Recid = subDatas.get(RecIdFor12State.CS_RECID_TRUNK_LOOPPORT.getRecIdValue());

			// Saurabh
			SubData subData_640Recid = subDatas.get(RecIdFor12State.CS_RECID_DIDPBX_RESALE.getRecIdValue());

			// Ruby
			SubData subData_212Recid = subDatas.get(RecIdFor12State.CS_RECID_TRANS_CALL_TG.getRecIdValue());
			SubData subData_213Recid = subDatas.get(RecIdFor12State.CS_RECID_TG_TC.getRecIdValue());
			SubData subData_642Recid = subDatas.get(RecIdFor12State.CS_RECID_DIDPBX_LOOPPORT.getRecIdValue());
			SubData subData_641Recid = subDatas.get(RecIdFor12State.CS_RECID_DIDPBX_PORT.getRecIdValue());
			// Mahendra
			SubData subData_543Recid = subDatas.get(RecIdFor12State.CS_RECID_DISPLAY_SBC_CANCEL.getRecIdValue());

			// Aprajita
			List treeViewList_841 = new ArrayList(); // ISDN port ius channel_841(12states)
			List treeViewList_157 = new ArrayList(); // F_ feature detail _157(12state)
			List treeViewList_159 = new ArrayList(); // channel feature _159(12States)
			List treeViewList_210 = new ArrayList(); // isdn port pri disc tn _210(tnnum_12states)

			List treeViewList_158 = new ArrayList(); // trunkgrp tgfeature_158 (12States)
			List treeViewList_842 = new ArrayList(); // loopport IUS channel_842(12States)

			SubData subData_841Recid = subDatas.get(RecIdFor12State.CS_RECID_ISDN_PORT.getRecIdValue());
			SubData subData_159Recid = subDatas.get(RecIdFor12State.CS_RECID_CHAN_FEATURES.getRecIdValue());
			SubData subData_210Recid = subDatas.get(RecIdFor12State.CS_RECID_TRANS_CALL_TN.getRecIdValue());
			SubData subData_157Recid = subDatas.get(RecIdFor12State.CS_RECID_F_FEATURES.getRecIdValue());

			SubData subData_842Recid = subDatas.get(RecIdFor12State.CS_RECID_ISDN_LOOPPORT.getRecIdValue());
			SubData subData_158Recid = subDatas.get(RecIdFor12State.CS_RECID_TG_FEATURES.getRecIdValue());

			// nisha
			SubData subData_889Recid = subDatas.get(RecIdFor12State.CS_RECID_DISPLAY_CONFIRM_ECVER_V6.getRecIdValue());
			SubData subData_890Recid = subDatas.get(RecIdFor12State.CS_RECID_DISPLAY_COMPLETE_FIX_V6.getRecIdValue());
			SubData subData_898Recid = subDatas
					.get(RecIdFor12State.CS_RECID_DISPLAY_COMPLETE_REQORD_V6.getRecIdValue());
			SubData subData_894Recid = subDatas.get(RecIdFor12State.CS_RECID_DISPLAY_COMPLETE_DIR_V6.getRecIdValue());
			SubData subData_895Recid = subDatas
					.get(RecIdFor12State.CS_RECID_DISPLAY_COMPLETE_DIRDTL_V6.getRecIdValue());
			SubData subData_560Recid = subDatas.get(RecIdFor12State.CS_RECID_COMPLETE.getRecIdValue());
			SubData subData_568Recid = subDatas.get(RecIdFor12State.CS_RECID_COMPLETE_REQORD.getRecIdValue());
			SubData subData_563Recid = subDatas.get(RecIdFor12State.CS_RECID_COMPLETE_RCDORD.getRecIdValue());
			SubData subData_567Recid = subDatas.get(RecIdFor12State.CS_RECID_COMPLETE_ACTR_LSC.getRecIdValue());
			SubData subData_577Recid = subDatas.get(RecIdFor12State.CS_RECID_LOSS_LSR_INFO.getRecIdValue());
			SubData subData_578Recid = subDatas.get(RecIdFor12State.CS_RECID_LOSS_INFO.getRecIdValue());
			SubData subData_893Recid = subDatas.get(RecIdFor12State.CS_RECID_DISPLAY_COMPLETE_ACTR_V6.getRecIdValue());
			SubData subData_897Recid = subDatas
					.get(RecIdFor12State.CS_RECID_DISPLAY_COMPLETE_ACTR_LSC_V6.getRecIdValue());

			// Divya
			SubData subData_884Recid = subDatas.get(RecIdFor12State.CS_RECID_DISPLAY_CONFIRM_DIR_V6.getRecIdValue());
			SubData subData_883Recid = subDatas.get(RecIdFor12State.CS_RECID_DISPLAY_CONFIRM_ACTR_V6.getRecIdValue());
			SubData subData_887Recid = subDatas
					.get(RecIdFor12State.CS_RECID_DISPLAY_CONFIRM_ACTR_LSC_V6.getRecIdValue());

			SubData subData_888Recid = subDatas.get(RecIdFor12State.CS_RECID_DISPLAY_CONFIRM_REQORD_V6.getRecIdValue());
			SubData subData_880Recid = subDatas.get(RecIdFor12State.CS_RECID_DISPLAY_CONFIRM_FIX_V6.getRecIdValue());
			SubData subData_881Recid = subDatas.get(RecIdFor12State.CS_RECID_DISPLAY_CONFIRM_HUNT_V6.getRecIdValue());
			SubData subData_882Recid = subDatas.get(RecIdFor12State.CS_RECID_DISPLAY_CONFIRM_DTL_V6.getRecIdValue());

			SubData subData_885Recid = subDatas.get(RecIdFor12State.CS_RECID_DISPLAY_CONFIRM_CAN_V6.getRecIdValue());
			SubData subData_886Recid = subDatas.get(RecIdFor12State.CS_RECID_DISPLAY_CONFIRM_NOPROD_V6.getRecIdValue());

			// Nitin
			SubData subData_538Recid = subDatas.get(RecIdFor12State.CS_RECID_HISTORY_EXCEPTION.getRecIdValue());

			SubData subData_535Recid = subDatas.get(RecIdFor12State.CS_RECID_HISTORY.getRecIdValue());
			SubData subData_537Recid = subDatas.get(RecIdFor12State.CS_RECID_HISTORY_SORD.getRecIdValue());
			SubData subData_536Recid = subDatas.get(RecIdFor12State.CS_RECID_HISTORY_INTERFACE.getRecIdValue());
			SubData subData_539Recid = subDatas.get(RecIdFor12State.CS_RECID_HISTORY_DERIVED_DATA.getRecIdValue());
			SubData subData_583Recid = subDatas.get(RecIdFor12State.CS_RECID_JEOPARDY_DETAIL.getRecIdValue());
			SubData subData_584Recid = subDatas.get(RecIdFor12State.CS_RECID_JEOPARDY_VIEW.getRecIdValue());

			// System.out.println("++++subData_538Recid++++++" + subData_538Recid);
			// method
			treeViewList = requestTypeC_Z_12State(selectRequestData, subDatas, session, treeViewList);
			treeViewList = confirmationTaskGeneral(selectRequestData, subDatas, session, treeViewList);
			treeViewList = correctingConfTaskNoProd(selectRequestData, subDatas, session, treeViewList);
			treeViewList = confirmationTaskNoProd12(selectRequestData, subDatas, session, treeViewList);
			treeViewList = Correctingconfirmationtaskmain12states(selectRequestData, subDatas, session, treeViewList);
			// Hrushikesh
			SubData subData_672Recid = subDatas.get(RecIdFor12State.CS_RECID_UPDATE_ECCKTS.getRecIdValue());
			SubData subData_668Recid = subDatas.get(RecIdFor12State.CS_RECID_UPDATE_COMPLETE_REQORD.getRecIdValue());
			SubData subData_658Recid = subDatas.get(RecIdFor12State.CS_RECID_UPDATE_CONFIRM_REQORD.getRecIdValue());
			SubData subData_652Recid = subDatas.get(RecIdFor12State.CS_RECID_UPDATE_CONFIRM_DTL.getRecIdValue());
			SubData subData_544Recid = subDatas.get("544");

			// yash
			// 10252021
			SubData subData_540Recid = subDatas.get(RecIdFor12State.CS_RECID_ISSUE_RESEND.getRecIdValue());
			// Supriya
			treeViewList = jeopardyTaskListData(selectRequestData, subDatas, session, treeViewList);
			// In writeTreeViewService
			// rks 570
			///////////////////////////// 570/////////////////////////////
			if (subData_570Recid != null && subData_570Recid.getSubHeader().getRecord_type().equals("570")) {
				// List<FollowUpData9States> treeViewList_549 = new ArrayList();
				SubHeader receivedSubHeader = subData_570Recid.getSubHeader();
				String[] subDataRows = subData_570Recid.getSubDataRows();
				// System.out.println("subdata rks for 570 for 12 states" +
				// Arrays.toString(subDataRows));
				treeViewList.add("570");

			}

			// Edit Order Number
			List<String> editOrderRecIdList = setEditOrderData(subData_658Recid, subData_652Recid, session,
					selectRequestData);
			for (String recid : editOrderRecIdList) {
				treeViewList.add(recid);
			}

			// Edit Ecckt
			if (subData_672Recid != null && subData_672Recid.getSubHeader().getRecord_type().equals("672")) {

				SubHeader receivedSubHeader = subData_672Recid.getSubHeader();
				String[] subDataRows = subData_672Recid.getSubDataRows();
				List<EditEccktTableRow> treeViewList_672 = new ArrayList<EditEccktTableRow>();
				treeViewList.add("672");
				for (String subDataRow : subDataRows) {
					String[] attributes = mqReadUtil.getAttributes(subDataRow, 42);
					// System.out.println("subData_672Recid======> " + Arrays.toString(attributes));

					EditEccktTableRow editEccktTableRow = new EditEccktTableRow();

					editEccktTableRow.setItemnum(attributes[0]);
					editEccktTableRow.setLnum(attributes[1]);
					editEccktTableRow.setNumname(attributes[2]);
					editEccktTableRow.setNum_nbr(attributes[3]);
					editEccktTableRow.setOrd_attr(attributes[4]);
					editEccktTableRow.setOrd(attributes[5]);
					editEccktTableRow.setLord_attr(attributes[6]);
					editEccktTableRow.setLord(attributes[7]);
					editEccktTableRow.setFdt_attr(attributes[8]);
					editEccktTableRow.setFdt(attributes[9]);
					editEccktTableRow.setDd_attr(attributes[10]);
					editEccktTableRow.setDd(attributes[11]);
					editEccktTableRow.setEcckt_attr(attributes[12]);
					editEccktTableRow.setEcckt(attributes[13]);
					editEccktTableRow.setCkr(attributes[14]);
					editEccktTableRow.setShared_nbr(attributes[15]);
					editEccktTableRow.setDisc_nbr(attributes[16]);
					editEccktTableRow.setRecckt(attributes[17]);
					editEccktTableRow.setTns_attr(attributes[18]);
					editEccktTableRow.setTns(attributes[19]);
					editEccktTableRow.setTers_attr(attributes[20]);
					editEccktTableRow.setTers(attributes[21]);
					editEccktTableRow.setCfa(attributes[22]);
					editEccktTableRow.setCcea(attributes[23]);
					editEccktTableRow.setIspid_attr(attributes[24]);
					editEccktTableRow.setIspid(attributes[25]);
					editEccktTableRow.setFecckt_attr(attributes[26]);
					editEccktTableRow.setFecckt(attributes[27]);
					editEccktTableRow.setNpord_attr(attributes[28]);
					editEccktTableRow.setNpord(attributes[29]);
					editEccktTableRow.setPorted_nbr(attributes[30]);
					editEccktTableRow.setRti_attr(attributes[31]);
					editEccktTableRow.setRti(attributes[32]);
					editEccktTableRow.setCbcid_attr(attributes[33]);
					editEccktTableRow.setCbcid(attributes[34]);
					editEccktTableRow.setCableid_attr(attributes[35]);
					editEccktTableRow.setCableid(attributes[36]);
					editEccktTableRow.setChan_pair_attr(attributes[37]);
					editEccktTableRow.setChan_pair(attributes[38]);
					editEccktTableRow.setOld_ord(attributes[39]);
					editEccktTableRow.setOld_lord(attributes[40]);
					editEccktTableRow.setOld_npord(attributes[41]);

					treeViewList_672.add(editEccktTableRow);

				}
				// editEccktData.setEditEccktTableRows(editEccktTableRows);
				session.setAttribute("treeViewList_672", treeViewList_672);
				selectRequestData.setSubHeader(receivedSubHeader);

			}

			// yash
			// yash
			if (subData_544Recid != null && subData_544Recid.getSubHeader().getRecord_type().equals("544")) {
				// List<FollowUpData9States> treeViewList_549 = new ArrayList();
				SubHeader receivedSubHeader = subData_544Recid.getSubHeader();
				String[] subDataRows = subData_544Recid.getSubDataRows();
				treeViewList.add("544");

			}

			// 10252021
			if (subData_540Recid != null && subData_540Recid.getSubHeader().getRecord_type().equals("540")) {
				// List<FollowUpData9States> treeViewList_549 = new ArrayList();
				SubHeader receivedSubHeader = subData_540Recid.getSubHeader();
				String[] subDataRows = subData_540Recid.getSubDataRows();
				treeViewList.add("540");

				for (String subDataRow : subDataRows) {
					String[] attributes = mqReadUtil.getAttributes(subDataRow, 9);

					session.setAttribute("recid_40Data", attributes);

				}

			}
			// Update Order Number

			if (subData_668Recid != null && subData_668Recid.getSubHeader().getRecord_type().equals("668")) {

				SubHeader receivedSubHeader = subData_668Recid.getSubHeader();
				String[] subDataRows = subData_668Recid.getSubDataRows();
				List<UpdateOrderNumberRow> treeViewList_668 = new ArrayList<UpdateOrderNumberRow>();
				treeViewList.add("668");
				for (String subDataRow : subDataRows) {
					String[] attributes = mqReadUtil.getAttributes(subDataRow, 14);
					// System.out.println("subData_668Recid======> " + Arrays.toString(attributes));

					UpdateOrderNumberRow updateOrderNumberRow = new UpdateOrderNumberRow();

					updateOrderNumberRow.setOld_dtm(attributes[0]);
					updateOrderNumberRow.setOld_ord(attributes[1]);
					updateOrderNumberRow.setOrd_attr(attributes[2]);
					updateOrderNumberRow.setOrd(attributes[3]);
					updateOrderNumberRow.setFdt_attr(attributes[4]);
					updateOrderNumberRow.setFdt(attributes[5]);
					updateOrderNumberRow.setDd_attr(attributes[6]);
					updateOrderNumberRow.setDd(attributes[7]);
					updateOrderNumberRow.setComp_dt_attr(attributes[8]);
					updateOrderNumberRow.setComp_dt(attributes[9]);
					updateOrderNumberRow.setPosted_date_attr(attributes[10]);
					updateOrderNumberRow.setPosted_date(attributes[11]);
					updateOrderNumberRow.setApptime_attr(attributes[12]);
					updateOrderNumberRow.setApptime(attributes[13]);

					treeViewList_668.add(updateOrderNumberRow);

				}
				// editEccktData.setEditEccktTableRows(editEccktTableRows);
				session.setAttribute("treeViewList_668", treeViewList_668);
				selectRequestData.setSubHeader(receivedSubHeader);

			}

			// Hrushikesh Code End

			// Vipul

			// Shalu-changed for rec id 049
			if (subData_049Recid != null && subData_049Recid.getSubHeader().getRecord_type().equals("049")) {
				SubHeader receivedSubHeader = subData_049Recid.getSubHeader();
				String[] subDataRows = subData_049Recid.getSubDataRows();
				List<NotesFupBindingData12States> treeViewList_049 = new ArrayList();
				String lsrNo = "";
				String status = "";
				treeViewList.add("049");
				for (String subDataRow : subDataRows) {
					String[] attributes = mqReadUtil.getAttributes(subDataRow, 10);
					NotesFupBindingData12States noteFupData12 = new NotesFupBindingData12States();
					noteFupData12.setCompany_code(attributes[0]);
					noteFupData12.setDate_time_received(attributes[1]); // (attributes[8].isEmpty() || attributes[8] ==
																		// null ? " " : attributes[8]); //Not getting
																		// data...!
					noteFupData12.setPon(attributes[2]);
					noteFupData12.setRver(attributes[3]);
					noteFupData12.setRequest_id(attributes[4]);
					noteFupData12.setReqtype(attributes[5]);
					noteFupData12.setStatus(attributes[6]);
					noteFupData12.setLspauth_attr(attributes[7]);
					noteFupData12.setLspauth(attributes[8].isEmpty() || attributes[8] == null ? " " : attributes[8]);
					noteFupData12.setCvoip(attributes[9]);
					lsrNo = attributes[4];
					status = attributes[6];
					treeViewList_049.add(noteFupData12);
				}
				selectRequestData.setSubHeader(receivedSubHeader);
				session.setAttribute("treeViewList_049", treeViewList_049);
				String readOnlyIndicator = receivedHeader.getRead_only_ind();
				session.setAttribute("readOnlyIndictaor", readOnlyIndicator);
				if (receivedHeader.getRead_only_ind().equals("Y")) {
					session.setAttribute("LrsNo", lsrNo);
					String Readonly_userid = receivedHeader.getRead_only_user_id();
					session.setAttribute("status", status.concat("***Read Only -Opened by " + Readonly_userid + "***"));
				} else {
					session.setAttribute("LrsNo", lsrNo);
					session.setAttribute("status", status);

				}
			}

			// Rupa
			// Hunting 12 States
			if (subData_160Recid != null && subData_160Recid.getSubHeader().getRecord_type().equals("160")) {

				SubHeader receivedSubHeader = subData_160Recid.getSubHeader();
				String[] subDataRows = subData_160Recid.getSubDataRows();
				treeViewList.add("160");
				// int i = 0;
				for (String subDataRow : subDataRows) {
					String[] attributes = mqReadUtil.getAttributes(subDataRow, 11);
//					//System.out.println("attributes:=160:Reqid======> " + Arrays.toString(attributes));
					LSRHunting160 LSRHunting = new LSRHunting160();

					LSRHunting.setHunt_item_num(attributes[0]);
					LSRHunting.setHnum_attr(attributes[1]);
					LSRHunting.setHnum(attributes[2]);
					LSRHunting.setHa_attr(attributes[3]);
					LSRHunting.setHa(attributes[4]);
					LSRHunting.setHid_attr(attributes[5]);
					LSRHunting.setHid(attributes[6]);
					LSRHunting.setHtli_attr(attributes[7]);
					LSRHunting.setHtli(attributes[8]);
					LSRHunting.setHntyp_attr(attributes[9]);
					LSRHunting.setHntyp(attributes[10]);

					// resaleprivatelinecircuit12states.setScreenName("Circut");

					treeViewList160.add(LSRHunting);
				}
				selectRequestData.setSubHeader(receivedSubHeader);
				// System.out.println("treeViewList160 size() "+treeViewList160.size());

			}

			if (subData_161Recid != null && subData_161Recid.getSubHeader().getRecord_type().equals("161")) {

				SubHeader receivedSubHeader = subData_161Recid.getSubHeader();
				String[] subDataRows = subData_161Recid.getSubDataRows();
				treeViewList.add("161");
				// int i = 0;
				for (String subDataRow : subDataRows) {
					String[] attributes = mqReadUtil.getAttributes(subDataRow, 10);
//					//System.out.println("attributes:=161:Reqid======> " + Arrays.toString(attributes));
					LSRHunting161 LSRHunting = new LSRHunting161();

					LSRHunting.setHid_attr(attributes[0]);
					LSRHunting.setHid(attributes[1]);
					LSRHunting.setHla_attr(attributes[2]);
					LSRHunting.setHla(attributes[3]);
					LSRHunting.setHtseq_attr(attributes[4]);
					LSRHunting.setHtseq(attributes[5]);
					LSRHunting.setHt_attr(attributes[6]);
					LSRHunting.setHt(attributes[7]);
					LSRHunting.setHunt_item_num_attr(attributes[8]);
					LSRHunting.setHunt_item_num(attributes[9]);

					// resaleprivatelinecircuit12states.setScreenName("Circut");

					treeViewList161.add(LSRHunting);
				}
				selectRequestData.setSubHeader(receivedSubHeader);
				// System.out.println("treeViewList161 size() "+treeViewList161.size());

			}

			// EndUser_DISCTC
			if (subData_105Recid != null && subData_105Recid.getSubHeader().getRecord_type().equals("105")) {

				SubHeader receivedSubHeader = subData_105Recid.getSubHeader();
				String[] subDataRows = subData_105Recid.getSubDataRows();
				treeViewList.add("105");
				for (String subDataRow : subDataRows) {
					String[] attributes = mqReadUtil.getAttributes(subDataRow, 18);
					// System.out.println("attributes:=105:Reqid======> " +
					// Arrays.toString(attributes));
					EndUser_DISC_TC103_12States EndUserDiscTc = new EndUser_DISC_TC103_12States();

					EndUserDiscTc.setItem_num(attributes[0]);
					EndUserDiscTc.setDnum_attr(attributes[1]);
					EndUserDiscTc.setDnum(attributes[2]);
					EndUserDiscTc.setDisc_nbr_attr(attributes[3]);
					EndUserDiscTc.setDisc_nbr(attributes[4]);
					EndUserDiscTc.setDisc_ter_attr(attributes[5]);
					EndUserDiscTc.setDisc_ter(attributes[6]);
					EndUserDiscTc.setEu_tc_opt_attr(attributes[7]);
					EndUserDiscTc.setEu_tc_opt(attributes[8]);
					EndUserDiscTc.setEu_tc_per_attr(attributes[9]);
					EndUserDiscTc.setEu_tc_per(FormatUtil.getMqDateAddSlash(attributes[10] != null && attributes[10] != "" ? attributes[10] : " "));// supriya changes 14 feb for date format
					EndUserDiscTc.setEu_tc_to_pri_attr(attributes[11]);
					EndUserDiscTc.setEu_tc_to_pri(FormatUtil.getTelephoneNumberWithDashes(attributes[12] != null && attributes[12] != "" ? attributes[12] : " "));// supriya changes 14 feb for date format
					EndUserDiscTc.setEu_tc_name_pri_attr(attributes[13]);
					EndUserDiscTc.setEu_tc_name_pri(attributes[14]);
					EndUserDiscTc.setEu_tc_id_attr(attributes[15]);
					EndUserDiscTc.setEu_tc_id(attributes[16]);

					treeViewList105.add(EndUserDiscTc);
				}
				selectRequestData.setSubHeader(receivedSubHeader);

			}

			if (subData_106Recid != null && subData_106Recid.getSubHeader().getRecord_type().equals("106")) {

				SubHeader receivedSubHeader = subData_106Recid.getSubHeader();
				String[] subDataRows = subData_106Recid.getSubDataRows();
				treeViewList.add("106");
				// int i = 0;
				for (String subDataRow : subDataRows) {
					String[] attributes = mqReadUtil.getAttributes(subDataRow, 7);
//					//System.out.println("attributes:=161:Reqid======> " + Arrays.toString(attributes));
					EndUser_DISC_TC106_12States EndUserDiscTcGrid = new EndUser_DISC_TC106_12States();

					EndUserDiscTcGrid.setItem_num(attributes[0]);
					EndUserDiscTcGrid.setTc_id_sec_attr(attributes[1]);
					EndUserDiscTcGrid.setTc_id_sec(attributes[2]);
					EndUserDiscTcGrid.setTc_to_sec_attr(attributes[3]);
					EndUserDiscTcGrid.setTc_to_sec(attributes[4]);
					EndUserDiscTcGrid.setTc_name_sec_attr(attributes[5]);
					EndUserDiscTcGrid.setTc_name_sec(attributes[6]);

					treeViewList106.add(EndUserDiscTcGrid);
				}
				selectRequestData.setSubHeader(receivedSubHeader);
				// System.out.println("treeViewList106 size() "+treeViewList106.size());
			}

			// Bill and Contact

			if (subData_050Recid != null && subData_050Recid.getSubHeader().getRecord_type().equals("050")) {

//				SubHeader receivedSubHeader = subData_050Recid.getSubHeader();
//				String[] subDataRows = subData_050Recid.getSubDataRows();
//				treeViewList.add("050");
				getSubData_050Recid(subData_050Recid, treeViewList, selectRequestData, session, treeViewList050);
//				for (String subDataRow : subDataRows) {
//					String[] attributes = mqReadUtil.getAttributes(subDataRow, 109);
//					LSRBillAndContact12States BillAndContact = new LSRBillAndContact12States();
//
//					BillAndContact.setCver_attr(attributes[0]);
//					BillAndContact.setCver(attributes[1]);
//					BillAndContact.setSm(attributes[2]);
//					BillAndContact.setDt_sent(attributes[3]);
//					BillAndContact.setAdm_sc_attr(attributes[4]);
//					BillAndContact.setAdm_sc(attributes[5]);
//					BillAndContact.setDdd_attr(attributes[6]);
//					BillAndContact.setDdd(attributes[7]);
//					BillAndContact.setApptime_attr(attributes[8]);
//					BillAndContact.setApptime(attributes[9]);
//					BillAndContact.setResid_attr(attributes[10]);
//					BillAndContact.setResid(attributes[11]);
//					BillAndContact.setDfdt_attr(attributes[12]);
//					BillAndContact.setDfdt(attributes[13]);
//					BillAndContact.setDddo_attr(attributes[14]);
//					BillAndContact.setDddo(attributes[15]);
//					BillAndContact.setDfdto_attr(attributes[16]);
//					BillAndContact.setDfdto(attributes[17]);
//					BillAndContact.setChc_attr(attributes[18]);
//					BillAndContact.setChc(attributes[19]);
//					BillAndContact.setExp_attr(attributes[20]);
//					BillAndContact.setExp(attributes[21]);
//					BillAndContact.setExprsn_attr(attributes[22]);
//					BillAndContact.setExprsn(attributes[23]);
//					BillAndContact.setAct_attr(attributes[24]);
//					BillAndContact.setAct(attributes[25]);
//					BillAndContact.setSup_attr(attributes[26]);
//					BillAndContact.setSup(attributes[27]);
//					BillAndContact.setTos_attr(attributes[28]);
//					BillAndContact.setTos(attributes[29]);
//					BillAndContact.setAtn_attr(attributes[30]);
//					BillAndContact.setAtn(attributes[31]);
//					BillAndContact.setRtr_attr(attributes[32]);
//					BillAndContact.setRtr(attributes[33]);
//					BillAndContact.setOnsp_attr(attributes[34]);
//					BillAndContact.setOnsp(attributes[35]);
//					BillAndContact.setNnsp_attr(attributes[36]);
//					BillAndContact.setNnsp(attributes[37]);
//					BillAndContact.setNor_attr(attributes[38]);
//					BillAndContact.setNor(attributes[39]);
//					BillAndContact.setRpon_attr(attributes[40]);
//					BillAndContact.setRpon(attributes[41]);
//					BillAndContact.setRord_attr(attributes[42]);
//					BillAndContact.setRord(attributes[43]);
//					BillAndContact.setActl_attr(attributes[44]);
//					BillAndContact.setActl(attributes[45]);
//					BillAndContact.setLst_attr(attributes[46]);
//					BillAndContact.setLst(attributes[47]);
//					BillAndContact.setSpec_attr(attributes[48]);
//					BillAndContact.setSpec(attributes[49]);
//					BillAndContact.setAdm_nc_attr(attributes[50]);
//					BillAndContact.setAdm_nc(attributes[51]);
//					BillAndContact.setAdm_nci_attr(attributes[52]);
//					BillAndContact.setAdm_nci(attributes[53]);
//					BillAndContact.setSecnci_attr(attributes[54]);
//					BillAndContact.setSecnci(attributes[55]);
//					BillAndContact.setAtr_attr(attributes[56]);
//					BillAndContact.setAtr(attributes[57]);
//					BillAndContact.setNena_ecc_attr(attributes[58]);
//					BillAndContact.setNena_ecc(attributes[59]);
//					BillAndContact.setAlbr_attr(attributes[60]);
//					BillAndContact.setAlbr(attributes[61]);
//					BillAndContact.setProject_attr(attributes[62]);
//					BillAndContact.setProject(attributes[63]);
//					BillAndContact.setAgauth_attr(attributes[64]);
//					BillAndContact.setAgauth(attributes[65]);
//					BillAndContact.setBan1_attr(attributes[66]);
//					BillAndContact.setBan1(attributes[67]);
//					BillAndContact.setBan2_attr(attributes[68]);
//					BillAndContact.setBan2(attributes[69]);
//					BillAndContact.setEbp_attr(attributes[70]);
//					BillAndContact.setEbp(attributes[71]);
//					BillAndContact.setVta_attr(attributes[72]);
//					BillAndContact.setVta(attributes[73]);
//					BillAndContact.setInit_attr(attributes[73]);
//					BillAndContact.setInit(attributes[75]);
//					BillAndContact.setTel_no_attr(attributes[76]);
//					BillAndContact.setTel_no(attributes[77]);
//					BillAndContact.setFax_no(attributes[78]);
//					BillAndContact.setImpcon_attr(attributes[79]);
//					BillAndContact.setImpcon(attributes[80]);
//					BillAndContact.setImpcon_telno_attr(attributes[81]);
//					BillAndContact.setImpcon_telno(attributes[82]);
//					BillAndContact.setDrc_attr(attributes[83]);
//					BillAndContact.setDrc(attributes[84]);
//					BillAndContact.setDsgcon(attributes[85]);
//					BillAndContact.setDsgcon_telno_attr(attributes[86]);
//					BillAndContact.setDsgcon_telno(attributes[87]);
//					BillAndContact.setDsgcon_faxno_attr(attributes[88]);
//					BillAndContact.setDsgcon_faxno(attributes[89]);
//					BillAndContact.setActivity(attributes[90]);
//					BillAndContact.setReqtype(attributes[91]);
//					BillAndContact.setPb_sb_ind(attributes[92]);
//					BillAndContact.setNpdi_attr(attributes[93]);
//					BillAndContact.setNpdi(attributes[94]);
//					BillAndContact.setScd_attr(attributes[95]);
//					BillAndContact.setScd(attributes[96]);
//					BillAndContact.setSli_attr(attributes[97]);
//					BillAndContact.setSli(attributes[98]);
//					BillAndContact.setQrynbr_attr(attributes[99]);
//					BillAndContact.setQrynbr(attributes[100]);
//					BillAndContact.setSactl_attr(attributes[101]);
//					BillAndContact.setSactl(attributes[102]);
//					BillAndContact.setAdet_attr(attributes[103]);
//					BillAndContact.setAdet(attributes[104]);
//					BillAndContact.setAn_attr(attributes[105]);
//					BillAndContact.setAn(attributes[106]);
//					BillAndContact.setCcna_attr(attributes[107]);
//					BillAndContact.setCcna(attributes[108]);
//
//					treeViewList050.add(BillAndContact);
//				}
//				selectRequestData.setSubHeader(receivedSubHeader);
				// System.out.println("treeViewList050 size() "+treeViewList050.size());
			}

			// End User

			if (subData_100Recid != null && subData_100Recid.getSubHeader().getRecord_type().equals("100")) {

				SubHeader receivedSubHeader = subData_100Recid.getSubHeader();
				String[] subDataRows = subData_100Recid.getSubDataRows();
				treeViewList.add("100");

				// int i = 0;
				for (String subDataRow : subDataRows) {
					String[] attributes = mqReadUtil.getAttributes(subDataRow, 98);
//					//System.out.println("attributes:=100:Reqid======> " + Arrays.toString(attributes));
					EndUser_12States EndUser = new EndUser_12States();

					EndUser.setItemnum_attr(attributes[0]);
					EndUser.setItemnum(attributes[1]);
					EndUser.setItemnum1_attr(attributes[2]);
					EndUser.setItemnum1(attributes[3]);
					EndUser.setLocnum_attr(attributes[4]);
					EndUser.setLocnum(attributes[5]);
					EndUser.setLocnum1_attr(attributes[6]);
					EndUser.setLocnum1(attributes[7]);
					EndUser.setEu_name_attr(attributes[8]);
					EndUser.setEu_name(attributes[9]);
					EndUser.setEu_eatn_attr(attributes[10]);
					EndUser.setEu_eatn(attributes[11]);
					EndUser.setElt_attr(attributes[12]);
					EndUser.setElt(attributes[13]);
					EndUser.setWsop_attr(attributes[14]);
					EndUser.setWsop(attributes[15]);
					EndUser.setEu_ncon_attr(attributes[16]);
					EndUser.setEu_ncon(attributes[17]);
					EndUser.setEu_aft_attr(attributes[18]);
					EndUser.setEu_aft(attributes[19]);
					EndUser.setEu_sapr_attr(attributes[20]);
					EndUser.setEu_sapr(attributes[21]);
					EndUser.setEu_sapr1_attr(attributes[22]);
					EndUser.setEu_sapr1(attributes[23]);
					EndUser.setEu_sano_attr(attributes[24]);
					EndUser.setEu_sano(attributes[25]);
					EndUser.setEu_sano1_attr(attributes[26]);
					EndUser.setEu_sano1(attributes[27]);
					EndUser.setEu_sasf_attr(attributes[28]);
					EndUser.setEu_sasf(attributes[29]);
					EndUser.setEu_sasf1_attr(attributes[30]);
					EndUser.setEu_sasf1(attributes[31]);
					EndUser.setEu_sasd_attr(attributes[32]);
					EndUser.setEu_sasd(attributes[33]);
					EndUser.setEu_sasd1_attr(attributes[34]);
					EndUser.setEu_sasd1(attributes[35]);
					EndUser.setEu_sasn_attr(attributes[36]);
					EndUser.setEu_sasn(attributes[37]);
					EndUser.setEu_sasn1_attr(attributes[38]);
					EndUser.setEu_sasn1(attributes[39]);
					EndUser.setEu_sath_attr(attributes[40]);
					EndUser.setEu_sath(attributes[41]);
					EndUser.setEu_sath1_attr(attributes[42]);
					EndUser.setEu_sath1(attributes[43]);
					EndUser.setEu_sass_attr(attributes[44]);
					EndUser.setEu_sass(attributes[45]);
					EndUser.setEu_sass1_attr(attributes[46]);
					EndUser.setEu_sass1(attributes[47]);
					EndUser.setEu_ld1_attr(attributes[48]);
					EndUser.setEu_ld1(attributes[49]);
					EndUser.setEu_ld11_attr(attributes[50]);
					EndUser.setEu_ld11(attributes[51]);
					EndUser.setEi_lv1_attr(attributes[52]);
					EndUser.setEu_lv1(attributes[53]);
					EndUser.setEu_lv11_attr(attributes[54]);
					EndUser.setEu_lv11(attributes[55]);
					EndUser.setEu_ld2_attr(attributes[56]);
					EndUser.setEu_ld2(attributes[57]);
					EndUser.setEu_ld22_attr(attributes[58]);
					EndUser.setEu_ld22(attributes[59]);
					EndUser.setEu_lv2_attr(attributes[60]);
					EndUser.setEu_lv2(attributes[61]);
					EndUser.setEu_lv22_attr(attributes[62]);
					EndUser.setEu_lv22(attributes[63]);
					EndUser.setEu_ld3_attr(attributes[64]);
					EndUser.setEu_ld3(attributes[65]);
					EndUser.setEu_ld33_attr(attributes[66]);
					EndUser.setEu_ld33(attributes[67]);
					EndUser.setEu_lv3_attr(attributes[68]);
					EndUser.setEu_lv3(attributes[69]);
					EndUser.setEu_lv33_attr(attributes[70]);
					EndUser.setEu_lv33(attributes[71]);
					EndUser.setEu_aai_attr(attributes[72]);
					EndUser.setEu_aai(attributes[73]);
					EndUser.setEu_aai1_attr(attributes[73]);
					EndUser.setEu_aai1(attributes[75]);
					EndUser.setEu_city_attr(attributes[76]);
					EndUser.setEu_city(attributes[77]);
					EndUser.setEu_city1_attr(attributes[78]);
					EndUser.setEu_city1(attributes[79]);
					EndUser.setEu_state_attr(attributes[80]);
					EndUser.setEu_state(attributes[81]);
					EndUser.setEu_state1_attr(attributes[82]);
					EndUser.setEu_state1(attributes[83]);
					EndUser.setEu_zip_attr(attributes[84]);
					EndUser.setEu_zip(attributes[85]);
					EndUser.setEu_zip1_attr(attributes[86]);
					EndUser.setEu_zip1(attributes[87]);
					EndUser.setEu_lcon_attr(attributes[88]);
					EndUser.setEu_lcon(attributes[89]);
					EndUser.setEu_telno_attr(attributes[90]);
					EndUser.setEu_telno(attributes[91]);
					EndUser.setEu_acc_attr(attributes[92]);
					EndUser.setEu_acc(attributes[93]);
					EndUser.setCpe_mfr_attr(attributes[94]);
					EndUser.setCpe_mfr(attributes[95]);
					EndUser.setCpe_mod_attr(attributes[96]);
					EndUser.setCpe_mod(attributes[97]);

					treeViewList100.add(EndUser);
				}
				selectRequestData.setSubHeader(receivedSubHeader);
				// System.out.println("treeViewList100 size() "+treeViewList100.size());
			}

			if (subData_154Recid != null && subData_154Recid.getSubHeader().getRecord_type().equals("154")) {

				SubHeader receivedSubHeader = subData_154Recid.getSubHeader();
				String[] subDataRows = subData_154Recid.getSubDataRows();
				treeViewList.add("154");
				// int i = 0;
				for (String subDataRow : subDataRows) {
					String[] attributes = mqReadUtil.getAttributes(subDataRow, 7);
//					//System.out.println("attributes:=154:Reqid======> " + Arrays.toString(attributes));
					LSRAdmin_Grid LSRAdmin12_grid = new LSRAdmin_Grid();

					LSRAdmin12_grid.setItem_num(attributes[0]);
					LSRAdmin12_grid.setAfa_attr(attributes[1]);
					LSRAdmin12_grid.setAfa(attributes[2]);
					LSRAdmin12_grid.setAccount_feature_attr(attributes[3]);
					LSRAdmin12_grid.setAccount_feature(attributes[4]);
					LSRAdmin12_grid.setAccount_feature_detail_attr(attributes[5]);
					LSRAdmin12_grid.setAccount_feature_detail(attributes[6]);

					treeViewList154.add(LSRAdmin12_grid);
				}
				selectRequestData.setSubHeader(receivedSubHeader);
				// System.out.println("treeViewList154 size() "+treeViewList154.size());
			}
			session.setAttribute("treeViewList160", treeViewList160);
			// System.out.println("++++treeViewList161+++before session+++" +
			// treeViewList161);
			session.setAttribute("treeViewList161", treeViewList161);
			// System.out.println("++++treeViewList105+++before session+++" +
			// treeViewList105);
			session.setAttribute("treeViewList105", treeViewList105);
			// System.out.println("++++treeViewList106+++before session+++" +
			// treeViewList106);
			session.setAttribute("treeViewList106", treeViewList106);
			// System.out.println("++++treeViewList050+++before session+++" +
			// treeViewList050);
			session.setAttribute("treeViewList050", treeViewList050);
			// System.out.println("++++treeViewList100+++before session+++" +
			// treeViewList100);
			session.setAttribute("treeViewList100", treeViewList100);

			// System.out.println("++++treeViewList154+++before session+++" +
			// treeViewList154);
			session.setAttribute("treeViewList154", treeViewList154);

			// Bharati
			SubData subData_200Recid = subDatas.get(RecIdFor12State.CS_RECID_LOOP.getRecIdValue());
			SubData subData_300Recid = subDatas.get(RecIdFor12State.CS_RECID_LOOPNP.getRecIdValue());
			// System.out.println(subData_200Recid + "#####");

			if (subData_200Recid != null && subData_200Recid.getSubHeader().getRecord_type().equals("200")) {
				getSubData_200RecidData(subData_200Recid,treeViewList,session,selectRequestData);
			}

			if (subData_300Recid != null && subData_300Recid.getSubHeader().getRecord_type().equals("300")) {

				SubHeader receivedSubHeader = subData_300Recid.getSubHeader();
				String[] subDataRows = subData_300Recid.getSubDataRows();
				treeViewList.add("300");
				List<D_Record_Product_loopNP_12States> treeViewList300 = new ArrayList();
				// int i = 0;
				for (String subDataRow : subDataRows) {
					String[] attributes = mqReadUtil.getAttributes(subDataRow, 143);
//					//System.out.println("attributes:=300:Reqid======> " + Arrays.toString(attributes));
					D_Record_Product_loopNP_12States d_Record_Product_loopNP_12States = new D_Record_Product_loopNP_12States();

					d_Record_Product_loopNP_12States.setItem_num(attributes[0]);
					d_Record_Product_loopNP_12States.setLnum_attr(attributes[1]);
					d_Record_Product_loopNP_12States.setLnum(attributes[2]);
					d_Record_Product_loopNP_12States.setLna_attr(attributes[3]);
					d_Record_Product_loopNP_12States.setLna(attributes[4]);
					d_Record_Product_loopNP_12States.setLmt_attr(attributes[5]);
					d_Record_Product_loopNP_12States.setLmt(attributes[6]);
					d_Record_Product_loopNP_12States.setEcckt_attr(attributes[7]);
					d_Record_Product_loopNP_12States.setEcckt(attributes[8]);
					d_Record_Product_loopNP_12States.setShared_nbr_attr(attributes[9]);
					d_Record_Product_loopNP_12States.setShared_nbr(attributes[10]);

					d_Record_Product_loopNP_12States.setDisc_nbr_attr(attributes[11]);
					d_Record_Product_loopNP_12States.setDisc_nbr(attributes[12]);
					d_Record_Product_loopNP_12States.setTers_attr(attributes[13]);
					d_Record_Product_loopNP_12States.setTers(attributes[14]);
					d_Record_Product_loopNP_12States.setCfa_attr(attributes[15]);

					d_Record_Product_loopNP_12States.setCfa(attributes[16]);
					d_Record_Product_loopNP_12States.setCcea_attr(attributes[17]);
					d_Record_Product_loopNP_12States.setCcea(attributes[18]);
					d_Record_Product_loopNP_12States.setSscfa_attr(attributes[19]);
					d_Record_Product_loopNP_12States.setSscfa(attributes[20]);
					d_Record_Product_loopNP_12States.setCableid_attr(attributes[21]);
					d_Record_Product_loopNP_12States.setCableid(attributes[22]);
					d_Record_Product_loopNP_12States.setChan_pair3_attr(attributes[23]);
					d_Record_Product_loopNP_12States.setChan_pair3(attributes[24]);
					d_Record_Product_loopNP_12States.setSystemid_attr(attributes[25]);
					d_Record_Product_loopNP_12States.setSystemid(attributes[26]);
					d_Record_Product_loopNP_12States.setCbcid_attr(attributes[27]);
					d_Record_Product_loopNP_12States.setCbcid(attributes[28]);
					d_Record_Product_loopNP_12States.setChan_pair_attr(attributes[29]);
					d_Record_Product_loopNP_12States.setChan_pair(attributes[30]);
					d_Record_Product_loopNP_12States.setCbcid2_attr(attributes[31]);
					d_Record_Product_loopNP_12States.setCbcid2(attributes[32]);
					d_Record_Product_loopNP_12States.setChan_pair2_attr(attributes[33]);
					d_Record_Product_loopNP_12States.setChan_pair2(attributes[34]);
					d_Record_Product_loopNP_12States.setCti_attr(attributes[35]);
					d_Record_Product_loopNP_12States.setCti(attributes[36]);
					d_Record_Product_loopNP_12States.setRelay_rack_attr(attributes[37]);
					d_Record_Product_loopNP_12States.setRelay_rack(attributes[38]);
					d_Record_Product_loopNP_12States.setShelf_attr(attributes[39]);
					d_Record_Product_loopNP_12States.setShelf(attributes[40]);
					d_Record_Product_loopNP_12States.setSlot_attr(attributes[41]);
					d_Record_Product_loopNP_12States.setSlot(attributes[42]);
					d_Record_Product_loopNP_12States.setCti2_attr(attributes[43]);
					d_Record_Product_loopNP_12States.setCti2(attributes[44]);
					d_Record_Product_loopNP_12States.setRelay_rack2_attr(attributes[45]);
					d_Record_Product_loopNP_12States.setRelay_rack2(attributes[46]);
					d_Record_Product_loopNP_12States.setShelf2_attr(attributes[47]);
					d_Record_Product_loopNP_12States.setShelf2(attributes[48]);
					d_Record_Product_loopNP_12States.setSlot2_attr(attributes[49]);
					d_Record_Product_loopNP_12States.setSlot2(attributes[50]);
					d_Record_Product_loopNP_12States.setCti3_attr(attributes[51]);
					d_Record_Product_loopNP_12States.setCti3(attributes[52]);
					d_Record_Product_loopNP_12States.setRelay_rack3_attr(attributes[53]);
					d_Record_Product_loopNP_12States.setRelay_rack3(attributes[54]);
					d_Record_Product_loopNP_12States.setShelf3_attr(attributes[55]);
					d_Record_Product_loopNP_12States.setShelf3(attributes[56]);
					d_Record_Product_loopNP_12States.setSlot3_attr(attributes[57]);
					d_Record_Product_loopNP_12States.setSlot3(attributes[58]);
					d_Record_Product_loopNP_12States.setCti4_attr(attributes[59]);
					d_Record_Product_loopNP_12States.setCti4(attributes[60]);
					d_Record_Product_loopNP_12States.setRelay_rack4_attr(attributes[61]);
					d_Record_Product_loopNP_12States.setRelay_rack4(attributes[62]);
					d_Record_Product_loopNP_12States.setShelf4_attr(attributes[63]);
					d_Record_Product_loopNP_12States.setShelf4(attributes[64]);
					d_Record_Product_loopNP_12States.setSlot4_attr(attributes[65]);
					d_Record_Product_loopNP_12States.setSlot4(attributes[66]);
					d_Record_Product_loopNP_12States.setVpi_attr(attributes[67]);
					d_Record_Product_loopNP_12States.setVpi(attributes[68]);
					d_Record_Product_loopNP_12States.setVci_attr(attributes[69]);
					d_Record_Product_loopNP_12States.setVci(attributes[70]);
					d_Record_Product_loopNP_12States.setCode_set_attr(attributes[71]);
					d_Record_Product_loopNP_12States.setCode_set(attributes[72]);
					d_Record_Product_loopNP_12States.setRecckt_attr(attributes[73]);
					d_Record_Product_loopNP_12States.setRecckt(attributes[74]);
					d_Record_Product_loopNP_12States.setCkr_attr(attributes[75]);
					d_Record_Product_loopNP_12States.setCkr(attributes[76]);
					d_Record_Product_loopNP_12States.setTsp_attr(attributes[77]);
					d_Record_Product_loopNP_12States.setTsp(attributes[78]);
					d_Record_Product_loopNP_12States.setPorted_nbr_attr(attributes[79]);
					d_Record_Product_loopNP_12States.setPorted_nbr(attributes[80]);
					d_Record_Product_loopNP_12States.setNpt_attr(attributes[81]);
					d_Record_Product_loopNP_12States.setNpt(attributes[82]);
					d_Record_Product_loopNP_12States.setRti_attr(attributes[83]);
					d_Record_Product_loopNP_12States.setRti(attributes[84]);
					d_Record_Product_loopNP_12States.setNptg_attr(attributes[85]);
					d_Record_Product_loopNP_12States.setNptg(attributes[86]);
					d_Record_Product_loopNP_12States.setNpi_attr(attributes[87]);
					d_Record_Product_loopNP_12States.setNpi(attributes[88]);
					d_Record_Product_loopNP_12States.setLst_attr(attributes[89]);
					d_Record_Product_loopNP_12States.setLst(attributes[90]);
					d_Record_Product_loopNP_12States.setTns_attr(attributes[91]);
					d_Record_Product_loopNP_12States.setTns(attributes[92]);
					d_Record_Product_loopNP_12States.setOtn_attr(attributes[93]);
					d_Record_Product_loopNP_12States.setOtn(attributes[94]);
					d_Record_Product_loopNP_12States.setIspid_attr(attributes[95]);
					d_Record_Product_loopNP_12States.setIspid(attributes[96]);
					d_Record_Product_loopNP_12States.setPic_attr(attributes[97]);
					d_Record_Product_loopNP_12States.setPic(attributes[98]);
					d_Record_Product_loopNP_12States.setLpic_attr(attributes[99]);
					d_Record_Product_loopNP_12States.setLpic(attributes[100]);
					d_Record_Product_loopNP_12States.setSsig_attr(attributes[101]);
					d_Record_Product_loopNP_12States.setSsig(attributes[102]);
					d_Record_Product_loopNP_12States.setBa_attr(attributes[103]);
					d_Record_Product_loopNP_12States.setBa(attributes[104]);
					d_Record_Product_loopNP_12States.setBlock_attr(attributes[105]);
					d_Record_Product_loopNP_12States.setBlock(attributes[106]);
					d_Record_Product_loopNP_12States.setJk_code_attr(attributes[107]);
					d_Record_Product_loopNP_12States.setJk_code(attributes[108]);
					d_Record_Product_loopNP_12States.setJk_num_attr(attributes[109]);
					d_Record_Product_loopNP_12States.setJk_num(attributes[110]);
					d_Record_Product_loopNP_12States.setJk_pos_attr(attributes[111]);
					d_Record_Product_loopNP_12States.setJk_pos(attributes[112]);
					d_Record_Product_loopNP_12States.setJr_attr(attributes[113]);
					d_Record_Product_loopNP_12States.setJr(attributes[114]);
					d_Record_Product_loopNP_12States.setNidr_attr(attributes[115]);
					d_Record_Product_loopNP_12States.setNidr(attributes[116]);
					d_Record_Product_loopNP_12States.setIwjk1_attr(attributes[117]);
					d_Record_Product_loopNP_12States.setIwjk1(attributes[118]);
					d_Record_Product_loopNP_12States.setIwjk2_attr(attributes[119]);
					d_Record_Product_loopNP_12States.setIwjk2(attributes[120]);
					d_Record_Product_loopNP_12States.setIwjk3_attr(attributes[121]);
					d_Record_Product_loopNP_12States.setIwjk3(attributes[122]);
					d_Record_Product_loopNP_12States.setIwjk4_attr(attributes[123]);
					d_Record_Product_loopNP_12States.setIwjk4(attributes[124]);
					d_Record_Product_loopNP_12States.setIwjk5_attr(attributes[125]);
					d_Record_Product_loopNP_12States.setIwjk5(attributes[126]);
					d_Record_Product_loopNP_12States.setIwjq1_attr(attributes[127]);
					d_Record_Product_loopNP_12States.setIwjq1(attributes[128]);
					d_Record_Product_loopNP_12States.setIwjq2_attr(attributes[129]);
					d_Record_Product_loopNP_12States.setIwjq2(attributes[130]);
					d_Record_Product_loopNP_12States.setIwjq3_attr(attributes[131]);
					d_Record_Product_loopNP_12States.setIwjq3(attributes[132]);
					d_Record_Product_loopNP_12States.setIwjq4_attr(attributes[133]);
					d_Record_Product_loopNP_12States.setIwjq4(attributes[134]);
					d_Record_Product_loopNP_12States.setIwjq5_attr(attributes[135]);
					d_Record_Product_loopNP_12States.setIwjq5(attributes[136]);
					d_Record_Product_loopNP_12States.setLidb_attr(attributes[137]);
					d_Record_Product_loopNP_12States.setLidb(attributes[138]);
					d_Record_Product_loopNP_12States.setS_attr(attributes[139]);
					d_Record_Product_loopNP_12States.setS(attributes[140]);
					d_Record_Product_loopNP_12States.setOecckt_attr(attributes[141]);
					d_Record_Product_loopNP_12States.setOecckt(attributes[142]);
					// d_Record_Product_loopNP_12States.setScreenName("Circut");

					treeViewList300.add(d_Record_Product_loopNP_12States);
				}
				session.setAttribute("treeViewList300", treeViewList300);
				selectRequestData.setSubHeader(receivedSubHeader);
				// System.out.println("treeViewList300 size() "+treeViewList300.size());

			}

			// Nitin
			if (subData_538Recid != null && subData_538Recid.getSubHeader().getRecord_type().equals("538")) {

				SubHeader receivedSubHeader = subData_538Recid.getSubHeader();
				String[] subDataRows = subData_538Recid.getSubDataRows();
				List<ExceptionHistoryData12State> treeViewList_538 = new ArrayList();
				treeViewList.add("538");

				// int i = 0;
				for (String subDataRow : subDataRows) {
					String[] attributes = mqReadUtil.getAttributes(subDataRow, 4);
//					//System.out.println("attributes:=538:Reqid======> " + Arrays.toString(attributes));
					ExceptionHistoryData12State exceptionHistoryData12State = new ExceptionHistoryData12State();

					exceptionHistoryData12State.setSupp(attributes[0]);
					exceptionHistoryData12State.setDttm_exception_msg(attributes[1]);
					exceptionHistoryData12State.setException_code(attributes[2]);
					exceptionHistoryData12State.setText_msg(attributes[3]);
					treeViewList_538.add(exceptionHistoryData12State);
				}
				selectRequestData.setSubHeader(receivedSubHeader);
				session.setAttribute("treeViewList_538", treeViewList_538);
				// System.out.println("treeViewList_538 size() "+treeViewList_538.size());
			}

			if (subData_536Recid != null && subData_536Recid.getSubHeader().getRecord_type().equals("536")) {

				SubHeader receivedSubHeader = subData_536Recid.getSubHeader();
				String[] subDataRows = subData_536Recid.getSubDataRows();
				List<InterfaceMessagesData12State> treeViewList_536 = new ArrayList();
				treeViewList.add("536");
				// int i = 0;
				for (String subDataRow : subDataRows) {
					String[] attributes = mqReadUtil.getAttributes(subDataRow, 5);
//					//System.out.println("attributes:=536:Reqid======> " + Arrays.toString(attributes));
					InterfaceMessagesData12State interfaceMessagesData12State = new InterfaceMessagesData12State();

					interfaceMessagesData12State.setSupp(attributes[0]);
					interfaceMessagesData12State.setDttm_message(attributes[1]);
					interfaceMessagesData12State.setItem_num(attributes[2]);
					interfaceMessagesData12State.setInter_face(attributes[3]);
					interfaceMessagesData12State.setInterface_status(attributes[4]);

					treeViewList_536.add(interfaceMessagesData12State);
				}
				selectRequestData.setSubHeader(receivedSubHeader);
				session.setAttribute("treeViewList_536", treeViewList_536);
				// selectRequestData.setSelectRequestTableRows(selectRequestTableRows);
				// System.out.println("treeViewList_536 size() "+treeViewList_536.size());
			}

			if (subData_537Recid != null && subData_537Recid.getSubHeader().getRecord_type().equals("537")) {

				SubHeader receivedSubHeader = subData_537Recid.getSubHeader();
				String[] subDataRows = subData_537Recid.getSubDataRows();
				List<ServiceOrderHistoryData12States> treeViewList_537 = new ArrayList();
				treeViewList.add("537");
				// List treeViewList = new ArrayList();
				// int i = 0;
				for (String subDataRow : subDataRows) {
					String[] attributes = mqReadUtil.getAttributes(subDataRow, 7);
//					//System.out.println("attributes:=537======> " + Arrays.toString(attributes));
					ServiceOrderHistoryData12States serviceOrderHistoryData12States = new ServiceOrderHistoryData12States();

					serviceOrderHistoryData12States.setSupp(attributes[0]);
					serviceOrderHistoryData12States.setDttm_entered(attributes[1]);
					serviceOrderHistoryData12States.setOrd(attributes[2]);
					serviceOrderHistoryData12States.setLoc(attributes[3]);
					serviceOrderHistoryData12States.setOrd_stat(attributes[4]);
					serviceOrderHistoryData12States.setDate(attributes[5]);
					serviceOrderHistoryData12States.setOrd_dist_dttm(attributes[6]);

					treeViewList_537.add(serviceOrderHistoryData12States);
				}
				selectRequestData.setSubHeader(receivedSubHeader);
				session.setAttribute("treeViewList_537", treeViewList_537);
				// selectRequestData.setSelectRequestTableRows(selectRequestTableRows);
				// System.out.println("treeViewList_537 size() "+treeViewList_537.size());
			}
			if (subData_539Recid != null && subData_539Recid.getSubHeader().getRecord_type().equals("539")) {

				SubHeader receivedSubHeader = subData_539Recid.getSubHeader();
				String[] subDataRows = subData_539Recid.getSubDataRows();
				List<AddIInfoData12State> treeViewList_539 = new ArrayList();
				treeViewList.add("539");
				// int i = 0;
				for (String subDataRow : subDataRows) {
					String[] attributes = mqReadUtil.getAttributes(subDataRow, 5);
//					//System.out.println("attributes:=539:Reqid======> " + Arrays.toString(attributes));
					AddIInfoData12State addIInfoData12State = new AddIInfoData12State();

					addIInfoData12State.setLasrver(attributes[0]);
					addIInfoData12State.setDt_enter(attributes[1]);
					addIInfoData12State.setItem_num(attributes[2]);
					addIInfoData12State.setField_name(attributes[3]);
					addIInfoData12State.setField_data(attributes[4]);

					treeViewList_539.add(addIInfoData12State);
				}
				selectRequestData.setSubHeader(receivedSubHeader);
				session.setAttribute("treeViewList_539", treeViewList_539);
				// System.out.println("treeViewList_539 size() "+treeViewList_539.size());
				// selectRequestData.setSelectRequestTableRows(selectRequestTableRows);
			}

			if (subData_583Recid != null && subData_583Recid.getSubHeader().getRecord_type().equals("583")) {

				SubHeader receivedSubHeader = subData_583Recid.getSubHeader();
				String[] subDataRows = subData_583Recid.getSubDataRows();

				List<JeopardyViewTableData12State> treeViewList_583 = new ArrayList();
				treeViewList.add("583");
				// int i = 0;
				for (String subDataRow : subDataRows) {
					String[] attributes = mqReadUtil.getAttributes(subDataRow, 7);
//					//System.out.println("attributes:=583======> " + Arrays.toString(attributes));
					JeopardyViewTableData12State jeopardyViewDataTableRow12State = new JeopardyViewTableData12State();

					jeopardyViewDataTableRow12State.setJep_ecckt(attributes[0]);
					jeopardyViewDataTableRow12State.setJep_tns(attributes[1]);
					jeopardyViewDataTableRow12State.setJep_cfa(attributes[2]);
					jeopardyViewDataTableRow12State.setJep_ccea(attributes[3]);
					jeopardyViewDataTableRow12State.setCbcid(attributes[4]);
					jeopardyViewDataTableRow12State.setCableid(attributes[5]);
					jeopardyViewDataTableRow12State.setChan_pair(attributes[6]);

					treeViewList_583.add(jeopardyViewDataTableRow12State);
				}
				selectRequestData.setSubHeader(receivedSubHeader);
				session.setAttribute("treeViewList_583", treeViewList_583);
				// System.out.println("treeViewList_583 size() "+treeViewList_583.size());
				// selectRequestData.setSelectRequestTableRows(selectRequestTableRows);
			}

			if (subData_584Recid != null && subData_584Recid.getSubHeader().getRecord_type().equals("584")) {

				SubHeader receivedSubHeader = subData_584Recid.getSubHeader();
				String[] subDataRows = subData_584Recid.getSubDataRows();

				List<JeopardyViewData12State> treeViewList_584 = new ArrayList();
				treeViewList.add("584");
				for (String subDataRow : subDataRows) {
					String[] attributes = mqReadUtil.getAttributes(subDataRow, 30);
//					//System.out.println("attributes:=584======> " + Arrays.toString(attributes));
					JeopardyViewData12State jeopardyViewData12State = new JeopardyViewData12State();

					jeopardyViewData12State.setCver_attr(attributes[0]);
					jeopardyViewData12State.setCver(attributes[1]);
					jeopardyViewData12State.setRt_attr(attributes[2]);
					jeopardyViewData12State.setRt(attributes[3]);
					jeopardyViewData12State.setEc_ver_attr(attributes[4]);
					jeopardyViewData12State.setEc_ver(attributes[5]);
					jeopardyViewData12State.setDt_sent_attr(attributes[6]);
					jeopardyViewData12State.setDt_sent(attributes[7]);
					jeopardyViewData12State.setResponse_dt_sent_attr(attributes[8]);
					jeopardyViewData12State.setResponse_dt_sent(attributes[9]);
					jeopardyViewData12State.setOrd_attr(attributes[10]);
					jeopardyViewData12State.setOrd(attributes[11]);
					jeopardyViewData12State.setLord_attr(attributes[12]);
					jeopardyViewData12State.setLord(attributes[13]);
					jeopardyViewData12State.setJcode_attr(attributes[14]);
					jeopardyViewData12State.setJcode(attributes[15]);
					jeopardyViewData12State.setRcode_attr(attributes[16]);
					jeopardyViewData12State.setRcode(attributes[17]);
					jeopardyViewData12State.setRdet_attr(attributes[18]);
					jeopardyViewData12State.setRdet(attributes[19]);
					jeopardyViewData12State.setEsdd_attr(attributes[20]);
					jeopardyViewData12State.setEsdd(attributes[21]);
					jeopardyViewData12State.setSent_by_attr(attributes[22]);
					jeopardyViewData12State.setSent_by(attributes[23]);
					jeopardyViewData12State.setNpord_attr(attributes[24]);
					jeopardyViewData12State.setNpord(attributes[25]);
					jeopardyViewData12State.setSpec_code(attributes[26]);
					jeopardyViewData12State.setApptime_attr(attributes[27]);
					jeopardyViewData12State.setApptime(attributes[28]);

					treeViewList_584.add(jeopardyViewData12State);
				}
				selectRequestData.setSubHeader(receivedSubHeader);
				session.setAttribute("treeViewList_584", treeViewList_584);
				// System.out.println("treeViewList_584 size() "+treeViewList_584.size());
				// selectRequestData.setSelectRequestTableRows(selectRequestTableRows);
			}

			if (subData_535Recid != null && subData_535Recid.getSubHeader().getRecord_type().equals("535")) {

				SubHeader receivedSubHeader = subData_535Recid.getSubHeader();
				String[] subDataRows = subData_535Recid.getSubDataRows();

				List<FieldDataChangesData12State> treeViewList_535 = new ArrayList();
				treeViewList.add("535");
				// int i = 0;
				for (String subDataRow : subDataRows) {
					String[] attributes = mqReadUtil.getAttributes(subDataRow, 12);
//					//System.out.println("attributes:==535=====> " + Arrays.toString(attributes));
					FieldDataChangesData12State fieldDataChangesData12State = new FieldDataChangesData12State();

					fieldDataChangesData12State.setSupp(attributes[0]);
					fieldDataChangesData12State.setChanged_dttm(attributes[1]);
					fieldDataChangesData12State.setOrder_num(attributes[2]);
					fieldDataChangesData12State.setField_name(attributes[3]);
					fieldDataChangesData12State.setHunt_item_num(attributes[4]);
					fieldDataChangesData12State.setItem_num(attributes[5]);
					fieldDataChangesData12State.setLnum(attributes[6]);
					fieldDataChangesData12State.setNumname(attributes[7]);
					fieldDataChangesData12State.setNumnbr(attributes[8]);
					fieldDataChangesData12State.setChanged_from(attributes[9]);
					fieldDataChangesData12State.setChanged_to(attributes[10]);
					fieldDataChangesData12State.setChanged_by(attributes[11]);

					treeViewList_535.add(fieldDataChangesData12State);
				}
				selectRequestData.setSubHeader(receivedSubHeader);
				session.setAttribute("treeViewList_535", treeViewList_535);
				// System.out.println("treeViewList_535 size() "+treeViewList_535.size());
				// selectRequestData.setSelectRequestTableRows(selectRequestTableRows);
			}

			if (subData_894Recid != null && subData_894Recid.getSubHeader().getRecord_type().equals("894")) {

				SubHeader receivedSubHeader = subData_894Recid.getSubHeader();
				String[] subDataRows = subData_894Recid.getSubDataRows();

				List<CompletionLSOGReqTypeJ> treeViewList894 = new ArrayList();
				treeViewList.add("894");

				for (String subDataRow : subDataRows) {
					String[] attributes = mqReadUtil.getAttributes(subDataRow, 8);
//					//System.out.println("subData_894Recid======> " + Arrays.toString(attributes));

					CompletionLSOGReqTypeJ completionLSOGReqTypeJ = new CompletionLSOGReqTypeJ();

					completionLSOGReqTypeJ.setCver(attributes[0]);
					completionLSOGReqTypeJ.setDor(attributes[1]);
					completionLSOGReqTypeJ.setAtn(attributes[2]);
					completionLSOGReqTypeJ.setRt(attributes[3]);
					completionLSOGReqTypeJ.setEcver(attributes[4]);
					completionLSOGReqTypeJ.setD_t_sent_local(attributes[5]);
					completionLSOGReqTypeJ.setResponse_d_t_sent_central_time(attributes[6]);
					completionLSOGReqTypeJ.setDda(attributes[7]);

					treeViewList894.add(completionLSOGReqTypeJ);

				}
				session.setAttribute("treeViewList894", treeViewList894);
				selectRequestData.setSubHeader(receivedSubHeader);
				// System.out.println("treeViewList894 size() "+treeViewList894.size());
			}

			if (subData_895Recid != null && subData_895Recid.getSubHeader().getRecord_type().equals("895")) {

				SubHeader receivedSubHeader = subData_895Recid.getSubHeader();
				String[] subDataRows = subData_895Recid.getSubDataRows();
				treeViewList.add("895");

				List<CompletionLSOGReqTypeJDetails> treeViewList895 = new ArrayList();

				for (String subDataRow : subDataRows) {
					String[] attributes = mqReadUtil.getAttributes(subDataRow, 12);
//					//System.out.println("subData_895Recid=====> " + Arrays.toString(attributes));
					CompletionLSOGReqTypeJDetails completionLSOGReqTypeJDetails = new CompletionLSOGReqTypeJDetails();

					completionLSOGReqTypeJDetails.setItemnum(attributes[0]);
					completionLSOGReqTypeJDetails.setDlnum(attributes[1]);
					completionLSOGReqTypeJDetails.setAli(attributes[2]);
					completionLSOGReqTypeJDetails.setLtn(attributes[3]);
					completionLSOGReqTypeJDetails.setNstn(attributes[4]);
					completionLSOGReqTypeJDetails.setLact(attributes[5]);
					completionLSOGReqTypeJDetails.setLty(attributes[6]);
					completionLSOGReqTypeJDetails.setStyc(attributes[7]);
					completionLSOGReqTypeJDetails.setToa(attributes[8]);
					completionLSOGReqTypeJDetails.setDoi(attributes[9]);
					completionLSOGReqTypeJDetails.setListnm(attributes[10]);
					completionLSOGReqTypeJDetails.setListadr(attributes[11]);

					treeViewList895.add(completionLSOGReqTypeJDetails);

				}
				session.setAttribute("treeViewList895", treeViewList895);
				selectRequestData.setSubHeader(receivedSubHeader);
				// System.out.println("treeViewList895 size() "+treeViewList895.size());
			}

			// for RecId 893 and 897

			if (subData_897Recid != null && subData_897Recid.getSubHeader().getRecord_type().equals("897")) {

				SubHeader receivedSubHeader = subData_897Recid.getSubHeader();
				String[] subDataRows = subData_897Recid.getSubDataRows();

				List<CompletionActivityRLSOG6LscInfo> treeViewList897 = new ArrayList();
				treeViewList.add("897");

				for (String subDataRow : subDataRows) {
					String[] attributes = mqReadUtil.getAttributes(subDataRow, 11);
//					//System.out.println("subData_897Recid======> " + Arrays.toString(attributes));
					CompletionActivityRLSOG6LscInfo completionActivityRLSOG6LscInfo = new CompletionActivityRLSOG6LscInfo();

					completionActivityRLSOG6LscInfo
							.setOld_dtm(attributes[0] != null && attributes[0] != "" ? attributes[0] : " ");
					completionActivityRLSOG6LscInfo
							.setOld_ord(attributes[1] != null && attributes[1] != "" ? attributes[1] : " ");
					completionActivityRLSOG6LscInfo
							.setOrd_attr(attributes[2] != null && attributes[2] != "" ? attributes[2] : " ");
					completionActivityRLSOG6LscInfo
							.setOrd(attributes[3] != null && attributes[3] != "" ? attributes[3] : " ");

					treeViewList897.add(completionActivityRLSOG6LscInfo);

				}
				session.setAttribute("treeViewList897", treeViewList897);
				selectRequestData.setSubHeader(receivedSubHeader);
				// System.out.println("treeViewList897 size() "+treeViewList897.size());
			}

			if (subData_893Recid != null && subData_893Recid.getSubHeader().getRecord_type().equals("893")) {

				SubHeader receivedSubHeader = subData_893Recid.getSubHeader();
				String[] subDataRows = subData_893Recid.getSubDataRows();

				List<CompletionActivityRLSOG6> treeViewList893 = new ArrayList();
				treeViewList.add("893");

				for (String subDataRow : subDataRows) {
					String[] attributes = mqReadUtil.getAttributes(subDataRow, 9);
//					//System.out.println("subData_893Recid======> " + Arrays.toString(attributes));
					CompletionActivityRLSOG6 completionActivityRLSOG6 = new CompletionActivityRLSOG6();

					completionActivityRLSOG6
							.setA_cver(attributes[0] != null && attributes[0] != "" ? attributes[0] : " ");
					completionActivityRLSOG6.setA_atn(attributes[1]);
					completionActivityRLSOG6
							.setA_rt(attributes[2] != null && attributes[2] != "" ? attributes[2] : " ");
					completionActivityRLSOG6
							.setA_ecver(attributes[3] != null && attributes[3] != "" ? attributes[3] : " ");
					completionActivityRLSOG6.setA_d_t_sent_local(attributes[4]);
					completionActivityRLSOG6.setA_response_d_t_sent_central_time(attributes[5]);
					completionActivityRLSOG6.setA_comp_dt_attr(attributes[6]);
					completionActivityRLSOG6.setA_comp_dt(attributes[7]);
					completionActivityRLSOG6
							.setA_an(attributes[8] != null && attributes[8] != "" ? attributes[8] : " ");

					treeViewList893.add(completionActivityRLSOG6);

				}
				session.setAttribute("treeViewList893", treeViewList893);
				selectRequestData.setSubHeader(receivedSubHeader);
				// System.out.println("treeViewList893 size "+treeViewList893.size());
			}

			// for RecId 890 and 898
//for RecId subData_889Recid adde by nisha

			if (subData_889Recid != null && subData_889Recid.getSubHeader().getRecord_type().equals("889")) {

				SubHeader receivedSubHeader = subData_889Recid.getSubHeader();
				String[] subDataRows = subData_889Recid.getSubDataRows();
				List<ResponseEcver> treeViewList889 = new ArrayList();
				treeViewList.add("889");

				for (String subDataRow : subDataRows) {
					String[] attributes = mqReadUtil.getAttributes(subDataRow, 4);
//				 System.out.println("subData_889Recid======> " + Arrays.toString(attributes));

					ResponseEcver responseEcver = new ResponseEcver();

					responseEcver.setEcver(attributes[0]);

					treeViewList889.add(responseEcver);

				}
//				System.out.println("=========treeViewLis889==========");
				treeViewList889.forEach(x -> System.out.println(x));
				session.setAttribute("treeViewList889", treeViewList889);
				selectRequestData.setSubHeader(receivedSubHeader);

			}

			if (subData_890Recid != null && subData_890Recid.getSubHeader().getRecord_type().equals("890")) {

				SubHeader receivedSubHeader = subData_890Recid.getSubHeader();
				String[] subDataRows = subData_890Recid.getSubDataRows();

				List<CompletionLSOG6> treeViewList890 = new ArrayList();
				treeViewList.add("890");

				for (String subDataRow : subDataRows) {
					String[] attributes = mqReadUtil.getAttributes(subDataRow, 11);
//					//System.out.println("subData_890Recid======> " + Arrays.toString(attributes));
					CompletionLSOG6 completionLSOG6 = new CompletionLSOG6();

					completionLSOG6.setA_cver(attributes[0] != null && attributes[0] != "" ? attributes[0] : " ");
					completionLSOG6.setA_atn(attributes[1] != null && attributes[1] != "" ? attributes[1] : " ");
					completionLSOG6.setA_rt(attributes[2] != null && attributes[2] != "" ? attributes[2] : " ");
					completionLSOG6.setA_ecver(attributes[3] != null && attributes[3] != "" ? attributes[3] : " ");
					completionLSOG6.setD_t_sent_local(attributes[4]);
					completionLSOG6.setResponse_d_t_sent_central_time(attributes[5]);
					completionLSOG6
							.setA_comp_dt_attr(attributes[6] != null && attributes[6] != "" ? attributes[6] : " ");
					completionLSOG6.setComp_dt(attributes[7]);
					completionLSOG6
							.setA_company_code_attr(attributes[8] != null && attributes[8] != "" ? attributes[8] : " ");
					completionLSOG6
							.setA_comapny_code(attributes[9] != null && attributes[9] != "" ? attributes[9] : " ");
					completionLSOG6.setA_an(attributes[10] != null && attributes[10] != "" ? attributes[10] : " ");

					treeViewList890.add(completionLSOG6);
				}
				session.setAttribute("treeViewList890", treeViewList890);
				selectRequestData.setSubHeader(receivedSubHeader);
				// System.out.println("treeViewList890 size "+treeViewList890.size());
			}

			if (subData_898Recid != null && subData_898Recid.getSubHeader().getRecord_type().equals("898")) {

				SubHeader receivedSubHeader = subData_898Recid.getSubHeader();
				String[] subDataRows = subData_898Recid.getSubDataRows();
				List<CompletionActivityRLSOG6LscInfo> treeViewList898 = new ArrayList();
				treeViewList.add("898");

				for (String subDataRow : subDataRows) {
					String[] attributes = mqReadUtil.getAttributes(subDataRow, 12);
//					//System.out.println("subData_898Recid======> " + Arrays.toString(attributes));

					CompletionActivityRLSOG6LscInfo completionActivityRLSOG6LscInfo = new CompletionActivityRLSOG6LscInfo();

					completionActivityRLSOG6LscInfo
							.setOld_dtm(attributes[0] != null && attributes[0] != "" ? attributes[0] : " ");
					completionActivityRLSOG6LscInfo
							.setOld_ord(attributes[1] != null && attributes[1] != "" ? attributes[1] : " ");
					completionActivityRLSOG6LscInfo
							.setOrd_attr(attributes[2] != null && attributes[2] != "" ? attributes[2] : " ");
					completionActivityRLSOG6LscInfo
							.setOrd(attributes[3] != null && attributes[3] != "" ? attributes[3] : " ");

					treeViewList898.add(completionActivityRLSOG6LscInfo);

				}
				session.setAttribute("treeViewList898", treeViewList898);
				selectRequestData.setSubHeader(receivedSubHeader);
				// System.out.println("treeViewList898 size "+treeViewList898.size());
			}

			// for recId 563 and 567
			if (subData_563Recid != null && subData_563Recid.getSubHeader().getRecord_type().equals("563")) {

				SubHeader receivedSubHeader = subData_563Recid.getSubHeader();
				String[] subDataRows = subData_563Recid.getSubDataRows();
				List<CompletionProviderTaskActivityR> treeViewList563 = new ArrayList();
				treeViewList.add("563");

				for (String subDataRow : subDataRows) {
					String[] attributes = mqReadUtil.getAttributes(subDataRow, 9);
//					//System.out.println("subData_563Recid======> " + Arrays.toString(attributes));

					CompletionProviderTaskActivityR completionProviderTaskActivityR = new CompletionProviderTaskActivityR();

					completionProviderTaskActivityR
							.setCver(attributes[0] != null && attributes[0] != "" ? attributes[0] : " ");
					completionProviderTaskActivityR
							.setAtn(attributes[1] != null && attributes[1] != "" ? attributes[1] : " ");
					completionProviderTaskActivityR
							.setRt(attributes[2] != null && attributes[2] != "" ? attributes[2] : " ");
					completionProviderTaskActivityR
							.setEcver(attributes[3] != null && attributes[3] != "" ? attributes[3] : " ");
					completionProviderTaskActivityR
							.setD_t_sent_local(attributes[4] != null && attributes[4] != "" ? attributes[4] : " ");
					completionProviderTaskActivityR.setResponse_d_t_sent_central_time(
							attributes[5] != null && attributes[5] != "" ? attributes[5] : " ");
					completionProviderTaskActivityR
							.setComp_dt_attr(attributes[6] != null && attributes[6] != "" ? attributes[6] : " ");
					completionProviderTaskActivityR
							.setComp_dt(attributes[7] != null && attributes[7] != "" ? attributes[7] : " ");
					completionProviderTaskActivityR
							.setAn(attributes[8] != null && attributes[8] != "" ? attributes[8] : " ");

					treeViewList563.add(completionProviderTaskActivityR);

				}
				session.setAttribute("treeViewList563", treeViewList563);
				selectRequestData.setSubHeader(receivedSubHeader);
				// System.out.println("treeViewList563 size "+treeViewList563.size());
			}
			if (subData_567Recid != null && subData_567Recid.getSubHeader().getRecord_type().equals("567")) {

				SubHeader receivedSubHeader = subData_567Recid.getSubHeader();
				String[] subDataRows = subData_567Recid.getSubDataRows();
				List<CompletionActivityRLSOG6LscInfo> treeViewList567 = new ArrayList();
				treeViewList.add("567");

				for (String subDataRow : subDataRows) {
					String[] attributes = mqReadUtil.getAttributes(subDataRow, 11);
//					//System.out.println("subData_567Recid======> " + Arrays.toString(attributes));

					CompletionActivityRLSOG6LscInfo completionActivityRLSOG6LscInfo = new CompletionActivityRLSOG6LscInfo();

					completionActivityRLSOG6LscInfo
							.setOld_dtm(attributes[0] != null && attributes[0] != "" ? attributes[0] : " ");
					completionActivityRLSOG6LscInfo
							.setOld_ord(attributes[1] != null && attributes[1] != "" ? attributes[1] : " ");
					completionActivityRLSOG6LscInfo
							.setOrd_attr(attributes[2] != null && attributes[2] != "" ? attributes[2] : " ");
					completionActivityRLSOG6LscInfo
							.setOrd(attributes[3] != null && attributes[3] != "" ? attributes[3] : " ");
					completionActivityRLSOG6LscInfo.setFdt_attr(attributes[4]);
					completionActivityRLSOG6LscInfo.setFdt(attributes[5]);
					completionActivityRLSOG6LscInfo.setDd_attr(attributes[6]);
					completionActivityRLSOG6LscInfo.setDd(attributes[7]);
					completionActivityRLSOG6LscInfo.setComp_dt_attr(attributes[8]);

					treeViewList567.add(completionActivityRLSOG6LscInfo);

				}
				session.setAttribute("treeViewList567", treeViewList567);
				selectRequestData.setSubHeader(receivedSubHeader);
				// System.out.println("treeViewList567 size "+treeViewList567.size());
			}

			// for recId 574, 568 ,577, 578

			// for recId 560 and 568 ----> Anjali

			if (subData_560Recid != null && subData_560Recid.getSubHeader().getRecord_type().equals("560")) {

				SubHeader receivedSubHeader = subData_560Recid.getSubHeader();
				String[] subDataRows = subData_560Recid.getSubDataRows();
				List<CompletionProviderTask> treeViewList560 = new ArrayList();
				treeViewList.add("560");

				for (String subDataRow : subDataRows) {
					String[] attributes = mqReadUtil.getAttributes(subDataRow, 11);

					CompletionProviderTask completionProviderTask = new CompletionProviderTask();

					completionProviderTask.setCver(attributes[0] != null && attributes[0] != "" ? attributes[0] : " ");
					completionProviderTask.setAtn(attributes[1] != null && attributes[1] != "" ? attributes[1] : " ");
					completionProviderTask.setRt(attributes[2] != null && attributes[2] != "" ? attributes[2] : " ");
					completionProviderTask.setEcver(attributes[3] != null && attributes[3] != "" ? attributes[3] : " ");
					completionProviderTask
							.setD_t_sent_local(attributes[4] != null && attributes[4] != "" ? attributes[4] : " ");
					completionProviderTask.setResponse_d_t_sent_central_time(
							attributes[5] != null && attributes[5] != "" ? attributes[5] : " ");
					completionProviderTask
							.setComp_dt_attr(attributes[6] != null && attributes[6] != "" ? attributes[6] : " ");
					completionProviderTask.setComp_dt(FormatUtil
							.getMqStringToDate(attributes[7] != null && attributes[7] != "" ? attributes[7] : " "));

					completionProviderTask
							.setCompany_code_attr(attributes[8] != null && attributes[8] != "" ? attributes[8] : " ");
					completionProviderTask
							.setCompany_code(attributes[9] != null && attributes[9] != "" ? attributes[9] : " ");
					completionProviderTask.setAn(attributes[10] != null && attributes[10] != "" ? attributes[10] : " ");

					treeViewList560.add(completionProviderTask);

				}
				session.setAttribute("treeViewList560", treeViewList560);
				selectRequestData.setSubHeader(receivedSubHeader);

			}

			if (subData_568Recid != null && subData_568Recid.getSubHeader().getRecord_type().equals("568")) {

				SubHeader receivedSubHeader = subData_568Recid.getSubHeader();
				String[] subDataRows = subData_568Recid.getSubDataRows();
				List<CompletionActivityRLSOG6LscInfo> treeViewList568 = new ArrayList();
				treeViewList.add("568");

				for (String subDataRow : subDataRows) {
					String[] attributes = mqReadUtil.getAttributes(subDataRow, 14);

					CompletionActivityRLSOG6LscInfo completionActivityRLSOG6LscInfo = new CompletionActivityRLSOG6LscInfo();

					completionActivityRLSOG6LscInfo
							.setOld_dtm(attributes[0] != null && attributes[0] != "" ? attributes[0] : " ");
					completionActivityRLSOG6LscInfo
							.setOld_ord(attributes[1] != null && attributes[1] != "" ? attributes[1] : " ");
					completionActivityRLSOG6LscInfo
							.setOrd_attr(attributes[2] != null && attributes[2] != "" ? attributes[2] : " ");
					completionActivityRLSOG6LscInfo
							.setOrd(attributes[3] != null && attributes[3] != "" ? attributes[3] : " ");
					completionActivityRLSOG6LscInfo
							.setFdt_attr(attributes[4] != null && attributes[4] != "" ? attributes[4] : " ");
					completionActivityRLSOG6LscInfo
							.setFdt(attributes[5] != null && attributes[5] != "" ? attributes[5] : " ");
					completionActivityRLSOG6LscInfo
							.setDd_attr(attributes[6] != null && attributes[6] != "" ? attributes[6] : " ");
					completionActivityRLSOG6LscInfo
							.setDd(attributes[7] != null && attributes[7] != "" ? attributes[7] : " ");
					completionActivityRLSOG6LscInfo
							.setComp_dt_attr(attributes[8] != null && attributes[8] != "" ? attributes[8] : " ");
					// rashmita 28 jan
					completionActivityRLSOG6LscInfo.setComp_dt(FormatUtil
							.getMqStringToDate(attributes[9] != null && attributes[9] != "" ? attributes[9] : " "));// end
																													// 28
																													// jan
					completionActivityRLSOG6LscInfo
							.setPosted_date_attr(attributes[10] != null && attributes[10] != "" ? attributes[10] : " ");
					completionActivityRLSOG6LscInfo
							.setPosted_date(attributes[11] != null && attributes[11] != "" ? attributes[11] : " ");
					completionActivityRLSOG6LscInfo
							.setApptime_attr(attributes[12] != null && attributes[12] != "" ? attributes[12] : " ");
					completionActivityRLSOG6LscInfo
							.setApptime(attributes[13] != null && attributes[13] != "" ? attributes[13] : " ");

					treeViewList568.add(completionActivityRLSOG6LscInfo);

				}
				session.setAttribute("treeViewList568", treeViewList568);
				selectRequestData.setSubHeader(receivedSubHeader);

			}

			if (subData_577Recid != null && subData_577Recid.getSubHeader().getRecord_type().equals("577")) {

				SubHeader receivedSubHeader = subData_577Recid.getSubHeader();
				String[] subDataRows = subData_577Recid.getSubDataRows();
				List<CompletionProviderTaskWithLossLasrInfo> treeViewList577 = new ArrayList();
				treeViewList.add("577");

				for (String subDataRow : subDataRows) {
					String[] attributes = mqReadUtil.getAttributes(subDataRow, 11);
//					//System.out.println("subData_577Recid======> " + Arrays.toString(attributes));

					CompletionProviderTaskWithLossLasrInfo completionProviderTaskWithLossLasrInfo = new CompletionProviderTaskWithLossLasrInfo();

					completionProviderTaskWithLossLasrInfo
							.setA_numname_attr(attributes[0] != null && attributes[0] != "" ? attributes[0] : " ");
					completionProviderTaskWithLossLasrInfo
							.setA_numname(attributes[1] != null && attributes[1] != "" ? attributes[1] : " ");
					completionProviderTaskWithLossLasrInfo
							.setA_numnbr_attr(attributes[2] != null && attributes[2] != "" ? attributes[2] : " ");
					completionProviderTaskWithLossLasrInfo
							.setA_numnbr(attributes[3] != null && attributes[3] != "" ? attributes[3] : " ");
					completionProviderTaskWithLossLasrInfo
							.setA_wtn_attr(attributes[4] != null && attributes[4] != "" ? attributes[4] : " ");
					completionProviderTaskWithLossLasrInfo
							.setA_wtn(attributes[5] != null && attributes[5] != "" ? attributes[5] : " ");
					completionProviderTaskWithLossLasrInfo
							.setA_ecckt_attr(attributes[6] != null && attributes[6] != "" ? attributes[6] : " ");
					completionProviderTaskWithLossLasrInfo
							.setA_ecckt(attributes[7] != null && attributes[7] != "" ? attributes[7] : " ");
					completionProviderTaskWithLossLasrInfo
							.setA_cvd_attr(attributes[8] != null && attributes[8] != "" ? attributes[8] : " ");
					completionProviderTaskWithLossLasrInfo
							.setA_cvd(attributes[9] != null && attributes[9] != "" ? attributes[9] : " ");

					treeViewList577.add(completionProviderTaskWithLossLasrInfo);

				}
				session.setAttribute("treeViewList577", treeViewList577);
				selectRequestData.setSubHeader(receivedSubHeader);
				// System.out.println("treeViewList577 size "+treeViewList577.size());
			}

			if (subData_578Recid != null && subData_578Recid.getSubHeader().getRecord_type().equals("578")) {

				SubHeader receivedSubHeader = subData_578Recid.getSubHeader();
				String[] subDataRows = subData_578Recid.getSubDataRows();
				List<CompletionProviderTaskLossInfo> treeViewList578 = new ArrayList();
				treeViewList.add("578");

				for (String subDataRow : subDataRows) {
					String[] attributes = mqReadUtil.getAttributes(subDataRow, 10);
//					//System.out.println("subData_577Recid======> " + Arrays.toString(attributes));

					CompletionProviderTaskLossInfo completionProviderTaskLossInfo = new CompletionProviderTaskLossInfo();

					completionProviderTaskLossInfo
							.setNumname_attr(attributes[0] != null && attributes[0] != "" ? attributes[0] : " ");
					completionProviderTaskLossInfo
							.setNumname(attributes[1] != null && attributes[1] != "" ? attributes[1] : " ");
					completionProviderTaskLossInfo
							.setNumnbr_attr(attributes[2] != null && attributes[2] != "" ? attributes[2] : " ");
					completionProviderTaskLossInfo
							.setNumnbr(attributes[3] != null && attributes[3] != "" ? attributes[3] : " ");
					completionProviderTaskLossInfo
							.setWtn_attr(attributes[4] != null && attributes[4] != "" ? attributes[4] : " ");
					completionProviderTaskLossInfo
							.setWtn(attributes[5] != null && attributes[5] != "" ? attributes[5] : " ");
					completionProviderTaskLossInfo
							.setEcckt_attr(attributes[6] != null && attributes[6] != "" ? attributes[6] : " ");
					completionProviderTaskLossInfo
							.setEcckt(attributes[7] != null && attributes[7] != "" ? attributes[7] : " ");
					completionProviderTaskLossInfo
							.setCvd_attr(attributes[8] != null && attributes[8] != "" ? attributes[8] : " ");
					completionProviderTaskLossInfo
							.setCvd(attributes[9] != null && attributes[9] != "" ? attributes[9] : " ");

					treeViewList578.add(completionProviderTaskLossInfo);
				}
				session.setAttribute("treeViewList578", treeViewList578);
				selectRequestData.setSubHeader(receivedSubHeader);
				// System.out.println("treeViewList578 size "+treeViewList578.size());
			}

			if (subData_683Recid != null && subData_683Recid.getSubHeader().getRecord_type().equals("683")) {

				SubHeader receivedSubHeader = subData_683Recid.getSubHeader();
				String[] subDataRows = subData_683Recid.getSubDataRows();
				List<CentrexResaleCommonBlockSectionDW1DATA12> treeViewList_683 = new ArrayList();
				treeViewList.add("683");
				// int i = 0;
				for (String subDataRow : subDataRows) {
					String[] attributes = mqReadUtil.getAttributes(subDataRow, 2);
//					//System.out.println("attributes:=683:Reqid======> " + Arrays.toString(attributes));
					CentrexResaleCommonBlockSectionDW1DATA12 centrexResaleCommonBlockSectionDW1DATA12 = new CentrexResaleCommonBlockSectionDW1DATA12();

					centrexResaleCommonBlockSectionDW1DATA12
							.setCb_attr(attributes[0] != null || attributes[0] != "" ? attributes[0] : " ");
					centrexResaleCommonBlockSectionDW1DATA12
							.setCb(attributes[1] != null || attributes[1] != "" ? attributes[1] : " ");

					treeViewList_683.add(centrexResaleCommonBlockSectionDW1DATA12);

					// treeViewList.add(centrexResaleCommonBlockSectionDW1DATA12);
				}
				selectRequestData.setSubHeader(receivedSubHeader);
				session.setAttribute("treeViewList_683", treeViewList_683);
				// System.out.println("treeViewList_683 size "+treeViewList_683.size());
			}

			if (subData_684Recid != null && subData_684Recid.getSubHeader().getRecord_type().equals("684")) {

				SubHeader receivedSubHeader = subData_684Recid.getSubHeader();
				String[] subDataRows = subData_684Recid.getSubDataRows();
				List<CentrexResaleCommonBlockSection_DW2Data12> treeViewList_684 = new ArrayList();
				treeViewList.add("684");
				// int i = 0;
				for (String subDataRow : subDataRows) {
					String[] attributes = mqReadUtil.getAttributes(subDataRow, 4);
//					//System.out.println("attributes:=684:Reqid======> " + Arrays.toString(attributes));
					CentrexResaleCommonBlockSection_DW2Data12 centrexResaleCommonBlockSection_DW2Data12 = new CentrexResaleCommonBlockSection_DW2Data12();

					centrexResaleCommonBlockSection_DW2Data12
							.setSna_attr(attributes[0] != null || attributes[0] != "" ? attributes[0] : " ");
					centrexResaleCommonBlockSection_DW2Data12
							.setSna(attributes[1] != null || attributes[1] != "" ? attributes[1] : " ");
					centrexResaleCommonBlockSection_DW2Data12
							.setSn_attr(attributes[2] != null || attributes[2] != "" ? attributes[2] : " ");
					centrexResaleCommonBlockSection_DW2Data12
							.setSn(attributes[3] != null || attributes[3] != "" ? attributes[3] : " ");

					treeViewList_684.add(centrexResaleCommonBlockSection_DW2Data12);

					// treeViewList.add(centrexResaleCommonBlockSection_DW2Data12);
				}
				session.setAttribute("treeViewList_684", treeViewList_684);
				selectRequestData.setSubHeader(receivedSubHeader);
				// System.out.println("treeViewList_684 size "+treeViewList_684.size());
			}
			if (subData_680Recid != null && subData_680Recid.getSubHeader().getRecord_type().equals("680")) {

				SubHeader receivedSubHeader = subData_680Recid.getSubHeader();
				String[] subDataRows = subData_680Recid.getSubDataRows();
				List<CentrexResaleCRSStationDW1Data12> treeViewList_680 = new ArrayList();
				treeViewList.add("680");
				// int i = 0;
				for (String subDataRow : subDataRows) {
					String[] attributes = mqReadUtil.getAttributes(subDataRow, 115);
//					//System.out.println("attributes:=680:Reqid======> " + Arrays.toString(attributes));
					CentrexResaleCRSStationDW1Data12 centrexResaleCRSStationDW1Data12 = new CentrexResaleCRSStationDW1Data12();

					centrexResaleCRSStationDW1Data12
							.setItem_num(attributes[0] != null && attributes[0] != "" ? attributes[0] : " ");
					centrexResaleCRSStationDW1Data12
							.setLnum_attr(attributes[1] != null && attributes[1] != "" ? attributes[1] : " ");
					centrexResaleCRSStationDW1Data12
							.setLnum(attributes[2] != null && attributes[2] != "" ? attributes[2] : " ");
					centrexResaleCRSStationDW1Data12.setLna_attr(attributes[3]);
					centrexResaleCRSStationDW1Data12.setLna(attributes[4]);
					centrexResaleCRSStationDW1Data12.setNpi_attr(attributes[5]);
					centrexResaleCRSStationDW1Data12.setNpi(attributes[6]);
					centrexResaleCRSStationDW1Data12.setLst_attr(attributes[7]);
					centrexResaleCRSStationDW1Data12.setLst(attributes[8]);
					centrexResaleCRSStationDW1Data12.setTns_attr(attributes[9]);
					centrexResaleCRSStationDW1Data12.setTns(attributes[10]);
					centrexResaleCRSStationDW1Data12.setTers_attr(attributes[11]);
					centrexResaleCRSStationDW1Data12.setTers(attributes[12]);
					centrexResaleCRSStationDW1Data12.setOtn_attr(attributes[13]);
					centrexResaleCRSStationDW1Data12.setOtn(attributes[14]);
					centrexResaleCRSStationDW1Data12.setIspid_attr(attributes[15]);
					centrexResaleCRSStationDW1Data12.setIspid(attributes[16]);
					centrexResaleCRSStationDW1Data12.setIsdnp_attr(attributes[17]);
					centrexResaleCRSStationDW1Data12.setIsdnp(attributes[18]);
					centrexResaleCRSStationDW1Data12.setEcckt_attr(attributes[19]);
					centrexResaleCRSStationDW1Data12.setEcckt(attributes[20]);
					centrexResaleCRSStationDW1Data12.setCfa_attr(attributes[21]);
					centrexResaleCRSStationDW1Data12.setCfa(attributes[22]);
					centrexResaleCRSStationDW1Data12.setCcea_attr(attributes[23]);
					centrexResaleCRSStationDW1Data12.setCcea(attributes[24]);
					centrexResaleCRSStationDW1Data12.setCkr_attr(attributes[25]);
					centrexResaleCRSStationDW1Data12.setCkr(attributes[26]);
					centrexResaleCRSStationDW1Data12.setPic_attr(attributes[27]);
					centrexResaleCRSStationDW1Data12.setPic(attributes[28]);
					centrexResaleCRSStationDW1Data12.setLpic_attr(attributes[29]);
					centrexResaleCRSStationDW1Data12.setLpic(attributes[30]);
					centrexResaleCRSStationDW1Data12.setSsig_attr(attributes[31]);
					centrexResaleCRSStationDW1Data12.setSsig(attributes[32]);
					centrexResaleCRSStationDW1Data12.setBa_attr(attributes[33]);
					centrexResaleCRSStationDW1Data12.setBa(attributes[34]);
					centrexResaleCRSStationDW1Data12.setBlock_attr(attributes[35]);
					centrexResaleCRSStationDW1Data12.setBlock(attributes[36]);
					centrexResaleCRSStationDW1Data12.setTsp_attr(attributes[37]);
					centrexResaleCRSStationDW1Data12.setTsp(attributes[38]);
					centrexResaleCRSStationDW1Data12.setJk_code_attr(attributes[39]);
					centrexResaleCRSStationDW1Data12.setJk_code(attributes[40]);
					centrexResaleCRSStationDW1Data12.setJk_num_attr(attributes[41]);
					centrexResaleCRSStationDW1Data12.setJk_num(attributes[42]);
					centrexResaleCRSStationDW1Data12.setJk_pos_attr(attributes[43]);
					centrexResaleCRSStationDW1Data12.setJk_pos(attributes[44]);
					centrexResaleCRSStationDW1Data12.setJr_attr(attributes[45]);
					centrexResaleCRSStationDW1Data12.setJr(attributes[46]);
					centrexResaleCRSStationDW1Data12.setNidr_attr(attributes[47]);
					centrexResaleCRSStationDW1Data12.setNidr(attributes[48]);
					centrexResaleCRSStationDW1Data12.setIwjk1_attr(attributes[49]);
					centrexResaleCRSStationDW1Data12.setIwjk1(attributes[50]);
					centrexResaleCRSStationDW1Data12.setIwjk2_attr(attributes[51]);
					centrexResaleCRSStationDW1Data12.setIwjk2(attributes[52]);
					centrexResaleCRSStationDW1Data12.setIwjk3_attr(attributes[53]);
					centrexResaleCRSStationDW1Data12.setIwjk3(attributes[54]);
					centrexResaleCRSStationDW1Data12.setIwjk4_attr(attributes[55]);
					centrexResaleCRSStationDW1Data12.setIwjk4(attributes[56]);
					centrexResaleCRSStationDW1Data12.setIwjk5_attr(attributes[57]);
					centrexResaleCRSStationDW1Data12.setIwjk5(attributes[58]);
					centrexResaleCRSStationDW1Data12.setIwjq1_attr(attributes[59]);
					centrexResaleCRSStationDW1Data12.setIwjq1(attributes[60]);
					centrexResaleCRSStationDW1Data12.setIwjq2_attr(attributes[61]);
					centrexResaleCRSStationDW1Data12.setIwjq2(attributes[62]);
					centrexResaleCRSStationDW1Data12.setIwjq3_attr(attributes[63]);
					centrexResaleCRSStationDW1Data12.setIwjq3(attributes[64]);
					centrexResaleCRSStationDW1Data12.setIwjq4_attr(attributes[65]);
					centrexResaleCRSStationDW1Data12.setIwjq4(attributes[66]);
					centrexResaleCRSStationDW1Data12.setIwjq5_attr(attributes[67]);
					centrexResaleCRSStationDW1Data12.setIwjq5(attributes[68]);
					centrexResaleCRSStationDW1Data12.setSai_attr(attributes[69]);
					centrexResaleCRSStationDW1Data12.setSai(attributes[70]);
					centrexResaleCRSStationDW1Data12.setName_attr(attributes[71]);
					centrexResaleCRSStationDW1Data12.setName(attributes[72]);
					centrexResaleCRSStationDW1Data12.setNcon_attr(attributes[73]);
					centrexResaleCRSStationDW1Data12.setNcon(attributes[74]);
					centrexResaleCRSStationDW1Data12.setAft_attr(attributes[75]);
					centrexResaleCRSStationDW1Data12.setAft(attributes[76]);
					centrexResaleCRSStationDW1Data12.setSapr_attr(attributes[77]);
					centrexResaleCRSStationDW1Data12.setSapr(attributes[78]);
					centrexResaleCRSStationDW1Data12.setSano_attr(attributes[79]);
					centrexResaleCRSStationDW1Data12.setSano(attributes[80]);
					centrexResaleCRSStationDW1Data12.setSasf_attr(attributes[81]);
					centrexResaleCRSStationDW1Data12.setSasf(attributes[82]);
					centrexResaleCRSStationDW1Data12.setSasd_attr(attributes[83]);
					centrexResaleCRSStationDW1Data12.setSasd(attributes[84]);
					centrexResaleCRSStationDW1Data12.setSasn_attr(attributes[85]);
					centrexResaleCRSStationDW1Data12.setSasn(attributes[86]);
					centrexResaleCRSStationDW1Data12.setSath_attr(attributes[87]);
					centrexResaleCRSStationDW1Data12.setSath(attributes[88]);
					centrexResaleCRSStationDW1Data12.setSass_attr(attributes[89]);
					centrexResaleCRSStationDW1Data12.setSass(attributes[90]);
					centrexResaleCRSStationDW1Data12.setLd1_attr(attributes[91]);
					centrexResaleCRSStationDW1Data12.setLd1(attributes[92]);
					centrexResaleCRSStationDW1Data12.setLv1_attr(attributes[93]);
					centrexResaleCRSStationDW1Data12.setLv1(attributes[94]);
					centrexResaleCRSStationDW1Data12.setLd2_attr(attributes[95]);
					centrexResaleCRSStationDW1Data12.setLd2(attributes[96]);
					centrexResaleCRSStationDW1Data12.setLv2_attr(attributes[97]);
					centrexResaleCRSStationDW1Data12.setLv2(attributes[98]);
					centrexResaleCRSStationDW1Data12.setLd3_attr(attributes[99]);
					centrexResaleCRSStationDW1Data12.setLd3(attributes[100]);
					centrexResaleCRSStationDW1Data12.setLv3_attr(attributes[101]);
					centrexResaleCRSStationDW1Data12.setLv3(attributes[102]);
					centrexResaleCRSStationDW1Data12.setAai_attr(attributes[103]);
					centrexResaleCRSStationDW1Data12.setAai(attributes[104]);
					centrexResaleCRSStationDW1Data12.setCity_attr(attributes[105]);
					centrexResaleCRSStationDW1Data12.setCity(attributes[106]);
					centrexResaleCRSStationDW1Data12.setState_attr(attributes[107]);
					centrexResaleCRSStationDW1Data12.setState(attributes[108]);
					centrexResaleCRSStationDW1Data12.setZip_attr(attributes[109]);
					centrexResaleCRSStationDW1Data12.setZip(attributes[110]);
					centrexResaleCRSStationDW1Data12.setLcon_attr(attributes[111]);
					centrexResaleCRSStationDW1Data12.setLcon(attributes[112]);
					centrexResaleCRSStationDW1Data12.setTelno_attr(attributes[113]);
					centrexResaleCRSStationDW1Data12.setTelno(attributes[114]);

					treeViewList_680.add(centrexResaleCRSStationDW1Data12);

				}
				session.setAttribute("treeViewList_680", treeViewList_680);
				selectRequestData.setSubHeader(receivedSubHeader);
				// System.out.println("treeViewList_680 size "+treeViewList_680.size());
			}

			if (subData_155Recid != null && subData_155Recid.getSubHeader().getRecord_type().equals("155")) {

				SubHeader receivedSubHeader = subData_155Recid.getSubHeader();
				String[] subDataRows = subData_155Recid.getSubDataRows();
				List<CentrexResaleCRSStationDW2Data12> treeViewList_155 = new ArrayList();
				treeViewList.add("155");
				// int i = 0;
				for (String subDataRow : subDataRows) {
					String[] attributes = mqReadUtil.getAttributes(subDataRow, 9);
//					//System.out.println("attributes:=155:Reqid======> " + Arrays.toString(attributes));
					CentrexResaleCRSStationDW2Data12 centrexResaleCRSStationDW2Data12 = new CentrexResaleCRSStationDW2Data12();

					centrexResaleCRSStationDW2Data12.setItem_num(attributes[0]);
					centrexResaleCRSStationDW2Data12.setF_fa_attr(attributes[1]);
					centrexResaleCRSStationDW2Data12.setF_fa(attributes[2]);
					centrexResaleCRSStationDW2Data12.setF_feature_attr(attributes[3]);
					centrexResaleCRSStationDW2Data12.setF_feature(attributes[4]);
					centrexResaleCRSStationDW2Data12.setF_feature_detail_attr(attributes[5]);
					centrexResaleCRSStationDW2Data12.setF_feature_detail(attributes[6]);
					centrexResaleCRSStationDW2Data12.setLine_asgn_attr(attributes[7]);
					centrexResaleCRSStationDW2Data12.setLine_asgn(attributes[8]);

					treeViewList_155.add(centrexResaleCRSStationDW2Data12);
				}
				session.setAttribute("treeViewList_155", treeViewList_155);
				selectRequestData.setSubHeader(receivedSubHeader);
				// System.out.println("treeViewList_155 size "+treeViewList_155.size());
			}
			if (subData_108Recid != null && subData_108Recid.getSubHeader().getRecord_type().equals("108")) {

				SubHeader receivedSubHeader = subData_108Recid.getSubHeader();
				String[] subDataRows = subData_108Recid.getSubDataRows();
				List<CentrexResaleCRSStationDisconnect_TCDW2Data12> treeViewList_108 = new ArrayList();
				treeViewList.add("108");
				// int i = 0;
				for (String subDataRow : subDataRows) {
					String[] attributes = mqReadUtil.getAttributes(subDataRow, 7);
//					//System.out.println("attributes:=108:Reqid======> " + Arrays.toString(attributes));
					CentrexResaleCRSStationDisconnect_TCDW2Data12 CentrexResaleCRSStationDisconnect_TCDW2Data12 = new CentrexResaleCRSStationDisconnect_TCDW2Data12();

					CentrexResaleCRSStationDisconnect_TCDW2Data12.setItem_num(attributes[0]);
					CentrexResaleCRSStationDisconnect_TCDW2Data12.setTc_id_sec_attr(attributes[1]);
					CentrexResaleCRSStationDisconnect_TCDW2Data12.setTc_id_sec(attributes[2]);
					CentrexResaleCRSStationDisconnect_TCDW2Data12.setTc_to_sec_attr(attributes[3]);
					CentrexResaleCRSStationDisconnect_TCDW2Data12.setTc_to_sec(attributes[4]);
					CentrexResaleCRSStationDisconnect_TCDW2Data12.setTc_name_sec_attr(attributes[5]);
					CentrexResaleCRSStationDisconnect_TCDW2Data12.setTc_name_sec(attributes[6]);

					treeViewList_108.add(CentrexResaleCRSStationDisconnect_TCDW2Data12);
				}
				session.setAttribute("treeViewList_108", treeViewList_108);
				selectRequestData.setSubHeader(receivedSubHeader);
				// System.out.println("treeViewList_108 size "+treeViewList_108.size());
			}
			if (subData_211Recid != null && subData_211Recid.getSubHeader().getRecord_type().equals("211")) {

				SubHeader receivedSubHeader = subData_211Recid.getSubHeader();
				String[] subDataRows = subData_211Recid.getSubDataRows();
				List<CentrexResaleCRSStationDisconnect_TCDW1Data12> treeViewList_211 = new ArrayList();
				treeViewList.add("211");
				// int i = 0;
				for (String subDataRow : subDataRows) {
					String[] attributes = mqReadUtil.getAttributes(subDataRow, 13);
//					//System.out.println("attributes:=211:Reqid======> " + Arrays.toString(attributes));
					CentrexResaleCRSStationDisconnect_TCDW1Data12 centrexResaleCRSStationDisconnect_TCDW1Data12 = new CentrexResaleCRSStationDisconnect_TCDW1Data12();

					centrexResaleCRSStationDisconnect_TCDW1Data12
							.setItem_num(attributes[0] != null && attributes[0] != "" ? attributes[0] : " ");
					centrexResaleCRSStationDisconnect_TCDW1Data12
							.setLnum_attr(attributes[1] != null && attributes[1] != "" ? attributes[1] : " ");
					centrexResaleCRSStationDisconnect_TCDW1Data12
							.setLnum(attributes[2] != null && attributes[2] != "" ? attributes[2] : " ");
					centrexResaleCRSStationDisconnect_TCDW1Data12
							.setTc_opt_attr(attributes[3] != null && attributes[3] != "" ? attributes[3] : " ");
					centrexResaleCRSStationDisconnect_TCDW1Data12
							.setTc_opt(attributes[4] != null && attributes[4] != "" ? attributes[4] : " ");
					centrexResaleCRSStationDisconnect_TCDW1Data12
							.setTc_per_attr(attributes[5] != null && attributes[5] != "" ? attributes[5] : " ");
					centrexResaleCRSStationDisconnect_TCDW1Data12
							.setTc_per(attributes[6] != null && attributes[6] != "" ? attributes[6] : " ");
					centrexResaleCRSStationDisconnect_TCDW1Data12
							.setTc_to_pri_attr(attributes[7] != null && attributes[7] != "" ? attributes[7] : " ");
					centrexResaleCRSStationDisconnect_TCDW1Data12
							.setTc_to_pri(attributes[8] != null && attributes[8] != "" ? attributes[8] : " ");
					centrexResaleCRSStationDisconnect_TCDW1Data12
							.setTc_name_pri_attr(attributes[9] != null && attributes[9] != "" ? attributes[9] : " ");
					centrexResaleCRSStationDisconnect_TCDW1Data12
							.setTc_name_pri(attributes[10] != null && attributes[10] != "" ? attributes[10] : " ");
					centrexResaleCRSStationDisconnect_TCDW1Data12
							.setTc_id_attr(attributes[11] != null && attributes[11] != "" ? attributes[11] : " ");
					centrexResaleCRSStationDisconnect_TCDW1Data12
							.setTc_id(attributes[12] != null && attributes[12] != "" ? attributes[12] : " ");

					treeViewList_211.add(centrexResaleCRSStationDisconnect_TCDW1Data12);
				}
				session.setAttribute("treeViewList_211", treeViewList_211);
				selectRequestData.setSubHeader(receivedSubHeader);
				// System.out.println("treeViewList_211 size "+treeViewList_211.size());
			}

			// Sneha
			if (subData12_585Recid != null && subData12_585Recid.getSubHeader().getRecord_type().equals("585")) {
				SubHeader receivedSubHeader = subData12_585Recid.getSubHeader();
				String[] subDataRows = subData12_585Recid.getSubDataRows();
				List<PostToBillTask_RecId585> treeViewList_585 = new ArrayList();
				treeViewList.add("585");
				String lsrNo = "";
				String status = "";
				for (String subDataRow : subDataRows) {
					String[] attributes = mqReadUtil.getAttributes(subDataRow, 12);
					PostToBillTask_RecId585 noteFupData = new PostToBillTask_RecId585();
					noteFupData.setC_ver_attr(attributes[0] != null && attributes[0] != "" ? attributes[0] : " ");
					noteFupData.setC_ver(attributes[1] != null && attributes[1] != "" ? attributes[1] : " ");
					noteFupData.setRt_attr(attributes[2] != null && attributes[2] != "" ? attributes[2] : " "); // Not
																												// getting
																												// data...!
					noteFupData.setRt(attributes[3] != null && attributes[3] != "" ? attributes[3] : " ");
					noteFupData.setEc_ver_attr(attributes[4] != null && attributes[4] != "" ? attributes[4] : " ");
					noteFupData.setEc_ver(attributes[5] != null && attributes[5] != "" ? attributes[5] : " ");
					noteFupData
							.setDt_sent_local_attr(attributes[6] != null && attributes[6] != "" ? attributes[6] : " ");
					noteFupData.setDt_sent_local(attributes[7] != null && attributes[7] != "" ? attributes[7] : " ");

					noteFupData.setResponse_dt_sent_attr(
							attributes[8] != null && attributes[8] != "" ? attributes[8] : " ");
					noteFupData.setResponse_dt_sent(attributes[9] != null && attributes[9] != "" ? attributes[9] : " ");
					//Sneha 14 Feb start
					noteFupData.setPd(FormatUtil.getMqStringToDate(attributes[11] != null && attributes[11] != "" ? attributes[11] : " "));
					//Sneha 14 Feb end
					
					//noteFupData.setPd_attr(attributes[10] != null && attributes[10] != "" ? attributes[10] : " ");
					noteFupData.setPd(attributes[11] != null && attributes[11] != "" ? attributes[11] : " ");

					treeViewList_585.add(noteFupData);
				}
				selectRequestData.setSubHeader(receivedSubHeader);
				session.setAttribute("treeViewList_585", treeViewList_585);
				// model.addAttribute("treeViewList_558", treeViewList_558);
				System.out.println("Model get Attribute  ");
			}

			if (subData12_588Recid != null && subData12_588Recid.getSubHeader().getRecord_type().equals("588")) {
				SubHeader receivedSubHeader = subData12_588Recid.getSubHeader();
				String[] subDataRows = subData12_588Recid.getSubDataRows();
				List<PostToBillTaskLSCInfo_588> treeViewList_588 = new ArrayList();
				treeViewList.add("588");
				String lsrNo = "";
				String status = "";
				for (String subDataRow : subDataRows) {
					String[] attributes = mqReadUtil.getAttributes(subDataRow, 14);
					PostToBillTaskLSCInfo_588 noteFupData = new PostToBillTaskLSCInfo_588();
					noteFupData.setOld_dtm(attributes[0] != null && attributes[0] != "" ? attributes[0] : " ");
					noteFupData.setOld_ord(attributes[1] != null && attributes[1] != "" ? attributes[1] : " ");
					noteFupData.setOrd_attr(attributes[2] != null && attributes[2] != "" ? attributes[2] : " "); // Not
																													// getting
																													// data...!
					noteFupData.setOrd(attributes[3] != null && attributes[3] != "" ? attributes[3] : " ");
					noteFupData.setFdt_attr(attributes[4] != null && attributes[4] != "" ? attributes[4] : " ");
					noteFupData.setFdt(attributes[5] != null && attributes[5] != "" ? attributes[5] : " ");
					noteFupData.setDd_attr(attributes[6] != null && attributes[6] != "" ? attributes[6] : " ");
					// noteFupData.setDd(attributes[7] != null && attributes[7] != "" ?
					// attributes[7] : " ");
					noteFupData.setDd(FormatUtil
							.getMqStringToDate(attributes[7] != null && attributes[7] != "" ? attributes[7] : " "));// Rupas
																													// changes
					noteFupData.setComp_dt_attr(attributes[8] != null && attributes[8] != "" ? attributes[8] : " ");
					noteFupData.setComp_dt(attributes[9] != null && attributes[9] != "" ? attributes[9] : " ");
					noteFupData
							.setPosted_date_attr(attributes[10] != null && attributes[10] != "" ? attributes[10] : " ");
					noteFupData.setPosted_date(attributes[11] != null && attributes[11] != "" ? attributes[11] : " ");
					noteFupData.setApptime_attr(attributes[12] != null && attributes[12] != "" ? attributes[12] : " ");
					noteFupData.setApptime(attributes[13] != null && attributes[13] != "" ? attributes[13] : " ");

					treeViewList_588.add(noteFupData);
				}
				selectRequestData.setSubHeader(receivedSubHeader);
				session.setAttribute("treeViewList_588", treeViewList_588);
				// model.addAttribute("treeViewList_558", treeViewList_558);
				System.out.println("Model get Attribute  ");
			}

			// =======================Sneha End======================================

			if (subData_681Recid != null && subData_681Recid.getSubHeader().getRecord_type().equals("681")) {
				// System.out.println("====sucess 681====");
				SubHeader receivedSubHeader = subData_681Recid.getSubHeader();
				String[] subDataRows = subData_681Recid.getSubDataRows();
				List<CentrexPort_CUS_Location_12State_ReqV> treeViewList_681 = new ArrayList();
				treeViewList.add("681");
				for (String subDataRow : subDataRows) {
					String[] attributes = mqReadUtil.getAttributes(subDataRow, 115);
//					//System.out.println("attributes:=681======> " + Arrays.toString(attributes));
					CentrexPort_CUS_Location_12State_ReqV portShared12 = new CentrexPort_CUS_Location_12State_ReqV();
					portShared12.setItem_num(attributes[0]);
					portShared12.setLnum_attr(attributes[1]);
					portShared12.setLnum(attributes[2]);
					portShared12.setLna_attr(attributes[3]);
					portShared12.setLna(attributes[4]);
					portShared12.setNpi_attr(attributes[5]);
					portShared12.setNpi(attributes[6]);
					portShared12.setLst_attr(attributes[7]);
					portShared12.setLst(attributes[8]);
					portShared12.setTns_attr(attributes[9]);
					portShared12.setTns(attributes[10]);
					portShared12.setTers_attr(attributes[11]);
					portShared12.setTers(attributes[12]);
					portShared12.setOtn_attr(attributes[13]);
					portShared12.setOtn(attributes[14]);
					portShared12.setIspid_attr(attributes[15]);
					portShared12.setIspid(attributes[16]);
					portShared12.setIsdnp_attr(attributes[17]);
					portShared12.setIsdnp(attributes[18]);
					portShared12.setEcckt_attr(attributes[19]);
					portShared12.setEcckt(attributes[20]);
					portShared12.setCfa_attr(attributes[21]);
					portShared12.setCfa(attributes[22]);
					portShared12.setCcea_attr(attributes[23]);
					portShared12.setCcea(attributes[24]);
					portShared12.setCkr_attr(attributes[25]);
					portShared12.setCkr(attributes[26]);
					portShared12.setPic_attr(attributes[27]);
					portShared12.setPic(attributes[28]);
					portShared12.setLpic_attr(attributes[29]);
					portShared12.setLpic(attributes[30]);
					portShared12.setSsig_attr(attributes[31]);
					portShared12.setSsig(attributes[32]);
					portShared12.setBa_attr(attributes[33]);
					portShared12.setBa(attributes[34]);
					portShared12.setBlock_attr(attributes[35]);
					portShared12.setBlock(attributes[36]);
					portShared12.setTsp_attr(attributes[37]);
					portShared12.setTsp(attributes[38]);
					portShared12.setJk_code_attr(attributes[39]);
					portShared12.setJk_code(attributes[40]);
					portShared12.setJk_num_attr(attributes[41]);
					portShared12.setJk_num(attributes[42]);
					portShared12.setJk_pos_attr(attributes[43]);
					portShared12.setJk_pos(attributes[44]);
					portShared12.setJr_attr(attributes[45]);
					portShared12.setJr(attributes[46]);
					portShared12.setNidr_attr(attributes[47]);
					portShared12.setNidr(attributes[48]);
					portShared12.setIwjk1_attr(attributes[49]);
					portShared12.setIwjk1(attributes[50]);
					portShared12.setIwjk2_attr(attributes[51]);
					portShared12.setIwjk2(attributes[52]);
					portShared12.setIwjk3_attr(attributes[53]);
					portShared12.setIwjk3(attributes[54]);
					portShared12.setIwjk4_attr(attributes[55]);
					portShared12.setIwjk4(attributes[56]);
					portShared12.setIwjk5_attr(attributes[57]);
					portShared12.setIwjk5(attributes[58]);
					portShared12.setIwjq1_attr(attributes[59]);
					portShared12.setIwjq1(attributes[60]);
					portShared12.setIwjq2_attr(attributes[61]);
					portShared12.setIwjq2(attributes[62]);
					portShared12.setIwjq3_attr(attributes[63]);
					portShared12.setIwjq3(attributes[64]);
					portShared12.setIwjq4_attr(attributes[65]);
					portShared12.setIwjq4(attributes[66]);
					portShared12.setIwjq5_attr(attributes[67]);
					portShared12.setIwjq5(attributes[68]);
					portShared12.setSai_attr(attributes[69]);
					portShared12.setSai(attributes[70]);
					portShared12.setName_attr(attributes[71]);
					portShared12.setName(attributes[72]);
					portShared12.setNcon_attr(attributes[73]);
					portShared12.setNcon(attributes[74]);

					portShared12.setAft_attr(attributes[75]);
					portShared12.setAft(attributes[76]);
					portShared12.setSapr_attr(attributes[77]);
					portShared12.setSapr(attributes[78]);
					portShared12.setSano_attr(attributes[79]);
					portShared12.setSano(attributes[80]);
					portShared12.setSasf_attr(attributes[81]);
					portShared12.setSasf(attributes[82]);
					portShared12.setSasd_attr(attributes[83]);
					portShared12.setSasd(attributes[84]);
					portShared12.setSasn_attr(attributes[85]);
					portShared12.setSasn(attributes[86]);
					portShared12.setSath_attr(attributes[87]);
					portShared12.setSath(attributes[88]);
					portShared12.setSass_attr(attributes[89]);
					portShared12.setSass(attributes[90]);
					portShared12.setLd1_attr(attributes[91]);
					portShared12.setLd1(attributes[92]);
					portShared12.setLv1_attr(attributes[93]);
					portShared12.setLv1(attributes[94]);
					portShared12.setLd2_attr(attributes[95]);
					portShared12.setLd2(attributes[96]);
					portShared12.setLv2_attr(attributes[97]);
					portShared12.setLv2(attributes[98]);
					portShared12.setLd3_attr(attributes[99]);
					portShared12.setLd3(attributes[100]);
					portShared12.setLv3_attr(attributes[101]);
					portShared12.setLv3(attributes[102]);
					portShared12.setAai_attr(attributes[103]);
					portShared12.setAai(attributes[104]);
					portShared12.setCity_attr(attributes[105]);
					portShared12.setCity(attributes[106]);
					portShared12.setState_attr(attributes[107]);
					portShared12.setState(attributes[108]);
					portShared12.setZip_attr(attributes[109]);
					portShared12.setZip(attributes[110]);
					portShared12.setLcon_attr(attributes[111]);
					portShared12.setLcon(attributes[112]);
					portShared12.setTelno_attr(attributes[113]);
					portShared12.setTelno(attributes[114]);

					treeViewList_681.add(portShared12);
				}
				session.setAttribute("treeViewList_681", treeViewList_681);
				selectRequestData.setSubHeader(receivedSubHeader);
				// System.out.println("treeViewList_681 size "+treeViewList_681.size());
			}
			if (subData_682Recid != null && subData_682Recid.getSubHeader().getRecord_type().equals("682")) {
				// System.out.println("====sucess==");
				SubHeader receivedSubHeader = subData_682Recid.getSubHeader();
				String[] subDataRows = subData_682Recid.getSubDataRows();
				List<CentrexPort_LoopCUS_Station_12Data> treeViewList_682 = new ArrayList();
				treeViewList.add("682");
				for (String subDataRow : subDataRows) {
					String[] attributes = mqReadUtil.getAttributes(subDataRow, 115);
//					//System.out.println("attributes:=682======> " + Arrays.toString(attributes));
					CentrexPort_LoopCUS_Station_12Data portShared12 = new CentrexPort_LoopCUS_Station_12Data();
					portShared12.setItem_num(attributes[0]);
					portShared12.setLnum_attr(attributes[1]);
					portShared12.setLnum(attributes[2]);
					portShared12.setLna_attr(attributes[3]);
					portShared12.setLna(attributes[4]);
					portShared12.setNpi_attr(attributes[5]);
					portShared12.setNpi(attributes[6]);
					portShared12.setLst_attr(attributes[7]);
					portShared12.setLst(attributes[8]);
					portShared12.setTns_attr(attributes[9]);
					portShared12.setTns(attributes[10]);
					portShared12.setTers_attr(attributes[11]);
					portShared12.setTers(attributes[12]);
					portShared12.setOtn_attr(attributes[13]);
					portShared12.setOtn(attributes[14]);
					portShared12.setIspid_attr(attributes[15]);
					portShared12.setIspid(attributes[16]);
					portShared12.setIsdnp_attr(attributes[17]);
					portShared12.setIsdnp(attributes[18]);
					portShared12.setEcckt_attr(attributes[19]);
					portShared12.setEcckt(attributes[20]);
					portShared12.setCfa_attr(attributes[21]);
					portShared12.setCfa(attributes[22]);
					portShared12.setCcea_attr(attributes[23]);
					portShared12.setCcea(attributes[24]);
					portShared12.setCkr_attr(attributes[25]);
					portShared12.setCkr(attributes[26]);
					portShared12.setPic_attr(attributes[27]);
					portShared12.setPic(attributes[28]);
					portShared12.setLpic_attr(attributes[29]);
					portShared12.setLpic(attributes[30]);
					portShared12.setSsig_attr(attributes[31]);
					portShared12.setSsig(attributes[32]);
					portShared12.setBa_attr(attributes[33]);
					portShared12.setBa(attributes[34]);
					portShared12.setBlock_attr(attributes[35]);
					portShared12.setBlock(attributes[36]);
					portShared12.setTsp_attr(attributes[37]);
					portShared12.setTsp(attributes[38]);
					portShared12.setJk_code_attr(attributes[39]);
					portShared12.setJk_code(attributes[40]);
					portShared12.setJk_num_attr(attributes[41]);
					portShared12.setJk_num(attributes[42]);
					portShared12.setJk_pos_attr(attributes[43]);
					portShared12.setJk_pos(attributes[44]);
					portShared12.setJr_attr(attributes[45]);
					portShared12.setJr(attributes[46]);
					portShared12.setNidr_attr(attributes[47]);
					portShared12.setNidr(attributes[48]);
					portShared12.setIwjk1_attr(attributes[49]);
					portShared12.setIwjk1(attributes[50]);
					portShared12.setIwjk2_attr(attributes[51]);
					portShared12.setIwjk2(attributes[52]);
					portShared12.setIwjk3_attr(attributes[53]);
					portShared12.setIwjk3(attributes[54]);
					portShared12.setIwjk4_attr(attributes[55]);
					portShared12.setIwjk4(attributes[56]);
					portShared12.setIwjk5_attr(attributes[57]);
					portShared12.setIwjk5(attributes[58]);
					portShared12.setIwjq1_attr(attributes[59]);
					portShared12.setIwjq1(attributes[60]);
					portShared12.setIwjq2_attr(attributes[61]);
					portShared12.setIwjq2(attributes[62]);
					portShared12.setIwjq3_attr(attributes[63]);
					portShared12.setIwjq3(attributes[64]);
					portShared12.setIwjq4_attr(attributes[65]);
					portShared12.setIwjq4(attributes[66]);
					portShared12.setIwjq5_attr(attributes[67]);
					portShared12.setIwjq5(attributes[68]);
					portShared12.setSai_attr(attributes[69]);
					portShared12.setSai(attributes[70]);
					portShared12.setName_attr(attributes[71]);
					portShared12.setName(attributes[72]);
					portShared12.setNcon_attr(attributes[73]);
					portShared12.setNcon(attributes[74]);

					portShared12.setAft_attr(attributes[75]);
					portShared12.setAft(attributes[76]);
					portShared12.setSapr_attr(attributes[77]);
					portShared12.setSapr(attributes[78]);
					portShared12.setSano_attr(attributes[79]);
					portShared12.setSano(attributes[80]);
					portShared12.setSasf_attr(attributes[81]);
					portShared12.setSasf(attributes[82]);
					portShared12.setSasd_attr(attributes[83]);
					portShared12.setSasd(attributes[84]);
					portShared12.setSasn_attr(attributes[85]);
					portShared12.setSasn(attributes[86]);
					portShared12.setSath_attr(attributes[87]);
					portShared12.setSath(attributes[88]);
					portShared12.setSass_attr(attributes[89]);
					portShared12.setSass(attributes[90]);
					portShared12.setLd1_attr(attributes[91]);
					portShared12.setLd1(attributes[92]);
					portShared12.setLv1_attr(attributes[93]);
					portShared12.setLv1(attributes[94]);
					portShared12.setLd2_attr(attributes[95]);
					portShared12.setLd2(attributes[96]);
					portShared12.setLv2_attr(attributes[97]);
					portShared12.setLv2(attributes[98]);
					portShared12.setLd3_attr(attributes[99]);
					portShared12.setLd3(attributes[100]);
					portShared12.setLv3_attr(attributes[101]);
					portShared12.setLv3(attributes[102]);
					portShared12.setAai_attr(attributes[103]);
					portShared12.setAai(attributes[104]);
					portShared12.setCity_attr(attributes[105]);
					portShared12.setCity(attributes[106]);
					portShared12.setState_attr(attributes[107]);
					portShared12.setState(attributes[108]);
					portShared12.setZip_attr(attributes[109]);
					portShared12.setZip(attributes[110]);
					portShared12.setLcon_attr(attributes[111]);
					portShared12.setLcon(attributes[112]);
					portShared12.setTelno_attr(attributes[113]);
					portShared12.setTelno(attributes[114]);

					treeViewList_682.add(portShared12);
				}
				session.setAttribute("treeViewList_682", treeViewList_682);
				selectRequestData.setSubHeader(receivedSubHeader);
				// System.out.println("treeViewList_682 size "+treeViewList_682.size());
			}

			if (subData_500Recid != null && subData_500Recid.getSubHeader().getRecord_type().equals("500")) {

				SubHeader receivedSubHeader = subData_500Recid.getSubHeader();
				String[] subDataRows = subData_500Recid.getSubDataRows();
				List<Resaleprivatelinecircuit12states> treeViewList_500 = new ArrayList();
				treeViewList.add("500");
				// int i = 0;
				for (String subDataRow : subDataRows) {
					String[] attributes = mqReadUtil.getAttributes(subDataRow, 17);
//					//System.out.println("attributes:=500:Reqid======> " + Arrays.toString(attributes));
					Resaleprivatelinecircuit12states resaleprivatelinecircuit12states = new Resaleprivatelinecircuit12states();

					resaleprivatelinecircuit12states
							.setItem_num(attributes[0] != null && attributes[0] != "" ? attributes[0] : " ");
					resaleprivatelinecircuit12states
							.setLnum_attr(attributes[1] != null && attributes[1] != "" ? attributes[1] : " ");
					resaleprivatelinecircuit12states
							.setLnum(attributes[2] != null && attributes[2] != "" ? attributes[2] : " ");
					resaleprivatelinecircuit12states
							.setCkta_attr(attributes[3] != null && attributes[3] != "" ? attributes[3] : " ");
					resaleprivatelinecircuit12states
							.setCkta(attributes[4] != null && attributes[4] != "" ? attributes[4] : " ");
					resaleprivatelinecircuit12states
							.setSvc_cd_attr(attributes[5] != null && attributes[5] != "" ? attributes[5] : " ");
					resaleprivatelinecircuit12states
							.setSvc_cd(attributes[6] != null && attributes[6] != "" ? attributes[6] : " ");
					resaleprivatelinecircuit12states
							.setCkttyp_attr(attributes[7] != null && attributes[7] != "" ? attributes[7] : " ");
					resaleprivatelinecircuit12states
							.setCkttyp(attributes[8] != null && attributes[8] != "" ? attributes[8] : " ");
					resaleprivatelinecircuit12states
							.setEcckt_attr(attributes[9] != null && attributes[9] != "" ? attributes[9] : " ");
					resaleprivatelinecircuit12states
							.setEcckt(attributes[10] != null && attributes[10] != "" ? attributes[10] : " ");

					resaleprivatelinecircuit12states
							.setMtp_attr(attributes[11] != null && attributes[11] != "" ? attributes[11] : " ");
					resaleprivatelinecircuit12states
							.setMtp(attributes[12] != null && attributes[12] != "" ? attributes[12] : " ");
					resaleprivatelinecircuit12states
							.setWire_attr(attributes[13] != null && attributes[13] != "" ? attributes[13] : " ");
					resaleprivatelinecircuit12states
							.setWire(attributes[14] != null && attributes[14] != "" ? attributes[14] : " ");
					resaleprivatelinecircuit12states
							.setDisc_ecckt_attr(attributes[15] != null && attributes[15] != "" ? attributes[15] : " ");

					resaleprivatelinecircuit12states
							.setDisc_ecckt(attributes[16] != null && attributes[16] != "" ? attributes[16] : " ");
					// resaleprivatelinecircuit12states.setScreenName("Circut");

					treeViewList_500.add(resaleprivatelinecircuit12states);
				}
				session.setAttribute("treeViewList_500", treeViewList_500);
				selectRequestData.setSubHeader(receivedSubHeader);
				// System.out.println("treeViewList_500 size "+treeViewList_500.size());
			}

			if (subData_510Recid != null && subData_510Recid.getSubHeader().getRecord_type().equals("510")) {

				SubHeader receivedSubHeader = subData_510Recid.getSubHeader();
				String[] subDataRows = subData_510Recid.getSubDataRows();
				List<Resaleprivatelineprimarylocation12states> treeViewList_510 = new ArrayList();
				treeViewList.add("510");
				// List treeViewList = new ArrayList();
				// int i = 0;
				for (String subDataRow : subDataRows) {
					String[] attributes = mqReadUtil.getAttributes(subDataRow, 98);
//					//System.out.println("attributes:=510======> " + Arrays.toString(attributes));
					Resaleprivatelineprimarylocation12states resaleprivatelineprimarylocation12states = new Resaleprivatelineprimarylocation12states();

					resaleprivatelineprimarylocation12states.setRequest_prod_id(attributes[0]);
					resaleprivatelineprimarylocation12states.setItem_num(attributes[1]);
					resaleprivatelineprimarylocation12states.setLnum_attr(attributes[2]);
					resaleprivatelineprimarylocation12states.setLnum(attributes[3]);
					resaleprivatelineprimarylocation12states.setLeg_itemnum_attr(attributes[4]);
					resaleprivatelineprimarylocation12states.setLeg_itemnum(attributes[5]);
					resaleprivatelineprimarylocation12states.setLegnum_attr(attributes[6]);
					resaleprivatelineprimarylocation12states.setLegnum(attributes[7]);
					resaleprivatelineprimarylocation12states.setPri_lna_attr(attributes[8]);
					resaleprivatelineprimarylocation12states.setPri_lna(attributes[9]);
					resaleprivatelineprimarylocation12states.setLit_attr(attributes[10]);
					resaleprivatelineprimarylocation12states.setLit(attributes[11]);
					resaleprivatelineprimarylocation12states.setPriloc_attr(attributes[12]);
					resaleprivatelineprimarylocation12states.setPriloc(attributes[13]);
					resaleprivatelineprimarylocation12states.setPriname_attr(attributes[14]);
					resaleprivatelineprimarylocation12states.setPriname(attributes[15]);
					resaleprivatelineprimarylocation12states.setCfa_attr(attributes[16]);
					resaleprivatelineprimarylocation12states.setCfa(attributes[17]);
					resaleprivatelineprimarylocation12states.setFic_attr(attributes[18]);
					resaleprivatelineprimarylocation12states.setFic(attributes[19]);
					resaleprivatelineprimarylocation12states.setSr_attr(attributes[20]);
					resaleprivatelineprimarylocation12states.setSr(attributes[21]);
					resaleprivatelineprimarylocation12states.setRpl_ncon_attr(attributes[22]);
					resaleprivatelineprimarylocation12states.setRpl_ncon(attributes[23]);
					resaleprivatelineprimarylocation12states.setAft_attr(attributes[24]);
					resaleprivatelineprimarylocation12states.setAft(attributes[25]);
					resaleprivatelineprimarylocation12states.setSapr_attr(attributes[26]);
					resaleprivatelineprimarylocation12states.setSapr(attributes[27]);
					resaleprivatelineprimarylocation12states.setSano_attr(attributes[28]);
					resaleprivatelineprimarylocation12states.setSano(attributes[29]);
					resaleprivatelineprimarylocation12states.setSasf_attr(attributes[30]);
					resaleprivatelineprimarylocation12states.setSasf(attributes[31]);
					resaleprivatelineprimarylocation12states.setSasd_attr(attributes[32]);
					resaleprivatelineprimarylocation12states.setSasd(attributes[33]);
					resaleprivatelineprimarylocation12states.setSasn_attr(attributes[34]);
					resaleprivatelineprimarylocation12states.setSasn(attributes[35]);
					resaleprivatelineprimarylocation12states.setSath_attr(attributes[36]);
					resaleprivatelineprimarylocation12states.setSath(attributes[37]);
					resaleprivatelineprimarylocation12states.setSass_attr(attributes[38]);
					resaleprivatelineprimarylocation12states.setSass(attributes[39]);
					resaleprivatelineprimarylocation12states.setLd1_attr(attributes[40]);
					resaleprivatelineprimarylocation12states.setLd1(attributes[41]);
					resaleprivatelineprimarylocation12states.setLv1_attr(attributes[42]);
					resaleprivatelineprimarylocation12states.setLv1(attributes[43]);
					resaleprivatelineprimarylocation12states.setLd2_attr(attributes[44]);
					resaleprivatelineprimarylocation12states.setLd2(attributes[45]);
					resaleprivatelineprimarylocation12states.setLv2_attr(attributes[46]);
					resaleprivatelineprimarylocation12states.setLv2(attributes[47]);
					resaleprivatelineprimarylocation12states.setLd3_attr(attributes[48]);
					resaleprivatelineprimarylocation12states.setLd3(attributes[49]);
					resaleprivatelineprimarylocation12states.setLv3_attr(attributes[50]);
					resaleprivatelineprimarylocation12states.setLv3(attributes[51]);
					resaleprivatelineprimarylocation12states.setAai_attr(attributes[52]);
					resaleprivatelineprimarylocation12states.setAai(attributes[53]);
					resaleprivatelineprimarylocation12states.setCity_attr(attributes[54]);
					resaleprivatelineprimarylocation12states.setCity(attributes[55]);
					resaleprivatelineprimarylocation12states.setState_attr(attributes[56]);
					resaleprivatelineprimarylocation12states.setState(attributes[57]);
					resaleprivatelineprimarylocation12states.setZip_attr(attributes[58]);
					resaleprivatelineprimarylocation12states.setZip(attributes[59]);
					resaleprivatelineprimarylocation12states.setAloc_attr(attributes[60]);
					resaleprivatelineprimarylocation12states.setAloc(attributes[61]);
					resaleprivatelineprimarylocation12states.setLcon_attr(attributes[62]);
					resaleprivatelineprimarylocation12states.setLcon(attributes[63]);
					resaleprivatelineprimarylocation12states.setActel_no_attr(attributes[64]);
					resaleprivatelineprimarylocation12states.setActel_no(attributes[65]);
					resaleprivatelineprimarylocation12states.setAcc_attr(attributes[66]);
					resaleprivatelineprimarylocation12states.setAcc(attributes[67]);
					resaleprivatelineprimarylocation12states.setJr_attr(attributes[68]);
					resaleprivatelineprimarylocation12states.setJr(attributes[69]);
					resaleprivatelineprimarylocation12states.setJk_code_attr(attributes[70]);
					resaleprivatelineprimarylocation12states.setJk_code(attributes[71]);
					resaleprivatelineprimarylocation12states.setJk_num_attr(attributes[72]);
					resaleprivatelineprimarylocation12states.setJk_num(attributes[73]);
					resaleprivatelineprimarylocation12states.setJk_pos_attr(attributes[74]);
					resaleprivatelineprimarylocation12states.setJk_pos(attributes[75]);
					resaleprivatelineprimarylocation12states.setIwo_attr(attributes[76]);
					resaleprivatelineprimarylocation12states.setIwo(attributes[77]);
					resaleprivatelineprimarylocation12states.setIwjq1_attr(attributes[78]);
					resaleprivatelineprimarylocation12states.setIwjq1(attributes[79]);
					resaleprivatelineprimarylocation12states.setIwjq2_attr(attributes[80]);
					resaleprivatelineprimarylocation12states.setIwjq2(attributes[81]);
					resaleprivatelineprimarylocation12states.setIwjq3_attr(attributes[82]);
					resaleprivatelineprimarylocation12states.setIwjq3(attributes[83]);
					resaleprivatelineprimarylocation12states.setIwjq4_attr(attributes[84]);
					resaleprivatelineprimarylocation12states.setIwjq4(attributes[85]);
					resaleprivatelineprimarylocation12states.setIwjq5_attr(attributes[86]);
					resaleprivatelineprimarylocation12states.setIwjq5(attributes[87]);
					resaleprivatelineprimarylocation12states.setIwjk1_attr(attributes[88]);
					resaleprivatelineprimarylocation12states.setIwjk1(attributes[89]);
					resaleprivatelineprimarylocation12states.setIwjk2_attr(attributes[90]);
					resaleprivatelineprimarylocation12states.setIwjk2(attributes[91]);
					resaleprivatelineprimarylocation12states.setIwjk3_attr(attributes[92]);
					resaleprivatelineprimarylocation12states.setIwjk3(attributes[93]);
					resaleprivatelineprimarylocation12states.setIwjk4_attr(attributes[94]);
					resaleprivatelineprimarylocation12states.setIwjk4(attributes[95]);
					resaleprivatelineprimarylocation12states.setIwjk5_attr(attributes[96]);
					resaleprivatelineprimarylocation12states.setIwjk5(attributes[97]);

					treeViewList_510.add(resaleprivatelineprimarylocation12states);
				}
				session.setAttribute("treeViewList_510", treeViewList_510);
				selectRequestData.setSubHeader(receivedSubHeader);
				// System.out.println("treeViewList_510 size "+treeViewList_510.size());
			}
			if (subData_156Recid != null && subData_156Recid.getSubHeader().getRecord_type().equals("156")) {

				SubHeader receivedSubHeader = subData_156Recid.getSubHeader();
				String[] subDataRows = subData_156Recid.getSubDataRows();
				List<Resaleprivatelineprimarylocation_grid12states> treeViewList_156 = new ArrayList();
				treeViewList.add("156");
				// List treeViewList = new ArrayList();
				// int i = 0;
				for (String subDataRow : subDataRows) {
					String[] attributes = mqReadUtil.getAttributes(subDataRow, 11);
//					//System.out.println("attributes:==156=====> " + Arrays.toString(attributes));
					Resaleprivatelineprimarylocation_grid12states resaleprivatelineprimarylocation_grid12states = new Resaleprivatelineprimarylocation_grid12states();

					resaleprivatelineprimarylocation_grid12states.setRequest_prod_id(attributes[0]);
					resaleprivatelineprimarylocation_grid12states.setItem_num(attributes[1]);
					resaleprivatelineprimarylocation_grid12states.setLeg_itemnum(attributes[2]);
					resaleprivatelineprimarylocation_grid12states.setFa_attr(attributes[3]);
					resaleprivatelineprimarylocation_grid12states.setFa(attributes[4]);
					resaleprivatelineprimarylocation_grid12states.setFeature_attr(attributes[5]);
					resaleprivatelineprimarylocation_grid12states.setFeature(attributes[6]);
					resaleprivatelineprimarylocation_grid12states.setFeature_detail_attr(attributes[7]);
					resaleprivatelineprimarylocation_grid12states.setFeature_detail(attributes[8]);
					resaleprivatelineprimarylocation_grid12states.setLine_asgn_attr(attributes[9]);
					resaleprivatelineprimarylocation_grid12states.setLine_asgn(attributes[10]);

					treeViewList_156.add(resaleprivatelineprimarylocation_grid12states);
				}
				session.setAttribute("treeViewList_156", treeViewList_156);
				selectRequestData.setSubHeader(receivedSubHeader);
				// System.out.println("treeViewList_156 size "+treeViewList_156.size());
			}
			if (subData_511Recid != null && subData_511Recid.getSubHeader().getRecord_type().equals("511")) {

				SubHeader receivedSubHeader = subData_511Recid.getSubHeader();
				String[] subDataRows = subData_511Recid.getSubDataRows();
				List<Resaleprivatelinesecondarylocation12states> treeViewList_511 = new ArrayList();
				treeViewList.add("511");

				// int i = 0;
				for (String subDataRow : subDataRows) {
					String[] attributes = mqReadUtil.getAttributes(subDataRow, 104);
//					//System.out.println("attributes:=511:Reqid======> " + Arrays.toString(attributes));
					Resaleprivatelinesecondarylocation12states resaleprivatelinesecondarylocation12states = new Resaleprivatelinesecondarylocation12states();

					resaleprivatelinesecondarylocation12states.setRequest_prod_id(attributes[0]);
					resaleprivatelinesecondarylocation12states.setItem_num(attributes[1]);
					resaleprivatelinesecondarylocation12states.setLnum_attr(attributes[2]);
					resaleprivatelinesecondarylocation12states.setLnum(attributes[3]);
					resaleprivatelinesecondarylocation12states.setLeg_itemnum_attr(attributes[4]);
					resaleprivatelinesecondarylocation12states.setLeg_itemnum(attributes[5]);
					resaleprivatelinesecondarylocation12states.setLegnum_attr(attributes[6]);
					resaleprivatelinesecondarylocation12states.setLegnum(attributes[7]);
					resaleprivatelinesecondarylocation12states.setLegid_attr(attributes[8]);
					resaleprivatelinesecondarylocation12states.setLegid(attributes[9]);
					resaleprivatelinesecondarylocation12states.setSec_lna_attr(attributes[10]);
					resaleprivatelinesecondarylocation12states.setSec_lna(attributes[11]);
					resaleprivatelinesecondarylocation12states.setMl_attr(attributes[12]);
					resaleprivatelinesecondarylocation12states.setMl(attributes[13]);
					resaleprivatelinesecondarylocation12states.setLit_attr(attributes[14]);
					resaleprivatelinesecondarylocation12states.setLit(attributes[15]);
					resaleprivatelinesecondarylocation12states.setSecloc_attr(attributes[16]);
					resaleprivatelinesecondarylocation12states.setSecloc(attributes[17]);
					resaleprivatelinesecondarylocation12states.setSecname_attr(attributes[18]);
					resaleprivatelinesecondarylocation12states.setSecname(attributes[19]);
					resaleprivatelinesecondarylocation12states.setCfa_attr(attributes[20]);
					resaleprivatelinesecondarylocation12states.setCfa(attributes[21]);
					resaleprivatelinesecondarylocation12states.setFic_attr(attributes[22]);
					resaleprivatelinesecondarylocation12states.setFic(attributes[23]);
					resaleprivatelinesecondarylocation12states.setSr_attr(attributes[24]);
					resaleprivatelinesecondarylocation12states.setSr(attributes[25]);
					resaleprivatelinesecondarylocation12states.setRpl_ncon_attr(attributes[26]);
					resaleprivatelinesecondarylocation12states.setRpl_ncon(attributes[27]);
					resaleprivatelinesecondarylocation12states.setAft_attr(attributes[28]);
					resaleprivatelinesecondarylocation12states.setAft(attributes[29]);
					resaleprivatelinesecondarylocation12states.setSapr_attr(attributes[30]);
					resaleprivatelinesecondarylocation12states.setSapr(attributes[31]);
					resaleprivatelinesecondarylocation12states.setSano_attr(attributes[32]);
					resaleprivatelinesecondarylocation12states.setSano(attributes[33]);
					resaleprivatelinesecondarylocation12states.setSasf_attr(attributes[34]);
					resaleprivatelinesecondarylocation12states.setSasf(attributes[35]);
					resaleprivatelinesecondarylocation12states.setSasd_attr(attributes[36]);
					resaleprivatelinesecondarylocation12states.setSasd(attributes[37]);
					resaleprivatelinesecondarylocation12states.setSasn_attr(attributes[38]);
					resaleprivatelinesecondarylocation12states.setSasn(attributes[39]);
					resaleprivatelinesecondarylocation12states.setSath_attr(attributes[40]);
					resaleprivatelinesecondarylocation12states.setSath(attributes[41]);
					resaleprivatelinesecondarylocation12states.setSass_attr(attributes[42]);
					resaleprivatelinesecondarylocation12states.setSass(attributes[43]);
					resaleprivatelinesecondarylocation12states.setLd1_attr(attributes[44]);
					resaleprivatelinesecondarylocation12states.setLd1(attributes[45]);
					resaleprivatelinesecondarylocation12states.setLv1_attr(attributes[46]);
					resaleprivatelinesecondarylocation12states.setLv1(attributes[47]);
					resaleprivatelinesecondarylocation12states.setLd2_attr(attributes[48]);
					resaleprivatelinesecondarylocation12states.setLd2(attributes[49]);
					resaleprivatelinesecondarylocation12states.setLv2_attr(attributes[50]);
					resaleprivatelinesecondarylocation12states.setLv2(attributes[51]);
					resaleprivatelinesecondarylocation12states.setLd3_attr(attributes[52]);
					resaleprivatelinesecondarylocation12states.setLd3(attributes[53]);
					resaleprivatelinesecondarylocation12states.setLv3_attr(attributes[54]);
					resaleprivatelinesecondarylocation12states.setLv3(attributes[55]);
					resaleprivatelinesecondarylocation12states.setAai_attr(attributes[56]);
					resaleprivatelinesecondarylocation12states.setAai(attributes[57]);
					resaleprivatelinesecondarylocation12states.setCity_attr(attributes[58]);
					resaleprivatelinesecondarylocation12states.setCity(attributes[59]);
					resaleprivatelinesecondarylocation12states.setState_attr(attributes[60]);
					resaleprivatelinesecondarylocation12states.setState(attributes[61]);
					resaleprivatelinesecondarylocation12states.setZip_attr(attributes[62]);
					resaleprivatelinesecondarylocation12states.setZip(attributes[63]);
					resaleprivatelinesecondarylocation12states.setAloc_attr(attributes[64]);
					resaleprivatelinesecondarylocation12states.setAloc(attributes[65]);
					resaleprivatelinesecondarylocation12states.setLcon_attr(attributes[66]);
					resaleprivatelinesecondarylocation12states.setLcon(attributes[67]);
					resaleprivatelinesecondarylocation12states.setActel_no_attr(attributes[68]);
					resaleprivatelinesecondarylocation12states.setActel_no(attributes[69]);
					resaleprivatelinesecondarylocation12states.setAcc_attr(attributes[70]);
					resaleprivatelinesecondarylocation12states.setAcc(attributes[71]);
					resaleprivatelinesecondarylocation12states.setJr_attr(attributes[72]);
					resaleprivatelinesecondarylocation12states.setJr(attributes[73]);
					resaleprivatelinesecondarylocation12states.setJk_code_attr(attributes[74]);
					resaleprivatelinesecondarylocation12states.setJk_code(attributes[75]);
					resaleprivatelinesecondarylocation12states.setJk_num_attr(attributes[76]);
					resaleprivatelinesecondarylocation12states.setJk_num(attributes[77]);
					resaleprivatelinesecondarylocation12states.setJk_pos_attr(attributes[78]);
					resaleprivatelinesecondarylocation12states.setJk_pos(attributes[79]);
					resaleprivatelinesecondarylocation12states.setIwo_attr(attributes[80]);
					resaleprivatelinesecondarylocation12states.setIwo(attributes[81]);
					resaleprivatelinesecondarylocation12states.setIwjq1_attr(attributes[82]);
					resaleprivatelinesecondarylocation12states.setIwjq1(attributes[83]);
					resaleprivatelinesecondarylocation12states.setIwjq2_attr(attributes[84]);
					resaleprivatelinesecondarylocation12states.setIwjq2(attributes[85]);
					resaleprivatelinesecondarylocation12states.setIwjq3_attr(attributes[86]);
					resaleprivatelinesecondarylocation12states.setIwjq3(attributes[87]);
					resaleprivatelinesecondarylocation12states.setIwjq4_attr(attributes[88]);
					resaleprivatelinesecondarylocation12states.setIwjq4(attributes[89]);
					resaleprivatelinesecondarylocation12states.setIwjq5_attr(attributes[90]);
					resaleprivatelinesecondarylocation12states.setIwjq5(attributes[91]);
					resaleprivatelinesecondarylocation12states.setIwjk1_attr(attributes[92]);
					resaleprivatelinesecondarylocation12states.setIwjk1(attributes[93]);
					resaleprivatelinesecondarylocation12states.setIwjk2_attr(attributes[94]);
					resaleprivatelinesecondarylocation12states.setIwjk2(attributes[95]);
					resaleprivatelinesecondarylocation12states.setIwjk3_attr(attributes[96]);
					resaleprivatelinesecondarylocation12states.setIwjk3(attributes[97]);
					resaleprivatelinesecondarylocation12states.setIwjk4_attr(attributes[98]);
					resaleprivatelinesecondarylocation12states.setIwjk4(attributes[99]);
					resaleprivatelinesecondarylocation12states.setIwjk5_attr(attributes[100]);
					resaleprivatelinesecondarylocation12states.setIwjk5(attributes[101]);
					resaleprivatelinesecondarylocation12states.setCklt_attr(attributes[102]);
					resaleprivatelinesecondarylocation12states.setCklt(attributes[103]);
					// resaleprivatelinecircuit12states.setScreenName("Circut");

					treeViewList_511.add(resaleprivatelinesecondarylocation12states);
				}
				session.setAttribute("treeViewList_511", treeViewList_511);
				selectRequestData.setSubHeader(receivedSubHeader);
				// System.out.println("treeViewList_511 size "+treeViewList_511.size());
			}
			if (subData_109Recid != null && subData_109Recid.getSubHeader().getRecord_type().equals("109")) {

				SubHeader receivedSubHeader = subData_109Recid.getSubHeader();
				String[] subDataRows = subData_109Recid.getSubDataRows();
				List<Resaleprivatelineprimarylocation_grid12states> treeViewList_109 = new ArrayList();
				treeViewList.add("109");
				for (String subDataRow : subDataRows) {
					String[] attributes = mqReadUtil.getAttributes(subDataRow, 11);
//					//System.out.println("attributes:==109=====> " + Arrays.toString(attributes));
					Resaleprivatelineprimarylocation_grid12states resaleprivatelineprimarylocation_grid12states = new Resaleprivatelineprimarylocation_grid12states();

					resaleprivatelineprimarylocation_grid12states.setRequest_prod_id(attributes[0]);
					resaleprivatelineprimarylocation_grid12states.setItem_num(attributes[1]);
					resaleprivatelineprimarylocation_grid12states.setLeg_itemnum(attributes[2]);
					resaleprivatelineprimarylocation_grid12states.setFa_attr(attributes[3]);
					resaleprivatelineprimarylocation_grid12states.setFa(attributes[4]);
					resaleprivatelineprimarylocation_grid12states.setFeature_attr(attributes[5]);
					resaleprivatelineprimarylocation_grid12states.setFeature(attributes[6]);
					resaleprivatelineprimarylocation_grid12states.setFeature_detail_attr(attributes[7]);
					resaleprivatelineprimarylocation_grid12states.setFeature_detail(attributes[8]);
					resaleprivatelineprimarylocation_grid12states.setLine_asgn_attr(attributes[9]);
					resaleprivatelineprimarylocation_grid12states.setLine_asgn(attributes[10]);

					treeViewList_109.add(resaleprivatelineprimarylocation_grid12states);
				}
				session.setAttribute("treeViewList_109", treeViewList_109);
				selectRequestData.setSubHeader(receivedSubHeader);
				// System.out.println("treeViewList_109 size "+treeViewList_109.size());
			}

			// Amit

			if (subData_420Recid != null && subData_420Recid.getSubHeader().getRecord_type().equals("420")) {

				SubHeader receivedSubHeader = subData_420Recid.getSubHeader();
				String[] subDataRows = subData_420Recid.getSubDataRows();
				List<DirectoryDeliveryAddress12> treeViewList_420 = new ArrayList();

				treeViewList.add("420");
				// int i = 0;
				for (String subDataRow : subDataRows) {
					String[] attributes = mqReadUtil.getAttributes(subDataRow, 56);
//					//System.out.println("attributes:=420:Reqid======> " + Arrays.toString(attributes));
					DirectoryDeliveryAddress12 directoryDeliveryAddress12State = new DirectoryDeliveryAddress12();

					directoryDeliveryAddress12State.setDact_attr(attributes[0]);
					directoryDeliveryAddress12State.setDact(attributes[1]);
					directoryDeliveryAddress12State.setDdapr_attr(attributes[2]);
					directoryDeliveryAddress12State.setDdapr(attributes[3]);
					directoryDeliveryAddress12State.setDdano_attr(attributes[4]);
					directoryDeliveryAddress12State.setDdano(attributes[5]);
					directoryDeliveryAddress12State.setDdasf_attr(attributes[6]);
					directoryDeliveryAddress12State.setDdasf(attributes[7]);
					directoryDeliveryAddress12State.setDdasd_attr(attributes[8]);
					directoryDeliveryAddress12State.setDdasd(attributes[9]);
					directoryDeliveryAddress12State.setDdasn_attr(attributes[10]);
					directoryDeliveryAddress12State.setDdasn(attributes[11]);
					directoryDeliveryAddress12State.setDdath_attr(attributes[12]);
					directoryDeliveryAddress12State.setDdath(attributes[13]);
					directoryDeliveryAddress12State.setDdass_attr(attributes[14]);
					directoryDeliveryAddress12State.setDdass(attributes[15]);
					directoryDeliveryAddress12State.setDel_ld1_attr(attributes[16]);
					directoryDeliveryAddress12State.setLd1(attributes[17]);
					directoryDeliveryAddress12State.setDel_lv1_attr(attributes[18]);
					directoryDeliveryAddress12State.setLv1(attributes[19]);
					directoryDeliveryAddress12State.setDel_ld2_attr(attributes[20]);
					directoryDeliveryAddress12State.setLd2(attributes[21]);
					directoryDeliveryAddress12State.setDel_lv2_attr(attributes[22]);
					directoryDeliveryAddress12State.setLv2(attributes[23]);
					directoryDeliveryAddress12State.setDel_ld3_attr(attributes[24]);
					directoryDeliveryAddress12State.setLd3(attributes[25]);
					directoryDeliveryAddress12State.setDel_lv3_attr(attributes[26]);
					directoryDeliveryAddress12State.setLv3(attributes[27]);
					directoryDeliveryAddress12State.setDel_aai_attr(attributes[28]);
					directoryDeliveryAddress12State.setAai(attributes[29]);
					directoryDeliveryAddress12State.setDel_city_attr(attributes[30]);
					directoryDeliveryAddress12State.setCity(attributes[31]);
					directoryDeliveryAddress12State.setDel_state_attr(attributes[32]);
					directoryDeliveryAddress12State.setState(attributes[33]);
					directoryDeliveryAddress12State.setDel_zip_attr(attributes[34]);
					directoryDeliveryAddress12State.setZip(attributes[35]);
					directoryDeliveryAddress12State.setDirqty_attr(attributes[36]);
					directoryDeliveryAddress12State.setDirqty(attributes[37]);
					directoryDeliveryAddress12State.setDirtyp1_attr(attributes[38]);
					directoryDeliveryAddress12State.setDirtyp1(attributes[39]);
					directoryDeliveryAddress12State.setDirtyp2_attr(attributes[40]);
					directoryDeliveryAddress12State.setDirtyp2(attributes[41]);
					directoryDeliveryAddress12State.setDirtyp3_attr(attributes[42]);
					directoryDeliveryAddress12State.setDirtyp3(attributes[43]);
					directoryDeliveryAddress12State.setDirqtya1_attr(attributes[44]);
					directoryDeliveryAddress12State.setDirqtya1(attributes[45]);
					directoryDeliveryAddress12State.setDirqtya2_attr(attributes[46]);
					directoryDeliveryAddress12State.setDirqtya2(attributes[47]);
					directoryDeliveryAddress12State.setDirqtya3_attr(attributes[48]);
					directoryDeliveryAddress12State.setDirqtya3(attributes[49]);
					directoryDeliveryAddress12State.setDirqtync1_attr(attributes[50]);
					directoryDeliveryAddress12State.setDirqtync1(attributes[51]);
					directoryDeliveryAddress12State.setDirqtync2_attr(attributes[52]);
					directoryDeliveryAddress12State.setDirqtync2(attributes[53]);
					directoryDeliveryAddress12State.setDirqtync3_attr(attributes[54]);
					directoryDeliveryAddress12State.setDirqtync3(attributes[55]);

					treeViewList_420.add(directoryDeliveryAddress12State);
				}
				selectRequestData.setSubHeader(receivedSubHeader);
				session.setAttribute("treeViewList_420", treeViewList_420);
				// selectRequestData.setSelectRequestTableRows(selectRequestTableRows);
				// System.out.println("treeViewList_420 size "+treeViewList_420.size());
			}

			if (subData_430Recid != null && subData_430Recid.getSubHeader().getRecord_type().equals("430")) {

				SubHeader receivedSubHeader = subData_430Recid.getSubHeader();
				String[] subDataRows = subData_430Recid.getSubDataRows();
				List<DirectoryListing12> treeViewList_430 = new ArrayList();

				treeViewList.add("430");
				// List treeViewList = new ArrayList();
				// int i = 0;
				for (String subDataRow : subDataRows) {
					String[] attributes = mqReadUtil.getAttributes(subDataRow, 103);
//					//System.out.println("attributes:=430======> " + Arrays.toString(attributes));
					DirectoryListing12 directoryListing12states = new DirectoryListing12();

					directoryListing12states.setItemnum(attributes[0]);
					directoryListing12states.setDlnum_attr(attributes[1]);
					directoryListing12states.setDlnum(attributes[2]);
					directoryListing12states.setLact_attr(attributes[3]);
					directoryListing12states.setLact(attributes[4]);
					directoryListing12states.setAli_attr(attributes[5]);
					directoryListing12states.setAli(attributes[6]);
					directoryListing12states.setRty_attr(attributes[7]);
					directoryListing12states.setRty(attributes[8]);
					directoryListing12states.setLty_attr(attributes[9]);
					directoryListing12states.setLty(attributes[10]);
					directoryListing12states.setStyc_attr(attributes[11]);
					directoryListing12states.setStyc(attributes[12]);
					directoryListing12states.setToa_attr(attributes[13]);
					directoryListing12states.setToa(attributes[14]);
					directoryListing12states.setDoi_attr(attributes[15]);
					directoryListing12states.setDoi(attributes[16]);
					directoryListing12states.setWpp_attr(attributes[17]);
					directoryListing12states.setWpp(attributes[18]);
					directoryListing12states.setDml_attr(attributes[19]);
					directoryListing12states.setDml(attributes[20]);
					directoryListing12states.setBro_attr(attributes[21]);
					directoryListing12states.setBro(attributes[22]);
					directoryListing12states.setAdv_attr(attributes[23]);
					directoryListing12states.setAdv(attributes[24]);
					directoryListing12states.setStr_attr(attributes[25]);
					directoryListing12states.setStr(attributes[26]);
					directoryListing12states.setDlnm_attr(attributes[27]);
					directoryListing12states.setDlnm(attributes[28]);
					directoryListing12states.setDiridl_attr(attributes[29]);
					directoryListing12states.setDiridl(attributes[30]);
					directoryListing12states.setProf_attr(attributes[31]);
					directoryListing12states.setProf(attributes[32]);
					directoryListing12states.setDirsub_attr(attributes[33]);
					directoryListing12states.setDirsub(attributes[34]);
					directoryListing12states.setOmsd_attr(attributes[35]);
					directoryListing12states.setOmsd(attributes[36]);
					directoryListing12states.setLtn_attr(attributes[37]);
					directoryListing12states.setLtn(FormatUtil.getTelephoneNumberWithDashes(attributes[38] != null && attributes[38] != "" ? attributes[38] : " "));// supriya changes for date format
					directoryListing12states.setNstn_attr(attributes[39]);
					directoryListing12states.setNstn(attributes[40]);
					directoryListing12states.setOmtn_attr(attributes[41]);
					directoryListing12states.setOmtn(attributes[42]);
					directoryListing12states.setLex_attr(attributes[43]);
					directoryListing12states.setLex(attributes[44]);
					directoryListing12states.setDna_attr(attributes[45]);
					directoryListing12states.setDna(attributes[46]);
					directoryListing12states.setLnpl_attr(attributes[47]);
					directoryListing12states.setLnpl(attributes[48]);
					directoryListing12states.setLnln_attr(attributes[49]);
					directoryListing12states.setLnln(attributes[50]);
					directoryListing12states.setLnfn_attr(attributes[51]);
					directoryListing12states.setLnfn(attributes[52]);
					directoryListing12states.setDes_attr(attributes[53]);
					directoryListing12states.setDes(attributes[54]);
					directoryListing12states.setTl_attr(attributes[55]);
					directoryListing12states.setTl(attributes[56]);
					directoryListing12states.setTitle1_attr(attributes[57]);
					directoryListing12states.setTitle1(attributes[58]);
					directoryListing12states.setTitle2_attr(attributes[59]);
					directoryListing12states.setTitle2(attributes[60]);
					directoryListing12states.setTld_attr(attributes[61]);
					directoryListing12states.setTld(attributes[62]);
					directoryListing12states.setTitle1d_attr(attributes[63]);
					directoryListing12states.setTitle1d(attributes[64]);
					directoryListing12states.setTitle2d_attr(attributes[65]);
					directoryListing12states.setTitle2d(attributes[66]);
					directoryListing12states.setNick_attr(attributes[67]);
					directoryListing12states.setNick(attributes[68]);
					directoryListing12states.setPla_attr(attributes[69]);
					directoryListing12states.setPla(attributes[70]);
					directoryListing12states.setLphrase_attr(attributes[71]);
					directoryListing12states.setLphrase(attributes[72]);
					directoryListing12states.setAdi_attr(attributes[73]);
					directoryListing12states.setAdi(attributes[74]);
					directoryListing12states.setDno_attr(attributes[75]);
					directoryListing12states.setDno(attributes[76]);
					directoryListing12states.setLapr_attr(attributes[77]);
					directoryListing12states.setLapr(attributes[78]);
					directoryListing12states.setLano_attr(attributes[79]);
					directoryListing12states.setLano(attributes[80]);
					directoryListing12states.setLasf_attr(attributes[81]);
					directoryListing12states.setLasf(attributes[82]);
					directoryListing12states.setLasd_attr(attributes[83]);
					directoryListing12states.setLasd(attributes[84]);
					directoryListing12states.setLasn_attr(attributes[85]);
					directoryListing12states.setLasn(attributes[86]);
					directoryListing12states.setLath_attr(attributes[87]);
					directoryListing12states.setLath(attributes[88]);
					directoryListing12states.setLass_attr(attributes[89]);
					directoryListing12states.setLass(attributes[90]);
					directoryListing12states.setLalo_attr(attributes[91]);
					directoryListing12states.setLalo(attributes[92]);
					directoryListing12states.setLaloc_attr(attributes[93]);
					directoryListing12states.setLaloc(attributes[94]);
					directoryListing12states.setLast_attr(attributes[95]);
					directoryListing12states.setLast(attributes[96]);
					directoryListing12states.setLazc_attr(attributes[97]);
					directoryListing12states.setLazc(attributes[98]);
					directoryListing12states.setSic_attr(attributes[99]);
					directoryListing12states.setSic(attributes[100]);
					directoryListing12states.setYph_attr(attributes[101]);
					directoryListing12states.setYph(attributes[102]);

					treeViewList_430.add(directoryListing12states);
				}
				selectRequestData.setSubHeader(receivedSubHeader);
				session.setAttribute("treeViewList_430", treeViewList_430);
				// selectRequestData.setSelectRequestTableRows(selectRequestTableRows);
				// System.out.println("treeViewList_430 size "+treeViewList_430.size());
			}
			if (subData_435Recid != null && subData_435Recid.getSubHeader().getRecord_type().equals("435")) {

				SubHeader receivedSubHeader = subData_435Recid.getSubHeader();
				String[] subDataRows = subData_435Recid.getSubDataRows();
				List<DirectoryListingText12> treeViewList_435 = new ArrayList();
				treeViewList.add("435");
				// List treeViewList = new ArrayList();
				// int i = 0;
				for (String subDataRow : subDataRows) {
					String[] attributes = mqReadUtil.getAttributes(subDataRow, 4);
//					//System.out.println("attributes:==435=====> " + Arrays.toString(attributes));
					DirectoryListingText12 directoryListingText12States = new DirectoryListingText12();

					directoryListingText12States.setItemnum(attributes[0]);
					directoryListingText12States.setDlnum_attr(attributes[1]);
					directoryListingText12States.setDlnum(attributes[2]);

					treeViewList_435.add(directoryListingText12States);
				}
				selectRequestData.setSubHeader(receivedSubHeader);
				session.setAttribute("treeViewList_435", treeViewList_435);
				// System.out.println("treeViewList_435 size "+treeViewList_435.size());
				// selectRequestData.setSelectRequestTableRows(selectRequestTableRows);
			}
			if (subData_436Recid != null && subData_436Recid.getSubHeader().getRecord_type().equals("436")) {

				SubHeader receivedSubHeader = subData_436Recid.getSubHeader();
				String[] subDataRows = subData_436Recid.getSubDataRows();
				List<TxtListDetail> treeViewList_436 = new ArrayList();
				treeViewList.add("436");

				// List treeViewList = new ArrayList();
				// int i = 0;
				for (String subDataRow : subDataRows) {
					String[] attributes = mqReadUtil.getAttributes(subDataRow, 5);
//					//System.out.println("attributes:==436=====> " + Arrays.toString(attributes));
					TxtListDetail txtListDetail = new TxtListDetail();

					txtListDetail.setItem_num(attributes[0]);
					txtListDetail.setLtxty_attr(attributes[1]);
					txtListDetail.setLtxty(attributes[2]);
					txtListDetail.setLtext_attr(attributes[3]);
					txtListDetail.setLtext(attributes[4]);

					treeViewList_436.add(txtListDetail);
				}
				selectRequestData.setSubHeader(receivedSubHeader);
				session.setAttribute("treeViewList_436", treeViewList_436);
				// System.out.println("treeViewList_436 size "+treeViewList_436.size());
				// selectRequestData.setSelectRequestTableRows(selectRequestTableRows);
			}
			if (subData_440Recid != null && subData_440Recid.getSubHeader().getRecord_type().equals("440")) {

				SubHeader receivedSubHeader = subData_440Recid.getSubHeader();
				String[] subDataRows = subData_440Recid.getSubDataRows();
				List<DirectoryCaption12> treeViewList_440 = new ArrayList();
				treeViewList.add("440");

				// List treeViewList = new ArrayList();
				// int i = 0;
				for (String subDataRow : subDataRows) {
					String[] attributes = mqReadUtil.getAttributes(subDataRow, 17);
					// System.out.println("attributes:==440=====> " + Arrays.toString(attributes));
					DirectoryCaption12 directoryCaption12States = new DirectoryCaption12();

					directoryCaption12States.setItemnum(attributes[0]);
					directoryCaption12States.setDlnum_attr(attributes[1]);
					directoryCaption12States.setDlnum(attributes[2]);
					directoryCaption12States.setLvl_attr(attributes[3]);
					directoryCaption12States.setLvl(attributes[4]);
					directoryCaption12States.setPls_attr(attributes[5]);
					directoryCaption12States.setPls(attributes[6]);
					directoryCaption12States.setPlinfo_attr(attributes[7]);
					directoryCaption12States.setPlinfo(attributes[8]);
					directoryCaption12States.setPltn_attr(attributes[9]);
					directoryCaption12States.setPltn(attributes[10]);
					directoryCaption12States.setSo_attr(attributes[11]);
					directoryCaption12States.setSo(attributes[12]);
					directoryCaption12States.setFainfo_attr(attributes[13]);
					directoryCaption12States.setFainfo(attributes[14]);
					directoryCaption12States.setFatn_attr(attributes[15]);
					directoryCaption12States.setFatn(attributes[16]);

					treeViewList_440.add(directoryCaption12States);
				}
				selectRequestData.setSubHeader(receivedSubHeader);
				session.setAttribute("treeViewList_440", treeViewList_440);
				// selectRequestData.setSelectRequestTableRows(selectRequestTableRows);
			}

			// Shalu

			if (subData_150Recid != null && subData_150Recid.getSubHeader().getRecord_type().equals("150")) {

				SubHeader receivedSubHeader = subData_150Recid.getSubHeader();
				String[] subDataRows = subData_150Recid.getSubDataRows();
				treeViewList.add("150");
				// int i = 0;
				for (String subDataRow : subDataRows) {
					String[] attributes = mqReadUtil.getAttributes(subDataRow, 143);
					// System.out.println("attributes:=150:Reqid======> " +
					// Arrays.toString(attributes));
					Resale_12state_Data resale_12state_Data = new Resale_12state_Data();

					resale_12state_Data.setItem_num(attributes[0]);
					resale_12state_Data.setLnum_attr(attributes[1]);
					resale_12state_Data.setLnum(attributes[2]);
					resale_12state_Data.setLna_attr(attributes[3]);
					resale_12state_Data.setLna(attributes[4]);
					resale_12state_Data.setLmt_attr(attributes[5]);
					resale_12state_Data.setLmt(attributes[6]);
					resale_12state_Data.setEcckt_attr(attributes[7]);
					resale_12state_Data.setEcckt(attributes[8]);
					resale_12state_Data.setShared_nbr_attr(attributes[9]);
					resale_12state_Data.setShared_nbr(attributes[10]);
					resale_12state_Data.setDisc_nbr_attr(attributes[11]);
					resale_12state_Data.setDisc_nbr(attributes[12]);
					resale_12state_Data.setTers_attr(attributes[13]);
					resale_12state_Data.setTers(attributes[14]);
					resale_12state_Data.setCfa_attr(attributes[15]);
					resale_12state_Data.setCfa(attributes[16]);
					resale_12state_Data.setCcea_attr(attributes[17]);
					resale_12state_Data.setCcea(attributes[18]);
					resale_12state_Data.setSscfa_attr(attributes[19]);
					resale_12state_Data.setSscfa(attributes[20]);
					resale_12state_Data.setCableid_attr(attributes[21]);
					resale_12state_Data.setCableid(attributes[22]);
					resale_12state_Data.setChan_pair3_attr(attributes[23]);
					resale_12state_Data.setChan_pair3(attributes[24]);
					resale_12state_Data.setSystemid_attr(attributes[25]);
					resale_12state_Data.setSystemid(attributes[26]);
					resale_12state_Data.setCbcid_attr(attributes[27]);
					resale_12state_Data.setCbcid(attributes[28]);
					resale_12state_Data.setChan_pair_attr(attributes[29]);
					resale_12state_Data.setChan_pair(attributes[30]);
					resale_12state_Data.setCbcid2_attr(attributes[31]);
					resale_12state_Data.setCbcid2(attributes[32]);
					resale_12state_Data.setChan_pair2_attr(attributes[33]);
					resale_12state_Data.setChan_pair2(attributes[34]);
					resale_12state_Data.setCti_attr(attributes[35]);
					resale_12state_Data.setCti(attributes[36]);
					resale_12state_Data.setRelay_rack_attr(attributes[37]);
					resale_12state_Data.setRelay_rack(attributes[38]);
					resale_12state_Data.setShelf_attr(attributes[39]);
					resale_12state_Data.setShelf(attributes[40]);
					resale_12state_Data.setSlot_attr(attributes[41]);
					resale_12state_Data.setSlot(attributes[42]);
					resale_12state_Data.setCti2_attr(attributes[43]);
					resale_12state_Data.setCti2(attributes[44]);
					resale_12state_Data.setRelay_rack2_attr(attributes[45]);
					resale_12state_Data.setRelay_rack2(attributes[46]);
					resale_12state_Data.setShelf2_attr(attributes[47]);
					resale_12state_Data.setShelf2(attributes[48]);
					resale_12state_Data.setSlot2_attr(attributes[49]);
					resale_12state_Data.setSlot2(attributes[50]);
					resale_12state_Data.setCti3_attr(attributes[51]);
					resale_12state_Data.setCti3(attributes[52]);
					resale_12state_Data.setRelay_rack3_attr(attributes[53]);
					resale_12state_Data.setRelay_rack3(attributes[54]);
					resale_12state_Data.setShelf3_attr(attributes[55]);
					resale_12state_Data.setShelf3(attributes[56]);
					resale_12state_Data.setSlot3_attr(attributes[57]);
					resale_12state_Data.setSlot3(attributes[58]);
					resale_12state_Data.setCti4_attr(attributes[59]);
					resale_12state_Data.setCti4(attributes[60]);
					resale_12state_Data.setRelay_rack4_attr(attributes[61]);
					resale_12state_Data.setRelay_rack4(attributes[62]);
					resale_12state_Data.setShelf4_attr(attributes[63]);
					resale_12state_Data.setShelf4(attributes[64]);
					resale_12state_Data.setSlot4_attr(attributes[65]);
					resale_12state_Data.setSlot4(attributes[66]);
					resale_12state_Data.setVpi_attr(attributes[67]);
					resale_12state_Data.setVpi(attributes[68]);
					resale_12state_Data.setVci_attr(attributes[69]);
					resale_12state_Data.setVci(attributes[70]);
					resale_12state_Data.setCode_set_attr(attributes[71]);
					resale_12state_Data.setCode_set(attributes[72]);
					resale_12state_Data.setRecckt_attr(attributes[73]);
					resale_12state_Data.setRecckt(attributes[74]);
					resale_12state_Data.setCkr_attr(attributes[75]);
					resale_12state_Data.setCkr(attributes[76]);
					resale_12state_Data.setTsp_attr(attributes[77]);
					resale_12state_Data.setTsp(attributes[78]);
					resale_12state_Data.setPorted_nbr_attr(attributes[79]);
					resale_12state_Data.setPorted_nbr(attributes[80]);
					resale_12state_Data.setNpt_attr(attributes[81]);
					resale_12state_Data.setNpt(attributes[82]);
					resale_12state_Data.setRti_attr(attributes[83]);
					resale_12state_Data.setRti(attributes[84]);
					resale_12state_Data.setNptg_attr(attributes[85]);
					resale_12state_Data.setNptg(attributes[86]);
					resale_12state_Data.setNpi_attr(attributes[87]);
					resale_12state_Data.setNpi(attributes[88]);
					resale_12state_Data.setLst_attr(attributes[89]);
					resale_12state_Data.setLst(attributes[90]);
					resale_12state_Data.setTns_attr(attributes[91]);
					resale_12state_Data.setTns(attributes[92]);
					resale_12state_Data.setOtn_attr(attributes[93]);
					resale_12state_Data.setOtn(attributes[94]);
					resale_12state_Data.setIspid_attr(attributes[95]);
					resale_12state_Data.setIspid(attributes[96]);
					resale_12state_Data.setPic_attr(attributes[97]);
					resale_12state_Data.setPic(attributes[98]);
					resale_12state_Data.setLpic_attr(attributes[99]);
					resale_12state_Data.setLpic(attributes[100]);
					resale_12state_Data.setSsig_attr(attributes[101]);
					resale_12state_Data.setSsig(attributes[102]);
					resale_12state_Data.setBa_attr(attributes[103]);
					resale_12state_Data.setBa(attributes[104]);
					resale_12state_Data.setBlock_attr(attributes[105]);
					resale_12state_Data.setBlock(attributes[106]);
					resale_12state_Data.setJk_code_attr(attributes[107]);
					resale_12state_Data.setJk_code(attributes[108]);
					resale_12state_Data.setJk_num_attr(attributes[109]);
					resale_12state_Data.setJk_num(attributes[110]);
					resale_12state_Data.setJk_pos_attr(attributes[111]);
					resale_12state_Data.setJk_pos(attributes[112]);
					resale_12state_Data.setJr_attr(attributes[113]);
					resale_12state_Data.setJr(attributes[114]);
					resale_12state_Data.setNidr_attr(attributes[115]);
					resale_12state_Data.setNidr(attributes[116]);
					resale_12state_Data.setIwjk1_attr(attributes[117]);
					resale_12state_Data.setIwjk1(attributes[118]);
					resale_12state_Data.setIwjk2_attr(attributes[119]);
					resale_12state_Data.setIwjk2(attributes[120]);
					resale_12state_Data.setIwjk3_attr(attributes[121]);
					resale_12state_Data.setIwjk3(attributes[122]);
					resale_12state_Data.setIwjk4_attr(attributes[123]);
					resale_12state_Data.setIwjk4(attributes[124]);
					resale_12state_Data.setIwjk5_attr(attributes[125]);
					resale_12state_Data.setIwjk5(attributes[126]);
					resale_12state_Data.setIwjq1_attr(attributes[127]);
					resale_12state_Data.setIwjq1(attributes[128]);
					resale_12state_Data.setIwjq2_attr(attributes[129]);
					resale_12state_Data.setIwjq2(attributes[130]);
					resale_12state_Data.setIwjq3_attr(attributes[131]);
					resale_12state_Data.setIwjq3(attributes[132]);
					resale_12state_Data.setIwjq4_attr(attributes[133]);
					resale_12state_Data.setIwjq4(attributes[134]);
					resale_12state_Data.setIwjq5_attr(attributes[135]);
					resale_12state_Data.setIwjq5(attributes[136]);
					resale_12state_Data.setLidb_attr(attributes[137]);
					resale_12state_Data.setLidb(attributes[138]);
					resale_12state_Data.setS_attr(attributes[139]);
					resale_12state_Data.setS(attributes[140]);
					resale_12state_Data.setOecckt_attr(attributes[141]);
					resale_12state_Data.setOecckt(attributes[142]);

					treeViewList_150.add(resale_12state_Data);
				}
				session.setAttribute("treeViewList_150", treeViewList_150);
				selectRequestData.setSubHeader(receivedSubHeader);

			}

			if (subData_107Recid != null && subData_107Recid.getSubHeader().getRecord_type().equals("107")) {

				SubHeader receivedSubHeader = subData_107Recid.getSubHeader();
				String[] subDataRows = subData_107Recid.getSubDataRows();
				treeViewList.add("107");

				// int i = 0;
				for (String subDataRow : subDataRows) {
					String[] attributes = mqReadUtil.getAttributes(subDataRow, 18);
					// System.out.println("attributes:=107:Reqid======> " +
					// Arrays.toString(attributes));
					ResaleTC_12state_Data resaleTC_12state_Data = new ResaleTC_12state_Data();

					resaleTC_12state_Data.setItem_num(attributes[0]);
					resaleTC_12state_Data.setLnum_attr(attributes[1]);
					resaleTC_12state_Data.setLnum(attributes[2]);
					resaleTC_12state_Data.setDisc_nbr_attr(attributes[3]);
					resaleTC_12state_Data.setDisc_nbr(attributes[4]);
					resaleTC_12state_Data.setTers_attr(attributes[5]);
					resaleTC_12state_Data.setTers(attributes[6]);
					resaleTC_12state_Data.setTc_opt_attr(attributes[7]);
					resaleTC_12state_Data.setTc_opt(attributes[8]);
					resaleTC_12state_Data.setTc_per_attr(attributes[9]);
					resaleTC_12state_Data.setTc_per(attributes[10]);
					resaleTC_12state_Data.setTc_to_pri_attr(attributes[11]);
					resaleTC_12state_Data.setTc_to_pri(attributes[12]);
					resaleTC_12state_Data.setTc_name_pri_attr(attributes[13]);
					resaleTC_12state_Data.setTc_name_pri(attributes[14]);
					resaleTC_12state_Data.setTc_id_attr(attributes[15]);
					resaleTC_12state_Data.setTc_id(attributes[16]);
					// resaleprivatelinecircuit12states.setScreenName("Circut");

					treeViewList_107.add(resaleTC_12state_Data);
				}
				session.setAttribute("treeViewList_107", treeViewList_107);
				selectRequestData.setSubHeader(receivedSubHeader);

			}

			if (subData_350Recid != null && subData_350Recid.getSubHeader().getRecord_type().equals("350")) {

				SubHeader receivedSubHeader = subData_350Recid.getSubHeader();
				String[] subDataRows = subData_350Recid.getSubDataRows();
				treeViewList.add("350");

				// List treeViewList = new ArrayList();
				// int i = 0;
				for (String subDataRow : subDataRows) {
					String[] attributes = mqReadUtil.getAttributes(subDataRow, 143);
					// System.out.println("attributes:=350======> " + Arrays.toString(attributes));
					Port_12state_Data port_12state_Data = new Port_12state_Data();

					port_12state_Data.setItem_num(attributes[0]);
					port_12state_Data.setLnum_attr(attributes[1]);
					port_12state_Data.setLnum(attributes[2]);
					port_12state_Data.setLna_attr(attributes[3]);
					port_12state_Data.setLna(attributes[4]);
					port_12state_Data.setLmt_attr(attributes[5]);
					port_12state_Data.setLmt(attributes[6]);
					port_12state_Data.setEcckt_attr(attributes[7]);
					port_12state_Data.setEcckt(attributes[8]);
					port_12state_Data.setShared_nbr_attr(attributes[9]);
					port_12state_Data.setShared_nbr(attributes[10]);
					port_12state_Data.setDisc_nbr_attr(attributes[11]);
					port_12state_Data.setDisc_nbr(attributes[12]);
					port_12state_Data.setTers_attr(attributes[13]);
					port_12state_Data.setTers(attributes[14]);
					port_12state_Data.setCfa_attr(attributes[15]);
					port_12state_Data.setCfa(attributes[16]);
					port_12state_Data.setCcea_attr(attributes[17]);
					port_12state_Data.setCcea(attributes[18]);
					port_12state_Data.setSscfa_attr(attributes[19]);
					port_12state_Data.setSscfa(attributes[20]);
					port_12state_Data.setCableid_attr(attributes[21]);
					port_12state_Data.setCableid(attributes[22]);
					port_12state_Data.setChan_pair3_attr(attributes[23]);
					port_12state_Data.setChan_pair3(attributes[24]);
					port_12state_Data.setSystemid_attr(attributes[25]);
					port_12state_Data.setSystemid(attributes[26]);
					port_12state_Data.setCbcid_attr(attributes[27]);
					port_12state_Data.setCbcid(attributes[28]);
					port_12state_Data.setChan_pair_attr(attributes[29]);
					port_12state_Data.setChan_pair(attributes[30]);
					port_12state_Data.setCbcid2_attr(attributes[31]);
					port_12state_Data.setCbcid2(attributes[32]);
					port_12state_Data.setChan_pair2_attr(attributes[33]);
					port_12state_Data.setChan_pair2(attributes[34]);
					port_12state_Data.setCti_attr(attributes[35]);
					port_12state_Data.setCti(attributes[36]);
					port_12state_Data.setRelay_rack_attr(attributes[37]);
					port_12state_Data.setRelay_rack(attributes[38]);
					port_12state_Data.setShelf_attr(attributes[39]);
					port_12state_Data.setShelf(attributes[40]);
					port_12state_Data.setSlot_attr(attributes[41]);
					port_12state_Data.setSlot(attributes[42]);
					port_12state_Data.setCti2_attr(attributes[43]);
					port_12state_Data.setCti2(attributes[44]);
					port_12state_Data.setRelay_rack2_attr(attributes[45]);
					port_12state_Data.setRelay_rack2(attributes[46]);
					port_12state_Data.setShelf2_attr(attributes[47]);
					port_12state_Data.setShelf2(attributes[48]);
					port_12state_Data.setSlot2_attr(attributes[49]);
					port_12state_Data.setSlot2(attributes[50]);
					port_12state_Data.setCti3_attr(attributes[51]);
					port_12state_Data.setCti3(attributes[52]);
					port_12state_Data.setRelay_rack3_attr(attributes[53]);
					port_12state_Data.setRelay_rack3(attributes[54]);
					port_12state_Data.setShelf3_attr(attributes[55]);
					port_12state_Data.setShelf3(attributes[56]);
					port_12state_Data.setSlot3_attr(attributes[57]);
					port_12state_Data.setSlot3(attributes[58]);
					port_12state_Data.setCti4_attr(attributes[59]);
					port_12state_Data.setCti4(attributes[60]);
					port_12state_Data.setRelay_rack4_attr(attributes[61]);
					port_12state_Data.setRelay_rack4(attributes[62]);
					port_12state_Data.setShelf4_attr(attributes[63]);
					port_12state_Data.setShelf4(attributes[64]);
					port_12state_Data.setSlot4_attr(attributes[65]);
					port_12state_Data.setSlot4(attributes[66]);
					port_12state_Data.setVpi_attr(attributes[67]);
					port_12state_Data.setVpi(attributes[68]);
					port_12state_Data.setVci_attr(attributes[69]);
					port_12state_Data.setVci(attributes[70]);
					port_12state_Data.setCode_set_attr(attributes[71]);
					port_12state_Data.setCode_set(attributes[72]);
					port_12state_Data.setRecckt_attr(attributes[73]);
					port_12state_Data.setRecckt(attributes[74]);
					port_12state_Data.setCkr_attr(attributes[75]);
					port_12state_Data.setCkr(attributes[76]);
					port_12state_Data.setTsp_attr(attributes[77]);
					port_12state_Data.setTsp(attributes[78]);
					port_12state_Data.setPorted_nbr_attr(attributes[79]);
					port_12state_Data.setPorted_nbr(attributes[80]);
					port_12state_Data.setNpt_attr(attributes[81]);
					port_12state_Data.setNpt(attributes[82]);
					port_12state_Data.setRti_attr(attributes[83]);
					port_12state_Data.setRti(attributes[84]);
					port_12state_Data.setNptg_attr(attributes[85]);
					port_12state_Data.setNptg(attributes[86]);
					port_12state_Data.setNpi_attr(attributes[87]);
					port_12state_Data.setNpi(attributes[88]);
					port_12state_Data.setLst_attr(attributes[89]);
					port_12state_Data.setLst(attributes[90]);
					port_12state_Data.setTns_attr(attributes[91]);
					port_12state_Data.setTns(attributes[92]);
					port_12state_Data.setOtn_attr(attributes[93]);
					port_12state_Data.setOtn(attributes[94]);
					port_12state_Data.setIspid_attr(attributes[95]);
					port_12state_Data.setIspid(attributes[96]);
					port_12state_Data.setPic_attr(attributes[97]);
					port_12state_Data.setPic(attributes[98]);
					port_12state_Data.setLpic_attr(attributes[99]);
					port_12state_Data.setLpic(attributes[100]);
					port_12state_Data.setSsig_attr(attributes[101]);
					port_12state_Data.setSsig(attributes[102]);
					port_12state_Data.setBa_attr(attributes[103]);
					port_12state_Data.setBa(attributes[104]);
					port_12state_Data.setBlock_attr(attributes[105]);
					port_12state_Data.setBlock(attributes[106]);
					port_12state_Data.setJk_code_attr(attributes[107]);
					port_12state_Data.setJk_code(attributes[108]);
					port_12state_Data.setJk_num_attr(attributes[109]);
					port_12state_Data.setJk_num(attributes[110]);
					port_12state_Data.setJk_pos_attr(attributes[111]);
					port_12state_Data.setJk_pos(attributes[112]);
					port_12state_Data.setJr_attr(attributes[113]);
					port_12state_Data.setJr(attributes[114]);
					port_12state_Data.setNidr_attr(attributes[115]);
					port_12state_Data.setNidr(attributes[116]);
					port_12state_Data.setIwjk1_attr(attributes[117]);
					port_12state_Data.setIwjk1(attributes[118]);
					port_12state_Data.setIwjk2_attr(attributes[119]);
					port_12state_Data.setIwjk2(attributes[120]);
					port_12state_Data.setIwjk3_attr(attributes[121]);
					port_12state_Data.setIwjk3(attributes[122]);
					port_12state_Data.setIwjk4_attr(attributes[123]);
					port_12state_Data.setIwjk4(attributes[124]);
					port_12state_Data.setIwjk5_attr(attributes[125]);
					port_12state_Data.setIwjk5(attributes[126]);
					port_12state_Data.setIwjq1_attr(attributes[127]);
					port_12state_Data.setIwjq1(attributes[128]);
					port_12state_Data.setIwjq2_attr(attributes[129]);
					port_12state_Data.setIwjq2(attributes[130]);
					port_12state_Data.setIwjq3_attr(attributes[131]);
					port_12state_Data.setIwjq3(attributes[132]);
					port_12state_Data.setIwjq4_attr(attributes[133]);
					port_12state_Data.setIwjq4(attributes[134]);
					port_12state_Data.setIwjq5_attr(attributes[135]);
					port_12state_Data.setIwjq5(attributes[136]);
					port_12state_Data.setLidb_attr(attributes[137]);
					port_12state_Data.setLidb(attributes[138]);
					port_12state_Data.setS_attr(attributes[139]);
					port_12state_Data.setS(attributes[140]);
					port_12state_Data.setOecckt_attr(attributes[141]);
					port_12state_Data.setOecckt(attributes[142]);

					treeViewList_350.add(port_12state_Data);
				}
				session.setAttribute("treeViewList_350", treeViewList_350);
				selectRequestData.setSubHeader(receivedSubHeader);

			}
			if (subData_275Recid != null && subData_275Recid.getSubHeader().getRecord_type().equals("275")) {

				SubHeader receivedSubHeader = subData_275Recid.getSubHeader();
				String[] subDataRows = subData_275Recid.getSubDataRows();
				treeViewList.add("275");

				// List treeViewList = new ArrayList();
				// int i = 0;
				for (String subDataRow : subDataRows) {
					String[] attributes = mqReadUtil.getAttributes(subDataRow, 143);
					// System.out.println("attributes:=275======> " + Arrays.toString(attributes));
					Loop_w_12state_Data loop_w_12state_Data = new Loop_w_12state_Data();

					loop_w_12state_Data.setItem_num(attributes[0]);
					loop_w_12state_Data.setLnum_attr(attributes[1]);
					loop_w_12state_Data.setLnum(attributes[2]);
					loop_w_12state_Data.setLna_attr(attributes[3]);
					loop_w_12state_Data.setLna(attributes[4]);
					loop_w_12state_Data.setLmt_attr(attributes[5]);
					loop_w_12state_Data.setLmt(attributes[6]);
					loop_w_12state_Data.setEcckt_attr(attributes[7]);
					loop_w_12state_Data.setEcckt(attributes[8]);
					loop_w_12state_Data.setShared_nbr_attr(attributes[9]);
					loop_w_12state_Data.setShared_nbr(attributes[10]);
					loop_w_12state_Data.setDisc_nbr_attr(attributes[11]);
					loop_w_12state_Data.setDisc_nbr(attributes[12]);
					loop_w_12state_Data.setTers_attr(attributes[13]);
					loop_w_12state_Data.setTers(attributes[14]);
					loop_w_12state_Data.setCfa_attr(attributes[15]);
					loop_w_12state_Data.setCfa(attributes[16]);
					loop_w_12state_Data.setCcea_attr(attributes[17]);
					loop_w_12state_Data.setCcea(attributes[18]);
					loop_w_12state_Data.setSscfa_attr(attributes[19]);
					loop_w_12state_Data.setSscfa(attributes[20]);
					loop_w_12state_Data.setCableid_attr(attributes[21]);
					loop_w_12state_Data.setCableid(attributes[22]);
					loop_w_12state_Data.setChan_pair3_attr(attributes[23]);
					loop_w_12state_Data.setChan_pair3(attributes[24]);
					loop_w_12state_Data.setSystemid_attr(attributes[25]);
					loop_w_12state_Data.setSystemid(attributes[26]);
					loop_w_12state_Data.setCbcid_attr(attributes[27]);
					loop_w_12state_Data.setCbcid(attributes[28]);
					loop_w_12state_Data.setChan_pair_attr(attributes[29]);
					loop_w_12state_Data.setChan_pair(attributes[30]);
					loop_w_12state_Data.setCbcid2_attr(attributes[31]);
					loop_w_12state_Data.setCbcid2(attributes[32]);
					loop_w_12state_Data.setChan_pair2_attr(attributes[33]);
					loop_w_12state_Data.setChan_pair2(attributes[34]);
					loop_w_12state_Data.setCti_attr(attributes[35]);
					loop_w_12state_Data.setCti(attributes[36]);
					loop_w_12state_Data.setRelay_rack_attr(attributes[37]);
					loop_w_12state_Data.setRelay_rack(attributes[38]);
					loop_w_12state_Data.setShelf_attr(attributes[39]);
					loop_w_12state_Data.setShelf(attributes[40]);
					loop_w_12state_Data.setSlot_attr(attributes[41]);
					loop_w_12state_Data.setSlot(attributes[42]);
					loop_w_12state_Data.setCti2_attr(attributes[43]);
					loop_w_12state_Data.setCti2(attributes[44]);
					loop_w_12state_Data.setRelay_rack2_attr(attributes[45]);
					loop_w_12state_Data.setRelay_rack2(attributes[46]);
					loop_w_12state_Data.setShelf2_attr(attributes[47]);
					loop_w_12state_Data.setShelf2(attributes[48]);
					loop_w_12state_Data.setSlot2_attr(attributes[49]);
					loop_w_12state_Data.setSlot2(attributes[50]);
					loop_w_12state_Data.setCti3_attr(attributes[51]);
					loop_w_12state_Data.setCti3(attributes[52]);
					loop_w_12state_Data.setRelay_rack3_attr(attributes[53]);
					loop_w_12state_Data.setRelay_rack3(attributes[54]);
					loop_w_12state_Data.setShelf3_attr(attributes[55]);
					loop_w_12state_Data.setShelf3(attributes[56]);
					loop_w_12state_Data.setSlot3_attr(attributes[57]);
					loop_w_12state_Data.setSlot3(attributes[58]);
					loop_w_12state_Data.setCti4_attr(attributes[59]);
					loop_w_12state_Data.setCti4(attributes[60]);
					loop_w_12state_Data.setRelay_rack4_attr(attributes[61]);
					loop_w_12state_Data.setRelay_rack4(attributes[62]);
					loop_w_12state_Data.setShelf4_attr(attributes[63]);
					loop_w_12state_Data.setShelf4(attributes[64]);
					loop_w_12state_Data.setSlot4_attr(attributes[65]);
					loop_w_12state_Data.setSlot4(attributes[66]);
					loop_w_12state_Data.setVpi_attr(attributes[67]);
					loop_w_12state_Data.setVpi(attributes[68]);
					loop_w_12state_Data.setVci_attr(attributes[69]);
					loop_w_12state_Data.setVci(attributes[70]);
					loop_w_12state_Data.setCode_set_attr(attributes[71]);
					loop_w_12state_Data.setCode_set(attributes[72]);
					loop_w_12state_Data.setRecckt_attr(attributes[73]);
					loop_w_12state_Data.setRecckt(attributes[74]);
					loop_w_12state_Data.setCkr_attr(attributes[75]);
					loop_w_12state_Data.setCkr(attributes[76]);
					loop_w_12state_Data.setTsp_attr(attributes[77]);
					loop_w_12state_Data.setTsp(attributes[78]);
					loop_w_12state_Data.setPorted_nbr_attr(attributes[79]);
					loop_w_12state_Data.setPorted_nbr(attributes[80]);
					loop_w_12state_Data.setNpt_attr(attributes[81]);
					loop_w_12state_Data.setNpt(attributes[82]);
					loop_w_12state_Data.setRti_attr(attributes[83]);
					loop_w_12state_Data.setRti(attributes[84]);
					loop_w_12state_Data.setNptg_attr(attributes[85]);
					loop_w_12state_Data.setNptg(attributes[86]);
					loop_w_12state_Data.setNpi_attr(attributes[87]);
					loop_w_12state_Data.setNpi(attributes[88]);
					loop_w_12state_Data.setLst_attr(attributes[89]);
					loop_w_12state_Data.setLst(attributes[90]);
					loop_w_12state_Data.setTns_attr(attributes[91]);
					loop_w_12state_Data.setTns(attributes[92]);
					loop_w_12state_Data.setOtn_attr(attributes[93]);
					loop_w_12state_Data.setOtn(attributes[94]);
					loop_w_12state_Data.setIspid_attr(attributes[95]);
					loop_w_12state_Data.setIspid(attributes[96]);
					loop_w_12state_Data.setPic_attr(attributes[97]);
					loop_w_12state_Data.setPic(attributes[98]);
					loop_w_12state_Data.setLpic_attr(attributes[99]);
					loop_w_12state_Data.setLpic(attributes[100]);
					loop_w_12state_Data.setSsig_attr(attributes[101]);
					loop_w_12state_Data.setSsig(attributes[102]);
					loop_w_12state_Data.setBa_attr(attributes[103]);
					loop_w_12state_Data.setBa(attributes[104]);
					loop_w_12state_Data.setBlock_attr(attributes[105]);
					loop_w_12state_Data.setBlock(attributes[106]);
					loop_w_12state_Data.setJk_code_attr(attributes[107]);
					loop_w_12state_Data.setJk_code(attributes[108]);
					loop_w_12state_Data.setJk_num_attr(attributes[109]);
					loop_w_12state_Data.setJk_num(attributes[110]);
					loop_w_12state_Data.setJk_pos_attr(attributes[111]);
					loop_w_12state_Data.setJk_pos(attributes[112]);
					loop_w_12state_Data.setJr_attr(attributes[113]);
					loop_w_12state_Data.setJr(attributes[114]);
					loop_w_12state_Data.setNidr_attr(attributes[115]);
					loop_w_12state_Data.setNidr(attributes[116]);
					loop_w_12state_Data.setIwjk1_attr(attributes[117]);
					loop_w_12state_Data.setIwjk1(attributes[118]);
					loop_w_12state_Data.setIwjk2_attr(attributes[119]);
					loop_w_12state_Data.setIwjk2(attributes[120]);
					loop_w_12state_Data.setIwjk3_attr(attributes[121]);
					loop_w_12state_Data.setIwjk3(attributes[122]);
					loop_w_12state_Data.setIwjk4_attr(attributes[123]);
					loop_w_12state_Data.setIwjk4(attributes[124]);
					loop_w_12state_Data.setIwjk5_attr(attributes[125]);
					loop_w_12state_Data.setIwjk5(attributes[126]);
					loop_w_12state_Data.setIwjq1_attr(attributes[127]);
					loop_w_12state_Data.setIwjq1(attributes[128]);
					loop_w_12state_Data.setIwjq2_attr(attributes[129]);
					loop_w_12state_Data.setIwjq2(attributes[130]);
					loop_w_12state_Data.setIwjq3_attr(attributes[131]);
					loop_w_12state_Data.setIwjq3(attributes[132]);
					loop_w_12state_Data.setIwjq4_attr(attributes[133]);
					loop_w_12state_Data.setIwjq4(attributes[134]);
					loop_w_12state_Data.setIwjq5_attr(attributes[135]);
					loop_w_12state_Data.setIwjq5(attributes[136]);
					loop_w_12state_Data.setLidb_attr(attributes[137]);
					loop_w_12state_Data.setLidb(attributes[138]);
					loop_w_12state_Data.setS_attr(attributes[139]);
					loop_w_12state_Data.setS(attributes[140]);
					loop_w_12state_Data.setOecckt_attr(attributes[141]);
					loop_w_12state_Data.setOecckt(attributes[142]);

					treeViewList_275.add(loop_w_12state_Data);

				}
				session.setAttribute("treeViewList_275", treeViewList_275);
				selectRequestData.setSubHeader(receivedSubHeader);

			}

			// Aprajita
			if (subData_841Recid != null && subData_841Recid.getSubHeader().getRecord_type().equals("841")) {

				SubHeader receivedSubHeader = subData_841Recid.getSubHeader();
				String[] subDataRows = subData_841Recid.getSubDataRows();
				treeViewList.add("841");

				// List treeViewList = new ArrayList();
				// int i = 0;
				for (String subDataRow : subDataRows) {
					String[] attributes = mqReadUtil.getAttributes(subDataRow, 217);
					// System.out.println("attributes:=841:Reqid=======> " +
					// Arrays.toString(attributes));
					ISDNPort_IUS_Channel_12States isdnPort_IUS_Channel_12States = new ISDNPort_IUS_Channel_12States();

					isdnPort_IUS_Channel_12States.setItem_num(attributes[0]);
					isdnPort_IUS_Channel_12States.setCnum_attr(attributes[1]);
					isdnPort_IUS_Channel_12States.setCnum(attributes[2]);
					isdnPort_IUS_Channel_12States.setFnum_attr(attributes[3]);
					isdnPort_IUS_Channel_12States.setFnum(attributes[4]);
					isdnPort_IUS_Channel_12States.setTnnum_attr(attributes[5]);
					isdnPort_IUS_Channel_12States.setTnnum(attributes[6]);
					isdnPort_IUS_Channel_12States.setTglnum_attr(attributes[7]);
					isdnPort_IUS_Channel_12States.setTglnum(attributes[8]);
					isdnPort_IUS_Channel_12States.setEcckt_attr(attributes[9]);
					isdnPort_IUS_Channel_12States.setEcckt(attributes[10]);
					isdnPort_IUS_Channel_12States.setCfa_attr(attributes[11]);
					isdnPort_IUS_Channel_12States.setCfa(attributes[12]);
					isdnPort_IUS_Channel_12States.setLtgn_attr(attributes[13]);
					isdnPort_IUS_Channel_12States.setLtgn(attributes[14]);
					isdnPort_IUS_Channel_12States.setIid_attr(attributes[15]);
					isdnPort_IUS_Channel_12States.setIid(attributes[16]);
					isdnPort_IUS_Channel_12States.setCord_attr(attributes[17]);
					isdnPort_IUS_Channel_12States.setCord(attributes[18]);
					isdnPort_IUS_Channel_12States.setIsdnp_attr(attributes[19]);
					isdnPort_IUS_Channel_12States.setIsdnp(attributes[20]);
					isdnPort_IUS_Channel_12States.setFlna_attr(attributes[21]);
					isdnPort_IUS_Channel_12States.setFlna(attributes[22]);
					isdnPort_IUS_Channel_12States.setCkttyp_attr(attributes[23]);
					isdnPort_IUS_Channel_12States.setCkttyp(attributes[24]);
					isdnPort_IUS_Channel_12States.setFecckt_attr(attributes[25]);
					isdnPort_IUS_Channel_12States.setFecckt(attributes[26]);
					isdnPort_IUS_Channel_12States.setPlst_attr(attributes[27]);
					isdnPort_IUS_Channel_12States.setPlst(attributes[28]);
					isdnPort_IUS_Channel_12States.setAuth_num_attr(attributes[29]);
					isdnPort_IUS_Channel_12States.setAuth_num(attributes[30]);
					isdnPort_IUS_Channel_12States.setPri_loc_attr(attributes[31]);
					isdnPort_IUS_Channel_12States.setPri_loc(attributes[32]);
					isdnPort_IUS_Channel_12States.setEulst_attr(attributes[33]);
					isdnPort_IUS_Channel_12States.setEulst(attributes[34]);
					isdnPort_IUS_Channel_12States.setCcea_attr(attributes[35]);
					isdnPort_IUS_Channel_12States.setCcea(attributes[36]);
					isdnPort_IUS_Channel_12States.setCfa_btn_attr(attributes[37]);
					isdnPort_IUS_Channel_12States.setCfa_btn(attributes[38]);
					isdnPort_IUS_Channel_12States.setCb_attr(attributes[39]);
					isdnPort_IUS_Channel_12States.setCb(attributes[40]);
					isdnPort_IUS_Channel_12States.setCbbtn_attr(attributes[41]);
					isdnPort_IUS_Channel_12States.setCbbtn(attributes[42]);
					isdnPort_IUS_Channel_12States.setNcon_attr(attributes[43]);
					isdnPort_IUS_Channel_12States.setNcon(attributes[44]);
					isdnPort_IUS_Channel_12States.setAft_attr(attributes[45]);
					isdnPort_IUS_Channel_12States.setAft(attributes[46]);
					isdnPort_IUS_Channel_12States.setSapr_attr(attributes[47]);
					isdnPort_IUS_Channel_12States.setSapr(attributes[48]);
					isdnPort_IUS_Channel_12States.setSano_attr(attributes[49]);
					isdnPort_IUS_Channel_12States.setSano(attributes[50]);
					isdnPort_IUS_Channel_12States.setSasf_attr(attributes[51]);
					isdnPort_IUS_Channel_12States.setSasf(attributes[52]);
					isdnPort_IUS_Channel_12States.setSasd_attr(attributes[53]);
					isdnPort_IUS_Channel_12States.setSasd(attributes[54]);
					isdnPort_IUS_Channel_12States.setSasn_attr(attributes[55]);
					isdnPort_IUS_Channel_12States.setSasn(attributes[56]);
					isdnPort_IUS_Channel_12States.setSath_attr(attributes[57]);
					isdnPort_IUS_Channel_12States.setSath(attributes[58]);
					isdnPort_IUS_Channel_12States.setSass_attr(attributes[59]);
					isdnPort_IUS_Channel_12States.setSass(attributes[60]);
					isdnPort_IUS_Channel_12States.setLd1_attr(attributes[61]);
					isdnPort_IUS_Channel_12States.setLd1(attributes[62]);
					isdnPort_IUS_Channel_12States.setLv1_attr(attributes[63]);
					isdnPort_IUS_Channel_12States.setLv1(attributes[64]);
					isdnPort_IUS_Channel_12States.setLd2_attr(attributes[65]);
					isdnPort_IUS_Channel_12States.setLd2(attributes[66]);
					isdnPort_IUS_Channel_12States.setLv2_attr(attributes[67]);
					isdnPort_IUS_Channel_12States.setLv2(attributes[68]);
					isdnPort_IUS_Channel_12States.setLd3_attr(attributes[69]);
					isdnPort_IUS_Channel_12States.setLd3(attributes[70]);
					isdnPort_IUS_Channel_12States.setLv3_attr(attributes[71]);
					isdnPort_IUS_Channel_12States.setLv3(attributes[72]);
					isdnPort_IUS_Channel_12States.setAai_attr(attributes[73]);
					isdnPort_IUS_Channel_12States.setAai(attributes[74]);
					isdnPort_IUS_Channel_12States.setCity_attr(attributes[75]);
					isdnPort_IUS_Channel_12States.setCity(attributes[76]);
					isdnPort_IUS_Channel_12States.setState_attr(attributes[77]);
					isdnPort_IUS_Channel_12States.setState(attributes[78]);
					isdnPort_IUS_Channel_12States.setZip_attr(attributes[79]);
					isdnPort_IUS_Channel_12States.setZip(attributes[80]);
					isdnPort_IUS_Channel_12States.setNidr_attr(attributes[81]);
					isdnPort_IUS_Channel_12States.setNidr(attributes[82]);
					isdnPort_IUS_Channel_12States.setIwo_attr(attributes[83]);
					isdnPort_IUS_Channel_12States.setIwo(attributes[84]);
					isdnPort_IUS_Channel_12States.setAloc_attr(attributes[85]);
					isdnPort_IUS_Channel_12States.setAloc(attributes[86]);
					isdnPort_IUS_Channel_12States.setLcon_attr(attributes[87]);
					isdnPort_IUS_Channel_12States.setLcon(attributes[88]);
					isdnPort_IUS_Channel_12States.setTelno_attr(attributes[89]);
					isdnPort_IUS_Channel_12States.setTelno(attributes[90]);
					isdnPort_IUS_Channel_12States.setPtnract_attr(attributes[91]);
					isdnPort_IUS_Channel_12States.setPtnract(attributes[92]);
					isdnPort_IUS_Channel_12States.setPtnrq_attr(attributes[93]);
					isdnPort_IUS_Channel_12States.setPtnrq(attributes[94]);
					isdnPort_IUS_Channel_12States.setPtnr1_attr(attributes[95]);
					isdnPort_IUS_Channel_12States.setPtnr1(attributes[96]);
					isdnPort_IUS_Channel_12States.setPtnr2_attr(attributes[97]);
					isdnPort_IUS_Channel_12States.setPtnr2(attributes[98]);
					isdnPort_IUS_Channel_12States.setPtnr3_attr(attributes[99]);
					isdnPort_IUS_Channel_12States.setPtnr3(attributes[100]);
					isdnPort_IUS_Channel_12States.setNpi_attr(attributes[101]);
					isdnPort_IUS_Channel_12States.setNpi(attributes[102]);
					isdnPort_IUS_Channel_12States.setDidr_attr(attributes[103]);
					isdnPort_IUS_Channel_12States.setDidr(attributes[104]);
					isdnPort_IUS_Channel_12States.setTgtli_attr(attributes[105]);
					isdnPort_IUS_Channel_12States.setTgtli(attributes[106]);
					isdnPort_IUS_Channel_12States.setDba1_attr(attributes[107]);
					isdnPort_IUS_Channel_12States.setDba1(attributes[108]);
					isdnPort_IUS_Channel_12States.setDba2_attr(attributes[109]);
					isdnPort_IUS_Channel_12States.setDba2(attributes[110]);
					isdnPort_IUS_Channel_12States.setDblock1_attr(attributes[111]);
					isdnPort_IUS_Channel_12States.setDblock1(attributes[112]);
					isdnPort_IUS_Channel_12States.setDblock2_attr(attributes[113]);
					isdnPort_IUS_Channel_12States.setDblock2(attributes[114]);
					isdnPort_IUS_Channel_12States.setNba_attr(attributes[115]);
					isdnPort_IUS_Channel_12States.setNba(attributes[116]);
					isdnPort_IUS_Channel_12States.setNbank1_attr(attributes[117]);
					isdnPort_IUS_Channel_12States.setNbank1(attributes[118]);
					isdnPort_IUS_Channel_12States.setNbank2_attr(attributes[119]);
					isdnPort_IUS_Channel_12States.setNbank2(attributes[120]);
					isdnPort_IUS_Channel_12States.setNbank3_attr(attributes[121]);
					isdnPort_IUS_Channel_12States.setNbank3(attributes[122]);
					isdnPort_IUS_Channel_12States.setNbank4_attr(attributes[123]);
					isdnPort_IUS_Channel_12States.setNbank4(attributes[124]);
					isdnPort_IUS_Channel_12States.setDstnact_attr(attributes[125]);
					isdnPort_IUS_Channel_12States.setDstnact(attributes[126]);
					isdnPort_IUS_Channel_12States.setDstnq_attr(attributes[127]);
					isdnPort_IUS_Channel_12States.setDstnq(attributes[128]);
					isdnPort_IUS_Channel_12States.setDstn1_attr(attributes[129]);
					isdnPort_IUS_Channel_12States.setDstn1(attributes[130]);
					isdnPort_IUS_Channel_12States.setDstn2_attr(attributes[131]);
					isdnPort_IUS_Channel_12States.setDstn2(attributes[132]);
					isdnPort_IUS_Channel_12States.setDstn3_attr(attributes[133]);
					isdnPort_IUS_Channel_12States.setDstn3(attributes[134]);
					isdnPort_IUS_Channel_12States.setDstn4_attr(attributes[135]);
					isdnPort_IUS_Channel_12States.setDstn4(attributes[136]);
					isdnPort_IUS_Channel_12States.setDstn5_attr(attributes[137]);
					isdnPort_IUS_Channel_12States.setDstn5(attributes[138]);
					isdnPort_IUS_Channel_12States.setTglna_attr(attributes[139]);
					isdnPort_IUS_Channel_12States.setTglna(attributes[140]);
					isdnPort_IUS_Channel_12States.setTgn_attr(attributes[141]);
					isdnPort_IUS_Channel_12States.setTgn(attributes[142]);
					isdnPort_IUS_Channel_12States.setPtgn_of_attr(attributes[143]);
					isdnPort_IUS_Channel_12States.setPtgn_of(attributes[144]);
					isdnPort_IUS_Channel_12States.setTgtli01_attr(attributes[145]);
					isdnPort_IUS_Channel_12States.setTgtli01(attributes[146]);
					isdnPort_IUS_Channel_12States.setTgrti_attr(attributes[147]);
					isdnPort_IUS_Channel_12States.setTgrti(attributes[148]);
					isdnPort_IUS_Channel_12States.setTgdir_attr(attributes[149]);
					isdnPort_IUS_Channel_12States.setTgdir(attributes[150]);
					isdnPort_IUS_Channel_12States.setPtgnh_attr(attributes[151]);
					isdnPort_IUS_Channel_12States.setPtgnh(attributes[152]);
					isdnPort_IUS_Channel_12States.setDgout_attr(attributes[153]);
					isdnPort_IUS_Channel_12States.setDgout(attributes[154]);
					isdnPort_IUS_Channel_12States.setDg_rcvd_attr(attributes[155]);
					isdnPort_IUS_Channel_12States.setDg_rcvd(attributes[156]);
					isdnPort_IUS_Channel_12States.setPdod_attr(attributes[157]);
					isdnPort_IUS_Channel_12States.setPdod(attributes[158]);
					isdnPort_IUS_Channel_12States.setPic_attr(attributes[159]);
					isdnPort_IUS_Channel_12States.setPic(attributes[160]);
					isdnPort_IUS_Channel_12States.setLpic_attr(attributes[161]);
					isdnPort_IUS_Channel_12States.setLpic(attributes[162]);
					isdnPort_IUS_Channel_12States.setGlare_attr(attributes[163]);
					isdnPort_IUS_Channel_12States.setGlare(attributes[164]);
					isdnPort_IUS_Channel_12States.setPbxid_attr(attributes[165]);
					isdnPort_IUS_Channel_12States.setPbxid(attributes[166]);
					isdnPort_IUS_Channel_12States.setCid_attr(attributes[167]);
					isdnPort_IUS_Channel_12States.setCid(attributes[168]);
					isdnPort_IUS_Channel_12States.setTot_attr(attributes[169]);
					isdnPort_IUS_Channel_12States.setTot(attributes[170]);
					isdnPort_IUS_Channel_12States.setGsind1_attr(attributes[171]);
					isdnPort_IUS_Channel_12States.setGsind1(attributes[172]);
					isdnPort_IUS_Channel_12States.setGsind2_attr(attributes[173]);
					isdnPort_IUS_Channel_12States.setGsind2(attributes[174]);
					isdnPort_IUS_Channel_12States.setGsind3_attr(attributes[175]);
					isdnPort_IUS_Channel_12States.setGsind3(attributes[176]);
					isdnPort_IUS_Channel_12States.setGsind4_attr(attributes[177]);
					isdnPort_IUS_Channel_12States.setGsind4(attributes[178]);
					isdnPort_IUS_Channel_12States.setGsind5_attr(attributes[179]);
					isdnPort_IUS_Channel_12States.setGsind5(attributes[180]);
					isdnPort_IUS_Channel_12States.setGsqty1_attr(attributes[181]);
					isdnPort_IUS_Channel_12States.setGsqty1(attributes[182]);
					isdnPort_IUS_Channel_12States.setGsqty2_attr(attributes[183]);
					isdnPort_IUS_Channel_12States.setGsqty2(attributes[184]);
					isdnPort_IUS_Channel_12States.setGsqty3_attr(attributes[185]);
					isdnPort_IUS_Channel_12States.setGsqty3(attributes[186]);
					isdnPort_IUS_Channel_12States.setGsqty4_attr(attributes[187]);
					isdnPort_IUS_Channel_12States.setGsqty4(attributes[188]);
					isdnPort_IUS_Channel_12States.setGsqty5_attr(attributes[189]);
					isdnPort_IUS_Channel_12States.setGsqty5(attributes[190]);
					isdnPort_IUS_Channel_12States.setGind1_attr(attributes[191]);
					isdnPort_IUS_Channel_12States.setGind1(attributes[192]);
					isdnPort_IUS_Channel_12States.setGind2_attr(attributes[193]);
					isdnPort_IUS_Channel_12States.setGind2(attributes[194]);
					isdnPort_IUS_Channel_12States.setGind3_attr(attributes[195]);
					isdnPort_IUS_Channel_12States.setGind3(attributes[196]);
					isdnPort_IUS_Channel_12States.setGind4_attr(attributes[197]);
					isdnPort_IUS_Channel_12States.setGind4(attributes[198]);
					isdnPort_IUS_Channel_12States.setGqty1_attr(attributes[199]);
					isdnPort_IUS_Channel_12States.setGqty1(attributes[200]);
					isdnPort_IUS_Channel_12States.setGqty2_attr(attributes[201]);
					isdnPort_IUS_Channel_12States.setGqty2(attributes[202]);
					isdnPort_IUS_Channel_12States.setGqty3_attr(attributes[203]);
					isdnPort_IUS_Channel_12States.setGqty3(attributes[204]);
					isdnPort_IUS_Channel_12States.setGqty4_attr(attributes[205]);
					isdnPort_IUS_Channel_12States.setGqty4(attributes[206]);
					isdnPort_IUS_Channel_12States.setSec_loc_attr(attributes[207]);
					isdnPort_IUS_Channel_12States.setSec_loc(attributes[208]);
					isdnPort_IUS_Channel_12States.setCb_sec_attr(attributes[209]);
					isdnPort_IUS_Channel_12States.setCb_sec(attributes[210]);
					isdnPort_IUS_Channel_12States.setCbbtn_sec_attr(attributes[211]);
					isdnPort_IUS_Channel_12States.setCbbtn_sec(attributes[212]);
					isdnPort_IUS_Channel_12States.setActl_attr(attributes[213]);
					isdnPort_IUS_Channel_12States.setActl(attributes[214]);
					isdnPort_IUS_Channel_12States.setCfa_ckt_attr(attributes[215]);
					isdnPort_IUS_Channel_12States.setCfa_ckt(attributes[216]);

					treeViewList_841.add(isdnPort_IUS_Channel_12States);
				}
				session.setAttribute("treeViewList_841", treeViewList_841);
				selectRequestData.setSubHeader(receivedSubHeader);
			}
			if (subData_157Recid != null && subData_157Recid.getSubHeader().getRecord_type().equals("157")) {

				SubHeader receivedSubHeader = subData_157Recid.getSubHeader();
				String[] subDataRows = subData_157Recid.getSubDataRows();
				treeViewList.add("157");

				// List treeViewList = new ArrayList();
				// int i = 0;
				for (String subDataRow : subDataRows) {
					String[] attributes = mqReadUtil.getAttributes(subDataRow, 9);
					// System.out.println("attributes:=157=======> " + Arrays.toString(attributes));
					ISDNPort_IUS_Location_f_features_12States isdnPort_IUS_Location_f_features_12States = new ISDNPort_IUS_Location_f_features_12States();

					isdnPort_IUS_Location_f_features_12States.setItem_num(attributes[0]);
					isdnPort_IUS_Location_f_features_12States.setF_fa_attr(attributes[1]);
					isdnPort_IUS_Location_f_features_12States.setF_fa(attributes[2]);
					isdnPort_IUS_Location_f_features_12States.setF_feature_attr(attributes[3]);
					isdnPort_IUS_Location_f_features_12States.setF_feature(attributes[4]);
					isdnPort_IUS_Location_f_features_12States.setF_feature_detail_attr(attributes[5]);
					isdnPort_IUS_Location_f_features_12States.setF_feature_detail(attributes[6]);
					isdnPort_IUS_Location_f_features_12States.setLine_asgn_attr(attributes[7]);
					isdnPort_IUS_Location_f_features_12States.setLine_asgn(attributes[8]);

					treeViewList_157.add(isdnPort_IUS_Location_f_features_12States);
				}
				session.setAttribute("treeViewList_157", treeViewList_157);
				selectRequestData.setSubHeader(receivedSubHeader);
			}
			if (subData_159Recid != null && subData_159Recid.getSubHeader().getRecord_type().equals("159")) {

				SubHeader receivedSubHeader = subData_159Recid.getSubHeader();
				String[] subDataRows = subData_159Recid.getSubDataRows();
				treeViewList.add("159");

				// List treeViewList = new ArrayList();
				// int i = 0;
				for (String subDataRow : subDataRows) {
					String[] attributes = mqReadUtil.getAttributes(subDataRow, 9);
					// System.out.println("attributes:=159=======> " + Arrays.toString(attributes));
					ISDNPort_IUS_ChannelFeaturesGrid_12States isdnPort_IUS_ChannelFeaturesGrid_12States = new ISDNPort_IUS_ChannelFeaturesGrid_12States();

					isdnPort_IUS_ChannelFeaturesGrid_12States.setItem_num(attributes[0]);
					isdnPort_IUS_ChannelFeaturesGrid_12States.setChannel_fa_attr(attributes[1]);
					isdnPort_IUS_ChannelFeaturesGrid_12States.setChannel_fa(attributes[2]);
					isdnPort_IUS_ChannelFeaturesGrid_12States.setChannel_feature_attr(attributes[3]);
					isdnPort_IUS_ChannelFeaturesGrid_12States.setChannel_feature(attributes[4]);
					isdnPort_IUS_ChannelFeaturesGrid_12States.setChannel_feature_detail_attr(attributes[5]);
					isdnPort_IUS_ChannelFeaturesGrid_12States.setChannel_feature_detail(attributes[6]);
					isdnPort_IUS_ChannelFeaturesGrid_12States.setLine_asgn_attr(attributes[7]);
					isdnPort_IUS_ChannelFeaturesGrid_12States.setLine_asgn(attributes[8]);

					treeViewList_159.add(isdnPort_IUS_ChannelFeaturesGrid_12States);
				}
				session.setAttribute("treeViewList_159", treeViewList_159);
				selectRequestData.setSubHeader(receivedSubHeader);
				// selectRequestData.setSelectRequestTableRows(selectRequestTableRows);
			}
			if (subData_210Recid != null && subData_210Recid.getSubHeader().getRecord_type().equals("210")) {

				SubHeader receivedSubHeader = subData_210Recid.getSubHeader();
				String[] subDataRows = subData_210Recid.getSubDataRows();
				treeViewList.add("210");

				// List treeViewList = new ArrayList();
				// int i = 0;
				for (String subDataRow : subDataRows) {
					String[] attributes = mqReadUtil.getAttributes(subDataRow, 14);
					// System.out.println("attributes:=210=======> " + Arrays.toString(attributes));
					ISDNPort_IUS_PRI_DISC_TN_12States isdnPort_IUS_PRI_DISC_TN_12States = new ISDNPort_IUS_PRI_DISC_TN_12States();

					isdnPort_IUS_PRI_DISC_TN_12States.setItem_num(attributes[0]);
					isdnPort_IUS_PRI_DISC_TN_12States.setTnnum_attr(attributes[1]);
					isdnPort_IUS_PRI_DISC_TN_12States.setTnnum(attributes[2]);
					isdnPort_IUS_PRI_DISC_TN_12States.setTc_opt_attr(attributes[3]);
					isdnPort_IUS_PRI_DISC_TN_12States.setTc_opt(attributes[4]);
					isdnPort_IUS_PRI_DISC_TN_12States.setTc_per_attr(attributes[5]);
					isdnPort_IUS_PRI_DISC_TN_12States.setTc_per(attributes[6]);
					isdnPort_IUS_PRI_DISC_TN_12States.setTc_to_pri_attr(attributes[7]);
					isdnPort_IUS_PRI_DISC_TN_12States.setTc_to_pri(attributes[8]);
					isdnPort_IUS_PRI_DISC_TN_12States.setTc_name_pri_attr(attributes[9]);
					isdnPort_IUS_PRI_DISC_TN_12States.setTc_name_pri(attributes[10]);
					isdnPort_IUS_PRI_DISC_TN_12States.setTc_id_attr(attributes[11]);
					isdnPort_IUS_PRI_DISC_TN_12States.setTc_id(attributes[12]);
					isdnPort_IUS_PRI_DISC_TN_12States.setLocnum(attributes[13]);

					treeViewList_210.add(isdnPort_IUS_PRI_DISC_TN_12States);
				}
				session.setAttribute("treeViewList_210", treeViewList_210);
				selectRequestData.setSubHeader(receivedSubHeader);
			}

			if (subData_158Recid != null && subData_158Recid.getSubHeader().getRecord_type().equals("158")) {

				SubHeader receivedSubHeader = subData_158Recid.getSubHeader();
				String[] subDataRows = subData_158Recid.getSubDataRows();
				treeViewList.add("158");

				// List treeViewList = new ArrayList();
				// int i = 0;
				for (String subDataRow : subDataRows) {
					String[] attributes = mqReadUtil.getAttributes(subDataRow, 9);
					// System.out.println("attributes:=158=======> " + Arrays.toString(attributes));
					ISDNPort_IUS_TrunkGroup_TG_FeaturesGrid_12States isdnPort_IUS_TrunkGroup_TG_FeaturesGrid_12States = new ISDNPort_IUS_TrunkGroup_TG_FeaturesGrid_12States();

					isdnPort_IUS_TrunkGroup_TG_FeaturesGrid_12States.setItem_num(attributes[0]);
					isdnPort_IUS_TrunkGroup_TG_FeaturesGrid_12States.setTgfa_attr(attributes[1]);
					isdnPort_IUS_TrunkGroup_TG_FeaturesGrid_12States.setTgfa(attributes[2]);
					isdnPort_IUS_TrunkGroup_TG_FeaturesGrid_12States.setTgfeature_attr(attributes[3]);
					isdnPort_IUS_TrunkGroup_TG_FeaturesGrid_12States.setTgfeature(attributes[4]);
					isdnPort_IUS_TrunkGroup_TG_FeaturesGrid_12States.setTgfeature_detail_attr(attributes[5]);
					isdnPort_IUS_TrunkGroup_TG_FeaturesGrid_12States.setTgfeature_detail(attributes[6]);
					isdnPort_IUS_TrunkGroup_TG_FeaturesGrid_12States.setLine_asgn_attr(attributes[7]);
					isdnPort_IUS_TrunkGroup_TG_FeaturesGrid_12States.setLine_asgn(attributes[8]);

					treeViewList_158.add(isdnPort_IUS_TrunkGroup_TG_FeaturesGrid_12States);
				}
				session.setAttribute("treeViewList_158", treeViewList_158);
				selectRequestData.setSubHeader(receivedSubHeader);
				// selectRequestData.setSelectRequestTableRows(selectRequestTableRows);
			}

			if (subData_842Recid != null && subData_842Recid.getSubHeader().getRecord_type().equals("842")) {

				SubHeader receivedSubHeader = subData_842Recid.getSubHeader();
				String[] subDataRows = subData_842Recid.getSubDataRows();
				treeViewList.add("842");

				// List treeViewList = new ArrayList();
				// int i = 0;
				for (String subDataRow : subDataRows) {
					String[] attributes = mqReadUtil.getAttributes(subDataRow, 217);
					// System.out.println("attributes:=842:Reqid=======> " +
					// Arrays.toString(attributes));
					ISDN_LoopPort_IUS_Channel_12States isdn_LoopPort_IUS_Channel_12States = new ISDN_LoopPort_IUS_Channel_12States();

					isdn_LoopPort_IUS_Channel_12States.setItem_num(attributes[0]);
					isdn_LoopPort_IUS_Channel_12States.setCnum_attr(attributes[1]);
					isdn_LoopPort_IUS_Channel_12States.setCnum(attributes[2]);
					isdn_LoopPort_IUS_Channel_12States.setFnum_attr(attributes[3]);
					isdn_LoopPort_IUS_Channel_12States.setFnum(attributes[4]);
					isdn_LoopPort_IUS_Channel_12States.setTnnum_attr(attributes[5]);
					isdn_LoopPort_IUS_Channel_12States.setTnnum(attributes[6]);
					isdn_LoopPort_IUS_Channel_12States.setTglnum_attr(attributes[7]);
					isdn_LoopPort_IUS_Channel_12States.setTglnum(attributes[8]);
					isdn_LoopPort_IUS_Channel_12States.setEcckt_attr(attributes[9]);
					isdn_LoopPort_IUS_Channel_12States.setEcckt(attributes[10]);
					isdn_LoopPort_IUS_Channel_12States.setCfa_attr(attributes[11]);
					isdn_LoopPort_IUS_Channel_12States.setCfa(attributes[12]);
					isdn_LoopPort_IUS_Channel_12States.setLtgn_attr(attributes[13]);
					isdn_LoopPort_IUS_Channel_12States.setLtgn(attributes[14]);
					isdn_LoopPort_IUS_Channel_12States.setIid_attr(attributes[15]);
					isdn_LoopPort_IUS_Channel_12States.setIid(attributes[16]);
					isdn_LoopPort_IUS_Channel_12States.setCord_attr(attributes[17]);
					isdn_LoopPort_IUS_Channel_12States.setCord(attributes[18]);
					isdn_LoopPort_IUS_Channel_12States.setIsdnp_attr(attributes[19]);
					isdn_LoopPort_IUS_Channel_12States.setIsdnp(attributes[20]);
					isdn_LoopPort_IUS_Channel_12States.setFlna_attr(attributes[21]);
					isdn_LoopPort_IUS_Channel_12States.setFlna(attributes[22]);
					isdn_LoopPort_IUS_Channel_12States.setCkttyp_attr(attributes[23]);
					isdn_LoopPort_IUS_Channel_12States.setCkttyp(attributes[24]);
					isdn_LoopPort_IUS_Channel_12States.setFecckt_attr(attributes[25]);
					isdn_LoopPort_IUS_Channel_12States.setFecckt(attributes[26]);
					isdn_LoopPort_IUS_Channel_12States.setPlst_attr(attributes[27]);
					isdn_LoopPort_IUS_Channel_12States.setPlst(attributes[28]);
					isdn_LoopPort_IUS_Channel_12States.setAuth_num_attr(attributes[29]);
					isdn_LoopPort_IUS_Channel_12States.setAuth_num(attributes[30]);
					isdn_LoopPort_IUS_Channel_12States.setPri_loc_attr(attributes[31]);
					isdn_LoopPort_IUS_Channel_12States.setPri_loc(attributes[32]);
					isdn_LoopPort_IUS_Channel_12States.setEulst_attr(attributes[33]);
					isdn_LoopPort_IUS_Channel_12States.setEulst(attributes[34]);
					isdn_LoopPort_IUS_Channel_12States.setCcea_attr(attributes[35]);
					isdn_LoopPort_IUS_Channel_12States.setCcea(attributes[36]);
					isdn_LoopPort_IUS_Channel_12States.setCfa_btn_attr(attributes[37]);
					isdn_LoopPort_IUS_Channel_12States.setCfa_btn(attributes[38]);
					isdn_LoopPort_IUS_Channel_12States.setCb_attr(attributes[39]);
					isdn_LoopPort_IUS_Channel_12States.setCb(attributes[40]);
					isdn_LoopPort_IUS_Channel_12States.setCbbtn_attr(attributes[41]);
					isdn_LoopPort_IUS_Channel_12States.setCbbtn(attributes[42]);
					isdn_LoopPort_IUS_Channel_12States.setNcon_attr(attributes[43]);
					isdn_LoopPort_IUS_Channel_12States.setNcon(attributes[44]);
					isdn_LoopPort_IUS_Channel_12States.setAft_attr(attributes[45]);
					isdn_LoopPort_IUS_Channel_12States.setAft(attributes[46]);
					isdn_LoopPort_IUS_Channel_12States.setSapr_attr(attributes[47]);
					isdn_LoopPort_IUS_Channel_12States.setSapr(attributes[48]);
					isdn_LoopPort_IUS_Channel_12States.setSano_attr(attributes[49]);
					isdn_LoopPort_IUS_Channel_12States.setSano(attributes[50]);
					isdn_LoopPort_IUS_Channel_12States.setSasf_attr(attributes[51]);
					isdn_LoopPort_IUS_Channel_12States.setSasf(attributes[52]);
					isdn_LoopPort_IUS_Channel_12States.setSasd_attr(attributes[53]);
					isdn_LoopPort_IUS_Channel_12States.setSasd(attributes[54]);
					isdn_LoopPort_IUS_Channel_12States.setSasn_attr(attributes[55]);
					isdn_LoopPort_IUS_Channel_12States.setSasn(attributes[56]);
					isdn_LoopPort_IUS_Channel_12States.setSath_attr(attributes[57]);
					isdn_LoopPort_IUS_Channel_12States.setSath(attributes[58]);
					isdn_LoopPort_IUS_Channel_12States.setSass_attr(attributes[59]);
					isdn_LoopPort_IUS_Channel_12States.setSass(attributes[60]);
					isdn_LoopPort_IUS_Channel_12States.setLd1_attr(attributes[61]);
					isdn_LoopPort_IUS_Channel_12States.setLd1(attributes[62]);
					isdn_LoopPort_IUS_Channel_12States.setLv1_attr(attributes[63]);
					isdn_LoopPort_IUS_Channel_12States.setLv1(attributes[64]);
					isdn_LoopPort_IUS_Channel_12States.setLd2_attr(attributes[65]);
					isdn_LoopPort_IUS_Channel_12States.setLd2(attributes[66]);
					isdn_LoopPort_IUS_Channel_12States.setLv2_attr(attributes[67]);
					isdn_LoopPort_IUS_Channel_12States.setLv2(attributes[68]);
					isdn_LoopPort_IUS_Channel_12States.setLd3_attr(attributes[69]);
					isdn_LoopPort_IUS_Channel_12States.setLd3(attributes[70]);
					isdn_LoopPort_IUS_Channel_12States.setLv3_attr(attributes[71]);
					isdn_LoopPort_IUS_Channel_12States.setLv3(attributes[72]);
					isdn_LoopPort_IUS_Channel_12States.setAai_attr(attributes[73]);
					isdn_LoopPort_IUS_Channel_12States.setAai(attributes[74]);
					isdn_LoopPort_IUS_Channel_12States.setCity_attr(attributes[75]);
					isdn_LoopPort_IUS_Channel_12States.setCity(attributes[76]);
					isdn_LoopPort_IUS_Channel_12States.setState_attr(attributes[77]);
					isdn_LoopPort_IUS_Channel_12States.setState(attributes[78]);
					isdn_LoopPort_IUS_Channel_12States.setZip_attr(attributes[79]);
					isdn_LoopPort_IUS_Channel_12States.setZip(attributes[80]);
					isdn_LoopPort_IUS_Channel_12States.setNidr_attr(attributes[81]);
					isdn_LoopPort_IUS_Channel_12States.setNidr(attributes[82]);
					isdn_LoopPort_IUS_Channel_12States.setIwo_attr(attributes[83]);
					isdn_LoopPort_IUS_Channel_12States.setIwo(attributes[84]);
					isdn_LoopPort_IUS_Channel_12States.setAloc_attr(attributes[85]);
					isdn_LoopPort_IUS_Channel_12States.setAloc(attributes[86]);
					isdn_LoopPort_IUS_Channel_12States.setLcon_attr(attributes[87]);
					isdn_LoopPort_IUS_Channel_12States.setLcon(attributes[88]);
					isdn_LoopPort_IUS_Channel_12States.setTelno_attr(attributes[89]);
					isdn_LoopPort_IUS_Channel_12States.setTelno(attributes[90]);
					isdn_LoopPort_IUS_Channel_12States.setPtnract_attr(attributes[91]);
					isdn_LoopPort_IUS_Channel_12States.setPtnract(attributes[92]);
					isdn_LoopPort_IUS_Channel_12States.setPtnrq_attr(attributes[93]);
					isdn_LoopPort_IUS_Channel_12States.setPtnrq(attributes[94]);
					isdn_LoopPort_IUS_Channel_12States.setPtnr1_attr(attributes[95]);
					isdn_LoopPort_IUS_Channel_12States.setPtnr1(attributes[96]);
					isdn_LoopPort_IUS_Channel_12States.setPtnr2_attr(attributes[97]);
					isdn_LoopPort_IUS_Channel_12States.setPtnr2(attributes[98]);
					isdn_LoopPort_IUS_Channel_12States.setPtnr3_attr(attributes[99]);
					isdn_LoopPort_IUS_Channel_12States.setPtnr3(attributes[100]);
					isdn_LoopPort_IUS_Channel_12States.setNpi_attr(attributes[101]);
					isdn_LoopPort_IUS_Channel_12States.setNpi(attributes[102]);
					isdn_LoopPort_IUS_Channel_12States.setDidr_attr(attributes[103]);
					isdn_LoopPort_IUS_Channel_12States.setDidr(attributes[104]);
					isdn_LoopPort_IUS_Channel_12States.setTgtli_attr(attributes[105]);
					isdn_LoopPort_IUS_Channel_12States.setTgtli(attributes[106]);
					isdn_LoopPort_IUS_Channel_12States.setDba1_attr(attributes[107]);
					isdn_LoopPort_IUS_Channel_12States.setDba1(attributes[108]);
					isdn_LoopPort_IUS_Channel_12States.setDba2_attr(attributes[109]);
					isdn_LoopPort_IUS_Channel_12States.setDba2(attributes[110]);
					isdn_LoopPort_IUS_Channel_12States.setDblock1_attr(attributes[111]);
					isdn_LoopPort_IUS_Channel_12States.setDblock1(attributes[112]);
					isdn_LoopPort_IUS_Channel_12States.setDblock2_attr(attributes[113]);
					isdn_LoopPort_IUS_Channel_12States.setDblock2(attributes[114]);
					isdn_LoopPort_IUS_Channel_12States.setNba_attr(attributes[115]);
					isdn_LoopPort_IUS_Channel_12States.setNba(attributes[116]);
					isdn_LoopPort_IUS_Channel_12States.setNbank1_attr(attributes[117]);
					isdn_LoopPort_IUS_Channel_12States.setNbank1(attributes[118]);
					isdn_LoopPort_IUS_Channel_12States.setNbank2_attr(attributes[119]);
					isdn_LoopPort_IUS_Channel_12States.setNbank2(attributes[120]);
					isdn_LoopPort_IUS_Channel_12States.setNbank3_attr(attributes[121]);
					isdn_LoopPort_IUS_Channel_12States.setNbank3(attributes[122]);
					isdn_LoopPort_IUS_Channel_12States.setNbank4_attr(attributes[123]);
					isdn_LoopPort_IUS_Channel_12States.setNbank4(attributes[124]);
					isdn_LoopPort_IUS_Channel_12States.setDstnact_attr(attributes[125]);
					isdn_LoopPort_IUS_Channel_12States.setDstnact(attributes[126]);
					isdn_LoopPort_IUS_Channel_12States.setDstnq_attr(attributes[127]);
					isdn_LoopPort_IUS_Channel_12States.setDstnq(attributes[128]);
					isdn_LoopPort_IUS_Channel_12States.setDstn1_attr(attributes[129]);
					isdn_LoopPort_IUS_Channel_12States.setDstn1(attributes[130]);
					isdn_LoopPort_IUS_Channel_12States.setDstn2_attr(attributes[131]);
					isdn_LoopPort_IUS_Channel_12States.setDstn2(attributes[132]);
					isdn_LoopPort_IUS_Channel_12States.setDstn3_attr(attributes[133]);
					isdn_LoopPort_IUS_Channel_12States.setDstn3(attributes[134]);
					isdn_LoopPort_IUS_Channel_12States.setDstn4_attr(attributes[135]);
					isdn_LoopPort_IUS_Channel_12States.setDstn4(attributes[136]);
					isdn_LoopPort_IUS_Channel_12States.setDstn5_attr(attributes[137]);
					isdn_LoopPort_IUS_Channel_12States.setDstn5(attributes[138]);
					isdn_LoopPort_IUS_Channel_12States.setTglna_attr(attributes[139]);
					isdn_LoopPort_IUS_Channel_12States.setTglna(attributes[140]);
					isdn_LoopPort_IUS_Channel_12States.setTgn_attr(attributes[141]);
					isdn_LoopPort_IUS_Channel_12States.setTgn(attributes[142]);
					isdn_LoopPort_IUS_Channel_12States.setPtgn_of_attr(attributes[143]);
					isdn_LoopPort_IUS_Channel_12States.setPtgn_of(attributes[144]);
					isdn_LoopPort_IUS_Channel_12States.setTgtli01_attr(attributes[145]);
					isdn_LoopPort_IUS_Channel_12States.setTgtli01(attributes[146]);
					isdn_LoopPort_IUS_Channel_12States.setTgrti_attr(attributes[147]);
					isdn_LoopPort_IUS_Channel_12States.setTgrti(attributes[148]);
					isdn_LoopPort_IUS_Channel_12States.setTgdir_attr(attributes[149]);
					isdn_LoopPort_IUS_Channel_12States.setTgdir(attributes[150]);
					isdn_LoopPort_IUS_Channel_12States.setPtgnh_attr(attributes[151]);
					isdn_LoopPort_IUS_Channel_12States.setPtgnh(attributes[152]);
					isdn_LoopPort_IUS_Channel_12States.setDgout_attr(attributes[153]);
					isdn_LoopPort_IUS_Channel_12States.setDgout(attributes[154]);
					isdn_LoopPort_IUS_Channel_12States.setDg_rcvd_attr(attributes[155]);
					isdn_LoopPort_IUS_Channel_12States.setDg_rcvd(attributes[156]);
					isdn_LoopPort_IUS_Channel_12States.setPdod_attr(attributes[157]);
					isdn_LoopPort_IUS_Channel_12States.setPdod(attributes[158]);
					isdn_LoopPort_IUS_Channel_12States.setPic_attr(attributes[159]);
					isdn_LoopPort_IUS_Channel_12States.setPic(attributes[160]);
					isdn_LoopPort_IUS_Channel_12States.setLpic_attr(attributes[161]);
					isdn_LoopPort_IUS_Channel_12States.setLpic(attributes[162]);
					isdn_LoopPort_IUS_Channel_12States.setGlare_attr(attributes[163]);
					isdn_LoopPort_IUS_Channel_12States.setGlare(attributes[164]);
					isdn_LoopPort_IUS_Channel_12States.setPbxid_attr(attributes[165]);
					isdn_LoopPort_IUS_Channel_12States.setPbxid(attributes[166]);
					isdn_LoopPort_IUS_Channel_12States.setCid_attr(attributes[167]);
					isdn_LoopPort_IUS_Channel_12States.setCid(attributes[168]);
					isdn_LoopPort_IUS_Channel_12States.setTot_attr(attributes[169]);
					isdn_LoopPort_IUS_Channel_12States.setTot(attributes[170]);
					isdn_LoopPort_IUS_Channel_12States.setGsind1_attr(attributes[171]);
					isdn_LoopPort_IUS_Channel_12States.setGsind1(attributes[172]);
					isdn_LoopPort_IUS_Channel_12States.setGsind2_attr(attributes[173]);
					isdn_LoopPort_IUS_Channel_12States.setGsind2(attributes[174]);
					isdn_LoopPort_IUS_Channel_12States.setGsind3_attr(attributes[175]);
					isdn_LoopPort_IUS_Channel_12States.setGsind3(attributes[176]);
					isdn_LoopPort_IUS_Channel_12States.setGsind4_attr(attributes[177]);
					isdn_LoopPort_IUS_Channel_12States.setGsind4(attributes[178]);
					isdn_LoopPort_IUS_Channel_12States.setGsind5_attr(attributes[179]);
					isdn_LoopPort_IUS_Channel_12States.setGsind5(attributes[180]);
					isdn_LoopPort_IUS_Channel_12States.setGsqty1_attr(attributes[181]);
					isdn_LoopPort_IUS_Channel_12States.setGsqty1(attributes[182]);
					isdn_LoopPort_IUS_Channel_12States.setGsqty2_attr(attributes[183]);
					isdn_LoopPort_IUS_Channel_12States.setGsqty2(attributes[184]);
					isdn_LoopPort_IUS_Channel_12States.setGsqty3_attr(attributes[185]);
					isdn_LoopPort_IUS_Channel_12States.setGsqty3(attributes[186]);
					isdn_LoopPort_IUS_Channel_12States.setGsqty4_attr(attributes[187]);
					isdn_LoopPort_IUS_Channel_12States.setGsqty4(attributes[188]);
					isdn_LoopPort_IUS_Channel_12States.setGsqty5_attr(attributes[189]);
					isdn_LoopPort_IUS_Channel_12States.setGsqty5(attributes[190]);
					isdn_LoopPort_IUS_Channel_12States.setGind1_attr(attributes[191]);
					isdn_LoopPort_IUS_Channel_12States.setGind1(attributes[192]);
					isdn_LoopPort_IUS_Channel_12States.setGind2_attr(attributes[193]);
					isdn_LoopPort_IUS_Channel_12States.setGind2(attributes[194]);
					isdn_LoopPort_IUS_Channel_12States.setGind3_attr(attributes[195]);
					isdn_LoopPort_IUS_Channel_12States.setGind3(attributes[196]);
					isdn_LoopPort_IUS_Channel_12States.setGind4_attr(attributes[197]);
					isdn_LoopPort_IUS_Channel_12States.setGind4(attributes[198]);
					isdn_LoopPort_IUS_Channel_12States.setGqty1_attr(attributes[199]);
					isdn_LoopPort_IUS_Channel_12States.setGqty1(attributes[200]);
					isdn_LoopPort_IUS_Channel_12States.setGqty2_attr(attributes[201]);
					isdn_LoopPort_IUS_Channel_12States.setGqty2(attributes[202]);
					isdn_LoopPort_IUS_Channel_12States.setGqty3_attr(attributes[203]);
					isdn_LoopPort_IUS_Channel_12States.setGqty3(attributes[204]);
					isdn_LoopPort_IUS_Channel_12States.setGqty4_attr(attributes[205]);
					isdn_LoopPort_IUS_Channel_12States.setGqty4(attributes[206]);
					isdn_LoopPort_IUS_Channel_12States.setSec_loc_attr(attributes[207]);
					isdn_LoopPort_IUS_Channel_12States.setSec_loc(attributes[208]);
					isdn_LoopPort_IUS_Channel_12States.setCb_sec_attr(attributes[209]);
					isdn_LoopPort_IUS_Channel_12States.setCb_sec(attributes[210]);
					isdn_LoopPort_IUS_Channel_12States.setCbbtn_sec_attr(attributes[211]);
					isdn_LoopPort_IUS_Channel_12States.setCbbtn_sec(attributes[212]);
					isdn_LoopPort_IUS_Channel_12States.setActl_attr(attributes[213]);
					isdn_LoopPort_IUS_Channel_12States.setActl(attributes[214]);
					isdn_LoopPort_IUS_Channel_12States.setCfa_ckt_attr(attributes[215]);
					isdn_LoopPort_IUS_Channel_12States.setCfa_ckt(attributes[216]);

					treeViewList_842.add(isdn_LoopPort_IUS_Channel_12States);
				}
				session.setAttribute("treeViewList_842", treeViewList_842);
				selectRequestData.setSubHeader(receivedSubHeader);
			}

			// Divya
			if (subData_886Recid != null && subData_886Recid.getSubHeader().getRecord_type().equals("886")) {
				SubHeader receivedSubHeader = subData_886Recid.getSubHeader();
				String[] subDataRows = subData_886Recid.getSubDataRows();
				treeViewList.add("886");

				List<ConfirmationNonProdLSOG6Row> treeview_886 = new ArrayList();
				for (String subDataRow : subDataRows) {
					String[] attributes = mqReadUtil.getAttributes(subDataRow, 14);
					// System.out.println("attributes:=886======> " + Arrays.toString(attributes));
					ConfirmationNonProdLSOG6Row confirmationNonProdLSOG6Row = new ConfirmationNonProdLSOG6Row();

					confirmationNonProdLSOG6Row.setCver(attributes[0]);
					confirmationNonProdLSOG6Row.setSvc_rep_tn(attributes[1]);
					confirmationNonProdLSOG6Row.setSvc_rep(attributes[2]);
					confirmationNonProdLSOG6Row.setAtn_attr(attributes[3]);
					confirmationNonProdLSOG6Row.setAtn(attributes[4]);
					confirmationNonProdLSOG6Row.setRt(attributes[5]);
					confirmationNonProdLSOG6Row.setEcver(attributes[6]);
					confirmationNonProdLSOG6Row.setD_t_sent_local(attributes[7]);
					confirmationNonProdLSOG6Row.setResponse_d_t_sent_central_time(attributes[8]);
					confirmationNonProdLSOG6Row.setDd_attr(attributes[9]);
					confirmationNonProdLSOG6Row.setDd(attributes[10]);
					confirmationNonProdLSOG6Row.setPia(attributes[11]);
					confirmationNonProdLSOG6Row.setAn_attr(attributes[12]);
					confirmationNonProdLSOG6Row.setAn(attributes[13]);
					;

					treeview_886.add(confirmationNonProdLSOG6Row);

				}
				session.setAttribute("treeview_886", treeview_886);
				selectRequestData.setSubHeader(receivedSubHeader);

			}

			if (subData_884Recid != null && subData_884Recid.getSubHeader().getRecord_type().equals("884")) {
				SubHeader receivedSubHeader = subData_884Recid.getSubHeader();
				String[] subDataRows = subData_884Recid.getSubDataRows();
				List<ConfirmationReqtypJLSOG6102Row> treeview_884 = new ArrayList();
				treeViewList.add("884");
				for (String subDataRow : subDataRows) {
					String[] attributes = mqReadUtil.getAttributes(subDataRow, 10);
					// System.out.println("attributes:=884======> " + Arrays.toString(attributes));
					ConfirmationReqtypJLSOG6102Row confirmationReqtypJLSOG6102Row = new ConfirmationReqtypJLSOG6102Row();

					confirmationReqtypJLSOG6102Row.setCver(attributes[0]);
					confirmationReqtypJLSOG6102Row.setDor(attributes[1]);
					confirmationReqtypJLSOG6102Row.setAtn(attributes[2]);
					confirmationReqtypJLSOG6102Row.setDinit(attributes[3]);
					confirmationReqtypJLSOG6102Row.setDda(attributes[4]);
					confirmationReqtypJLSOG6102Row.setRt(attributes[5]);
					confirmationReqtypJLSOG6102Row.setEcver(attributes[6]);
					confirmationReqtypJLSOG6102Row.setD_t_sent_local(attributes[7]);
					confirmationReqtypJLSOG6102Row.setResponse_d_t_sent_central_time(attributes[8]);
					confirmationReqtypJLSOG6102Row.setAn(attributes[9]);

					treeview_884.add(confirmationReqtypJLSOG6102Row);

				}
				session.setAttribute("treeview_884", treeview_884);
				selectRequestData.setSubHeader(receivedSubHeader);

			}

			if (subData_883Recid != null && subData_883Recid.getSubHeader().getRecord_type().equals("883")) {

				SubHeader receivedSubHeader = subData_883Recid.getSubHeader();
				String[] subDataRows = subData_883Recid.getSubDataRows();

				List<ConfirmationReqtypRLSOG6102Row> treeview_883 = new ArrayList();
				treeViewList.add("883");
				for (String subDataRow : subDataRows) {
					String[] attributes = mqReadUtil.getAttributes(subDataRow, 7);
					// System.out.println("attributes:=883======> " + Arrays.toString(attributes));
					ConfirmationReqtypRLSOG6102Row confirmationReqtypRLSOG6102Row = new ConfirmationReqtypRLSOG6102Row();

					confirmationReqtypRLSOG6102Row.setCver(attributes[0]);
					confirmationReqtypRLSOG6102Row.setAtn(attributes[1]);
					confirmationReqtypRLSOG6102Row.setRt(attributes[2]);
					confirmationReqtypRLSOG6102Row.setEcver(attributes[3]);
					confirmationReqtypRLSOG6102Row.setD_t_sent_local(attributes[4]);
					confirmationReqtypRLSOG6102Row.setResponse_d_t_sent_central_time(attributes[5]);
					confirmationReqtypRLSOG6102Row.setAn(attributes[6]);

					treeview_883.add(confirmationReqtypRLSOG6102Row);
				}
				session.setAttribute("treeview_883", treeview_883);
				selectRequestData.setSubHeader(receivedSubHeader);
			}

			if (subData_887Recid != null && subData_887Recid.getSubHeader().getRecord_type().equals("887")) {

				SubHeader receivedSubHeader = subData_887Recid.getSubHeader();
				String[] subDataRows = subData_887Recid.getSubDataRows();

				List<ConfirmationLS0G6DW2Row> treeview_887 = new ArrayList();
				treeViewList.add("887");
				for (String subDataRow : subDataRows) {
					String[] attributes = mqReadUtil.getAttributes(subDataRow, 14);
					// System.out.println("attributes:=887======> " + Arrays.toString(attributes));
					ConfirmationLS0G6DW2Row confirmationLS0G6DW2Row = new ConfirmationLS0G6DW2Row();
					confirmationLS0G6DW2Row.setOrd(attributes[0]);
					confirmationLS0G6DW2Row.setOld_dtm(attributes[1]);
					confirmationLS0G6DW2Row.setOld_ord(attributes[2]);
					confirmationLS0G6DW2Row.setOrd_attr(attributes[3]);

					confirmationLS0G6DW2Row.setFdt_attr(attributes[4]);
					confirmationLS0G6DW2Row.setFdt(attributes[5]);
					confirmationLS0G6DW2Row.setDd_attr(attributes[6]);
					confirmationLS0G6DW2Row.setDd_attr(attributes[7]);
					confirmationLS0G6DW2Row.setComp_dt_attr(attributes[8]);
					confirmationLS0G6DW2Row.setComp_dt(attributes[9]);
					confirmationLS0G6DW2Row.setPosted_date_attr(attributes[0]);
					confirmationLS0G6DW2Row.setPosted_date(attributes[11]);
					confirmationLS0G6DW2Row.setApptime_attr(attributes[12]);
					confirmationLS0G6DW2Row.setApptime(attributes[13]);

					treeview_887.add(confirmationLS0G6DW2Row);
				}
				session.setAttribute("treeview_887", treeview_887);
				selectRequestData.setSubHeader(receivedSubHeader);
			}

			if (subData_880Recid != null && subData_880Recid.getSubHeader().getRecord_type().equals("880")) {
				SubHeader receivedSubHeader = subData_880Recid.getSubHeader();
				String[] subDataRows = subData_880Recid.getSubDataRows();
				List<ConfirmationLS0G6DW1Row> treeview_880 = new ArrayList();
				treeViewList.add("880");
				for (String subDataRow : subDataRows) {
					String[] attributes = mqReadUtil.getAttributes(subDataRow, 20);
					// System.out.println("attributes:=880======> " + Arrays.toString(attributes));
					ConfirmationLS0G6DW1Row confirmationLS0G6DW1Row = new ConfirmationLS0G6DW1Row();

					confirmationLS0G6DW1Row.setA_cver(attributes[0]);
					confirmationLS0G6DW1Row.setA_atn_attr(attributes[1]);
					confirmationLS0G6DW1Row.setA_atn(attributes[2]);
					confirmationLS0G6DW1Row.setA_init(attributes[3]);
					confirmationLS0G6DW1Row.setA_rep(attributes[4]);
					confirmationLS0G6DW1Row.setA_tel_no(attributes[5]);
					confirmationLS0G6DW1Row.setA_rt(attributes[6]);
					confirmationLS0G6DW1Row.setA_ecver(attributes[7]);
					confirmationLS0G6DW1Row.setA_d_t_sent_local(FormatUtil.getMqDateTimeToViewString(attributes[8] != null && attributes[8] != "" ? attributes[8] : " "));// supriya changes for date format
					confirmationLS0G6DW1Row.setA_response_d_t_sent_cent_time(FormatUtil.getMqDateTimeToViewString(attributes[9] != null && attributes[9] != "" ? attributes[9] : " "));// supriya changes for date format
					confirmationLS0G6DW1Row.setA_pia(attributes[10]);
					confirmationLS0G6DW1Row.setA_chc(attributes[11]);
					confirmationLS0G6DW1Row.setA_fdt_attr(attributes[12]);
					confirmationLS0G6DW1Row.setA_fdt(attributes[13]);
					confirmationLS0G6DW1Row.setA_dd_att(attributes[14]);
					confirmationLS0G6DW1Row.setA_dd(attributes[15]);
					confirmationLS0G6DW1Row.setApp_time_attr(attributes[16]);
					confirmationLS0G6DW1Row.setApptime(attributes[17]);
					confirmationLS0G6DW1Row.setA_an_attr(attributes[18]);
					confirmationLS0G6DW1Row.setA_an(attributes[19]);

					treeview_880.add(confirmationLS0G6DW1Row);

				}
				session.setAttribute("treeview_880", treeview_880);
				selectRequestData.setSubHeader(receivedSubHeader);

			}

			if (subData_882Recid != null && subData_882Recid.getSubHeader().getRecord_type().equals("882")) {
				SubHeader receivedSubHeader = subData_882Recid.getSubHeader();
				String[] subDataRows = subData_882Recid.getSubDataRows();
				treeViewList.add("882");
				List<Confirmation101and102RequestTypeBRow> treeview_882 = new ArrayList();
				for (String subDataRow : subDataRows) {
					String[] attributes = mqReadUtil.getAttributes(subDataRow, 42);
					// System.out.println("attributes:=882======> " + Arrays.toString(attributes));
					Confirmation101and102RequestTypeBRow confirmation101and102RequestTypeBData = new Confirmation101and102RequestTypeBRow();

					confirmation101and102RequestTypeBData.setItemnum(attributes[0]);
					confirmation101and102RequestTypeBData.setLnum(attributes[1]);
					confirmation101and102RequestTypeBData.setNumname(attributes[2]);
					confirmation101and102RequestTypeBData.setNum_nbr(attributes[3]);
					confirmation101and102RequestTypeBData.setOrd_attr(attributes[4]);
					confirmation101and102RequestTypeBData.setOrd(attributes[5]);
					confirmation101and102RequestTypeBData.setLord_attr(attributes[6]);
					confirmation101and102RequestTypeBData.setLord(attributes[7]);
					confirmation101and102RequestTypeBData.setFdt_attr(attributes[8]);
					confirmation101and102RequestTypeBData.setFdt(attributes[9]);
					confirmation101and102RequestTypeBData.setDd_attr(attributes[10]);
					confirmation101and102RequestTypeBData.setDd(attributes[11]);
					confirmation101and102RequestTypeBData.setEcckt_attr(attributes[12]);
					confirmation101and102RequestTypeBData.setEcckt(attributes[13]);
					confirmation101and102RequestTypeBData.setCkr(attributes[14]);
					confirmation101and102RequestTypeBData.setShared_nbr(attributes[15]);
					confirmation101and102RequestTypeBData.setDisc_nbr(attributes[16]);
					confirmation101and102RequestTypeBData.setRecckt(attributes[17]);
					confirmation101and102RequestTypeBData.setTns_attr(attributes[18]);
					confirmation101and102RequestTypeBData.setTns(attributes[19]);
					confirmation101and102RequestTypeBData.setTers_attr(attributes[20]);
					confirmation101and102RequestTypeBData.setTers(attributes[21]);
					confirmation101and102RequestTypeBData.setCfa(attributes[22]);
					confirmation101and102RequestTypeBData.setCcea(attributes[23]);
					confirmation101and102RequestTypeBData.setIspid_attr(attributes[24]);
					confirmation101and102RequestTypeBData.setIspid(attributes[25]);
					confirmation101and102RequestTypeBData.setFecckt_attr(attributes[26]);
					confirmation101and102RequestTypeBData.setFecckt(attributes[27]);
					confirmation101and102RequestTypeBData.setNpord_attr(attributes[28]);
					confirmation101and102RequestTypeBData.setNpord(attributes[29]);
					confirmation101and102RequestTypeBData.setPorted_nbr(FormatUtil.getTelephoneNumberWithDashes(attributes[30] != null && attributes[30] != "" ? attributes[30] : " "));// supriya changes for date format[30]);
					confirmation101and102RequestTypeBData.setRti_attr(attributes[31]);
					confirmation101and102RequestTypeBData.setRti(attributes[32]);
					confirmation101and102RequestTypeBData.setCbcid_attr(attributes[33]);
					confirmation101and102RequestTypeBData.setCbcid(attributes[34]);
					confirmation101and102RequestTypeBData.setCableid_attr(attributes[35]);
					confirmation101and102RequestTypeBData.setCableid(attributes[36]);
					confirmation101and102RequestTypeBData.setChan_pair_attr(attributes[37]);
					confirmation101and102RequestTypeBData.setChain_pair(attributes[38]);
					confirmation101and102RequestTypeBData.setOld_ord(attributes[39]);
					confirmation101and102RequestTypeBData.setOld_lord(attributes[40]);
					confirmation101and102RequestTypeBData.setOld_npord(attributes[41]);

					treeview_882.add(confirmation101and102RequestTypeBData);
					// //System.out.println(confirmation101and102RequestTypeBData.getEcckt());
				}
				session.setAttribute("treeview_882", treeview_882);
				// //System.out.println(treeview_882);
				selectRequestData.setSubHeader(receivedSubHeader);

			}

			if (subData_888Recid != null && subData_888Recid.getSubHeader().getRecord_type().equals("888")) {
				SubHeader receivedSubHeader = subData_888Recid.getSubHeader();
				String[] subDataRows = subData_888Recid.getSubDataRows();
				List<ConfirmationLS0G6DW2Row> treeview_888 = new ArrayList();
				treeViewList.add("888");
				for (String subDataRow : subDataRows) {
					String[] attributes = mqReadUtil.getAttributes(subDataRow, 14);
					// System.out.println("attributes:=888======> " + Arrays.toString(attributes));
					ConfirmationLS0G6DW2Row confirmationLS0G6DW2Row = new ConfirmationLS0G6DW2Row();

					confirmationLS0G6DW2Row.setOld_dtm(attributes[0]);
					confirmationLS0G6DW2Row.setOld_ord(attributes[1]);
					confirmationLS0G6DW2Row.setOrd_attr(attributes[2]);
					confirmationLS0G6DW2Row.setOrd(attributes[3]);
					confirmationLS0G6DW2Row.setFdt_attr(attributes[4]);
					confirmationLS0G6DW2Row.setFdt(attributes[5]);
					confirmationLS0G6DW2Row.setDd_attr(attributes[6]);
					confirmationLS0G6DW2Row.setDd(attributes[7]);
					confirmationLS0G6DW2Row.setComp_dt_attr(attributes[8]);
					confirmationLS0G6DW2Row.setComp_dt(attributes[9]);
					confirmationLS0G6DW2Row.setPosted_date_attr(attributes[10]);
					confirmationLS0G6DW2Row.setPosted_date(attributes[11]);
					confirmationLS0G6DW2Row.setApptime_attr(attributes[12]);
					confirmationLS0G6DW2Row.setApptime(attributes[13]);

					treeview_888.add(confirmationLS0G6DW2Row);

				}
				session.setAttribute("treeview_888", treeview_888);
				selectRequestData.setSubHeader(receivedSubHeader);
			}
//divya 
			if (subData_881Recid != null && subData_881Recid.getSubHeader().getRecord_type().equals("881")) {
				SubHeader receivedSubHeader = subData_881Recid.getSubHeader();
				String[] subDataRows = subData_881Recid.getSubDataRows();
				List<ConfirmationLS0G6DW3Row> treeView881 = new ArrayList();
				treeViewList.add("881");
				for (String subDataRow : subDataRows) {
					String[] attributes = mqReadUtil.getAttributes(subDataRow, 6);
					// System.out.println("attributes:=881======> " + Arrays.toString(attributes));
					ConfirmationLS0G6DW3Row confirmationLS0G6DW3Row = new ConfirmationLS0G6DW3Row();
					confirmationLS0G6DW3Row.setItem_num(attributes[0]);
					confirmationLS0G6DW3Row.setHnum(attributes[1]);
					confirmationLS0G6DW3Row.setHid_attr(attributes[2]);
					confirmationLS0G6DW3Row.setHid(attributes[3]);
					confirmationLS0G6DW3Row.setHunt_tli_attr(attributes[4]);

					confirmationLS0G6DW3Row.setHunt_tli(attributes[5]);

					treeView881.add(confirmationLS0G6DW3Row);

				}
				session.setAttribute("treeView881", treeView881);

				selectRequestData.setSubHeader(receivedSubHeader);
			}

			// Rashmita and Supriya

			if (subData_801Recid != null && subData_801Recid.getSubHeader().getRecord_type().equals("801")) {

				SubHeader receivedSubHeader = subData_801Recid.getSubHeader();
				String[] subDataRows = subData_801Recid.getSubDataRows();
				List<DigitalTrunkingPortData12> treeViewList_801 = new ArrayList();
				treeViewList.add("801");

				// int i = 0;
				for (String subDataRow : subDataRows) {
					String[] attributes = mqReadUtil.getAttributes(subDataRow, 181);
					// System.out.println("attributes:=801:Reqid======> " +
					// Arrays.toString(attributes));
					DigitalTrunkingPortData12 digitalTrunkingPortData12 = new DigitalTrunkingPortData12();

					digitalTrunkingPortData12.setItem_num(attributes[0]);
					digitalTrunkingPortData12.setFnum_attr(attributes[1]);
					digitalTrunkingPortData12.setFnum(attributes[2]);
					digitalTrunkingPortData12.setFlna_attr(attributes[3]);
					digitalTrunkingPortData12.setFlna(attributes[4]);
					digitalTrunkingPortData12.setFecckt_attr(attributes[5]);
					digitalTrunkingPortData12.setFecckt(attributes[6]);
					digitalTrunkingPortData12.setCkr_attr(attributes[7]);
					digitalTrunkingPortData12.setCkr(attributes[8]);
					digitalTrunkingPortData12.setPri_loc_attr(attributes[9]);
					digitalTrunkingPortData12.setPri_loc(attributes[10]);
					digitalTrunkingPortData12.setEulst_attr(attributes[11]);
					digitalTrunkingPortData12.setEulst(attributes[12]);
					digitalTrunkingPortData12.setActl_attr(attributes[13]);
					digitalTrunkingPortData12.setActl(attributes[14]);
					digitalTrunkingPortData12.setCcea_attr(attributes[15]);
					digitalTrunkingPortData12.setCcea(attributes[16]);
					digitalTrunkingPortData12.setCfa_attr(attributes[17]);
					digitalTrunkingPortData12.setCfa(attributes[18]);
					digitalTrunkingPortData12.setCfa_btn(FormatUtil.getTelephoneNumberWithDashes(attributes[20] != null && attributes[20] != "" ? attributes[20] : " "));// supriya changes for date format
					digitalTrunkingPortData12.setCfa_btn(FormatUtil.getTelephoneNumberWithDashes(attributes[20]));
					digitalTrunkingPortData12.setNcon_attr(attributes[21]);
					digitalTrunkingPortData12.setNcon(attributes[22]);
					digitalTrunkingPortData12.setAft_attr(attributes[23]);
					digitalTrunkingPortData12.setAft(attributes[24]);
					digitalTrunkingPortData12.setSapr_attr(attributes[25]);
					digitalTrunkingPortData12.setSapr(attributes[26]);
					digitalTrunkingPortData12.setSano_attr(attributes[27]);
					digitalTrunkingPortData12.setSano(attributes[28]);
					digitalTrunkingPortData12.setSasf_attr(attributes[29]);
					digitalTrunkingPortData12.setSasf(attributes[30]);
					digitalTrunkingPortData12.setSasd_attr(attributes[31]);
					digitalTrunkingPortData12.setSasd(attributes[32]);
					digitalTrunkingPortData12.setSasn_attr(attributes[33]);
					digitalTrunkingPortData12.setSasn(attributes[34]);
					digitalTrunkingPortData12.setSath_attr(attributes[35]);
					digitalTrunkingPortData12.setSath(attributes[36]);
					digitalTrunkingPortData12.setSass_attr(attributes[37]);
					digitalTrunkingPortData12.setSass(attributes[38]);
					digitalTrunkingPortData12.setLd1_attr(attributes[39]);
					digitalTrunkingPortData12.setLd1(attributes[40]);
					digitalTrunkingPortData12.setLv1_attr(attributes[41]);
					digitalTrunkingPortData12.setLv1(attributes[42]);
					digitalTrunkingPortData12.setLd2_attr(attributes[43]);
					digitalTrunkingPortData12.setLd2(attributes[44]);
					digitalTrunkingPortData12.setLv2_attr(attributes[45]);
					digitalTrunkingPortData12.setLv2(attributes[46]);
					digitalTrunkingPortData12.setLd3_attr(attributes[47]);
					digitalTrunkingPortData12.setLd3(attributes[48]);
					digitalTrunkingPortData12.setLv3_attr(attributes[49]);
					digitalTrunkingPortData12.setLv3(attributes[50]);
					digitalTrunkingPortData12.setAai_attr(attributes[51]);
					digitalTrunkingPortData12.setAai(attributes[52]);
					digitalTrunkingPortData12.setCity_attr(attributes[53]);
					digitalTrunkingPortData12.setCity(attributes[54]);
					digitalTrunkingPortData12.setState_attr(attributes[55]);
					digitalTrunkingPortData12.setState(attributes[56]);
					digitalTrunkingPortData12.setZip_attr(attributes[57]);
					digitalTrunkingPortData12.setZip(attributes[58]);
					digitalTrunkingPortData12.setAloc_attr(attributes[59]);
					digitalTrunkingPortData12.setAloc(attributes[60]);
					digitalTrunkingPortData12.setNidr_attr(attributes[61]);
					digitalTrunkingPortData12.setNidr(attributes[62]);
					digitalTrunkingPortData12.setIwo_attr(attributes[63]);
					digitalTrunkingPortData12.setIwo(attributes[64]);
					digitalTrunkingPortData12.setLcon_attr(attributes[65]);
					digitalTrunkingPortData12.setLcon(attributes[66]);
					digitalTrunkingPortData12.setTelno_attr(attributes[67]);
					digitalTrunkingPortData12.setTelno(FormatUtil.getTelephoneNumberWithDashes(attributes[68] != null && attributes[68] != "" ? attributes[68] : " "));// supriya changes for date format
					digitalTrunkingPortData12.setSecloc_attr(attributes[69]);
					digitalTrunkingPortData12.setSecloc(attributes[70]);
					digitalTrunkingPortData12.setTglnum_attr(attributes[71]);
					digitalTrunkingPortData12.setTglnum(attributes[72]);
					digitalTrunkingPortData12.setTglna_attr(attributes[73]);
					digitalTrunkingPortData12.setTglna(attributes[74]);
					digitalTrunkingPortData12.setTgn1_attr(attributes[75]);
					digitalTrunkingPortData12.setTgn1(attributes[76]);
					digitalTrunkingPortData12.setTgn2_attr(attributes[77]);
					digitalTrunkingPortData12.setTgn2(attributes[78]);
					digitalTrunkingPortData12.setTgn3_attr(attributes[79]);
					digitalTrunkingPortData12.setTgn3(attributes[80]);
					digitalTrunkingPortData12.setTgtn_attr(attributes[81]);
					digitalTrunkingPortData12.setTgtn(FormatUtil.getTelephoneNumberWithDashes(attributes[82] != null && attributes[82] != "" ? attributes[82] : " "));// supriya changes for date format
					digitalTrunkingPortData12.setTgtli_attr(attributes[83]);
					digitalTrunkingPortData12.setTgtli(FormatUtil.getTelephoneNumberWithDashes(attributes[84] != null && attributes[84] != "" ? attributes[84] : " "));// supriya changes for date format					digitalTrunkingPortData12.setTgrti_attr(attributes[85]);
					digitalTrunkingPortData12.setTgrti(attributes[86]);
					digitalTrunkingPortData12.setTgdir_attr(attributes[87]);
					digitalTrunkingPortData12.setTgdir(attributes[88]);
					digitalTrunkingPortData12.setTgnh_attr(attributes[89]);
					digitalTrunkingPortData12.setTgnh(attributes[90]);
					digitalTrunkingPortData12.setDgout_attr(attributes[91]);
					digitalTrunkingPortData12.setDgout(attributes[92]);
					digitalTrunkingPortData12.setPic_attr(attributes[93]);
					digitalTrunkingPortData12.setPic(attributes[94]);
					digitalTrunkingPortData12.setLpic_attr(attributes[95]);
					digitalTrunkingPortData12.setLpic(attributes[96]);
					digitalTrunkingPortData12.setGlare_attr(attributes[97]);
					digitalTrunkingPortData12.setGlare(attributes[98]);
					digitalTrunkingPortData12.setTgpulse_attr(attributes[99]);
					digitalTrunkingPortData12.setTgpulse(attributes[100]);
					digitalTrunkingPortData12.setTgsgnl_attr(attributes[101]);
					digitalTrunkingPortData12.setTgsgnl(attributes[102]);
					digitalTrunkingPortData12.setDidnum_attr(attributes[103]);
					digitalTrunkingPortData12.setDidnum(attributes[104]);
					digitalTrunkingPortData12.setDidind_attr(attributes[105]);
					digitalTrunkingPortData12.setDidind(attributes[106]);
					digitalTrunkingPortData12.setDtnract_attr(attributes[107]);
					digitalTrunkingPortData12.setDtnract(attributes[108]);
					digitalTrunkingPortData12.setDtnrq_attr(attributes[109]);
					digitalTrunkingPortData12.setDtnrq(attributes[110]);
					digitalTrunkingPortData12.setDtnr1_attr(attributes[111]);
					digitalTrunkingPortData12.setDtnr1(attributes[112]);
					digitalTrunkingPortData12.setDtnr2_attr(attributes[113]);
					digitalTrunkingPortData12.setDtnr2(attributes[114]);
					digitalTrunkingPortData12.setDtnr3_attr(attributes[115]);
					digitalTrunkingPortData12.setDtnr3(attributes[116]);
					digitalTrunkingPortData12.setNpi_attr(attributes[117]);
					digitalTrunkingPortData12.setNpi(attributes[118]);
					digitalTrunkingPortData12.setDidr_attr(attributes[119]);
					digitalTrunkingPortData12.setDidr(attributes[120]);
					digitalTrunkingPortData12.setDba_attr(attributes[121]);
					digitalTrunkingPortData12.setDba(attributes[122]);
					digitalTrunkingPortData12.setDblock_attr(attributes[123]);
					digitalTrunkingPortData12.setDblock(attributes[124]);
					digitalTrunkingPortData12.setNba_attr(attributes[125]);
					digitalTrunkingPortData12.setNba(attributes[126]);
					digitalTrunkingPortData12.setNbank1_attr(attributes[127]);
					digitalTrunkingPortData12.setNbank1(attributes[128]);
					digitalTrunkingPortData12.setNbank2_attr(attributes[129]);
					digitalTrunkingPortData12.setNbank2(attributes[130]);
					digitalTrunkingPortData12.setNbank3_attr(attributes[131]);
					digitalTrunkingPortData12.setNbank3(attributes[132]);
					digitalTrunkingPortData12.setNbank4_attr(attributes[133]);
					digitalTrunkingPortData12.setNbank4(attributes[134]);
					digitalTrunkingPortData12.setDstnact_attr(attributes[135]);
					digitalTrunkingPortData12.setDstnact(attributes[136]);
					digitalTrunkingPortData12.setDstnq_attr(attributes[137]);
					digitalTrunkingPortData12.setDstnq(attributes[138]);
					digitalTrunkingPortData12.setDstn1_attr(attributes[139]);
					digitalTrunkingPortData12.setDstn1(attributes[140]);
					digitalTrunkingPortData12.setDstn2_attr(attributes[141]);
					digitalTrunkingPortData12.setDstn2(attributes[142]);
					digitalTrunkingPortData12.setDstn3_attr(attributes[143]);
					digitalTrunkingPortData12.setDstn3(attributes[144]);
					digitalTrunkingPortData12.setDstn4_attr(attributes[145]);
					digitalTrunkingPortData12.setDstn4(attributes[146]);
					digitalTrunkingPortData12.setDstn5_attr(attributes[147]);
					digitalTrunkingPortData12.setDstn5(attributes[148]);
					digitalTrunkingPortData12.setLnum_attr(attributes[149]);
					digitalTrunkingPortData12.setLnum(attributes[150]);
					digitalTrunkingPortData12.setTkind_attr(attributes[151]);
					digitalTrunkingPortData12.setTkind(attributes[152]);
					digitalTrunkingPortData12.setLna_attr(attributes[153]);
					digitalTrunkingPortData12.setLna(attributes[154]);
					digitalTrunkingPortData12.setTns_attr(attributes[155]);
					digitalTrunkingPortData12.setTns(FormatUtil.getTelephoneNumberWithDashes(attributes[156] != null && attributes[156] != "" ? attributes[156] : " "));// supriya changes for date format
					digitalTrunkingPortData12.setTers_attr(attributes[157]);
					digitalTrunkingPortData12.setTers(attributes[158]);
					digitalTrunkingPortData12.setOtn_attr(attributes[159]);
					digitalTrunkingPortData12.setOtn(FormatUtil.getTelephoneNumberWithDashes(attributes[160] != null && attributes[160] != "" ? attributes[160] : " "));// supriya changes for date format
					digitalTrunkingPortData12.setLtgn_attr(attributes[161]);
					digitalTrunkingPortData12.setLtgn(attributes[162]);
					digitalTrunkingPortData12.setEcckt_attr(attributes[163]);
					digitalTrunkingPortData12.setEcckt(attributes[164]);
					digitalTrunkingPortData12.setSsig_attr(attributes[165]);
					digitalTrunkingPortData12.setSsig(attributes[166]);
					digitalTrunkingPortData12.setBa_attr(attributes[167]);
					digitalTrunkingPortData12.setBa(attributes[168]);
					digitalTrunkingPortData12.setBlock_attr(attributes[169]);
					digitalTrunkingPortData12.setBlock(attributes[170]);
					digitalTrunkingPortData12.setCfa_trnk_attr(attributes[171]);
					digitalTrunkingPortData12.setCfa_trnk(attributes[172]);
					digitalTrunkingPortData12.setPic_trnk_attr(attributes[173]);
					digitalTrunkingPortData12.setPic_trnk(attributes[174]);
					digitalTrunkingPortData12.setLpic_trnk_attr(attributes[175]);
					digitalTrunkingPortData12.setLpic_trnk(attributes[176]);
					digitalTrunkingPortData12.setNpi_trnk_attr(attributes[177]);
					digitalTrunkingPortData12.setNpi_trnk(attributes[178]);
					digitalTrunkingPortData12.setTgtli_trnk_attr(attributes[179]);
					digitalTrunkingPortData12.setTgtli_trnk(FormatUtil.getTelephoneNumberWithDashes(attributes[180]));

					treeViewList_801.add(digitalTrunkingPortData12);
				}
				session.setAttribute("treeViewList_801", treeViewList_801);
				selectRequestData.setSubHeader(receivedSubHeader);
			}

			if (subData_800Recid != null && subData_800Recid.getSubHeader().getRecord_type().equals("800")) {

				SubHeader receivedSubHeader = subData_800Recid.getSubHeader();
				String[] subDataRows = subData_800Recid.getSubDataRows();
				List<DigitalTrunkingResaleData12> treeViewList_800 = new ArrayList();
				treeViewList.add("800");

				// int i = 0;
				for (String subDataRow : subDataRows) {
					String[] attributes = mqReadUtil.getAttributes(subDataRow, 181);
					// System.out.println("attributes:=800:Reqid======> " +
					// Arrays.toString(attributes));
					// DigitalTrunkingResaleData12 digitalTrunkingResaleData12= new
					// DigitalTrunkingResaleData12();

					DigitalTrunkingResaleData12 digitalTrunkingResaleData12 = new DigitalTrunkingResaleData12();

					digitalTrunkingResaleData12.setItem_num(attributes[0]);
					digitalTrunkingResaleData12.setFnum_attr(attributes[1]);
					digitalTrunkingResaleData12.setFnum(attributes[2]);
					digitalTrunkingResaleData12.setFlna_attr(attributes[3]);
					digitalTrunkingResaleData12.setFlna(attributes[4]);
					digitalTrunkingResaleData12.setFecckt_attr(attributes[5]);
					digitalTrunkingResaleData12.setFecckt(attributes[6]);
					digitalTrunkingResaleData12.setCkr_attr(attributes[7]);
					digitalTrunkingResaleData12.setCkr(attributes[8]);
					digitalTrunkingResaleData12.setPri_loc_attr(attributes[9]);
					digitalTrunkingResaleData12.setPri_loc(attributes[10]);
					digitalTrunkingResaleData12.setEulst_attr(attributes[11]);
					digitalTrunkingResaleData12.setEulst(attributes[12]);
					digitalTrunkingResaleData12.setActl_attr(attributes[13]);
					digitalTrunkingResaleData12.setActl(attributes[14]);
					digitalTrunkingResaleData12.setCcea_attr(attributes[15]);
					digitalTrunkingResaleData12.setCcea(attributes[16]);
					digitalTrunkingResaleData12.setCfa_attr(attributes[17]);
					digitalTrunkingResaleData12.setCfa(attributes[18]);
					digitalTrunkingResaleData12.setCfa_btn_attr(attributes[19]);
					digitalTrunkingResaleData12.setCfa_btn(FormatUtil.getTelephoneNumberWithDashes(attributes[20] != null && attributes[20] != "" ? attributes[20] : " "));// supriya changes for date format
					digitalTrunkingResaleData12.setNcon_attr(attributes[21]);
					digitalTrunkingResaleData12.setNcon(attributes[22]);
					digitalTrunkingResaleData12.setAft_attr(attributes[23]);
					digitalTrunkingResaleData12.setAft(attributes[24]);
					digitalTrunkingResaleData12.setSapr_attr(attributes[25]);
					digitalTrunkingResaleData12.setSapr(attributes[26]);
					digitalTrunkingResaleData12.setSano_attr(attributes[27]);
					digitalTrunkingResaleData12.setSano(attributes[28]);
					digitalTrunkingResaleData12.setSasf_attr(attributes[29]);
					digitalTrunkingResaleData12.setSasf(attributes[30]);
					digitalTrunkingResaleData12.setSasd_attr(attributes[31]);
					digitalTrunkingResaleData12.setSasd(attributes[32]);
					digitalTrunkingResaleData12.setSasn_attr(attributes[33]);
					digitalTrunkingResaleData12.setSasn(attributes[34]);
					digitalTrunkingResaleData12.setSath_attr(attributes[35]);
					digitalTrunkingResaleData12.setSath(attributes[36]);
					digitalTrunkingResaleData12.setSass_attr(attributes[37]);
					digitalTrunkingResaleData12.setSass(attributes[38]);
					digitalTrunkingResaleData12.setLd1_attr(attributes[39]);
					digitalTrunkingResaleData12.setLd1(attributes[40]);
					digitalTrunkingResaleData12.setLv1_attr(attributes[41]);
					digitalTrunkingResaleData12.setLv1(attributes[42]);
					digitalTrunkingResaleData12.setLd2_attr(attributes[43]);
					digitalTrunkingResaleData12.setLd2(attributes[44]);
					digitalTrunkingResaleData12.setLv2_attr(attributes[45]);
					digitalTrunkingResaleData12.setLv2(attributes[46]);
					digitalTrunkingResaleData12.setLd3_attr(attributes[47]);
					digitalTrunkingResaleData12.setLd3(attributes[48]);
					digitalTrunkingResaleData12.setLv3_attr(attributes[49]);
					digitalTrunkingResaleData12.setLv3(attributes[50]);
					digitalTrunkingResaleData12.setAai_attr(attributes[51]);
					digitalTrunkingResaleData12.setAai(attributes[52]);
					digitalTrunkingResaleData12.setCity_attr(attributes[53]);
					digitalTrunkingResaleData12.setCity(attributes[54]);
					digitalTrunkingResaleData12.setState_attr(attributes[55]);
					digitalTrunkingResaleData12.setState(attributes[56]);
					digitalTrunkingResaleData12.setZip_attr(attributes[57]);
					digitalTrunkingResaleData12.setZip(attributes[58]);
					digitalTrunkingResaleData12.setAloc_attr(attributes[59]);
					digitalTrunkingResaleData12.setAloc(attributes[60]);
					digitalTrunkingResaleData12.setNidr_attr(attributes[61]);
					digitalTrunkingResaleData12.setNidr(attributes[62]);
					digitalTrunkingResaleData12.setIwo_attr(attributes[63]);
					digitalTrunkingResaleData12.setIwo(attributes[64]);
					digitalTrunkingResaleData12.setLcon_attr(attributes[65]);
					digitalTrunkingResaleData12.setLcon(attributes[66]);
					digitalTrunkingResaleData12.setTelno_attr(attributes[67]);
					digitalTrunkingResaleData12.setTelno(FormatUtil.getTelephoneNumberWithDashes(attributes[68] != null && attributes[68] != "" ? attributes[68] : " "));// supriya changes for date format
					digitalTrunkingResaleData12.setSecloc_attr(attributes[69]);
					digitalTrunkingResaleData12.setSecloc(attributes[70]);
					digitalTrunkingResaleData12.setTglnum_attr(attributes[71]);
					digitalTrunkingResaleData12.setTglnum(attributes[72]);
					digitalTrunkingResaleData12.setTglna_attr(attributes[73]);
					digitalTrunkingResaleData12.setTglna(attributes[74]);
					digitalTrunkingResaleData12.setTgn1_attr(attributes[75]);
					digitalTrunkingResaleData12.setTgn1(attributes[76]);
					digitalTrunkingResaleData12.setTgn2_attr(attributes[77]);
					digitalTrunkingResaleData12.setTgn2(attributes[78]);
					digitalTrunkingResaleData12.setTgn3_attr(attributes[79]);
					digitalTrunkingResaleData12.setTgn3(attributes[80]);
					digitalTrunkingResaleData12.setTgtn_attr(attributes[81]);
					digitalTrunkingResaleData12.setTgtn(FormatUtil.getTelephoneNumberWithDashes(attributes[82] != null && attributes[82] != "" ? attributes[82] : " "));// supriya changes for date format		
					digitalTrunkingResaleData12.setTgtli_attr(attributes[83]);
					digitalTrunkingResaleData12.setTgtli(FormatUtil.getTelephoneNumberWithDashes(attributes[84] != null && attributes[84] != "" ? attributes[84] : " "));// supriya changes for date format		
					digitalTrunkingResaleData12.setTgrti_attr(attributes[85]);
					digitalTrunkingResaleData12.setTgrti(attributes[86]);
					digitalTrunkingResaleData12.setTgdir_attr(attributes[87]);
					digitalTrunkingResaleData12.setTgdir(attributes[88]);
					digitalTrunkingResaleData12.setTgnh_attr(attributes[89]);
					digitalTrunkingResaleData12.setTgnh(attributes[90]);
					digitalTrunkingResaleData12.setDgout_attr(attributes[91]);
					digitalTrunkingResaleData12.setDgout(attributes[92]);
					digitalTrunkingResaleData12.setPic_attr(attributes[93]);
					digitalTrunkingResaleData12.setPic(attributes[94]);
					digitalTrunkingResaleData12.setLpic_attr(attributes[95]);
					digitalTrunkingResaleData12.setLpic(attributes[96]);
					digitalTrunkingResaleData12.setGlare_attr(attributes[97]);
					digitalTrunkingResaleData12.setGlare(attributes[98]);
					digitalTrunkingResaleData12.setTgpulse_attr(attributes[99]);
					digitalTrunkingResaleData12.setTgpulse(attributes[100]);
					digitalTrunkingResaleData12.setTgsgnl_attr(attributes[101]);
					digitalTrunkingResaleData12.setTgsgnl(attributes[102]);
					digitalTrunkingResaleData12.setDidnum_attr(attributes[103]);
					digitalTrunkingResaleData12.setDidnum(attributes[104]);
					digitalTrunkingResaleData12.setDidind_attr(attributes[105]);
					digitalTrunkingResaleData12.setDidind(attributes[106]);
					digitalTrunkingResaleData12.setDtnract_attr(attributes[107]);
					digitalTrunkingResaleData12.setDtnract(attributes[108]);
					digitalTrunkingResaleData12.setDtnrq_attr(attributes[109]);
					digitalTrunkingResaleData12.setDtnrq(attributes[110]);
					digitalTrunkingResaleData12.setDtnr1_attr(attributes[111]);
					digitalTrunkingResaleData12.setDtnr1(attributes[112]);
					digitalTrunkingResaleData12.setDtnr2_attr(attributes[113]);
					digitalTrunkingResaleData12.setDtnr2(attributes[114]);
					digitalTrunkingResaleData12.setDtnr3_attr(attributes[115]);
					digitalTrunkingResaleData12.setDtnr3(attributes[116]);
					digitalTrunkingResaleData12.setNpi_attr(attributes[117]);
					digitalTrunkingResaleData12.setNpi(attributes[118]);
					digitalTrunkingResaleData12.setDidr_attr(attributes[119]);
					digitalTrunkingResaleData12.setDidr(attributes[120]);
					digitalTrunkingResaleData12.setDba_attr(attributes[121]);
					digitalTrunkingResaleData12.setDba(attributes[122]);
					digitalTrunkingResaleData12.setDblock_attr(attributes[123]);
					digitalTrunkingResaleData12.setDblock(attributes[124]);
					digitalTrunkingResaleData12.setNba_attr(attributes[125]);
					digitalTrunkingResaleData12.setNba(attributes[126]);
					digitalTrunkingResaleData12.setNbank1_attr(attributes[127]);
					digitalTrunkingResaleData12.setNbank1(attributes[128]);
					digitalTrunkingResaleData12.setNbank2_attr(attributes[129]);
					digitalTrunkingResaleData12.setNbank2(attributes[130]);
					digitalTrunkingResaleData12.setNbank3_attr(attributes[131]);
					digitalTrunkingResaleData12.setNbank3(attributes[132]);
					digitalTrunkingResaleData12.setNbank4_attr(attributes[133]);
					digitalTrunkingResaleData12.setNbank4(attributes[134]);
					digitalTrunkingResaleData12.setDstnact_attr(attributes[135]);
					digitalTrunkingResaleData12.setDstnact(attributes[136]);
					digitalTrunkingResaleData12.setDstnq_attr(attributes[137]);
					digitalTrunkingResaleData12.setDstnq(attributes[138]);
					digitalTrunkingResaleData12.setDstn1_attr(attributes[139]);
					digitalTrunkingResaleData12.setDstn1(attributes[140]);
					digitalTrunkingResaleData12.setDstn2_attr(attributes[141]);
					digitalTrunkingResaleData12.setDstn2(attributes[142]);
					digitalTrunkingResaleData12.setDstn3_attr(attributes[143]);
					digitalTrunkingResaleData12.setDstn3(attributes[144]);
					digitalTrunkingResaleData12.setDstn4_attr(attributes[145]);
					digitalTrunkingResaleData12.setDstn4(attributes[146]);
					digitalTrunkingResaleData12.setDstn5_attr(attributes[147]);
					digitalTrunkingResaleData12.setDstn5(attributes[148]);
					digitalTrunkingResaleData12.setLnum_attr(attributes[149]);
					digitalTrunkingResaleData12.setLnum(attributes[150]);
					digitalTrunkingResaleData12.setTkind_attr(attributes[151]);
					digitalTrunkingResaleData12.setTkind(attributes[152]);
					digitalTrunkingResaleData12.setLna_attr(attributes[153]);
					digitalTrunkingResaleData12.setLna(attributes[154]);
					digitalTrunkingResaleData12.setTns_attr(attributes[155]);
					digitalTrunkingResaleData12.setTns(FormatUtil.getTelephoneNumberWithDashes(attributes[156] != null && attributes[156] != "" ? attributes[156] : " "));// supriya changes for date format		
					digitalTrunkingResaleData12.setTers_attr(attributes[157]);
					digitalTrunkingResaleData12.setTers(attributes[158]);
					digitalTrunkingResaleData12.setOtn_attr(attributes[159]);
					digitalTrunkingResaleData12.setOtn(FormatUtil.getTelephoneNumberWithDashes(attributes[160] != null && attributes[160] != "" ? attributes[160] : " "));// supriya changes for date format		
					digitalTrunkingResaleData12.setLtgn_attr(attributes[161]);
					digitalTrunkingResaleData12.setLtgn(attributes[162]);
					digitalTrunkingResaleData12.setEcckt_attr(attributes[163]);
					digitalTrunkingResaleData12.setEcckt(attributes[164]);
					digitalTrunkingResaleData12.setSsig_attr(attributes[165]);
					digitalTrunkingResaleData12.setSsig(attributes[166]);
					digitalTrunkingResaleData12.setBa_attr(attributes[167]);
					digitalTrunkingResaleData12.setBa(attributes[168]);
					digitalTrunkingResaleData12.setBlock_attr(attributes[169]);
					digitalTrunkingResaleData12.setBlock(attributes[170]);
					digitalTrunkingResaleData12.setCfa_trnk_attr(attributes[171]);
					digitalTrunkingResaleData12.setCfa_trnk(attributes[172]);
					digitalTrunkingResaleData12.setPic_trnk_attr(attributes[173]);
					digitalTrunkingResaleData12.setPic_trnk(attributes[174]);
					digitalTrunkingResaleData12.setLpic_trnk_attr(attributes[175]);
					digitalTrunkingResaleData12.setLpic_trnk(attributes[176]);
					digitalTrunkingResaleData12.setNpi_trnk_attr(attributes[177]);
					digitalTrunkingResaleData12.setNpi_trnk(attributes[178]);
					digitalTrunkingResaleData12.setTgtli_trnk_attr(attributes[179]);
					digitalTrunkingResaleData12.setTgtli_trnk(attributes[180]);

					treeViewList_800.add(digitalTrunkingResaleData12);
				}
				session.setAttribute("treeViewList_800", treeViewList_800);
				selectRequestData.setSubHeader(receivedSubHeader);
			}

			if (subData_802Recid != null && subData_802Recid.getSubHeader().getRecord_type().equals("802")) {

				SubHeader receivedSubHeader = subData_802Recid.getSubHeader();
				String[] subDataRows = subData_802Recid.getSubDataRows();
				List<DigitalTrunkingLoopwPortDTU> treeViewList_802 = new ArrayList();
				treeViewList.add("802");
				// int i = 0;

				for (String subDataRow : subDataRows) {
					String[] attributes = mqReadUtil.getAttributes(subDataRow, 181);
					// System.out.println("attributes:=802:Reqid======> " +
					// Arrays.toString(attributes));
					DigitalTrunkingLoopwPortDTU digitalTrunkingLoopwPortDTU = new DigitalTrunkingLoopwPortDTU();

					digitalTrunkingLoopwPortDTU.setItem_num(attributes[0]);
					digitalTrunkingLoopwPortDTU.setFnum_attr(attributes[1]);
					digitalTrunkingLoopwPortDTU.setFnum(attributes[2]);
					digitalTrunkingLoopwPortDTU.setFlna_attr(attributes[3]);
					digitalTrunkingLoopwPortDTU.setFlna(attributes[4]);
					digitalTrunkingLoopwPortDTU.setFecckt_attr(attributes[5]);
					digitalTrunkingLoopwPortDTU.setFecckt(attributes[6]);
					digitalTrunkingLoopwPortDTU.setCkr_attr(attributes[7]);
					digitalTrunkingLoopwPortDTU.setCkr(attributes[8]);
					digitalTrunkingLoopwPortDTU.setPri_loc_attr(attributes[9]);
					digitalTrunkingLoopwPortDTU.setPri_loc(attributes[10]);
					digitalTrunkingLoopwPortDTU.setEulst_attr(attributes[11]);
					digitalTrunkingLoopwPortDTU.setEulst(attributes[12]);
					digitalTrunkingLoopwPortDTU.setActl_attr(attributes[13]);
					digitalTrunkingLoopwPortDTU.setActl(attributes[14]);
					digitalTrunkingLoopwPortDTU.setCcea_attr(attributes[15]);
					digitalTrunkingLoopwPortDTU.setCcea(attributes[16]);
					digitalTrunkingLoopwPortDTU.setCfa_attr(attributes[17]);
					digitalTrunkingLoopwPortDTU.setCfa(attributes[18]);
					digitalTrunkingLoopwPortDTU.setCfa_btn_attr(attributes[19]);
					digitalTrunkingLoopwPortDTU.setCfa_btn(FormatUtil.getTelephoneNumberWithDashes(attributes[20] != null && attributes[20] != "" ? attributes[20] : " "));// supriya changes for date format
					digitalTrunkingLoopwPortDTU.setNcon_attr(attributes[21]);
					digitalTrunkingLoopwPortDTU.setNcon(attributes[22]);
					digitalTrunkingLoopwPortDTU.setAft_attr(attributes[23]);
					digitalTrunkingLoopwPortDTU.setAft(attributes[24]);
					digitalTrunkingLoopwPortDTU.setSapr_attr(attributes[25]);
					digitalTrunkingLoopwPortDTU.setSapr(attributes[26]);
					digitalTrunkingLoopwPortDTU.setSano_attr(attributes[27]);
					digitalTrunkingLoopwPortDTU.setSano(attributes[28]);
					digitalTrunkingLoopwPortDTU.setSasf_attr(attributes[29]);
					digitalTrunkingLoopwPortDTU.setSasf(attributes[30]);
					digitalTrunkingLoopwPortDTU.setSasd_attr(attributes[31]);
					digitalTrunkingLoopwPortDTU.setSasd(attributes[32]);
					digitalTrunkingLoopwPortDTU.setSasn_attr(attributes[33]);
					digitalTrunkingLoopwPortDTU.setSasn(attributes[34]);
					digitalTrunkingLoopwPortDTU.setSath_attr(attributes[35]);
					digitalTrunkingLoopwPortDTU.setSath(attributes[36]);
					digitalTrunkingLoopwPortDTU.setSass_attr(attributes[37]);
					digitalTrunkingLoopwPortDTU.setSass(attributes[38]);
					digitalTrunkingLoopwPortDTU.setLd1_attr(attributes[39]);
					digitalTrunkingLoopwPortDTU.setLd1(attributes[40]);
					digitalTrunkingLoopwPortDTU.setLv1_attr(attributes[41]);
					digitalTrunkingLoopwPortDTU.setLv1(attributes[42]);
					digitalTrunkingLoopwPortDTU.setLd2_attr(attributes[43]);
					digitalTrunkingLoopwPortDTU.setLd2(attributes[44]);
					digitalTrunkingLoopwPortDTU.setLv2_attr(attributes[45]);
					digitalTrunkingLoopwPortDTU.setLv2(attributes[46]);
					digitalTrunkingLoopwPortDTU.setLd3_attr(attributes[47]);
					digitalTrunkingLoopwPortDTU.setLd3(attributes[48]);
					digitalTrunkingLoopwPortDTU.setLv3_attr(attributes[49]);
					digitalTrunkingLoopwPortDTU.setLv3(attributes[50]);
					digitalTrunkingLoopwPortDTU.setAai_attr(attributes[51]);
					digitalTrunkingLoopwPortDTU.setAai(attributes[52]);
					digitalTrunkingLoopwPortDTU.setCity_attr(attributes[53]);
					digitalTrunkingLoopwPortDTU.setCity(attributes[54]);
					digitalTrunkingLoopwPortDTU.setState_attr(attributes[55]);
					digitalTrunkingLoopwPortDTU.setState(attributes[56]);
					digitalTrunkingLoopwPortDTU.setZip_attr(attributes[57]);
					digitalTrunkingLoopwPortDTU.setZip(attributes[58]);
					digitalTrunkingLoopwPortDTU.setAloc_attr(attributes[59]);
					digitalTrunkingLoopwPortDTU.setAloc(attributes[60]);
					digitalTrunkingLoopwPortDTU.setNidr_attr(attributes[61]);
					digitalTrunkingLoopwPortDTU.setNidr(attributes[62]);
					digitalTrunkingLoopwPortDTU.setIwo_attr(attributes[63]);
					digitalTrunkingLoopwPortDTU.setIwo(attributes[64]);
					digitalTrunkingLoopwPortDTU.setLcon_attr(attributes[65]);
					digitalTrunkingLoopwPortDTU.setLcon(attributes[66]);
					digitalTrunkingLoopwPortDTU.setTelno_attr(attributes[67]);
					digitalTrunkingLoopwPortDTU.setTelno(FormatUtil.getTelephoneNumberWithDashes(attributes[68] != null && attributes[68] != "" ? attributes[68] : " "));// supriya changes for date format
					digitalTrunkingLoopwPortDTU.setSecloc_attr(attributes[69]);
					digitalTrunkingLoopwPortDTU.setSecloc(attributes[70]);
					digitalTrunkingLoopwPortDTU.setTglnum_attr(attributes[71]);
					digitalTrunkingLoopwPortDTU.setTglnum(attributes[72]);
					digitalTrunkingLoopwPortDTU.setTglna_attr(attributes[73]);
					digitalTrunkingLoopwPortDTU.setTglna(attributes[74]);
					digitalTrunkingLoopwPortDTU.setTgn1_attr(attributes[75]);
					digitalTrunkingLoopwPortDTU.setTgn1(attributes[76]);
					digitalTrunkingLoopwPortDTU.setTgn2_attr(attributes[77]);
					digitalTrunkingLoopwPortDTU.setTgn2(attributes[78]);
					digitalTrunkingLoopwPortDTU.setTgn3_attr(attributes[79]);
					digitalTrunkingLoopwPortDTU.setTgn3(attributes[80]);
					digitalTrunkingLoopwPortDTU.setTgtn_attr(attributes[81]);
					digitalTrunkingLoopwPortDTU.setTgtn(FormatUtil.getTelephoneNumberWithDashes(attributes[82] != null && attributes[82] != "" ? attributes[82] : " "));// supriya changes for date format
					digitalTrunkingLoopwPortDTU.setTgtli_attr(attributes[83]);
					digitalTrunkingLoopwPortDTU.setTgtli(FormatUtil.getTelephoneNumberWithDashes(attributes[84] != null && attributes[84] != "" ? attributes[84] : " "));// supriya changes for date format
					digitalTrunkingLoopwPortDTU.setTgrti_attr(attributes[85]);
					digitalTrunkingLoopwPortDTU.setTgrti(attributes[86]);
					digitalTrunkingLoopwPortDTU.setTgdir_attr(attributes[87]);
					digitalTrunkingLoopwPortDTU.setTgdir(attributes[88]);
					digitalTrunkingLoopwPortDTU.setTgnh_attr(attributes[89]);
					digitalTrunkingLoopwPortDTU.setTgnh(attributes[90]);
					digitalTrunkingLoopwPortDTU.setDgout_attr(attributes[91]);
					digitalTrunkingLoopwPortDTU.setDgout(attributes[92]);
					digitalTrunkingLoopwPortDTU.setPic_attr(attributes[93]);
					digitalTrunkingLoopwPortDTU.setPic(attributes[94]);
					digitalTrunkingLoopwPortDTU.setLpic_attr(attributes[95]);
					digitalTrunkingLoopwPortDTU.setLpic(attributes[96]);
					digitalTrunkingLoopwPortDTU.setGlare_attr(attributes[97]);
					digitalTrunkingLoopwPortDTU.setGlare(attributes[98]);
					digitalTrunkingLoopwPortDTU.setTgpulse_attr(attributes[99]);
					digitalTrunkingLoopwPortDTU.setTgpulse(attributes[100]);
					digitalTrunkingLoopwPortDTU.setTgsgnl_attr(attributes[101]);
					digitalTrunkingLoopwPortDTU.setTgsgnl(attributes[102]);
					digitalTrunkingLoopwPortDTU.setDidnum_attr(attributes[103]);
					digitalTrunkingLoopwPortDTU.setDidnum(attributes[104]);
					digitalTrunkingLoopwPortDTU.setDidind_attr(attributes[105]);
					digitalTrunkingLoopwPortDTU.setDidind(attributes[106]);
					digitalTrunkingLoopwPortDTU.setDtnract_attr(attributes[107]);
					digitalTrunkingLoopwPortDTU.setDtnract(attributes[108]);
					digitalTrunkingLoopwPortDTU.setDtnrq_attr(attributes[109]);
					digitalTrunkingLoopwPortDTU.setDtnrq(attributes[110]);
					digitalTrunkingLoopwPortDTU.setDtnr1_attr(attributes[111]);
					digitalTrunkingLoopwPortDTU.setDtnr1(attributes[112]);
					digitalTrunkingLoopwPortDTU.setDtnr2_attr(attributes[113]);
					digitalTrunkingLoopwPortDTU.setDtnr2(attributes[114]);
					digitalTrunkingLoopwPortDTU.setDtnr3_attr(attributes[115]);
					digitalTrunkingLoopwPortDTU.setDtnr3(attributes[116]);
					digitalTrunkingLoopwPortDTU.setNpi_attr(attributes[117]);
					digitalTrunkingLoopwPortDTU.setNpi(attributes[118]);
					digitalTrunkingLoopwPortDTU.setDidr_attr(attributes[119]);
					digitalTrunkingLoopwPortDTU.setDidr(attributes[120]);
					digitalTrunkingLoopwPortDTU.setDba_attr(attributes[121]);
					digitalTrunkingLoopwPortDTU.setDba(attributes[122]);
					digitalTrunkingLoopwPortDTU.setDblock_attr(attributes[123]);
					digitalTrunkingLoopwPortDTU.setDblock(attributes[124]);
					digitalTrunkingLoopwPortDTU.setNba_attr(attributes[125]);
					digitalTrunkingLoopwPortDTU.setNba(attributes[126]);
					digitalTrunkingLoopwPortDTU.setNbank1_attr(attributes[127]);
					digitalTrunkingLoopwPortDTU.setNbank1(attributes[128]);
					digitalTrunkingLoopwPortDTU.setNbank2_attr(attributes[129]);
					digitalTrunkingLoopwPortDTU.setNbank2(attributes[130]);
					digitalTrunkingLoopwPortDTU.setNbank3_attr(attributes[131]);
					digitalTrunkingLoopwPortDTU.setNbank3(attributes[132]);
					digitalTrunkingLoopwPortDTU.setNbank4_attr(attributes[133]);
					digitalTrunkingLoopwPortDTU.setNbank4(attributes[134]);
					digitalTrunkingLoopwPortDTU.setDstnact_attr(attributes[135]);
					digitalTrunkingLoopwPortDTU.setDstnact(attributes[136]);
					digitalTrunkingLoopwPortDTU.setDstnq_attr(attributes[137]);
					digitalTrunkingLoopwPortDTU.setDstnq(attributes[138]);
					digitalTrunkingLoopwPortDTU.setDstn1_attr(attributes[139]);
					digitalTrunkingLoopwPortDTU.setDstn1(attributes[140]);
					digitalTrunkingLoopwPortDTU.setDstn2_attr(attributes[141]);
					digitalTrunkingLoopwPortDTU.setDstn2(attributes[142]);
					digitalTrunkingLoopwPortDTU.setDstn3_attr(attributes[143]);
					digitalTrunkingLoopwPortDTU.setDstn3(attributes[144]);
					digitalTrunkingLoopwPortDTU.setDstn4_attr(attributes[145]);
					digitalTrunkingLoopwPortDTU.setDstn4(attributes[146]);
					digitalTrunkingLoopwPortDTU.setDstn5_attr(attributes[147]);
					digitalTrunkingLoopwPortDTU.setDstn5(attributes[148]);
					digitalTrunkingLoopwPortDTU.setLnum_attr(attributes[149]);
					digitalTrunkingLoopwPortDTU.setLnum(attributes[150]);
					digitalTrunkingLoopwPortDTU.setTkind_attr(attributes[151]);
					digitalTrunkingLoopwPortDTU.setTkind(attributes[152]);
					digitalTrunkingLoopwPortDTU.setLna_attr(attributes[153]);
					digitalTrunkingLoopwPortDTU.setLna(attributes[154]);
					digitalTrunkingLoopwPortDTU.setTns_attr(attributes[155]);
					digitalTrunkingLoopwPortDTU.setTns(FormatUtil.getTelephoneNumberWithDashes(attributes[156] != null && attributes[156] != "" ? attributes[156] : " "));// supriya changes for date format
					digitalTrunkingLoopwPortDTU.setTers_attr(attributes[157]);
					digitalTrunkingLoopwPortDTU.setTers(attributes[158]);
					digitalTrunkingLoopwPortDTU.setOtn_attr(attributes[159]);
					digitalTrunkingLoopwPortDTU.setOtn(FormatUtil.getTelephoneNumberWithDashes(attributes[160] != null && attributes[160] != "" ? attributes[160] : " "));// supriya changes for date format
					digitalTrunkingLoopwPortDTU.setLtgn_attr(attributes[161]);
					digitalTrunkingLoopwPortDTU.setLtgn(attributes[162]);
					digitalTrunkingLoopwPortDTU.setEcckt_attr(attributes[163]);
					digitalTrunkingLoopwPortDTU.setEcckt(attributes[164]);
					digitalTrunkingLoopwPortDTU.setSsig_attr(attributes[165]);
					digitalTrunkingLoopwPortDTU.setSsig(attributes[166]);
					digitalTrunkingLoopwPortDTU.setBa_attr(attributes[167]);
					digitalTrunkingLoopwPortDTU.setBa(attributes[168]);
					digitalTrunkingLoopwPortDTU.setBlock_attr(attributes[169]);
					digitalTrunkingLoopwPortDTU.setBlock(attributes[170]);
					digitalTrunkingLoopwPortDTU.setCfa_trnk_attr(attributes[171]);
					digitalTrunkingLoopwPortDTU.setCfa_trnk(attributes[172]);
					digitalTrunkingLoopwPortDTU.setPic_trnk_attr(attributes[173]);
					digitalTrunkingLoopwPortDTU.setPic_trnk(attributes[174]);
					digitalTrunkingLoopwPortDTU.setLpic_trnk_attr(attributes[175]);
					digitalTrunkingLoopwPortDTU.setLpic_trnk(attributes[176]);
					digitalTrunkingLoopwPortDTU.setNpi_trnk_attr(attributes[177]);
					digitalTrunkingLoopwPortDTU.setNpi_trnk(attributes[178]);
					digitalTrunkingLoopwPortDTU.setTgtli_trnk_attr(attributes[179]);
					digitalTrunkingLoopwPortDTU.setTgtli_trnk(attributes[180]);

					treeViewList_802.add(digitalTrunkingLoopwPortDTU);
				}
				session.setAttribute("treeViewList_802", treeViewList_802);
				selectRequestData.setSubHeader(receivedSubHeader);
			}

			// Saurabh
			if (subData_640Recid != null && subData_640Recid.getSubHeader().getRecord_type().equals("640")) {
				SubHeader receivedSubHeader = subData_640Recid.getSubHeader();
				String[] subDataRows = subData_640Recid.getSubDataRows();
				List<DPR_Trunk_12State> treeViewList_640 = new ArrayList<DPR_Trunk_12State>();
				treeViewList.add("640");
				for (String subDataRow : subDataRows) {
					String[] attributes = mqReadUtil.getAttributes(subDataRow, 154);
					// System.out.println("subData_640Recid attributes:=======> " +
					// Arrays.toString(attributes));
					DPR_Trunk_12State dpr_Trunk_12State = new DPR_Trunk_12State();
					dpr_Trunk_12State.setItem_num(attributes[0] != null || attributes[0] != "" ? attributes[0] : " ");
					dpr_Trunk_12State
							.setDidnum_attr(attributes[1] != null || attributes[1] != "" ? attributes[1] : " ");
					dpr_Trunk_12State.setDidnum(attributes[2] != null || attributes[2] != "" ? attributes[2] : " ");
					dpr_Trunk_12State
							.setDidind_attr(attributes[3] != null || attributes[3] != "" ? attributes[3] : " ");
					dpr_Trunk_12State.setDidind(attributes[4] != null || attributes[4] != "" ? attributes[4] : " ");
					dpr_Trunk_12State
							.setDtnract_attr(attributes[5] != null || attributes[5] != "" ? attributes[5] : " ");
					dpr_Trunk_12State.setDtnract(attributes[6] != null || attributes[6] != "" ? attributes[6] : " ");
					dpr_Trunk_12State.setDtnrq_attr(attributes[7] != null || attributes[7] != "" ? attributes[7] : " ");
					dpr_Trunk_12State.setDtnrq(attributes[8] != null || attributes[8] != "" ? attributes[8] : " ");
					dpr_Trunk_12State.setDtnr1_attr(attributes[9] != null || attributes[9] != "" ? attributes[9] : " ");
					dpr_Trunk_12State.setDtnr1(attributes[10] != null || attributes[10] != "" ? attributes[10] : " ");
					dpr_Trunk_12State
							.setDtnr2_attr(attributes[11] != null || attributes[11] != "" ? attributes[11] : " ");
					dpr_Trunk_12State.setDtnr2(attributes[12] != null || attributes[12] != "" ? attributes[12] : " ");
					dpr_Trunk_12State
							.setDtnr3_attr(attributes[13] != null || attributes[13] != "" ? attributes[13] : " ");
					dpr_Trunk_12State.setDtnr3(attributes[14] != null || attributes[14] != "" ? attributes[14] : " ");
					dpr_Trunk_12State
							.setNpi_attr(attributes[15] != null || attributes[15] != "" ? attributes[15] : " ");
					dpr_Trunk_12State.setNpi(attributes[16] != null || attributes[16] != "" ? attributes[16] : " ");
					dpr_Trunk_12State
							.setDidr_attr(attributes[17] != null || attributes[17] != "" ? attributes[17] : " ");
					dpr_Trunk_12State.setDidr(attributes[18] != null || attributes[18] != "" ? attributes[18] : " ");
					dpr_Trunk_12State
							.setDtkact_attr(attributes[19] != null || attributes[19] != "" ? attributes[19] : " ");
					dpr_Trunk_12State.setDtkact(attributes[20] != null || attributes[20] != "" ? attributes[20] : " ");
					dpr_Trunk_12State
							.setDtgn_attr(attributes[21] != null || attributes[21] != "" ? attributes[21] : " ");
					dpr_Trunk_12State.setDtgn(attributes[22] != null || attributes[22] != "" ? attributes[22] : " ");
					dpr_Trunk_12State
							.setDtli_attr(attributes[23] != null || attributes[23] != "" ? attributes[23] : " ");
					dpr_Trunk_12State.setDtli(attributes[24] != null || attributes[24] != "" ? attributes[24] : " ");
					dpr_Trunk_12State
							.setDba_attr(attributes[25] != null || attributes[25] != "" ? attributes[25] : " ");
					dpr_Trunk_12State.setDba(attributes[26] != null || attributes[26] != "" ? attributes[26] : " ");
					dpr_Trunk_12State
							.setDblock_attr(attributes[27] != null || attributes[27] != "" ? attributes[27] : " ");
					dpr_Trunk_12State.setDblock(attributes[28] != null || attributes[28] != "" ? attributes[28] : " ");
					dpr_Trunk_12State
							.setDpic_attr(attributes[29] != null || attributes[29] != "" ? attributes[29] : " ");
					dpr_Trunk_12State.setDpic(attributes[30] != null || attributes[30] != "" ? attributes[30] : " ");
					dpr_Trunk_12State
							.setDlpic_attr(attributes[31] != null || attributes[31] != "" ? attributes[31] : " ");
					dpr_Trunk_12State.setDlpic(attributes[32] != null || attributes[32] != "" ? attributes[32] : " ");
					dpr_Trunk_12State
							.setDrti_attr(attributes[33] != null || attributes[33] != "" ? attributes[33] : " ");
					dpr_Trunk_12State.setDrti(attributes[34] != null || attributes[34] != "" ? attributes[34] : " ");
					dpr_Trunk_12State
							.setDgout_attr(attributes[35] != null || attributes[35] != "" ? attributes[35] : " ");
					dpr_Trunk_12State.setDgout(attributes[36] != null || attributes[36] != "" ? attributes[36] : " ");
					dpr_Trunk_12State
							.setDpulse_attr(attributes[37] != null || attributes[37] != "" ? attributes[37] : " ");
					dpr_Trunk_12State.setDpulse(attributes[38] != null || attributes[38] != "" ? attributes[38] : " ");
					dpr_Trunk_12State
							.setDsgnl_attr(attributes[39] != null || attributes[39] != "" ? attributes[39] : " ");
					dpr_Trunk_12State.setDsgnl(attributes[40] != null || attributes[40] != "" ? attributes[40] : " ");
					dpr_Trunk_12State
							.setNba_attr(attributes[41] != null || attributes[41] != "" ? attributes[41] : " ");
					dpr_Trunk_12State.setNba(attributes[42] != null || attributes[42] != "" ? attributes[42] : " ");
					dpr_Trunk_12State
							.setNbank1_attr(attributes[43] != null || attributes[43] != "" ? attributes[43] : " ");
					dpr_Trunk_12State.setNbank1(attributes[44] != null || attributes[44] != "" ? attributes[44] : " ");
					dpr_Trunk_12State
							.setNbank2_attr(attributes[45] != null || attributes[45] != "" ? attributes[45] : " ");
					dpr_Trunk_12State.setNbank2(attributes[46] != null || attributes[46] != "" ? attributes[46] : " ");
					dpr_Trunk_12State
							.setNbank3_attr(attributes[47] != null || attributes[47] != "" ? attributes[47] : " ");
					dpr_Trunk_12State.setNbank3(attributes[48] != null || attributes[48] != "" ? attributes[48] : " ");
					dpr_Trunk_12State
							.setNbank4_attr(attributes[49] != null || attributes[49] != "" ? attributes[49] : " ");
					dpr_Trunk_12State.setNbank4(attributes[50] != null || attributes[50] != "" ? attributes[50] : " ");
					dpr_Trunk_12State
							.setDstnact_attr(attributes[51] != null || attributes[51] != "" ? attributes[51] : " ");
					dpr_Trunk_12State.setDstnact(attributes[52] != null || attributes[52] != "" ? attributes[52] : " ");
					dpr_Trunk_12State
							.setDstnq_attr(attributes[53] != null || attributes[53] != "" ? attributes[53] : " ");
					dpr_Trunk_12State.setDstnq(attributes[54] != null || attributes[54] != "" ? attributes[54] : " ");
					dpr_Trunk_12State
							.setDstn1_attr(attributes[55] != null || attributes[55] != "" ? attributes[55] : " ");
					dpr_Trunk_12State.setDstn1(attributes[56] != null || attributes[56] != "" ? attributes[56] : " ");
					dpr_Trunk_12State
							.setDstn2_attr(attributes[57] != null || attributes[57] != "" ? attributes[57] : " ");
					dpr_Trunk_12State.setDstn2(attributes[58] != null || attributes[58] != "" ? attributes[58] : " ");
					dpr_Trunk_12State
							.setDstn3_attr(attributes[59] != null || attributes[59] != "" ? attributes[59] : " ");
					dpr_Trunk_12State.setDstn3(attributes[60] != null || attributes[60] != "" ? attributes[60] : " ");
					dpr_Trunk_12State
							.setDstn4_attr(attributes[61] != null || attributes[61] != "" ? attributes[61] : " ");
					dpr_Trunk_12State.setDstn4(attributes[62] != null || attributes[62] != "" ? attributes[62] : " ");
					dpr_Trunk_12State
							.setDstn5_attr(attributes[63] != null || attributes[63] != "" ? attributes[63] : " ");
					dpr_Trunk_12State.setDstn5(attributes[64] != null || attributes[64] != "" ? attributes[64] : " ");
					dpr_Trunk_12State
							.setLnum_attr(attributes[65] != null || attributes[65] != "" ? attributes[65] : " ");
					dpr_Trunk_12State.setLnum(attributes[66] != null || attributes[66] != "" ? attributes[66] : " ");
					dpr_Trunk_12State
							.setLna_attr(attributes[67] != null || attributes[67] != "" ? attributes[67] : " ");
					dpr_Trunk_12State.setLna(attributes[68] != null || attributes[68] != "" ? attributes[68] : " ");
					dpr_Trunk_12State
							.setTns_attr(attributes[69] != null || attributes[69] != "" ? attributes[69] : " ");
					dpr_Trunk_12State.setTns(attributes[70] != null || attributes[70] != "" ? attributes[70] : " ");
					dpr_Trunk_12State
							.setTers_attr(attributes[71] != null || attributes[71] != "" ? attributes[71] : " ");
					dpr_Trunk_12State.setTers(attributes[72] != null || attributes[72] != "" ? attributes[72] : " ");
					dpr_Trunk_12State
							.setOtn_attr(attributes[73] != null || attributes[73] != "" ? attributes[73] : " ");
					dpr_Trunk_12State.setOtn(attributes[74] != null || attributes[74] != "" ? attributes[74] : " ");
					dpr_Trunk_12State
							.setLtgn_attr(attributes[75] != null || attributes[75] != "" ? attributes[75] : " ");
					dpr_Trunk_12State.setLtgn(attributes[76] != null || attributes[76] != "" ? attributes[76] : " ");
					dpr_Trunk_12State.setNc_attr(attributes[77] != null || attributes[77] != "" ? attributes[77] : " ");
					dpr_Trunk_12State.setNc(attributes[78] != null || attributes[78] != "" ? attributes[78] : " ");
					dpr_Trunk_12State
							.setNci_attr(attributes[79] != null || attributes[79] != "" ? attributes[79] : " ");
					dpr_Trunk_12State.setNci(attributes[80] != null || attributes[80] != "" ? attributes[80] : " ");
					dpr_Trunk_12State
							.setEcckt_attr(attributes[81] != null || attributes[81] != "" ? attributes[81] : " ");
					dpr_Trunk_12State.setEcckt(attributes[82] != null || attributes[82] != "" ? attributes[82] : " ");
					dpr_Trunk_12State
							.setCfa_attr(attributes[83] != null || attributes[83] != "" ? attributes[83] : " ");
					dpr_Trunk_12State.setCfa(attributes[84] != null || attributes[84] != "" ? attributes[84] : " ");
					dpr_Trunk_12State
							.setCcea_attr(attributes[85] != null || attributes[85] != "" ? attributes[85] : " ");
					dpr_Trunk_12State.setCcea(attributes[86] != null || attributes[86] != "" ? attributes[86] : " ");
					dpr_Trunk_12State
							.setCkr_attr(attributes[87] != null || attributes[87] != "" ? attributes[87] : " ");
					dpr_Trunk_12State.setCkr(attributes[88] != null || attributes[88] != "" ? attributes[88] : " ");
					dpr_Trunk_12State
							.setPic_attr(attributes[89] != null || attributes[89] != "" ? attributes[89] : " ");
					dpr_Trunk_12State.setPic(attributes[90] != null || attributes[90] != "" ? attributes[90] : " ");
					dpr_Trunk_12State
							.setLpic_attr(attributes[91] != null || attributes[91] != "" ? attributes[91] : " ");
					dpr_Trunk_12State.setLpic(attributes[92] != null || attributes[92] != "" ? attributes[92] : " ");
					dpr_Trunk_12State
							.setSsig_attr(attributes[93] != null || attributes[93] != "" ? attributes[93] : " ");
					dpr_Trunk_12State.setSsig(attributes[94] != null || attributes[94] != "" ? attributes[94] : " ");
					dpr_Trunk_12State.setBa_attr(attributes[95] != null || attributes[95] != "" ? attributes[95] : " ");
					dpr_Trunk_12State.setBa(attributes[96] != null || attributes[96] != "" ? attributes[96] : " ");
					dpr_Trunk_12State
							.setBlock_attr(attributes[97] != null || attributes[97] != "" ? attributes[97] : " ");
					dpr_Trunk_12State.setBlock(attributes[98] != null || attributes[98] != "" ? attributes[98] : " ");
					dpr_Trunk_12State
							.setTsp_attr(attributes[99] != null || attributes[99] != "" ? attributes[99] : " ");
					dpr_Trunk_12State.setTsp(attributes[100] != null || attributes[100] != "" ? attributes[100] : " ");
					dpr_Trunk_12State
							.setJk_code_attr(attributes[101] != null || attributes[101] != "" ? attributes[101] : " ");
					dpr_Trunk_12State
							.setJk_code(attributes[102] != null || attributes[102] != "" ? attributes[102] : " ");
					dpr_Trunk_12State
							.setJk_num_attr(attributes[103] != null || attributes[103] != "" ? attributes[103] : " ");
					dpr_Trunk_12State
							.setJk_num(attributes[104] != null || attributes[104] != "" ? attributes[104] : " ");
					dpr_Trunk_12State
							.setJk_pos_attr(attributes[105] != null || attributes[105] != "" ? attributes[105] : " ");
					dpr_Trunk_12State
							.setJk_pos(attributes[106] != null || attributes[106] != "" ? attributes[106] : " ");
					dpr_Trunk_12State
							.setJr_attr(attributes[107] != null || attributes[107] != "" ? attributes[107] : " ");
					dpr_Trunk_12State.setJr(attributes[108] != null || attributes[108] != "" ? attributes[108] : " ");
					dpr_Trunk_12State
							.setNidr_attr(attributes[109] != null || attributes[109] != "" ? attributes[109] : " ");
					dpr_Trunk_12State.setNidr(attributes[110] != null || attributes[110] != "" ? attributes[110] : " ");
					dpr_Trunk_12State
							.setIwjk1_attr(attributes[111] != null || attributes[111] != "" ? attributes[111] : " ");
					dpr_Trunk_12State
							.setIwjk1(attributes[112] != null || attributes[112] != "" ? attributes[112] : " ");
					dpr_Trunk_12State
							.setIwjk2_attr(attributes[113] != null || attributes[113] != "" ? attributes[113] : " ");
					dpr_Trunk_12State
							.setIwjk2(attributes[114] != null || attributes[114] != "" ? attributes[114] : " ");
					dpr_Trunk_12State
							.setIwjk3_attr(attributes[115] != null || attributes[115] != "" ? attributes[115] : " ");
					dpr_Trunk_12State
							.setIwjk3(attributes[116] != null || attributes[116] != "" ? attributes[116] : " ");
					dpr_Trunk_12State
							.setIwjk4_attr(attributes[117] != null || attributes[117] != "" ? attributes[117] : " ");
					dpr_Trunk_12State
							.setIwjk4(attributes[118] != null || attributes[118] != "" ? attributes[118] : " ");
					dpr_Trunk_12State
							.setIwjk5_attr(attributes[119] != null || attributes[119] != "" ? attributes[119] : " ");
					dpr_Trunk_12State
							.setIwjk5(attributes[120] != null || attributes[120] != "" ? attributes[120] : " ");
					dpr_Trunk_12State
							.setIwjq1_attr(attributes[121] != null || attributes[121] != "" ? attributes[121] : " ");
					dpr_Trunk_12State
							.setIwjq1(attributes[122] != null || attributes[122] != "" ? attributes[122] : " ");
					dpr_Trunk_12State
							.setIwjq2_attr(attributes[123] != null || attributes[123] != "" ? attributes[123] : " ");
					dpr_Trunk_12State
							.setIwjq2(attributes[124] != null || attributes[124] != "" ? attributes[124] : " ");
					dpr_Trunk_12State
							.setIwjq3_attr(attributes[125] != null || attributes[125] != "" ? attributes[125] : " ");
					dpr_Trunk_12State
							.setIwjq3(attributes[126] != null || attributes[126] != "" ? attributes[126] : " ");
					dpr_Trunk_12State
							.setIwjq4_attr(attributes[127] != null || attributes[127] != "" ? attributes[127] : " ");
					dpr_Trunk_12State
							.setIwjq4(attributes[128] != null || attributes[128] != "" ? attributes[128] : " ");
					dpr_Trunk_12State
							.setIwjq5_attr(attributes[129] != null || attributes[129] != "" ? attributes[129] : " ");
					dpr_Trunk_12State
							.setIwjq5(attributes[130] != null || attributes[130] != "" ? attributes[130] : " ");
					dpr_Trunk_12State
							.setNpi_trnk_attr(attributes[131] != null || attributes[131] != "" ? attributes[131] : " ");
					dpr_Trunk_12State
							.setNpi_trnk(attributes[132] != null || attributes[132] != "" ? attributes[132] : " ");
					dpr_Trunk_12State
							.setLocnum_attr(attributes[133] != null || attributes[133] != "" ? attributes[133] : " ");
					dpr_Trunk_12State
							.setLocnum(attributes[134] != null || attributes[134] != "" ? attributes[134] : " ");
					dpr_Trunk_12State
							.setTkid_attr(attributes[135] != null || attributes[135] != "" ? attributes[135] : " ");
					dpr_Trunk_12State.setTkid(attributes[136] != null || attributes[136] != "" ? attributes[136] : " ");
					dpr_Trunk_12State
							.setTtp_attr(attributes[137] != null || attributes[137] != "" ? attributes[137] : " ");
					dpr_Trunk_12State.setTtp(attributes[138] != null || attributes[138] != "" ? attributes[138] : " ");
					dpr_Trunk_12State
							.setIwt_attr(attributes[139] != null || attributes[139] != "" ? attributes[139] : " ");
					dpr_Trunk_12State.setIwt(attributes[140] != null || attributes[140] != "" ? attributes[140] : " ");
					dpr_Trunk_12State
							.setIwtq_attr(attributes[141] != null || attributes[141] != "" ? attributes[141] : " ");
					dpr_Trunk_12State.setIwtq(attributes[142] != null || attributes[142] != "" ? attributes[142] : " ");
					dpr_Trunk_12State
							.setDin_attr(attributes[143] != null || attributes[143] != "" ? attributes[143] : " ");
					dpr_Trunk_12State.setDin(attributes[144] != null || attributes[144] != "" ? attributes[144] : " ");
					dpr_Trunk_12State
							.setGlare_attr(attributes[145] != null || attributes[145] != "" ? attributes[145] : " ");
					dpr_Trunk_12State
							.setGlare(attributes[146] != null || attributes[146] != "" ? attributes[146] : " ");
					dpr_Trunk_12State
							.setCableid_attr(attributes[147] != null || attributes[147] != "" ? attributes[147] : " ");
					dpr_Trunk_12State
							.setCableid(attributes[148] != null || attributes[148] != "" ? attributes[148] : " ");
					dpr_Trunk_12State
							.setFpi_attr(attributes[149] != null || attributes[149] != "" ? attributes[149] : " ");
					dpr_Trunk_12State.setFpi(attributes[150] != null || attributes[150] != "" ? attributes[150] : " ");
					dpr_Trunk_12State
							.setQn_attr(attributes[151] != null || attributes[151] != "" ? attributes[151] : " ");
					dpr_Trunk_12State.setQn(attributes[152] != null || attributes[152] != "" ? attributes[152] : " ");
					dpr_Trunk_12State
							.setLoc_seq_num(attributes[153] != null || attributes[153] != "" ? attributes[153] : " ");

					treeViewList_640.add(dpr_Trunk_12State);
				}
				session.setAttribute("treeViewList_640", treeViewList_640);
				selectRequestData.setSubHeader(receivedSubHeader);
			}

			// Ruby

			// 12-State-DID/PBX Loop w/ Port DPU Trunk -Req-W-642
			if (subData_642Recid != null && subData_642Recid.getSubHeader().getRecord_type().equals("642")) {
				SubHeader receivedSubHeader = subData_642Recid.getSubHeader();
				String[] subDataRows = subData_642Recid.getSubDataRows();
				List<Loop_PortDPUTrunk_12State> treeViewList1_642 = new ArrayList();
				treeViewList.add("642");

				// int i = 0;
				for (String subDataRow : subDataRows) {
					String[] attributes = mqReadUtil.getAttributes(subDataRow, 133);
					// System.out.println("attributes:=======> " + Arrays.toString(attributes));
					Loop_PortDPUTrunk_12State loop_PortDPUTrunkGroup_12State = new Loop_PortDPUTrunk_12State();
					loop_PortDPUTrunkGroup_12State.setItem_num(attributes[0]);
					loop_PortDPUTrunkGroup_12State.setDidnum_attr(attributes[1]);
					loop_PortDPUTrunkGroup_12State.setDidnum(attributes[2]);
					loop_PortDPUTrunkGroup_12State.setDidind_attr(attributes[3]);
					loop_PortDPUTrunkGroup_12State.setDidind(attributes[4]);
					loop_PortDPUTrunkGroup_12State.setDtnract_attr(attributes[5]);
					loop_PortDPUTrunkGroup_12State.setDtnract(attributes[6]);
					loop_PortDPUTrunkGroup_12State.setDtnrq_attr(attributes[7]);
					loop_PortDPUTrunkGroup_12State.setDtnrq(attributes[8]);
					loop_PortDPUTrunkGroup_12State.setDtnr1_attr(attributes[9]);
					loop_PortDPUTrunkGroup_12State.setDtnr1(attributes[10]);
					loop_PortDPUTrunkGroup_12State.setDtnr2_attr(attributes[11]);
					loop_PortDPUTrunkGroup_12State.setDtnr2(attributes[12]);
					loop_PortDPUTrunkGroup_12State.setDtnr3_attr(attributes[13]);
					loop_PortDPUTrunkGroup_12State.setDtnr3(attributes[14]);
					loop_PortDPUTrunkGroup_12State.setNpi_attr(attributes[15]);
					loop_PortDPUTrunkGroup_12State.setNpi(attributes[16]);
					loop_PortDPUTrunkGroup_12State.setDidr_attr(attributes[17]);
					loop_PortDPUTrunkGroup_12State.setDidr(attributes[18]);
					loop_PortDPUTrunkGroup_12State.setDtkact_attr(attributes[19]);
					loop_PortDPUTrunkGroup_12State.setDtkact(attributes[20]);
					loop_PortDPUTrunkGroup_12State.setDtgn_attr(attributes[21]);
					loop_PortDPUTrunkGroup_12State.setDtgn(attributes[22]);
					loop_PortDPUTrunkGroup_12State.setDtli_attr(attributes[23]);
					loop_PortDPUTrunkGroup_12State.setDtli(attributes[24]);
					loop_PortDPUTrunkGroup_12State.setDba_attr(attributes[25]);
					loop_PortDPUTrunkGroup_12State.setDba(attributes[26]);
					loop_PortDPUTrunkGroup_12State.setDblock_attr(attributes[27]);
					loop_PortDPUTrunkGroup_12State.setDblock(attributes[28]);
					loop_PortDPUTrunkGroup_12State.setDpic_attr(attributes[29]);
					loop_PortDPUTrunkGroup_12State.setDpic(attributes[30]);
					loop_PortDPUTrunkGroup_12State.setDlpic_attr(attributes[31]);
					loop_PortDPUTrunkGroup_12State.setDlpic(attributes[32]);
					loop_PortDPUTrunkGroup_12State.setDrti_attr(attributes[33]);
					loop_PortDPUTrunkGroup_12State.setDrti(attributes[34]);
					loop_PortDPUTrunkGroup_12State.setDgout_attr(attributes[35]);
					loop_PortDPUTrunkGroup_12State.setDgout(attributes[36]);
					loop_PortDPUTrunkGroup_12State.setDpulse_attr(attributes[37]);
					loop_PortDPUTrunkGroup_12State.setDpulse(attributes[38]);
					loop_PortDPUTrunkGroup_12State.setDsgnl_attr(attributes[39]);
					loop_PortDPUTrunkGroup_12State.setDsgnl(attributes[40]);
					loop_PortDPUTrunkGroup_12State.setNba_attr(attributes[41]);
					loop_PortDPUTrunkGroup_12State.setNba(attributes[42]);
					loop_PortDPUTrunkGroup_12State.setNbank1_attr(attributes[43]);
					loop_PortDPUTrunkGroup_12State.setNbank1(attributes[44]);
					loop_PortDPUTrunkGroup_12State.setNbank2_attr(attributes[45]);
					loop_PortDPUTrunkGroup_12State.setNbank2(attributes[46]);
					loop_PortDPUTrunkGroup_12State.setNbank3_attr(attributes[47]);
					loop_PortDPUTrunkGroup_12State.setNbank3(attributes[48]);
					loop_PortDPUTrunkGroup_12State.setNbank4_attr(attributes[49]);
					loop_PortDPUTrunkGroup_12State.setNbank4(attributes[50]);
					loop_PortDPUTrunkGroup_12State.setDstnact_attr(attributes[51]);
					loop_PortDPUTrunkGroup_12State.setDstnact(attributes[52]);
					loop_PortDPUTrunkGroup_12State.setDstnq_attr(attributes[53]);
					loop_PortDPUTrunkGroup_12State.setDstnq(attributes[54]);
					loop_PortDPUTrunkGroup_12State.setDstn1_attr(attributes[55]);
					loop_PortDPUTrunkGroup_12State.setDstn1(attributes[56]);
					loop_PortDPUTrunkGroup_12State.setDstn2_attr(attributes[57]);
					loop_PortDPUTrunkGroup_12State.setDstn2(attributes[58]);
					loop_PortDPUTrunkGroup_12State.setDstn3_attr(attributes[59]);
					loop_PortDPUTrunkGroup_12State.setDstn3(attributes[60]);
					loop_PortDPUTrunkGroup_12State.setDstn4_attr(attributes[61]);
					loop_PortDPUTrunkGroup_12State.setDstn4(attributes[62]);
					loop_PortDPUTrunkGroup_12State.setDstn5_attr(attributes[63]);
					loop_PortDPUTrunkGroup_12State.setDstn5(attributes[64]);
					loop_PortDPUTrunkGroup_12State.setLnum_attr(attributes[65]);
					loop_PortDPUTrunkGroup_12State.setLnum(attributes[66]);
					loop_PortDPUTrunkGroup_12State.setLna_attr(attributes[67]);
					loop_PortDPUTrunkGroup_12State.setLna(attributes[68]);
					loop_PortDPUTrunkGroup_12State.setTns_attr(attributes[69]);
					loop_PortDPUTrunkGroup_12State.setTns(attributes[70]);
					loop_PortDPUTrunkGroup_12State.setTers_attr(attributes[71]);
					loop_PortDPUTrunkGroup_12State.setTers(attributes[72]);
					loop_PortDPUTrunkGroup_12State.setOtn_attr(attributes[73]);
					loop_PortDPUTrunkGroup_12State.setOtn(attributes[74]);
					loop_PortDPUTrunkGroup_12State.setLtgn_attr(attributes[75]);
					loop_PortDPUTrunkGroup_12State.setLtgn(attributes[76]);
					loop_PortDPUTrunkGroup_12State.setNc_attr(attributes[77]);
					loop_PortDPUTrunkGroup_12State.setNc(attributes[78]);
					loop_PortDPUTrunkGroup_12State.setNci_attr(attributes[79]);
					loop_PortDPUTrunkGroup_12State.setNci(attributes[80]);
					loop_PortDPUTrunkGroup_12State.setEcckt_attr(attributes[81]);
					loop_PortDPUTrunkGroup_12State.setEcckt(attributes[82]);
					loop_PortDPUTrunkGroup_12State.setCfa_attr(attributes[83]);
					loop_PortDPUTrunkGroup_12State.setCfa(attributes[84]);
					loop_PortDPUTrunkGroup_12State.setCcea_attr(attributes[85]);
					loop_PortDPUTrunkGroup_12State.setCcea(attributes[86]);
					loop_PortDPUTrunkGroup_12State.setCkr_attr(attributes[87]);
					loop_PortDPUTrunkGroup_12State.setCkr(attributes[88]);
					loop_PortDPUTrunkGroup_12State.setPic_attr(attributes[89]);
					loop_PortDPUTrunkGroup_12State.setPic(attributes[90]);
					loop_PortDPUTrunkGroup_12State.setLpic_attr(attributes[91]);
					loop_PortDPUTrunkGroup_12State.setLpic(attributes[92]);
					loop_PortDPUTrunkGroup_12State.setSsig_attr(attributes[93]);
					loop_PortDPUTrunkGroup_12State.setSsig(attributes[94]);
					loop_PortDPUTrunkGroup_12State.setBa_attr(attributes[95]);
					loop_PortDPUTrunkGroup_12State.setBa(attributes[96]);
					loop_PortDPUTrunkGroup_12State.setBlock_attr(attributes[97]);
					loop_PortDPUTrunkGroup_12State.setBlock(attributes[98]);
					loop_PortDPUTrunkGroup_12State.setTsp_attr(attributes[99]);
					loop_PortDPUTrunkGroup_12State.setTsp(attributes[100]);
					loop_PortDPUTrunkGroup_12State.setJk_code_attr(attributes[101]);
					loop_PortDPUTrunkGroup_12State.setJk_code(attributes[102]);
					loop_PortDPUTrunkGroup_12State.setJk_num_attr(attributes[103]);
					loop_PortDPUTrunkGroup_12State.setJk_num(attributes[104]);
					loop_PortDPUTrunkGroup_12State.setJk_pos_attr(attributes[105]);
					loop_PortDPUTrunkGroup_12State.setJk_pos(attributes[106]);
					loop_PortDPUTrunkGroup_12State.setJr_attr(attributes[107]);
					loop_PortDPUTrunkGroup_12State.setJr(attributes[108]);
					loop_PortDPUTrunkGroup_12State.setNidr_attr(attributes[109]);
					loop_PortDPUTrunkGroup_12State.setNidr(attributes[110]);
					loop_PortDPUTrunkGroup_12State.setIwjk1_attr(attributes[111]);
					loop_PortDPUTrunkGroup_12State.setIwjk1(attributes[112]);
					loop_PortDPUTrunkGroup_12State.setIwjk2_attr(attributes[113]);
					loop_PortDPUTrunkGroup_12State.setIwjk2(attributes[114]);
					loop_PortDPUTrunkGroup_12State.setIwjk3_attr(attributes[115]);
					loop_PortDPUTrunkGroup_12State.setIwjk3(attributes[116]);
					loop_PortDPUTrunkGroup_12State.setIwjk4_attr(attributes[117]);
					loop_PortDPUTrunkGroup_12State.setIwjk4(attributes[118]);
					loop_PortDPUTrunkGroup_12State.setIwjk5_attr(attributes[119]);
					loop_PortDPUTrunkGroup_12State.setIwjk5(attributes[120]);
					loop_PortDPUTrunkGroup_12State.setIwjq1_attr(attributes[121]);
					loop_PortDPUTrunkGroup_12State.setIwjq1(attributes[122]);
					loop_PortDPUTrunkGroup_12State.setIwjq2_attr(attributes[123]);
					loop_PortDPUTrunkGroup_12State.setIwjq2(attributes[124]);
					loop_PortDPUTrunkGroup_12State.setIwjq3_attr(attributes[125]);
					loop_PortDPUTrunkGroup_12State.setIwjq3(attributes[126]);
					loop_PortDPUTrunkGroup_12State.setIwjq4_attr(attributes[127]);
					loop_PortDPUTrunkGroup_12State.setIwjq4(attributes[128]);
					loop_PortDPUTrunkGroup_12State.setIwjq5_attr(attributes[129]);
					loop_PortDPUTrunkGroup_12State.setIwjq5(attributes[130]);
					loop_PortDPUTrunkGroup_12State.setNpi_trnk_attr(attributes[131]);
					loop_PortDPUTrunkGroup_12State.setNpi_trnk(attributes[132]);

					// resaleprivatelinecircuit12states.setScreenName("Circut");

					treeViewList1_642.add(loop_PortDPUTrunkGroup_12State);

					// System.out.println("loop_PortDPUTrunkGroup_12State: " +
					// loop_PortDPUTrunkGroup_12State);
				}
				session.setAttribute("treeViewList1_642", treeViewList1_642);
				selectRequestData.setSubHeader(receivedSubHeader);
				// selectRequestData.setSelectRequestTableRows(selectRequestTableRows);
			}

			// 12-State- DID/PBX Port DPU Trunk

			if (subData_641Recid != null && subData_641Recid.getSubHeader().getRecord_type().equals("641")) {

				SubHeader receivedSubHeader = subData_641Recid.getSubHeader();
				String[] subDataRows = subData_641Recid.getSubDataRows();

				List<PortDPUTrunk_12state> treeViewList1_641 = new ArrayList();
				treeViewList.add("641");
				// int i = 0;
				for (String subDataRow : subDataRows) {
					String[] attributes = mqReadUtil.getAttributes(subDataRow, 133);
					// System.out.println("attributes:=======> " + Arrays.toString(attributes));
					PortDPUTrunk_12state loop_PortDPUTrunkGroup_12State = new PortDPUTrunk_12state();
					loop_PortDPUTrunkGroup_12State.setItem_num(attributes[0]);
					loop_PortDPUTrunkGroup_12State.setDidnum_attr(attributes[1]);
					loop_PortDPUTrunkGroup_12State.setDidnum(attributes[2]);
					loop_PortDPUTrunkGroup_12State.setDidind_attr(attributes[3]);
					loop_PortDPUTrunkGroup_12State.setDidind(attributes[4]);
					loop_PortDPUTrunkGroup_12State.setDtnract_attr(attributes[5]);
					loop_PortDPUTrunkGroup_12State.setDtnract(attributes[6]);
					loop_PortDPUTrunkGroup_12State.setDtnrq_attr(attributes[7]);
					loop_PortDPUTrunkGroup_12State.setDtnrq(attributes[8]);
					loop_PortDPUTrunkGroup_12State.setDtnr1_attr(attributes[9]);
					loop_PortDPUTrunkGroup_12State.setDtnr1(attributes[10]);
					loop_PortDPUTrunkGroup_12State.setDtnr2_attr(attributes[11]);
					loop_PortDPUTrunkGroup_12State.setDtnr2(attributes[12]);
					loop_PortDPUTrunkGroup_12State.setDtnr3_attr(attributes[13]);
					loop_PortDPUTrunkGroup_12State.setDtnr3(attributes[14]);
					loop_PortDPUTrunkGroup_12State.setNpi_attr(attributes[15]);
					loop_PortDPUTrunkGroup_12State.setNpi(attributes[16]);
					loop_PortDPUTrunkGroup_12State.setDidr_attr(attributes[17]);
					loop_PortDPUTrunkGroup_12State.setDidr(attributes[18]);
					loop_PortDPUTrunkGroup_12State.setDtkact_attr(attributes[19]);
					loop_PortDPUTrunkGroup_12State.setDtkact(attributes[20]);
					loop_PortDPUTrunkGroup_12State.setDtgn_attr(attributes[21]);
					loop_PortDPUTrunkGroup_12State.setDtgn(attributes[22]);
					loop_PortDPUTrunkGroup_12State.setDtli_attr(attributes[23]);
					loop_PortDPUTrunkGroup_12State.setDtli(attributes[24]);
					loop_PortDPUTrunkGroup_12State.setDba_attr(attributes[25]);
					loop_PortDPUTrunkGroup_12State.setDba(attributes[26]);
					loop_PortDPUTrunkGroup_12State.setDblock_attr(attributes[27]);
					loop_PortDPUTrunkGroup_12State.setDblock(attributes[28]);
					loop_PortDPUTrunkGroup_12State.setDpic_attr(attributes[29]);
					loop_PortDPUTrunkGroup_12State.setDpic(attributes[30]);
					loop_PortDPUTrunkGroup_12State.setDlpic_attr(attributes[31]);
					loop_PortDPUTrunkGroup_12State.setDlpic(attributes[32]);
					loop_PortDPUTrunkGroup_12State.setDrti_attr(attributes[33]);
					loop_PortDPUTrunkGroup_12State.setDrti(attributes[34]);
					loop_PortDPUTrunkGroup_12State.setDgout_attr(attributes[35]);
					loop_PortDPUTrunkGroup_12State.setDgout(attributes[36]);
					loop_PortDPUTrunkGroup_12State.setDpulse_attr(attributes[37]);
					loop_PortDPUTrunkGroup_12State.setDpulse(attributes[38]);
					loop_PortDPUTrunkGroup_12State.setDsgnl_attr(attributes[39]);
					loop_PortDPUTrunkGroup_12State.setDsgnl(attributes[40]);
					loop_PortDPUTrunkGroup_12State.setNba_attr(attributes[41]);
					loop_PortDPUTrunkGroup_12State.setNba(attributes[42]);
					loop_PortDPUTrunkGroup_12State.setNbank1_attr(attributes[43]);
					loop_PortDPUTrunkGroup_12State.setNbank1(attributes[44]);
					loop_PortDPUTrunkGroup_12State.setNbank2_attr(attributes[45]);
					loop_PortDPUTrunkGroup_12State.setNbank2(attributes[46]);
					loop_PortDPUTrunkGroup_12State.setNbank3_attr(attributes[47]);
					loop_PortDPUTrunkGroup_12State.setNbank3(attributes[48]);
					loop_PortDPUTrunkGroup_12State.setNbank4_attr(attributes[49]);
					loop_PortDPUTrunkGroup_12State.setNbank4(attributes[50]);
					loop_PortDPUTrunkGroup_12State.setDstnact_attr(attributes[51]);
					loop_PortDPUTrunkGroup_12State.setDstnact(attributes[52]);
					loop_PortDPUTrunkGroup_12State.setDstnq_attr(attributes[53]);
					loop_PortDPUTrunkGroup_12State.setDstnq(attributes[54]);
					loop_PortDPUTrunkGroup_12State.setDstn1_attr(attributes[55]);
					loop_PortDPUTrunkGroup_12State.setDstn1(attributes[56]);
					loop_PortDPUTrunkGroup_12State.setDstn2_attr(attributes[57]);
					loop_PortDPUTrunkGroup_12State.setDstn2(attributes[58]);
					loop_PortDPUTrunkGroup_12State.setDstn3_attr(attributes[59]);
					loop_PortDPUTrunkGroup_12State.setDstn3(attributes[60]);
					loop_PortDPUTrunkGroup_12State.setDstn4_attr(attributes[61]);
					loop_PortDPUTrunkGroup_12State.setDstn4(attributes[62]);
					loop_PortDPUTrunkGroup_12State.setDstn5_attr(attributes[63]);
					loop_PortDPUTrunkGroup_12State.setDstn5(attributes[64]);
					;
					loop_PortDPUTrunkGroup_12State.setLnum_attr(attributes[65]);
					loop_PortDPUTrunkGroup_12State.setLnum(attributes[66]);
					loop_PortDPUTrunkGroup_12State.setLna_attr(attributes[67]);
					loop_PortDPUTrunkGroup_12State.setLna(attributes[68]);
					loop_PortDPUTrunkGroup_12State.setTns_attr(attributes[69]);

					loop_PortDPUTrunkGroup_12State.setTns(attributes[70]);
					loop_PortDPUTrunkGroup_12State.setTers_attr(attributes[71]);
					loop_PortDPUTrunkGroup_12State.setTers(attributes[72]);
					loop_PortDPUTrunkGroup_12State.setOtn_attr(attributes[73]);
					loop_PortDPUTrunkGroup_12State.setOtn(attributes[74]);
					loop_PortDPUTrunkGroup_12State.setLtgn_attr(attributes[75]);
					loop_PortDPUTrunkGroup_12State.setLtgn(attributes[76]);
					loop_PortDPUTrunkGroup_12State.setNc_attr(attributes[77]);
					loop_PortDPUTrunkGroup_12State.setNc(attributes[78]);
					loop_PortDPUTrunkGroup_12State.setNci_attr(attributes[79]);
					loop_PortDPUTrunkGroup_12State.setNci(attributes[80]);
					loop_PortDPUTrunkGroup_12State.setEcckt_attr(attributes[81]);
					loop_PortDPUTrunkGroup_12State.setEcckt(attributes[82]);
					loop_PortDPUTrunkGroup_12State.setCfa_attr(attributes[83]);
					loop_PortDPUTrunkGroup_12State.setCfa(attributes[84]);
					loop_PortDPUTrunkGroup_12State.setCcea_attr(attributes[85]);
					loop_PortDPUTrunkGroup_12State.setCcea(attributes[86]);
					loop_PortDPUTrunkGroup_12State.setCkr_attr(attributes[87]);
					loop_PortDPUTrunkGroup_12State.setCkr(attributes[88]);
					loop_PortDPUTrunkGroup_12State.setPic_attr(attributes[89]);
					loop_PortDPUTrunkGroup_12State.setPic(attributes[90]);
					loop_PortDPUTrunkGroup_12State.setLpic_attr(attributes[91]);
					loop_PortDPUTrunkGroup_12State.setLpic(attributes[92]);
					loop_PortDPUTrunkGroup_12State.setSsig_attr(attributes[93]);
					loop_PortDPUTrunkGroup_12State.setSsig(attributes[94]);
					loop_PortDPUTrunkGroup_12State.setBa_attr(attributes[95]);
					loop_PortDPUTrunkGroup_12State.setBa(attributes[96]);
					loop_PortDPUTrunkGroup_12State.setBlock_attr(attributes[97]);
					loop_PortDPUTrunkGroup_12State.setBlock(attributes[98]);
					loop_PortDPUTrunkGroup_12State.setTsp_attr(attributes[99]);
					loop_PortDPUTrunkGroup_12State.setTsp(attributes[100]);
					loop_PortDPUTrunkGroup_12State.setJk_code_attr(attributes[101]);
					loop_PortDPUTrunkGroup_12State.setJk_code(attributes[102]);
					loop_PortDPUTrunkGroup_12State.setJk_num_attr(attributes[103]);
					loop_PortDPUTrunkGroup_12State.setJk_num(attributes[104]);
					loop_PortDPUTrunkGroup_12State.setJk_pos_attr(attributes[105]);
					loop_PortDPUTrunkGroup_12State.setJk_pos(attributes[106]);
					loop_PortDPUTrunkGroup_12State.setJr_attr(attributes[107]);
					loop_PortDPUTrunkGroup_12State.setJr(attributes[108]);
					loop_PortDPUTrunkGroup_12State.setNidr_attr(attributes[109]);
					loop_PortDPUTrunkGroup_12State.setNidr(attributes[110]);
					loop_PortDPUTrunkGroup_12State.setIwjk1_attr(attributes[111]);
					loop_PortDPUTrunkGroup_12State.setIwjk1(attributes[112]);
					loop_PortDPUTrunkGroup_12State.setIwjk2_attr(attributes[113]);
					loop_PortDPUTrunkGroup_12State.setIwjk2(attributes[114]);
					loop_PortDPUTrunkGroup_12State.setIwjk3_attr(attributes[115]);
					loop_PortDPUTrunkGroup_12State.setIwjk3(attributes[116]);
					loop_PortDPUTrunkGroup_12State.setIwjk4_attr(attributes[117]);
					loop_PortDPUTrunkGroup_12State.setIwjk4(attributes[118]);
					loop_PortDPUTrunkGroup_12State.setIwjk5_attr(attributes[119]);
					loop_PortDPUTrunkGroup_12State.setIwjk5(attributes[120]);
					loop_PortDPUTrunkGroup_12State.setIwjq1_attr(attributes[121]);
					loop_PortDPUTrunkGroup_12State.setIwjq1(attributes[122]);
					loop_PortDPUTrunkGroup_12State.setIwjq2_attr(attributes[123]);
					loop_PortDPUTrunkGroup_12State.setIwjq2(attributes[124]);
					loop_PortDPUTrunkGroup_12State.setIwjq3_attr(attributes[125]);
					loop_PortDPUTrunkGroup_12State.setIwjq3(attributes[126]);
					loop_PortDPUTrunkGroup_12State.setIwjq4_attr(attributes[127]);
					loop_PortDPUTrunkGroup_12State.setIwjq4(attributes[128]);
					loop_PortDPUTrunkGroup_12State.setIwjq5_attr(attributes[129]);
					loop_PortDPUTrunkGroup_12State.setIwjq5(attributes[130]);
					loop_PortDPUTrunkGroup_12State.setNpi_trnk_attr(attributes[131]);
					loop_PortDPUTrunkGroup_12State.setNpi_trnk(attributes[132]);

					// resaleprivatelinecircuit12states.setScreenName("Circut");

					treeViewList1_641.add(loop_PortDPUTrunkGroup_12State);
					// System.out.println("loop_PortDPUTrunkGroup_12State :" +
					// loop_PortDPUTrunkGroup_12State);
				}
				session.setAttribute("treeViewList1_641", treeViewList1_641);
				selectRequestData.setSubHeader(receivedSubHeader);

				// selectRequestData.setSelectRequestTableRows(selectRequestTableRows);
			}

			// 12-StateDID/PBX Loop w/ Port DPU Trunk Group TGRP Disc/TC -reqtype-W 212
			// (left Screen)
			if (subData_212Recid != null && subData_212Recid.getSubHeader().getRecord_type().equals("212")) {

				SubHeader receivedSubHeader = subData_212Recid.getSubHeader();
				String[] subDataRows = subData_212Recid.getSubDataRows();
				List<PortDPUTrunkGroupTGRPDisc_12state> treeViewList_212 = new ArrayList<>();
				treeViewList.add("212");

				// int i = 0;
				for (String subDataRow : subDataRows) {
					String[] attributes = mqReadUtil.getAttributes(subDataRow, 13);
					// System.out.println("attributes 212:=======> " + Arrays.toString(attributes));
					PortDPUTrunkGroupTGRPDisc_12state loop_PortDPUTrunkGroupTGRPDisc_12state_ReqW = new PortDPUTrunkGroupTGRPDisc_12state();
					loop_PortDPUTrunkGroupTGRPDisc_12state_ReqW.setItem_num(attributes[0]);
					loop_PortDPUTrunkGroupTGRPDisc_12state_ReqW.setDidnum_attr(attributes[1]);
					loop_PortDPUTrunkGroupTGRPDisc_12state_ReqW.setDidnum(attributes[2]);
					loop_PortDPUTrunkGroupTGRPDisc_12state_ReqW.setTg_tc_opt_attr(attributes[3]);
					loop_PortDPUTrunkGroupTGRPDisc_12state_ReqW.setTg_tc_opt(attributes[4]);
					loop_PortDPUTrunkGroupTGRPDisc_12state_ReqW.setTg_tc_per_attr(attributes[5]);
					loop_PortDPUTrunkGroupTGRPDisc_12state_ReqW.setTg_tc_per(attributes[6]);
					loop_PortDPUTrunkGroupTGRPDisc_12state_ReqW.setTg_tc_to_pri_attr(attributes[7]);
					loop_PortDPUTrunkGroupTGRPDisc_12state_ReqW.setTg_tc_to_pri(FormatUtil.getTelephoneNumberWithDashes(attributes[8] != null && attributes[8] != "" ? attributes[8] : " "));// supriya changes for date format
					loop_PortDPUTrunkGroupTGRPDisc_12state_ReqW.setTg_tc_name_pri_attr(attributes[9]);
					loop_PortDPUTrunkGroupTGRPDisc_12state_ReqW.setTg_tc_name_pri(attributes[10]);
					loop_PortDPUTrunkGroupTGRPDisc_12state_ReqW.setTg_tc_id_attr(attributes[11]);
					loop_PortDPUTrunkGroupTGRPDisc_12state_ReqW.setTg_tc_id_pri(attributes[12]);

					// resaleprivatelinecircuit12states.setScreenName("Circut");
					// System.out.println(
					// "PortDPUTrunkGroupTGRPDisc_12state :" +
					// loop_PortDPUTrunkGroupTGRPDisc_12state_ReqW);
					treeViewList_212.add(loop_PortDPUTrunkGroupTGRPDisc_12state_ReqW);
				}
				session.setAttribute("treeViewList_212", treeViewList_212);
				selectRequestData.setSubHeader(receivedSubHeader);
				// selectRequestData.setSelectRequestTableRows(selectRequestTableRows);
			}

			// 12-StateDID/PBX Loop w/ Port DPU Trunk Group TGRP Disc/TC -reqtype-W 213
			// (right Screen)
			if (subData_213Recid != null && subData_213Recid.getSubHeader().getRecord_type().equals("213")) {

				SubHeader receivedSubHeader = subData_213Recid.getSubHeader();
				String[] subDataRows = subData_213Recid.getSubDataRows();
				List<PortDPUTrunkGroupTGRPDiscTable_12state> treeViewList_213 = new ArrayList<>();
				treeViewList.add("213");

				// int i = 0;
				for (String subDataRow : subDataRows) {
					String[] attributes = mqReadUtil.getAttributes(subDataRow, 13);
					// System.outut.println("attributes 213:=======> " +
					// Arrays.toString(attributes));
					PortDPUTrunkGroupTGRPDiscTable_12state portDPUTrunkGroupTGRPDiscTable_12state = new PortDPUTrunkGroupTGRPDiscTable_12state();
					portDPUTrunkGroupTGRPDiscTable_12state.setItem_num(attributes[0]);
					portDPUTrunkGroupTGRPDiscTable_12state.setTg_tc_id_sec_attr(attributes[1]);
					portDPUTrunkGroupTGRPDiscTable_12state.setTg_tc_id_sec(attributes[2]);
					portDPUTrunkGroupTGRPDiscTable_12state.setTg_tc_to_sec_attr(attributes[3]);
					portDPUTrunkGroupTGRPDiscTable_12state.setTg_tc_to_sec(attributes[4]);
					portDPUTrunkGroupTGRPDiscTable_12state.setTg_tc_name_sec_attr(attributes[5]);
					portDPUTrunkGroupTGRPDiscTable_12state.setTg_tc_name_sec(attributes[6]);

					// resaleprivatelinecircuit12states.setScreenName("Circut");

					treeViewList_213.add(portDPUTrunkGroupTGRPDiscTable_12state);
				}
				session.setAttribute("treeViewList_213", treeViewList_213);
				selectRequestData.setSubHeader(receivedSubHeader);
				// selectRequestData.setSelectRequestTableRows(selectRequestTableRows);
			}
			// Rejashekhar
			if (subData_602Recid != null && subData_602Recid.getSubHeader().getRecord_type().equals("602")) {

				List<FatalErrors12state> treeViewList_602 = new ArrayList<>();
				treeViewList.add("602");
				SubHeader receivedSubHeader = subData_602Recid.getSubHeader();
				String[] subDataRows = subData_602Recid.getSubDataRows();
				for (String subDataRow : subDataRows) {
					String[] attributes = mqReadUtil.getAttributes(subDataRow, 13);
					// System.out.println("attributes:=602:Reqid======> " +
					// Arrays.toString(attributes));
					FatalErrors12state fatalErrors12state = new FatalErrors12state();
					fatalErrors12state.setCver(attributes[0]);
					fatalErrors12state.setResponse_type(attributes[1]);
					fatalErrors12state.setEcver(attributes[2]);
					fatalErrors12state.setDt_sent_local(attributes[3]);
					fatalErrors12state.setResponse_dt_sent_central_time(attributes[4]);
					fatalErrors12state.setField_name(attributes[5]);
					fatalErrors12state.setItem_num(attributes[6]);
					fatalErrors12state.setLnum(attributes[7]);
					fatalErrors12state.setNum_name(attributes[8]);
					fatalErrors12state.setNum_nbr(attributes[9]);
					fatalErrors12state.setLeg_num(attributes[10]);
					fatalErrors12state.setError_code(attributes[11]);
					fatalErrors12state.setError_message(attributes[12]);

					treeViewList_602.add(fatalErrors12state);
				}
				selectRequestData.setSubHeader(receivedSubHeader);
				// selectRequestData.setSelectRequestTableRows(selectRequestTableRows);
				// System.out.println("++++treeViewList_602+++before session+++" +
				// treeViewList_602);
				session.setAttribute("treeViewList_602", treeViewList_602);
			}

			if (subData_530Recid != null && subData_530Recid.getSubHeader().getRecord_type().equals("530")) {

				List<NotesFup> treeViewList_530 = new ArrayList<>();
				treeViewList.add("530");
				SubHeader receivedSubHeader = subData_530Recid.getSubHeader();
				String[] subDataRows = subData_530Recid.getSubDataRows();
				for (String subDataRow : subDataRows) {
					String[] attributes = mqReadUtil.getAttributes(subDataRow, 17);
					// System.out.println("attributes:=530:Reqid======> " +
					// Arrays.toString(attributes));
					NotesFup notesFup = new NotesFup();
					notesFup.setWorked_ind_attr(attributes[0]);
					notesFup.setWorked_ind(attributes[1]);
					notesFup.setCancel_ind_attr(attributes[2]);
					notesFup.setCancel_ind(attributes[3]);
					notesFup.setNotes_datetime(attributes[4]);
					notesFup.setUser_id_attr(attributes[5]);
					notesFup.setUser_id(attributes[6]);
					notesFup.setLasr_ver_attr(attributes[7]);
					notesFup.setLasr_ver(attributes[8]);
					notesFup.setFollow_up_date_attr(attributes[9]);
					notesFup.setFollow_up_date(FormatUtil.getMqDateToViewString(attributes[10] != null && attributes[10] != "" ? attributes[10] : " "));// supriya changes for date format		
					notesFup.setFup_worked_date_attr(attributes[11]);
					notesFup.setFup_worked_date(FormatUtil.getMqDateToViewString(attributes[12] != null && attributes[12] != "" ? attributes[12] : " "));// supriya changes for date format
					notesFup.setFup_end_date_attr(attributes[13]);
					notesFup.setFup_end_date(FormatUtil.getMqDateToViewString(attributes[14] != null && attributes[14] != "" ? attributes[14] : " "));// supriya changes for date format		
					notesFup.setNotes_attr(attributes[15]);
					notesFup.setNotes(attributes[16]);

					treeViewList_530.add(notesFup);

				}
				selectRequestData.setSubHeader(receivedSubHeader);
				// selectRequestData.setSelectRequestTableRows(selectRequestTableRows);
				// System.out.println("++++treeViewList_530+++before session+++" +
				// treeViewList_530);
				session.setAttribute("treeViewList_530", treeViewList_530);
			}

			/* NP12states 12 state screen get data treeviwe Recid-250-LSR- */

			if (subData_250Recid != null && subData_250Recid.getSubHeader().getRecord_type().equals("250")) {

				List<NP12states> treeViewList_250 = new ArrayList<>();
				treeViewList.add("250");
				SubHeader receivedSubHeader = subData_250Recid.getSubHeader();
				String[] subDataRows = subData_250Recid.getSubDataRows();
				for (String subDataRow : subDataRows) {
					String[] attributes = mqReadUtil.getAttributes(subDataRow, 143);
					// System.out.println("attributes:=250:Reqid======> " +
					// Arrays.toString(attributes));
					NP12states np12states = new NP12states();
					np12states.setItem_num(attributes[0]);
					np12states.setLnum_attr(attributes[1]);
					np12states.setLnum(attributes[2]);
					np12states.setLna_attr(attributes[3]);
					np12states.setLna(attributes[4]);
					np12states.setLmt_attr(attributes[5]);
					np12states.setLmt(attributes[6]);
					np12states.setEcckt_attr(attributes[7]);
					np12states.setEcckt(attributes[8]);
					np12states.setShared_nbr_attr(attributes[9]);
					np12states.setShared_nbr(attributes[10]);
					np12states.setDisc_nbr_attr(attributes[11]);
					np12states.setDisc_nbr(attributes[12]);
					np12states.setTers_attr(attributes[13]);
					np12states.setTers(attributes[14]);
					np12states.setCfa_attr(attributes[15]);
					np12states.setCfa(attributes[16]);
					np12states.setCcea_attr(attributes[17]);
					np12states.setCcea(attributes[18]);
					np12states.setSscfa_attr(attributes[19]);
					np12states.setSscfa(attributes[20]);
					np12states.setCableid_attr(attributes[21]);
					np12states.setCableid(attributes[22]);
					np12states.setChan_pair3_attr(attributes[23]);
					np12states.setChan_pair3(attributes[24]);
					np12states.setSystemid_attr(attributes[25]);
					np12states.setSystemid(attributes[26]);
					np12states.setCbcid_attr(attributes[27]);
					np12states.setCbcid(attributes[28]);
					np12states.setChan_pair_attr(attributes[29]);
					np12states.setChan_pair(attributes[30]);
					np12states.setCbcid2_attr(attributes[31]);
					np12states.setCbcid2(attributes[32]);
					np12states.setChan_pair2_attr(attributes[33]);
					np12states.setChan_pair2(attributes[34]);
					np12states.setCti_attr(attributes[35]);
					np12states.setCti(attributes[36]);
					np12states.setRelay_rack_attr(attributes[37]);
					np12states.setRelay_rack(attributes[38]);
					np12states.setShelf_attr(attributes[39]);
					np12states.setShelf(attributes[40]);
					np12states.setSlot_attr(attributes[41]);
					np12states.setSlot(attributes[42]);
					np12states.setCti2_attr(attributes[43]);
					np12states.setCti2(attributes[44]);
					np12states.setRelay_rack2_attr(attributes[45]);
					np12states.setRelay_rack2(attributes[46]);
					np12states.setShelf2_attr(attributes[47]);
					np12states.setShelf2(attributes[48]);
					np12states.setSlot2_attr(attributes[49]);
					np12states.setSlot2(attributes[50]);
					np12states.setCti3_attr(attributes[51]);
					np12states.setCti3(attributes[52]);
					np12states.setRelay_rack3_attr(attributes[53]);
					np12states.setRelay_rack3(attributes[54]);
					np12states.setShelf3_attr(attributes[55]);
					np12states.setShelf3(attributes[56]);
					np12states.setSlot3_attr(attributes[57]);
					np12states.setSlot3(attributes[58]);
					np12states.setCti4_attr(attributes[59]);
					np12states.setCti(attributes[60]);
					np12states.setRelay_rack4_attr(attributes[61]);
					np12states.setRelay_rack4(attributes[62]);
					np12states.setShelf4_attr(attributes[63]);
					np12states.setShelf4(attributes[64]);
					np12states.setSlot4_attr(attributes[65]);
					np12states.setSlot4(attributes[66]);
					np12states.setVpi_attr(attributes[67]);
					np12states.setVpi(attributes[68]);
					np12states.setVci_attr(attributes[69]);
					np12states.setVci(attributes[70]);
					np12states.setCode_set_attr(attributes[71]);
					np12states.setCode_set(attributes[72]);
					np12states.setRecckt_attr(attributes[73]);
					np12states.setRecckt(attributes[74]);
					np12states.setCkr_attr(attributes[75]);
					np12states.setCkr(attributes[76]);
					np12states.setTsp_attr(attributes[77]);
					np12states.setTsp(attributes[78]);
					np12states.setPorted_nbr_attr(attributes[79]);
					np12states.setPorted_nbr(attributes[80]);
					np12states.setNpt_attr(attributes[81]);
					np12states.setNpt(attributes[82]);
					np12states.setRti_attr(attributes[83]);
					np12states.setRti(attributes[84]);
					np12states.setNptg_attr(attributes[85]);
					np12states.setNptg(attributes[86]);
					np12states.setNpi_attr(attributes[87]);
					np12states.setNpi(attributes[88]);
					np12states.setLst_attr(attributes[89]);
					np12states.setLst(attributes[90]);
					np12states.setTns_attr(attributes[91]);
					np12states.setTns(attributes[92]);
					np12states.setOtn_attr(attributes[93]);
					np12states.setOtn(attributes[94]);
					np12states.setIspid_attr(attributes[95]);
					np12states.setIspid(attributes[96]);
					np12states.setPic_attr(attributes[97]);
					np12states.setPic(attributes[98]);
					np12states.setLpic_attr(attributes[99]);
					np12states.setLpic(attributes[100]);
					np12states.setSsig_attr(attributes[101]);
					np12states.setSsig(attributes[102]);
					np12states.setBa_attr(attributes[103]);
					np12states.setBa(attributes[104]);
					np12states.setBlock_attr(attributes[105]);
					np12states.setBlock(attributes[106]);
					np12states.setJk_code_attr(attributes[107]);
					np12states.setJk_code(attributes[108]);
					np12states.setJk_num_attr(attributes[109]);
					np12states.setJk_num(attributes[110]);
					np12states.setJk_pos_attr(attributes[111]);
					np12states.setJk_pos(attributes[112]);
					np12states.setJr_attr(attributes[113]);
					np12states.setJr(attributes[114]);
					np12states.setNidr_attr(attributes[115]);
					np12states.setNidr(attributes[116]);
					np12states.setIwjk1_attr(attributes[117]);
					np12states.setIwjk1(attributes[118]);
					np12states.setIwjk2_attr(attributes[119]);
					np12states.setIwjk2(attributes[120]);
					np12states.setIwjk3_attr(attributes[121]);
					np12states.setIwjk3(attributes[122]);
					np12states.setIwjk4_attr(attributes[123]);
					np12states.setIwjk4(attributes[124]);
					np12states.setIwjk5_attr(attributes[125]);
					np12states.setIwjk5(attributes[126]);
					np12states.setIwjq1_attr(attributes[127]);
					np12states.setIwjq1(attributes[128]);
					np12states.setIwjq2_attr(attributes[129]);
					np12states.setIwjq2(attributes[130]);
					np12states.setIwjq3_attr(attributes[131]);
					np12states.setIwjq3(attributes[132]);
					np12states.setIwjq4_attr(attributes[133]);
					np12states.setIwjq4(attributes[134]);
					np12states.setIwjq5_attr(attributes[135]);
					np12states.setIwjq5(attributes[136]);
					np12states.setLidb_attr(attributes[137]);
					np12states.setLidb(attributes[138]);
					np12states.setS_attr(attributes[139]);
					np12states.setS(attributes[140]);
					np12states.setOecckt_attr(attributes[141]);
					np12states.setOecckt(attributes[142]);

					treeViewList_250.add(np12states);
				}
				selectRequestData.setSubHeader(receivedSubHeader);
				// selectRequestData.setSelectRequestTableRows(selectRequestTableRows);
				// System.out.println("++++treeViewList_250+++before session+++" +
				// treeViewList_250);
				session.setAttribute("treeViewList_250", treeViewList_250);
			}

			/* OGerrors 12 state screen get data treeviwe Recid-601-LSR- */

			if (subData_601Recid != null && subData_601Recid.getSubHeader().getRecord_type().equals("601")) {

				List<OGerrors12state> treeViewList_601 = new ArrayList<>();
				treeViewList.add("601");
				SubHeader receivedSubHeader = subData_601Recid.getSubHeader();
				String[] subDataRows = subData_601Recid.getSubDataRows();
				for (String subDataRow : subDataRows) {
					String[] attributes = mqReadUtil.getAttributes(subDataRow, 4);
//					//System.out.println("attributes:=601:Reqid======> " + Arrays.toString(attributes));
					OGerrors12state ogErrors12State = new OGerrors12state();
					ogErrors12State.setOrder_num(attributes[0]);
					ogErrors12State.setLocation(attributes[1]);
					ogErrors12State.setError_code(attributes[2]);
					ogErrors12State.setError_msg(attributes[3]);

					treeViewList_601.add(ogErrors12State);
				}
				selectRequestData.setSubHeader(receivedSubHeader);
				// selectRequestData.setSelectRequestTableRows(selectRequestTableRows);
				// System.out.println("++++treeViewList_601+++before session+++" +
				// treeViewList_601);
				session.setAttribute("treeViewList_601", treeViewList_601);

			}

			// mahendra

			/* AttCancelTask 12States to get TreeView 543-LSR- */
//			 System.out.println("++++subData_543Recid++++++"+subData_543Recid);
			if (subData_543Recid != null && subData_543Recid.getSubHeader().getRecord_type().equals("543")) {
				List<AttCancelTask> treeViewList_543 = new ArrayList();
				SubHeader receivedSubHeader = subData_543Recid.getSubHeader();
				String[] subDataRows = subData_543Recid.getSubDataRows();
				treeViewList.add("543");
				for (String subDataRow : subDataRows) {
					String[] attributes = mqReadUtil.getAttributes(subDataRow, 8);
					// System.out.println("attributes:=543:Reqid======> " +
					// Arrays.toString(attributes));
					AttCancelTask attCancelTask = new AttCancelTask();
					attCancelTask.setOrd(attributes[0]);
					attCancelTask.setOrd_status(attributes[1]);
					attCancelTask.setRcode(attributes[2]);
					attCancelTask.setJcode(attributes[3]);
					attCancelTask.setRdet(attributes[4]);
					attCancelTask.setDt_sent_local(FormatUtil.formatDateTimeString(attributes[5] != null && attributes[5] != "" ? attributes[5] : " "));// supriya changes for date format
					attCancelTask.setDt_sent_central_time(FormatUtil.formatDateTimeString(attributes[6] != null && attributes[6] != "" ? attributes[6] : " "));// supriya changes for date format
		
					treeViewList_543.add(attCancelTask);
				}
				selectRequestData.setSubHeader(receivedSubHeader);
				session.setAttribute("treeViewList_543", treeViewList_543);

			}

			/* Post to BillView 12 state screen get data treeviwe Recid-586-LSR- */

			if (subData_586Recid != null && subData_586Recid.getSubHeader().getRecord_type().equals("586")) {

				List<PostToBillView12states> treeViewList_586 = new ArrayList<>();
				treeViewList.add("586");
				SubHeader receivedSubHeader = subData_586Recid.getSubHeader();
				String[] subDataRows = subData_586Recid.getSubDataRows();
				for (String subDataRow : subDataRows) {
					String[] attributes = mqReadUtil.getAttributes(subDataRow, 12);
					// System.out.println("attributes:=586:Reqid======> " +
					// Arrays.toString(attributes));
					PostToBillView12states postToBillView12states = new PostToBillView12states();
					postToBillView12states.setC_ver_attr(attributes[0]);
					postToBillView12states.setC_ver(attributes[1]);
					postToBillView12states.setRt_attr(attributes[2]);
					postToBillView12states.setRt(attributes[3]);
					postToBillView12states.setEc_ver_attr(attributes[4]);
					postToBillView12states.setEc_ver(attributes[5]);
					postToBillView12states.setDt_sent_local_attr(attributes[6]);
					postToBillView12states.setDt_sent_local(attributes[7]);
					postToBillView12states.setResponse_dt_sent_attr(attributes[8]);
					postToBillView12states.setResponse_dt_sent(attributes[9]);
					postToBillView12states.setPd_attr(attributes[10]);
					postToBillView12states.setPd(attributes[11]);

					treeViewList_586.add(postToBillView12states);
				}
				selectRequestData.setSubHeader(receivedSubHeader);
				// selectRequestData.setSelectRequestTableRows(selectRequestTableRows);
				// System.out.println("++++treeViewList_586+++before session+++" +
				// treeViewList_586);
				session.setAttribute("treeViewList_586", treeViewList_586);
			}

			/*
			 * Remark12 state screen get data treeviwe Recid-065-LSR-20210503L00002
			 */

			if (subData_065Recid != null && subData_065Recid.getSubHeader().getRecord_type().equals("065")) {

				List<Remarks12states> treeViewList_065 = new ArrayList<>();
				treeViewList.add("065");

				SubHeader receivedSubHeader = subData_065Recid.getSubHeader();
				String[] subDataRows = subData_065Recid.getSubDataRows();
				for (String subDataRow : subDataRows) {
					String[] attributes = mqReadUtil.getAttributes(subDataRow, 2);
					// System.out.println("attributes:=065:Reqid======> " +
					// Arrays.toString(attributes));
					Remarks12states remarks12states = new Remarks12states();
					remarks12states.setRemark_attr(attributes[0]);
					remarks12states.setRemark(attributes[1]);
					treeViewList_065.add(remarks12states);
				}
				selectRequestData.setSubHeader(receivedSubHeader);
				// System.out.println("++++treeViewList_065+++before session+++" +
				// treeViewList_065);
				session.setAttribute("treeViewList_065", treeViewList_065);
				// selectRequestData.setSelectRequestTableRows(selectRequestTableRows);

			}

			if (subData_534Recid != null && subData_534Recid.getSubHeader().getRecord_type().equals("534")) {

				List<ResponseSummary12state> treeViewList_534 = new ArrayList<>();
				treeViewList.add("534");
				SubHeader receivedSubHeader = subData_534Recid.getSubHeader();
				String[] subDataRows = subData_534Recid.getSubDataRows();
				for (String subDataRow : subDataRows) {
					String[] attributes = mqReadUtil.getAttributes(subDataRow, 7);
					// System.out.println("attributes:=534:Reqid======> " +
					// Arrays.toString(attributes));
					ResponseSummary12state responseSummary12state = new ResponseSummary12state();
					responseSummary12state.setEcver(attributes[0]);
					responseSummary12state.setLsrver(attributes[1]);
					responseSummary12state.setType(attributes[2]);
					responseSummary12state.setPia(attributes[3]);
					responseSummary12state.setD_t_sent_local(attributes[4]);
					responseSummary12state.setD_t_sent_central(attributes[5]);
					responseSummary12state.setUserid(attributes[6]);
					treeViewList_534.add(responseSummary12state);
				}
				selectRequestData.setSubHeader(receivedSubHeader);
				// selectRequestData.setSelectRequestTableRows(selectRequestTableRows);
				// System.out.println("++++treeViewList_534+++before session+++" +
				// treeViewList_534);
				session.setAttribute("treeViewList_534", treeViewList_534);
			}

			session.setAttribute("treeViewList", treeViewList);
		}
		// System.out.println("++++treeViewList+++before session+++" + treeViewList);
		if (treeViewList.contains("570")) {
			session.setAttribute("manRejButton", "inline");

		} else {
			session.setAttribute("manRejButton", "none");
		}

		return treeViewList;

	}

	private void getSubData_200RecidData(SubData subData_200Recid, List treeViewList, HttpSession session,
			SelectRequestData selectRequestData) {
		SubHeader receivedSubHeader = subData_200Recid.getSubHeader();
		String[] subDataRows = subData_200Recid.getSubDataRows();
		treeViewList.add("200");
		List<D_Record_Product_loopV6_12States> treeViewList200 = new ArrayList();
		// int i = 0;
		for (String subDataRow : subDataRows) {
			String[] attributes = mqReadUtil.getAttributes(subDataRow, 143);
//			//System.out.println("attributes:=200:Reqid======> " + Arrays.toString(attributes));
			D_Record_Product_loopV6_12States d_record_product_loopV6_12states = new D_Record_Product_loopV6_12States();

			d_record_product_loopV6_12states.setItem_num(attributes[0]);
			d_record_product_loopV6_12states.setLnum_attr(attributes[1]);
			d_record_product_loopV6_12states.setLnum(attributes[2]);
			d_record_product_loopV6_12states.setLna_attr(attributes[3]);
			d_record_product_loopV6_12states.setLna(attributes[4]);
			d_record_product_loopV6_12states.setLmt_attr(attributes[5]);
			d_record_product_loopV6_12states.setLmt(attributes[6]);
			d_record_product_loopV6_12states.setEcckt_attr(attributes[7]);
			d_record_product_loopV6_12states.setEcckt(attributes[8]);
			d_record_product_loopV6_12states.setShared_nbr_attr(attributes[9]);
			d_record_product_loopV6_12states.setShared_nbr(attributes[10]);

			d_record_product_loopV6_12states.setDisc_nbr_attr(attributes[11]);
			d_record_product_loopV6_12states.setDisc_nbr(attributes[12]);
			d_record_product_loopV6_12states.setTers_attr(attributes[13]);
			d_record_product_loopV6_12states.setTers(attributes[14]);
			d_record_product_loopV6_12states.setCfa_attr(attributes[15]);

			d_record_product_loopV6_12states.setCfa(attributes[16]);
			d_record_product_loopV6_12states.setCcea_attr(attributes[17]);
			d_record_product_loopV6_12states.setCcea(attributes[18]);
			d_record_product_loopV6_12states.setSscfa_attr(attributes[19]);
			d_record_product_loopV6_12states.setSscfa(attributes[20]);
			d_record_product_loopV6_12states.setCableid_attr(attributes[21]);
			d_record_product_loopV6_12states.setCableid(attributes[22]);
			d_record_product_loopV6_12states.setChan_pair3_attr(attributes[23]);
			d_record_product_loopV6_12states.setChan_pair3(attributes[24]);
			d_record_product_loopV6_12states.setSystemid_attr(attributes[25]);
			d_record_product_loopV6_12states.setSystemid(attributes[26]);
			d_record_product_loopV6_12states.setCbcid_attr(attributes[27]);
			d_record_product_loopV6_12states.setCbcid(attributes[28]);
			d_record_product_loopV6_12states.setChan_pair_attr(attributes[29]);
			d_record_product_loopV6_12states.setChan_pair(attributes[30]);
			d_record_product_loopV6_12states.setCbcid2_attr(attributes[31]);
			d_record_product_loopV6_12states.setCbcid2(attributes[32]);
			d_record_product_loopV6_12states.setChan_pair2_attr(attributes[33]);
			d_record_product_loopV6_12states.setChan_pair2(attributes[34]);
			d_record_product_loopV6_12states.setCti_attr(attributes[35]);
			d_record_product_loopV6_12states.setCti(attributes[36]);
			d_record_product_loopV6_12states.setRelay_rack_attr(attributes[37]);
			d_record_product_loopV6_12states.setRelay_rack(attributes[38]);
			d_record_product_loopV6_12states.setShelf_attr(attributes[39]);
			d_record_product_loopV6_12states.setShelf(attributes[40]);
			d_record_product_loopV6_12states.setSlot_attr(attributes[41]);
			d_record_product_loopV6_12states.setSlot(attributes[42]);
			d_record_product_loopV6_12states.setCti2_attr(attributes[43]);
			d_record_product_loopV6_12states.setCti2(attributes[44]);
			d_record_product_loopV6_12states.setRelay_rack2_attr(attributes[45]);
			d_record_product_loopV6_12states.setRelay_rack2(attributes[46]);
			d_record_product_loopV6_12states.setShelf2_attr(attributes[47]);
			d_record_product_loopV6_12states.setShelf2(attributes[48]);
			d_record_product_loopV6_12states.setSlot2_attr(attributes[49]);
			d_record_product_loopV6_12states.setSlot2(attributes[50]);
			d_record_product_loopV6_12states.setCti3_attr(attributes[51]);
			d_record_product_loopV6_12states.setCti3(attributes[52]);
			d_record_product_loopV6_12states.setRelay_rack3_attr(attributes[53]);
			d_record_product_loopV6_12states.setRelay_rack3(attributes[54]);
			d_record_product_loopV6_12states.setShelf3_attr(attributes[55]);
			d_record_product_loopV6_12states.setShelf3(attributes[56]);
			d_record_product_loopV6_12states.setSlot3_attr(attributes[57]);
			d_record_product_loopV6_12states.setSlot3(attributes[58]);
			d_record_product_loopV6_12states.setCti4_attr(attributes[59]);
			d_record_product_loopV6_12states.setCti4(attributes[60]);
			d_record_product_loopV6_12states.setRelay_rack4_attr(attributes[61]);
			d_record_product_loopV6_12states.setRelay_rack4(attributes[62]);
			d_record_product_loopV6_12states.setShelf4_attr(attributes[63]);
			d_record_product_loopV6_12states.setShelf4(attributes[64]);
			d_record_product_loopV6_12states.setSlot4_attr(attributes[65]);
			d_record_product_loopV6_12states.setSlot4(attributes[66]);
			d_record_product_loopV6_12states.setVpi_attr(attributes[67]);
			d_record_product_loopV6_12states.setVpi(attributes[68]);
			d_record_product_loopV6_12states.setVci_attr(attributes[69]);
			d_record_product_loopV6_12states.setVci(attributes[70]);
			d_record_product_loopV6_12states.setCode_set_attr(attributes[71]);
			d_record_product_loopV6_12states.setCode_set(attributes[72]);
			d_record_product_loopV6_12states.setRecckt_attr(attributes[73]);
			d_record_product_loopV6_12states.setRecckt(attributes[74]);
			d_record_product_loopV6_12states.setCkr_attr(attributes[75]);
			d_record_product_loopV6_12states.setCkr(attributes[76]);
			d_record_product_loopV6_12states.setTsp_attr(attributes[77]);
			d_record_product_loopV6_12states.setTsp(attributes[78]);
			d_record_product_loopV6_12states.setPorted_nbr_attr(attributes[79]);
			d_record_product_loopV6_12states.setPorted_nbr(attributes[80]);
			d_record_product_loopV6_12states.setNpt_attr(attributes[81]);
			d_record_product_loopV6_12states.setNpt(attributes[82]);
			d_record_product_loopV6_12states.setRti_attr(attributes[83]);
			d_record_product_loopV6_12states.setRti(attributes[84]);
			d_record_product_loopV6_12states.setNptg_attr(attributes[85]);
			d_record_product_loopV6_12states.setNptg(attributes[86]);
			d_record_product_loopV6_12states.setNpi_attr(attributes[87]);
			d_record_product_loopV6_12states.setNpi(attributes[88]);
			d_record_product_loopV6_12states.setLst_attr(attributes[89]);
			d_record_product_loopV6_12states.setLst(attributes[90]);
			d_record_product_loopV6_12states.setTns_attr(attributes[91]);
			d_record_product_loopV6_12states.setTns(attributes[92]);
			d_record_product_loopV6_12states.setOtn_attr(attributes[93]);
			d_record_product_loopV6_12states.setOtn(attributes[94]);
			d_record_product_loopV6_12states.setIspid_attr(attributes[95]);
			d_record_product_loopV6_12states.setIspid(attributes[96]);
			d_record_product_loopV6_12states.setPic_attr(attributes[97]);
			d_record_product_loopV6_12states.setPic(attributes[98]);
			d_record_product_loopV6_12states.setLpic_attr(attributes[99]);
			d_record_product_loopV6_12states.setLpic(attributes[100]);
			d_record_product_loopV6_12states.setSsig_attr(attributes[101]);
			d_record_product_loopV6_12states.setSsig(attributes[102]);
			d_record_product_loopV6_12states.setBa_attr(attributes[103]);
			d_record_product_loopV6_12states.setBa(attributes[104]);
			d_record_product_loopV6_12states.setBlock_attr(attributes[105]);
			d_record_product_loopV6_12states.setBlock(attributes[106]);
			d_record_product_loopV6_12states.setJk_code_attr(attributes[107]);
			d_record_product_loopV6_12states.setJk_code(attributes[108]);
			d_record_product_loopV6_12states.setJk_num_attr(attributes[109]);
			d_record_product_loopV6_12states.setJk_num(attributes[110]);
			d_record_product_loopV6_12states.setJk_pos_attr(attributes[111]);
			d_record_product_loopV6_12states.setJk_pos(attributes[112]);
			d_record_product_loopV6_12states.setJr_attr(attributes[113]);
			d_record_product_loopV6_12states.setJr(attributes[114]);
			d_record_product_loopV6_12states.setNidr_attr(attributes[115]);
			d_record_product_loopV6_12states.setNidr(attributes[116]);
			d_record_product_loopV6_12states.setIwjk1_attr(attributes[117]);
			d_record_product_loopV6_12states.setIwjk1(attributes[118]);
			d_record_product_loopV6_12states.setIwjk2_attr(attributes[119]);
			d_record_product_loopV6_12states.setIwjk2(attributes[120]);
			d_record_product_loopV6_12states.setIwjk3_attr(attributes[121]);
			d_record_product_loopV6_12states.setIwjk3(attributes[122]);
			d_record_product_loopV6_12states.setIwjk4_attr(attributes[123]);
			d_record_product_loopV6_12states.setIwjk4(attributes[124]);
			d_record_product_loopV6_12states.setIwjk5_attr(attributes[125]);
			d_record_product_loopV6_12states.setIwjk5(attributes[126]);
			d_record_product_loopV6_12states.setIwjq1_attr(attributes[127]);
			d_record_product_loopV6_12states.setIwjq1(attributes[128]);
			d_record_product_loopV6_12states.setIwjq2_attr(attributes[129]);
			d_record_product_loopV6_12states.setIwjq2(attributes[130]);
			d_record_product_loopV6_12states.setIwjq3_attr(attributes[131]);
			d_record_product_loopV6_12states.setIwjq3(attributes[132]);
			d_record_product_loopV6_12states.setIwjq4_attr(attributes[133]);
			d_record_product_loopV6_12states.setIwjq4(attributes[134]);
			d_record_product_loopV6_12states.setIwjq5_attr(attributes[135]);
			d_record_product_loopV6_12states.setIwjq5(attributes[136]);
			d_record_product_loopV6_12states.setLidb_attr(attributes[137]);
			d_record_product_loopV6_12states.setLidb(attributes[138]);
			d_record_product_loopV6_12states.setS_attr(attributes[139]);
			d_record_product_loopV6_12states.setS(attributes[140]);
			d_record_product_loopV6_12states.setOecckt_attr(attributes[141]);
			d_record_product_loopV6_12states.setOecckt(attributes[142]);
			// d_record_product_loopV6_12states.setScreenName("Circut");

			treeViewList200.add(d_record_product_loopV6_12states);
		}
		session.setAttribute("treeViewList200", treeViewList200);
		selectRequestData.setSubHeader(receivedSubHeader);
		// System.out.println("treeViewList200 size() "+treeViewList200.size());
	}
	private void getSubData_050Recid(SubData subData_050Recid, List treeViewList, SelectRequestData selectRequestData,
			HttpSession session, List treeViewList050) {

		SubHeader receivedSubHeader = subData_050Recid.getSubHeader();
		String[] subDataRows = subData_050Recid.getSubDataRows();
		treeViewList.add("050");
		for (String subDataRow : subDataRows) {
			String[] attributes = mqReadUtil.getAttributes(subDataRow, 109);
//			//System.out.println("attributes:=050:Reqid======> " + Arrays.toString(attributes));
			LSRBillAndContact12States BillAndContact = new LSRBillAndContact12States();

			BillAndContact.setCver_attr(attributes[0]);
			BillAndContact.setCver(attributes[1]);
			BillAndContact.setSm(attributes[2]);
			BillAndContact.setDt_sent(attributes[3]);
			BillAndContact.setAdm_sc_attr(attributes[4]);
			BillAndContact.setAdm_sc(attributes[5]);
			BillAndContact.setDdd_attr(attributes[6]);
			BillAndContact.setDdd(attributes[7]);
			BillAndContact.setApptime_attr(attributes[8]);
			BillAndContact.setApptime(attributes[9]);
			BillAndContact.setResid_attr(attributes[10]);
			BillAndContact.setResid(attributes[11]);
			BillAndContact.setDfdt_attr(attributes[12]);
			BillAndContact.setDfdt(attributes[13]);
			BillAndContact.setDddo_attr(attributes[14]);
			BillAndContact.setDddo(attributes[15]);
			BillAndContact.setDfdto_attr(attributes[16]);
			BillAndContact.setDfdto(attributes[17]);
			BillAndContact.setChc_attr(attributes[18]);
			BillAndContact.setChc(attributes[19]);
			BillAndContact.setExp_attr(attributes[20]);
			BillAndContact.setExp(attributes[21]);
			BillAndContact.setExprsn_attr(attributes[22]);
			BillAndContact.setExprsn(attributes[23]);
			BillAndContact.setAct_attr(attributes[24]);
			BillAndContact.setAct(attributes[25]);
			BillAndContact.setSup_attr(attributes[26]);
			BillAndContact.setSup(attributes[27]);
			BillAndContact.setTos_attr(attributes[28]);
			BillAndContact.setTos(attributes[29]);
			BillAndContact.setAtn_attr(attributes[30]);
			BillAndContact.setAtn(FormatUtil.getTelephoneNumberWithDashes(attributes[31] != null && attributes[31] != "" ? attributes[31] : " "));// supriya changes for date format
					
			BillAndContact.setRtr_attr(attributes[32]);
			BillAndContact.setRtr(attributes[33]);
			BillAndContact.setOnsp_attr(attributes[34]);
			BillAndContact.setOnsp(attributes[35]);
			BillAndContact.setNnsp_attr(attributes[36]);
			BillAndContact.setNnsp(attributes[37]);
			BillAndContact.setNor_attr(attributes[38]);
			BillAndContact.setNor(attributes[39]);
			BillAndContact.setRpon_attr(attributes[40]);
			BillAndContact.setRpon(attributes[41]);
			BillAndContact.setRord_attr(attributes[42]);
			BillAndContact.setRord(attributes[43]);
			BillAndContact.setActl_attr(attributes[44]);
			BillAndContact.setActl(attributes[45]);
			BillAndContact.setLst_attr(attributes[46]);
			BillAndContact.setLst(attributes[47]);
			BillAndContact.setSpec_attr(attributes[48]);
			BillAndContact.setSpec(attributes[49]);
			BillAndContact.setAdm_nc_attr(attributes[50]);
			BillAndContact.setAdm_nc(attributes[51]);
			BillAndContact.setAdm_nci_attr(attributes[52]);
			BillAndContact.setAdm_nci(attributes[53]);
			BillAndContact.setSecnci_attr(attributes[54]);
			BillAndContact.setSecnci(attributes[55]);
			BillAndContact.setAtr_attr(attributes[56]);
			BillAndContact.setAtr(FormatUtil.getTelephoneNumberWithDashes(attributes[57] != null && attributes[57] != "" ? attributes[57] : " "));// supriya changes for date format
					
			BillAndContact.setNena_ecc_attr(attributes[58]);
			BillAndContact.setNena_ecc(attributes[59]);
			BillAndContact.setAlbr_attr(attributes[60]);
			BillAndContact.setAlbr(attributes[61]);
			BillAndContact.setProject_attr(attributes[62]);
			BillAndContact.setProject(attributes[63]);
			BillAndContact.setAgauth_attr(attributes[64]);
			BillAndContact.setAgauth(attributes[65]);
			BillAndContact.setBan1_attr(attributes[66]);
			BillAndContact.setBan1(attributes[67]);
			BillAndContact.setBan2_attr(attributes[68]);
			BillAndContact.setBan2(attributes[69]);
			BillAndContact.setEbp_attr(attributes[70]);
			BillAndContact.setEbp(attributes[71]);
			BillAndContact.setVta_attr(attributes[72]);
			BillAndContact.setVta(attributes[73]);
			BillAndContact.setInit_attr(attributes[74]);
			BillAndContact.setInit(attributes[75]);
			BillAndContact.setTel_no_attr(attributes[76]);
			BillAndContact.setTel_no(attributes[77]);
			BillAndContact.setFax_no(attributes[78]);
			BillAndContact.setImpcon_attr(attributes[79]);
			BillAndContact.setImpcon(attributes[80]);
			BillAndContact.setImpcon_telno_attr(attributes[81]);
			BillAndContact.setImpcon_telno(attributes[82]);
			BillAndContact.setDrc_attr(attributes[83]);
			BillAndContact.setDrc(attributes[84]);
			BillAndContact.setDsgcon(attributes[85]);
			BillAndContact.setDsgcon_telno_attr(attributes[86]);
			BillAndContact.setDsgcon_telno(attributes[87]);
			BillAndContact.setDsgcon_faxno_attr(attributes[88]);
			BillAndContact.setDsgcon_faxno(attributes[89]);
			BillAndContact.setActivity(attributes[90]);
			BillAndContact.setReqtype(attributes[91]);
			BillAndContact.setPb_sb_ind(attributes[92]);
			BillAndContact.setNpdi_attr(attributes[93]);
			BillAndContact.setNpdi(attributes[94]);
			BillAndContact.setScd_attr(attributes[95]);
			BillAndContact.setScd(attributes[96]);
			BillAndContact.setSli_attr(attributes[97]);
			BillAndContact.setSli(attributes[98]);
			BillAndContact.setQrynbr_attr(attributes[99]);
			BillAndContact.setQrynbr(attributes[100]);
			BillAndContact.setSactl_attr(attributes[101]);
			BillAndContact.setSactl(attributes[102]);
			BillAndContact.setAdet_attr(attributes[103]);
			BillAndContact.setAdet(attributes[104]);
			BillAndContact.setAn_attr(attributes[105]);
			BillAndContact.setAn(FormatUtil.getTelephoneNumberWithDashes(attributes[106] != null && attributes[106] != "" ? attributes[106] : " "));// supriya changes for date format
						
			BillAndContact.setCcna_attr(attributes[107]);
			BillAndContact.setCcna(attributes[108]);

			treeViewList050.add(BillAndContact);
		}
		selectRequestData.setSubHeader(receivedSubHeader);
		// System.out.println("treeViewList050 size() "+treeViewList050.size());

	}

	SubHeader prepareTreeSubHeader() {

		// Prepare SubHeader
		SubHeader subHeader = new SubHeader();

		subHeader.setLast_ind(LastInd.Y.name());
		subHeader.setProcess_mode(ProcessMode.CS_RETRIEVE.getProcessModeCode());
		subHeader.setRecord_type(null);
		subHeader.setReturn_code(null);
		subHeader.setDw_rownum(null);
		subHeader.setEcver(null);

		return subHeader;
	}

	Header prepareTreeHeader(String user_id, String object_handle, String process) {
		// Prepare Header
		Header header = new Header();

		header.setUser_id(user_id);
		header.setProcess(process);
		header.setTab_ind(null);
		header.setProcess_group_ind(ProcessGroupInd.RETRIEVE_IND.getProcessGroupInd());
		header.setObject_handle(object_handle);
		header.setObject_handle2(null);
		header.setLog_ind(LogInd.N.name());
		header.setStarttime(null);
		header.setEndtime(null);
		header.setGuid(null);
		header.setSession_trans_count("0000001");
		header.setHost_trans_seq(null);
		header.setReturn_code(null);
		header.setRead_only_ind(null);
		header.setNum_detail("0001");
		header.setRead_only_user_id(null);
		header.setLasrversion(null);

		return header;
	}

//	private Header prepareTreeHeader(String user_id, String object_handle, String process) {
//		// Prepare Header
//		Header header = new Header();
//
//		header.setUser_id(user_id);
//		header.setProcess(process);
//		header.setTab_ind(null);
//		header.setProcess_group_ind(ProcessGroupInd.RETRIEVE_IND.getProcessGroupInd());
//		header.setObject_handle(object_handle);
//		header.setObject_handle2(null);
//		header.setLog_ind(LogInd.N.name());
//		header.setStarttime(null);
//		header.setEndtime(null);
//		header.setGuid(null);
//		header.setSession_trans_count("0000001");
//		header.setHost_trans_seq(null);
//		header.setReturn_code(null);
//		header.setRead_only_ind(null);
//		header.setNum_detail("0001");
//		header.setRead_only_user_id(null);
//		header.setLasrversion(null);
//
//		return header;
//		}

	private List requestTypeC_Z_12State(SelectRequestData selectRequestData, Map<String, SubData> subDatas,
			HttpSession session, List treeViewList) {

		// sadasiva
		// sadasiva
		SubData subData_840Recid = subDatas.get(RecIdFor12State.CS_RECID_ISDN_RESALE.getRecIdValue());
		if (subData_840Recid != null && subData_840Recid.getSubHeader().getRecord_type().equals("840")) {

			SubHeader receivedSubHeader = subData_840Recid.getSubHeader();
			String[] subDataRows = subData_840Recid.getSubDataRows();
			List<ISDN_Resale_IRS_Channel_12State> treeViewList_840_12State = new ArrayList<ISDN_Resale_IRS_Channel_12State>();
			treeViewList.add("840");

			for (String subDataRow : subDataRows) {
				String[] attributes = mqReadUtil.getAttributes(subDataRow, 217);
				ISDN_Resale_IRS_Channel_12State iric12s = new ISDN_Resale_IRS_Channel_12State();

				iric12s.setItem_num(attributes[0]);
				iric12s.setCnum_attr(attributes[1]);
				iric12s.setCnum(attributes[2]);
				iric12s.setFnum_attr(attributes[3]);
				iric12s.setFnum(attributes[4]);
				iric12s.setTnnum_attr(attributes[5]);
				iric12s.setTnnum(attributes[6]);
				iric12s.setTglnum_attr(attributes[7]);
				iric12s.setTglnum(attributes[8]);
				iric12s.setEcckt_attr(attributes[9]);
				iric12s.setEcckt(attributes[10]);
				iric12s.setCfa_attr(attributes[11]);
				iric12s.setCfa(attributes[12]);
				iric12s.setLtgn_attr(attributes[13]);
				iric12s.setLtgn(attributes[14]);
				iric12s.setIid_attr(attributes[15]);
				iric12s.setIid(attributes[16]);
				iric12s.setCord_attr(attributes[17]);
				iric12s.setCord(attributes[18]);
				iric12s.setIsdnp_attr(attributes[19]);
				iric12s.setIsdnp(attributes[20]);
				iric12s.setFlna_attr(attributes[21]);
				iric12s.setFlna(attributes[22]);
				iric12s.setCkttyp_attr(attributes[23]);
				iric12s.setCkttyp(attributes[24]);
				iric12s.setFecckt_attr(attributes[25]);
				iric12s.setFecckt(attributes[26]);
				iric12s.setPlst_attr(attributes[27]);
				iric12s.setPlst(attributes[28]);
				iric12s.setAuth_num_attr(attributes[29]);
				iric12s.setAuth_num(attributes[30]);
				iric12s.setPri_loc_attr(attributes[31]);
				iric12s.setPri_loc(attributes[32]);
				iric12s.setEulst_attr(attributes[33]);
				iric12s.setEulst(attributes[34]);
				iric12s.setCcea_attr(attributes[35]);
				iric12s.setCcea(attributes[36]);
				iric12s.setCfa_btn_attr(attributes[37]);
				iric12s.setCfa_btn(attributes[38]);
				iric12s.setCb_attr(attributes[39]);
				iric12s.setCb(attributes[40]);
				iric12s.setCbbtn_attr(attributes[41]);
				iric12s.setCbbtn(attributes[42]);
				iric12s.setNcon_attr(attributes[43]);
				iric12s.setNcon(attributes[44]);
				iric12s.setAft_attr(attributes[45]);
				iric12s.setAft(attributes[46]);
				iric12s.setSapr_attr(attributes[47]);
				iric12s.setSapr(attributes[48]);
				iric12s.setSano_attr(attributes[49]);
				iric12s.setSano(attributes[50]);
				iric12s.setSasf_attr(attributes[51]);
				iric12s.setSasf(attributes[52]);
				iric12s.setSasd_attr(attributes[53]);
				iric12s.setSasd(attributes[54]);
				iric12s.setSasn_attr(attributes[55]);
				iric12s.setSasn(attributes[56]);
				iric12s.setSath_attr(attributes[57]);
				iric12s.setSath(attributes[58]);
				iric12s.setSass_attr(attributes[59]);
				iric12s.setSass(attributes[60]);
				iric12s.setLd1_attr(attributes[61]);
				iric12s.setLd1(attributes[62]);
				iric12s.setLv1_attr(attributes[63]);
				iric12s.setLv1(attributes[64]);
				iric12s.setLd2_attr(attributes[65]);
				iric12s.setLd2(attributes[66]);
				iric12s.setLv2_attr(attributes[67]);
				iric12s.setLv2(attributes[68]);
				iric12s.setLd3_attr(attributes[69]);
				iric12s.setLd3(attributes[70]);
				iric12s.setLv3_attr(attributes[71]);
				iric12s.setLv3(attributes[72]);
				iric12s.setAai_attr(attributes[73]);
				iric12s.setAai(attributes[74]);
				iric12s.setCity_attr(attributes[75]);
				iric12s.setCity(attributes[76]);
				iric12s.setState_attr(attributes[77]);
				iric12s.setState(attributes[78]);
				iric12s.setZip_attr(attributes[79]);
				iric12s.setZip(attributes[80]);
				iric12s.setNidr_attr(attributes[81]);
				iric12s.setNidr(attributes[82]);
				iric12s.setIwo_attr(attributes[83]);
				iric12s.setIwo(attributes[84]);
				iric12s.setAloc_attr(attributes[85]);
				iric12s.setAloc(attributes[86]);
				iric12s.setLcon_attr(attributes[87]);
				iric12s.setLcon(attributes[88]);
				iric12s.setTelno_attr(attributes[89]);
				iric12s.setTelno(attributes[90]);
				iric12s.setPtnract_attr(attributes[91]);
				iric12s.setPtnract(attributes[92]);
				iric12s.setPtnrq_attr(attributes[93]);
				iric12s.setPtnrq(attributes[94]);
				iric12s.setPtnr1_attr(attributes[95]);
				iric12s.setPtnr1(attributes[96]);
				iric12s.setPtnr2_attr(attributes[97]);
				iric12s.setPtnr2(attributes[98]);
				iric12s.setPtnr3_attr(attributes[99]);
				iric12s.setPtnr3(attributes[100]);
				iric12s.setNpi_attr(attributes[101]);
				iric12s.setNpi(attributes[102]);
				iric12s.setDidr_attr(attributes[103]);
				iric12s.setDidr(attributes[104]);
				iric12s.setTgtli_attr(attributes[105]);
				iric12s.setTgtli(attributes[106]);

				iric12s.setDba1_attr(attributes[107]);
				iric12s.setDba1(attributes[108]);
				iric12s.setDba2_attr(attributes[109]);
				iric12s.setDba2(attributes[110]);
				iric12s.setDblock1_attr(attributes[111]);
				iric12s.setDblock1(attributes[112]);
				iric12s.setDblock2_attr(attributes[113]);
				iric12s.setDblock2(attributes[114]);
				iric12s.setNba_attr(attributes[115]);
				iric12s.setNba(attributes[116]);
				iric12s.setNbank1_attr(attributes[117]);
				iric12s.setNbank1(attributes[118]);
				iric12s.setNbank2_attr(attributes[119]);
				iric12s.setNbank2(attributes[120]);
				iric12s.setNbank3_attr(attributes[121]);
				iric12s.setNbank3(attributes[122]);
				iric12s.setNbank4_attr(attributes[123]);
				iric12s.setNbank4(attributes[124]);
				iric12s.setDstnact_attr(attributes[125]);
				iric12s.setDstnact(attributes[126]);
				iric12s.setDstnq_attr(attributes[127]);
				iric12s.setDstnq(attributes[128]);
				iric12s.setDstn1_attr(attributes[129]);
				iric12s.setDstn1(attributes[130]);
				iric12s.setDstn2_attr(attributes[131]);
				iric12s.setDstn2(attributes[132]);
				iric12s.setDstn3_attr(attributes[133]);
				iric12s.setDstn3(attributes[134]);
				iric12s.setDstn4_attr(attributes[135]);
				iric12s.setDstn4(attributes[136]);
				iric12s.setDstn5_attr(attributes[137]);
				iric12s.setDstn5(attributes[138]);
				iric12s.setTglna_attr(attributes[139]);
				iric12s.setTglna(attributes[140]);
				iric12s.setTgn_attr(attributes[141]);
				iric12s.setTgn(attributes[142]);
				iric12s.setPtgn_of_attr(attributes[143]);
				iric12s.setPtgn_of(attributes[144]);
				iric12s.setTli_attr(attributes[145]);
				iric12s.setTli(attributes[146]);
				iric12s.setTgrti_attr(attributes[147]);
				iric12s.setTgrti(attributes[148]);
				iric12s.setTgdir_attr(attributes[149]);
				iric12s.setTgdir(attributes[150]);
				iric12s.setPtgnh_attr(attributes[151]);
				iric12s.setPtgnh(attributes[152]);
				iric12s.setDgout_attr(attributes[153]);
				iric12s.setDgout(attributes[154]);
				iric12s.setDg_rcvd_attr(attributes[155]);
				iric12s.setDg_rcvd(attributes[156]);
				iric12s.setPdod_attr(attributes[157]);
				iric12s.setPdod(attributes[158]);
				iric12s.setPic_attr(attributes[159]);
				iric12s.setPic(attributes[160]);
				iric12s.setLpic_attr(attributes[161]);
				iric12s.setLpic(attributes[162]);
				iric12s.setGlare_attr(attributes[163]);
				iric12s.setGlare(attributes[164]);
				iric12s.setPbxid_attr(attributes[165]);
				iric12s.setPbxid(attributes[166]);
				iric12s.setCid_attr(attributes[167]);
				iric12s.setCid(attributes[168]);
				iric12s.setTot_attr(attributes[169]);
				iric12s.setTot(attributes[170]);
				iric12s.setGsind1_attr(attributes[171]);
				iric12s.setGsind1(attributes[172]);
				iric12s.setGsind2_attr(attributes[173]);
				iric12s.setGsind2(attributes[174]);
				iric12s.setGsind3_attr(attributes[175]);
				iric12s.setGsind3(attributes[176]);
				iric12s.setGsind4_attr(attributes[177]);
				iric12s.setGsind4(attributes[178]);
				iric12s.setGsind5_attr(attributes[179]);
				iric12s.setGsind5(attributes[180]);
				iric12s.setGsqty1_attr(attributes[181]);
				iric12s.setGsqty1(attributes[182]);
				iric12s.setGsqty2_attr(attributes[183]);
				iric12s.setGsqty2(attributes[184]);
				iric12s.setGsqty3_attr(attributes[185]);
				iric12s.setGsqty3(attributes[186]);
				iric12s.setGsqty4_attr(attributes[187]);
				iric12s.setGsqty4(attributes[188]);
				iric12s.setGsqty5_attr(attributes[189]);
				iric12s.setGsqty5(attributes[190]);
				iric12s.setGind1_attr(attributes[191]);
				iric12s.setGind1(attributes[192]);
				iric12s.setGind2_attr(attributes[193]);
				iric12s.setGind2(attributes[194]);
				iric12s.setGind3_attr(attributes[195]);
				iric12s.setGind3(attributes[196]);
				iric12s.setGind4_attr(attributes[197]);
				iric12s.setGind4(attributes[198]);
				iric12s.setGqty1_attr(attributes[199]);
				iric12s.setGqty1(attributes[200]);
				iric12s.setGqty2_attr(attributes[201]);
				iric12s.setGqty2(attributes[202]);
				iric12s.setGqty3_attr(attributes[203]);
				iric12s.setGqty3(attributes[204]);
				iric12s.setGqty4_attr(attributes[205]);
				iric12s.setGqty4(attributes[206]);
				iric12s.setSec_loc_attr(attributes[207]);
				iric12s.setSec_loc(attributes[208]);
				iric12s.setCb_sec_attr(attributes[209]);
				iric12s.setCb_sec(attributes[210]);
				iric12s.setCbbtn_sec_attr(attributes[211]);
				iric12s.setCbbtn_sec(attributes[212]);
				iric12s.setActl_attr(attributes[213]);
				iric12s.setActl(attributes[214]);
				iric12s.setCfa_ckt_attr(attributes[215]);
				iric12s.setCfa_ckt(attributes[216]);

				treeViewList_840_12State.add(iric12s);
			}
			session.setAttribute("treeViewList_840_12State", treeViewList_840_12State);
			selectRequestData.setSubHeader(receivedSubHeader);
		}

		///////////////////////////////////////////// yash//////////////

		List treeViewList_532 = new ArrayList(); // Follow up
		// List treeViewList_531 = new ArrayList(); // Follow up

		SubData subData_532Recid = subDatas.get(RecIdFor12State.CS_RECID_FUP_EDIT.getRecIdValue());

		// SubData subData_532Recid = subDatas.get("532");
		if (subData_532Recid != null && subData_532Recid.getSubHeader().getRecord_type().equals("532")) {
			// List<FollowUpTableRow> treeViewList_532 = new ArrayList();
			SubHeader receivedSubHeader = subData_532Recid.getSubHeader();
			String[] subDataRows = subData_532Recid.getSubDataRows();
			treeViewList.add("532");

//									System.out.println("sub data for 532" + Arrays.toString(subDataRows));

			// int i = 0;
			FollowUpTableRow followUpUser = new FollowUpTableRow();
			for (String subDataRow : subDataRows) {
				String[] attributes = mqReadUtil.getAttributes(subDataRow, 17);

				followUpUser.setWorked_ind_attr(attributes[0]);
				followUpUser.setWorked_ind(attributes[1]);
				followUpUser.setCancel_ind_attr(attributes[2]);
				followUpUser.setCancel_ind(attributes[3]);
				followUpUser.setNotes_datetime(attributes[4]);
				followUpUser.setUser_id_attr(attributes[5]);
				followUpUser.setUser_id(attributes[6]);
				followUpUser.setLasr_ver_attr(attributes[7]);
				followUpUser.setLasr_ver(attributes[8]);
				followUpUser.setFollow_up_date_attr(attributes[9]);
				//Aprajita 14 feb start
				followUpUser.setFollow_up_date(FormatUtil.getMqDateToViewString(attributes[10] != null && attributes[10] != "" ? attributes[10] : " "));// supriya changes for date format
				//Aprajita 14 feb end
				//followUpUser.setFollow_up_date(attributes[10]);
				followUpUser.setFup_worked_date_attr(attributes[11]);
				followUpUser.setFup_worked_date(attributes[12]);
				followUpUser.setFup_end_date_attr(attributes[13]);
				followUpUser.setFup_end_date(attributes[14]);
				followUpUser.setNotes_attr(attributes[15]);
				followUpUser.setNotes(attributes[16]);

				treeViewList_532.add(followUpUser);
			}
			selectRequestData.setSubHeader(receivedSubHeader);
			session.setAttribute("followUpUser", followUpUser);
			session.setAttribute("treeViewList_532", treeViewList_532);

			// selectRequestData.setSelectRequestTableRows(selectRequestTableRows);
		}

		// Nitin--Supp1 Cancel
		SubData subData_885Recid = subDatas.get(RecIdFor12State.CS_RECID_DISPLAY_CONFIRM_CAN_V6.getRecIdValue());

		if (subData_885Recid != null && subData_885Recid.getSubHeader().getRecord_type().equals("885")) {

			SubHeader receivedSubHeader = subData_885Recid.getSubHeader();
			String[] subDataRows = subData_885Recid.getSubDataRows();
			List<ConfirmationReqtypRLSOG6102Row> confirmationReqtypRLSOG6102Rows_885 = new ArrayList<ConfirmationReqtypRLSOG6102Row>();

			treeViewList.add("885");
			for (String subDataRow : subDataRows) {
				String[] attributes = mqReadUtil.getAttributes(subDataRow, 7);
				ConfirmationReqtypRLSOG6102Row confirmationReqtypRLSOG6102Row = new ConfirmationReqtypRLSOG6102Row();
				confirmationReqtypRLSOG6102Row.setCver(attributes[0]);
				confirmationReqtypRLSOG6102Row.setAtn(attributes[1]);
				confirmationReqtypRLSOG6102Row.setRt(attributes[2]);
				confirmationReqtypRLSOG6102Row.setEcver(attributes[3]);
				confirmationReqtypRLSOG6102Row.setD_t_sent_local(attributes[4]);
				confirmationReqtypRLSOG6102Row.setResponse_d_t_sent_central_time(attributes[5]);
				confirmationReqtypRLSOG6102Row.setAn(attributes[6]);

				confirmationReqtypRLSOG6102Rows_885.add(confirmationReqtypRLSOG6102Row);
			}

			session.setAttribute("confirmationReqtypRLSOG6102Rows_885", confirmationReqtypRLSOG6102Rows_885);
			selectRequestData.setSubHeader(receivedSubHeader);
			// selectRequestData.setSelectRequestTableRows(confirmationReqtypRLSOG6102Rows);
		}

		///////////////////////////////////////////////////////////////
		// sadasiva
		// Shalu for confirmation task Activity R and correcting confirmation
		SubData subData_553Recid = subDatas.get(RecIdFor12State.CS_RECID_CONFIRM_ACTR.getRecIdValue());
		SubData subData_557Recid = subDatas.get(RecIdFor12State.CS_RECID_CONFIRM_ACTR_LSC.getRecIdValue());
//							SubData subData_850Recid = subDatas.get(RecIdFor12State.CS_RECID_ISSUE_PIA_FIX_V6.getRecIdValue());
//							SubData subData_858Recid = subDatas.get(RecIdFor12State.CS_RECID_ISSUE_PIA_REQORD_V6.getRecIdValue());
//							SubData subData_851Recid = subDatas.get(RecIdFor12State.CS_RECID_ISSUE_PIA_HUNT_V6.getRecIdValue());
//							SubData subData_852Recid = subDatas.get(RecIdFor12State.CS_RECID_ISSUE_PIA_DTL_V6.getRecIdValue());
		SubData subData_531Recid = subDatas.get(RecIdFor12State.CS_RECID_NOTES_INPUT.getRecIdValue());

		if (subData_531Recid != null && subData_531Recid.getSubHeader().getRecord_type().equals("531")) {
			List<FollowUpData> treeViewList_531 = new ArrayList();
			SubHeader receivedSubHeader = subData_531Recid.getSubHeader();
			String[] subDataRows = subData_531Recid.getSubDataRows();
//								System.out.println("sub data for 531" + Arrays.toString(subDataRows));
			treeViewList.add("531");
			if (!treeViewList.contains("532")) {
				session.removeAttribute("treeViewList_532");
				System.out.println("***************removing session**********");
			}
			// int i = 0;
			for (String subDataRow : subDataRows) {
				String[] attributes = mqReadUtil.getAttributes(subDataRow, 9);
//								System.out.println("attributes:=531:Reqid======> " + Arrays.toString(attributes));
				FollowUpData followUp = new FollowUpData();
				followUp.setNotes_datetime(attributes[0]);
				followUp.setUser_id_attr(attributes[1]);
				followUp.setUser_id(attributes[2]);
				followUp.setLasr_ver_attr(attributes[3]);
				followUp.setLasr_ver(attributes[4]);
				followUp.setFollow_up_date_attr(attributes[5]);
				followUp.setFollow_up_date(attributes[6]);
				followUp.setNotes_attr(attributes[7]);
				followUp.setNotes(attributes[8]);
				treeViewList_531.add(followUp);
			}
			selectRequestData.setSubHeader(receivedSubHeader);
			// System.out.println("++++treeViewList+++before session+++"+treeViewList_531);
			session.setAttribute("treeViewList_531", treeViewList_531);
			// selectRequestData.setSelectRequestTableRows(selectRequestTableRows);
		}

		if (subData_553Recid != null && subData_553Recid.getSubHeader().getRecord_type().equals("553")) {

			SubHeader receivedSubHeader = subData_553Recid.getSubHeader();
			String[] subDataRows = subData_553Recid.getSubDataRows();

			List<ConfirmationReqtypRLSOG6102Row> treeViewList_553 = new ArrayList();
			treeViewList.add("553");
			for (String subDataRow : subDataRows) {
				String[] attributes = mqReadUtil.getAttributes(subDataRow, 7);
//									System.out.println("attributes:=553======> " + Arrays.toString(attributes));
				ConfirmationReqtypRLSOG6102Row confirmationReqtypRLSOG6102Row = new ConfirmationReqtypRLSOG6102Row();

				confirmationReqtypRLSOG6102Row.setCver(attributes[0]);
				confirmationReqtypRLSOG6102Row.setAtn(attributes[1]);
				confirmationReqtypRLSOG6102Row.setRt(attributes[2]);
				confirmationReqtypRLSOG6102Row.setEcver(attributes[3]);
				confirmationReqtypRLSOG6102Row.setD_t_sent_local(attributes[4]);
				confirmationReqtypRLSOG6102Row.setResponse_d_t_sent_central_time(attributes[5]);
				confirmationReqtypRLSOG6102Row.setAn(attributes[6]);

				treeViewList_553.add(confirmationReqtypRLSOG6102Row);
			}
			session.setAttribute("treeViewList_553", treeViewList_553);
			selectRequestData.setSubHeader(receivedSubHeader);
		}

		if (subData_557Recid != null && subData_557Recid.getSubHeader().getRecord_type().equals("557")) {

			SubHeader receivedSubHeader = subData_557Recid.getSubHeader();
			String[] subDataRows = subData_557Recid.getSubDataRows();

			List<ConfirmationLS0G6DW2Row> treeViewList_557 = new ArrayList();
			treeViewList.add("557");
			for (String subDataRow : subDataRows) {
				String[] attributes = mqReadUtil.getAttributes(subDataRow, 14);
//									System.out.println("attributes:=557======> " + Arrays.toString(attributes));
				ConfirmationLS0G6DW2Row confirmationLS0G6DW2Row = new ConfirmationLS0G6DW2Row();
				confirmationLS0G6DW2Row.setOld_dtm(attributes[0]);
				confirmationLS0G6DW2Row.setOld_ord(attributes[1]);
				confirmationLS0G6DW2Row.setOrd_attr(attributes[2]);
				confirmationLS0G6DW2Row.setOrd(attributes[3]);
				confirmationLS0G6DW2Row.setFdt_attr(attributes[4]);
				confirmationLS0G6DW2Row.setFdt(attributes[5]);
				confirmationLS0G6DW2Row.setDd_attr(attributes[6]);
				confirmationLS0G6DW2Row.setDd_attr(attributes[7]);
				confirmationLS0G6DW2Row.setComp_dt_attr(attributes[8]);
				confirmationLS0G6DW2Row.setComp_dt(attributes[9]);
				confirmationLS0G6DW2Row.setPosted_date_attr(attributes[0]);
				confirmationLS0G6DW2Row.setPosted_date(attributes[11]);
				confirmationLS0G6DW2Row.setApptime_attr(attributes[12]);
				confirmationLS0G6DW2Row.setApptime(attributes[13]);

				treeViewList_557.add(confirmationLS0G6DW2Row);
			}
			session.setAttribute("treeViewList_557", treeViewList_557);
			selectRequestData.setSubHeader(receivedSubHeader);
		}

		return treeViewList;
	}

	private List<String> setEditOrderData(SubData subData_658Recid, SubData subData_652Recid, HttpSession session,
			SelectRequestData selectRequestData) {
		List<String> editOrderRecIdList = new ArrayList<String>();

		if (subData_658Recid != null && subData_658Recid.getSubHeader().getRecord_type().equals("658")) {

			SubHeader receivedSubHeader = subData_658Recid.getSubHeader();
			String[] subDataRows = subData_658Recid.getSubDataRows();
			List<EditOrderTable1Row> treeViewList_658 = new ArrayList<EditOrderTable1Row>();

			editOrderRecIdList.add("658");
			for (String subDataRow : subDataRows) {
				String[] attributes = mqReadUtil.getAttributes(subDataRow, 14);
				// System.out.println("subData_658Recid======> " + Arrays.toString(attributes));

				EditOrderTable1Row editOrderTable1Row = new EditOrderTable1Row();

				editOrderTable1Row.setOld_dtm(attributes[0]);
				editOrderTable1Row.setOld_ord(attributes[1]);
				editOrderTable1Row.setOrd_attr(attributes[2]);
				editOrderTable1Row.setOrd(attributes[3]);
				editOrderTable1Row.setFdt_attr(attributes[4]);
				editOrderTable1Row.setFdt(attributes[5]);
				editOrderTable1Row.setDd_attr(attributes[6]);
				editOrderTable1Row.setDd(attributes[7]);
				editOrderTable1Row.setComp_dt_attr(attributes[8]);
				editOrderTable1Row.setComp_dt(attributes[9]);
				editOrderTable1Row.setPosted_date_attr(attributes[10]);
				editOrderTable1Row.setPosted_date(attributes[11]);
				editOrderTable1Row.setApptime_attr(attributes[12]);
				editOrderTable1Row.setApptime(attributes[13]);

				treeViewList_658.add(editOrderTable1Row);

			}
			// editEccktData.setEditEccktTableRows(editEccktTableRows);
			session.setAttribute("treeViewList_658", treeViewList_658);
			selectRequestData.setSubHeader(receivedSubHeader);

		}

		if (subData_652Recid != null && subData_652Recid.getSubHeader().getRecord_type().equals("652")) {

			SubHeader receivedSubHeader = subData_652Recid.getSubHeader();
			String[] subDataRows = subData_652Recid.getSubDataRows();
			List<EditOrderTable2Row> treeViewList_652 = new ArrayList<EditOrderTable2Row>();
			editOrderRecIdList.add("652");
			for (String subDataRow : subDataRows) {
				String[] attributes = mqReadUtil.getAttributes(subDataRow, 42);
				// System.out.println("subData_652Recid======> " + Arrays.toString(attributes));

				EditOrderTable2Row editOrderTable2Row = new EditOrderTable2Row();

				editOrderTable2Row.setItemnum(attributes[0]);
				editOrderTable2Row.setLnum(attributes[1]);
				editOrderTable2Row.setNumname(attributes[2]);
				editOrderTable2Row.setNum_nbr(attributes[3]);
				editOrderTable2Row.setOrd_attr(attributes[4]);
				editOrderTable2Row.setOrd(attributes[5]);
				editOrderTable2Row.setLord_attr(attributes[6]);
				editOrderTable2Row.setLord(attributes[7]);
				editOrderTable2Row.setFdt_attr(attributes[8]);
				editOrderTable2Row.setFdt(attributes[9]);
				editOrderTable2Row.setDd_attr(attributes[10]);
				editOrderTable2Row.setDd(attributes[11]);
				editOrderTable2Row.setEcckt_attr(attributes[12]);
				editOrderTable2Row.setEcckt(attributes[13]);
				editOrderTable2Row.setCkr(attributes[14]);
				editOrderTable2Row.setShared_nbr(attributes[15]);
				editOrderTable2Row.setDisc_nbr(attributes[16]);
				editOrderTable2Row.setRecckt(attributes[17]);
				editOrderTable2Row.setTns_attr(attributes[18]);
				editOrderTable2Row.setTns(attributes[19]);
				editOrderTable2Row.setTers_attr(attributes[20]);
				editOrderTable2Row.setTers(attributes[21]);
				editOrderTable2Row.setCfa(attributes[22]);
				editOrderTable2Row.setCcea(attributes[23]);
				editOrderTable2Row.setIspid_attr(attributes[24]);
				editOrderTable2Row.setIspid(attributes[25]);
				editOrderTable2Row.setFecckt_attr(attributes[26]);
				editOrderTable2Row.setFecckt(attributes[27]);
				editOrderTable2Row.setNpord_attr(attributes[28]);
				editOrderTable2Row.setNpord(attributes[29]);
				editOrderTable2Row.setPorted_nbr(attributes[30]);
				editOrderTable2Row.setRti_attr(attributes[31]);
				editOrderTable2Row.setRti(attributes[32]);
				editOrderTable2Row.setCbcid(attributes[33]);
				editOrderTable2Row.setCbcid_attr(attributes[34]);
				editOrderTable2Row.setCableid_attr(attributes[35]);
				editOrderTable2Row.setCableid(attributes[36]);
				editOrderTable2Row.setChan_pair_attr(attributes[37]);
				editOrderTable2Row.setChan_pair(attributes[38]);
				editOrderTable2Row.setOld_ord(attributes[39]);
				editOrderTable2Row.setOld_lord(attributes[40]);
				editOrderTable2Row.setOld_npord(attributes[41]);

				treeViewList_652.add(editOrderTable2Row);

			}
			// editEccktData.setEditEccktTableRows(editEccktTableRows);
			session.setAttribute("treeViewList_652", treeViewList_652);
			selectRequestData.setSubHeader(receivedSubHeader);

		}
		return editOrderRecIdList;
	}

	public Confirmationtaskmain12states writeSelectedRequestConformationData(
			Confirmationtaskmain12states confirmationtaskmain12states, String user_id, String object_handle,
			HttpSession session) {

		Header header = null;
		SubHeader subHeader = null;
		StringBuilder subHeaderandData = new StringBuilder();
		System.out.println("Service:::111:inside:user_id::user_id::::" + user_id);
		String dataString049 = "";
		String dataString557 = "";
		int count = 0000;

		List<ConfirmationReqtypRLSOG6102Row> conformationList_553 = confirmationtaskmain12states
				.getConfirmationReqtypRLSOG6102Row();
		List<ConfirmationLS0G6DW2Row> conformationList_557 = confirmationtaskmain12states.getTreeViewList_557();
		List<NotesFupBindingData12States> conformationList_049 = confirmationtaskmain12states
				.getNotesFupBindingData12States();
		List<ConfirmationLS0G6DW2Row> list_557 = (List<ConfirmationLS0G6DW2Row>) (session
				.getAttribute("treeViewList_557"));

		List filterRecidList = (ArrayList) session.getAttribute("treeViewList");
		MQMessageStringBuilder mqMessageStringBuilder = new MQMessageStringBuilder();

		if (filterRecidList.contains("049")) {

			for (NotesFupBindingData12States notesFupBindingData12States : conformationList_049) {
				count++;
				session.setAttribute("Lrs_No", notesFupBindingData12States.getRequest_id().substring(0, 17).trim());
//				System.out.println("::::::susheel:val 999999inside for:LrsNo:session::"+session.getAttribute("Lrs_No"));
				dataString049 = notesFupBindingData12States.getNotesFupBindingData12String();
//				System.out.println("::::::dataString: confirmationTask_RecId_049_new for::::"+dataString049);

			}
		}

		if (filterRecidList.contains("557")) {
			// subHeader =
			// prepareSubHeader(RecIdFor12State.CS_RECID_CONFIRM_ACTR_LSC.getRecIdValue());
			for (ConfirmationLS0G6DW2Row confirmationTask_RecId_557_new : conformationList_557) {
				count++;

			}
		}

		// Shalu-changes done-21 Sep 2021
		if (filterRecidList.contains("049")) {
			String countVal = "";

			System.out.println("Count:::" + count);
			if (count < 10) {
				System.out.println("less:::");
				countVal = "000" + count;
			}
			if (count >= 10) {
				System.out.println("greater:::");
				countVal = "00" + count;
			}
			header = prepareconfHeader(user_id, object_handle, countVal);

			// Shalu-changes end
			subHeader = prepareSubHeader(RecIdFor12State.CS_RECID_HEADER.getRecIdValue());
			subHeaderandData.append(mqMessageStringBuilder.addHeader(header));
			subHeaderandData.append(mqMessageStringBuilder.appendSubHeaderAndData(subHeader, dataString049.toString()));
		}

		if (filterRecidList.contains("557")) {
			// Shalu changes done on 25 Oct start
			/*
			 * for (ConfirmationLS0G6DW2Row confirmationTask_RecId_557_new :
			 * conformationList_557) {
			 * if(confirmationTask_RecId_557_new.getOrd_attr().contains("U")) {
			 * confirmationTask_RecId_557_new.setOrd_attr("Y"); }
			 * if(confirmationTask_RecId_557_new.getDd_attr().contains("U")) {
			 * confirmationTask_RecId_557_new.setDd_attr("Y"); }
			 * 
			 * //shalu:-to set old order
			 * 
			 * String old_order = list_557.get(0).getOrd();
			 * 
			 * confirmationTask_RecId_557_new.setOld_ord(old_order);
			 */

			for (int i = 0; i < conformationList_557.size(); i++) {
				ConfirmationLS0G6DW2Row confirmationTask_RecId_557_new = conformationList_557.get(i);

				if (confirmationTask_RecId_557_new.getOrd_attr().contains("U")) {
					if (confirmationTask_RecId_557_new.getOrd().equals(list_557.get(i).getOrd()))
						confirmationTask_RecId_557_new.setOrd_attr("N");
					else
						confirmationTask_RecId_557_new.setOrd_attr("Y");
				}

				// shalu:-to set old order

				if (!confirmationTask_RecId_557_new.getOrd().equalsIgnoreCase(list_557.get(i).getOrd())) {
					String old_order = list_557.get(i).getOrd();
					confirmationTask_RecId_557_new.setOld_ord(old_order);
				}

				// Shalu changes done on 25 Oct end

				// subHeader =
				// prepareSubHeader(RecIdFor12State.CS_RECID_CONFIRM_ACTR_LSC.getRecIdValue());
				// subHeaderandData.append(mqMessageStringBuilder.appendSubHeaderAndData(subHeader,
				// dataString557.toString()));

				dataString557 = confirmationTask_RecId_557_new.getConfirmationLS0G6DW2();
				System.out.println("::::::dataString: confirmationTask_RecId_557_new for::::" + dataString557);
				subHeader = prepareSubHeader(RecIdFor12State.CS_RECID_CONFIRM_ACTR_LSC.getRecIdValue());
				subHeaderandData
						.append(mqMessageStringBuilder.appendSubHeaderAndData(subHeader, dataString557.toString()));
			}
		}

		String mqMessageString = mqMessageStringBuilder.getMqMessageString();
//		System.out.println("::::::58144444 formqMessageString::::"+mqMessageString);
		boolean isWritten = mqWriteUtil.writeDataToMQString(mqMessageString, session);
		// boolean isWritten = false;
		// String reg= (String) session.getAttribute("myReg");

		if (isWritten) {

			MQReceivedData mqReceivedData = null;

			try {

				mqReceivedData = mqReadUtil.readSortDataFromMQ(session);
				long endTime = System.nanoTime() + TimeUnit.NANOSECONDS.convert(3L, TimeUnit.MINUTES);
				Map<String, SubData> subDatas = mqReceivedData.getSubDatas();
				// Header receivedHeader = mqReceivedData.getHeader();
				while (mqReceivedData.getHeader() == null && System.nanoTime() < endTime) {
					System.out.println("*************inside if*************** ");
					mqReceivedData = mqReadUtil.readSortDataFromMQ(session);
				}

				System.out.println(mqReceivedData.getHeader().toString());
			} catch (Exception e) {
				// TODO Auto-generated catch block
				// mqReceivedData = mqReadUtil.readDataFromMQ(session);
				e.printStackTrace();

			}
			Map<String, SubData> subDatas = mqReceivedData.getSubDatas();
			Header receivedHeader = mqReceivedData.getHeader();
			confirmationtaskmain12states.setHeader(receivedHeader);
			System.out.println("::::::receivedHeader for::::returncode::::" + receivedHeader.getReturn_code());

			SubData subData = subDatas.get(RecIdFor12State.CS_RECID_ERROR.getRecIdValue());
			System.out.println("subData: " + subData);
			if (subData != null) {
				String[] subDataRows = subData.getSubDataRows();

				String[] attributes = mqReadUtil.getAttributes(subDataRows[0], 4);
//			System.out.println("attributes: Aug 10 " + Arrays.toString(attributes));
				// System.out.println("recieved subheader" + receivedSubHeader.toString() );
				if (receivedHeader.getReturn_code() != null && receivedHeader.getReturn_code().equals("999")) {

					System.out.println("inside 999");
					String errorData = attributes[0];

//				System.out.println("inside 999"+attributes[1]);
//				System.out.println("inside 999"+attributes[2]);
//				System.out.println("inside 999"+attributes[3]);

					ShowErrorService showErrorService = new ShowErrorService();
					showError = showErrorService.getErrorList(attributes[0], attributes[1], "", "U");

					System.out.println("ERRORS ******" + showError.toString());
					session.setAttribute("showError", showError);

				}
			}

		}
		return confirmationtaskmain12states;

	}

	private Header preparePopUpHeader(String user_id, String object_handle, String process_Group) {

		Header header = new Header();

		header.setUser_id(user_id);
		header.setProcess(Process.CS_CLOSE_REQUEST.getProcessCode());
		header.setTab_ind(TabInd.SAVE.getTabIndCode());
		header.setProcess_group_ind(process_Group);
		header.setObject_handle(object_handle);
		header.setObject_handle2(null);
		header.setLog_ind(LogInd.N.name());
		header.setStarttime(null);
		header.setEndtime(null);
		header.setGuid(null);
		header.setSession_trans_count("0000001");
		header.setHost_trans_seq(null);
		header.setReturn_code(null);
		header.setRead_only_ind(null);
		header.setNum_detail("0001");
		header.setRead_only_user_id(null);
		header.setLasrversion(null);

		return header;
	}

	private SubHeader preparePopUpSubHeader(String recid) {

		// Prepare SubHeader
		SubHeader subHeader = new SubHeader();

		subHeader.setLast_ind(LastInd.Y.name());
		subHeader.setProcess_mode(ProcessMode.CS_UPDATE.getProcessModeCode());
		subHeader.setRecord_type(recid);
		subHeader.setReturn_code(null);
		subHeader.setDw_rownum(null);
		subHeader.setEcver(null);

		return subHeader;
	}

	private SubHeader prepareSubHeader(String recid) {

		// Prepare SubHeader
		SubHeader subHeader = new SubHeader();

		subHeader.setLast_ind(LastInd.Y.name());
		subHeader.setProcess_mode(ProcessMode.CS_UPDATE.getProcessModeCode());
		subHeader.setRecord_type(recid);
		subHeader.setReturn_code(null);
		subHeader.setDw_rownum(null);
		subHeader.setEcver(null);

		return subHeader;
	}

	private Header prepareHeader(String user_id, String object_handle, int count) {

		Header header = new Header();

		header.setUser_id(user_id);
		header.setProcess(Process.CS_REQUEST.getProcessCode());
		header.setTab_ind(TabInd.FOC.getTabIndCode());
		header.setProcess_group_ind(ProcessGroupInd.ISSUE_IND.getProcessGroupInd());
		header.setObject_handle(object_handle);
		header.setObject_handle2(null);
		header.setLog_ind(LogInd.N.name());
		header.setStarttime(null);
		header.setEndtime(null);
		header.setGuid(null);
		header.setSession_trans_count("0000001");
		header.setHost_trans_seq(null);
		header.setReturn_code(null);
		header.setRead_only_ind(null);
		header.setNum_detail(String.valueOf(count));
		header.setRead_only_user_id(null);
		header.setLasrversion(null);

		return header;
	}

	private Header prepareconfHeader(String user_id, String object_handle, String count) {

		Header header = new Header();

		header.setUser_id(user_id);
		header.setProcess(Process.CS_REQUEST.getProcessCode());
		header.setTab_ind(TabInd.CONF.getTabIndCode());
		header.setProcess_group_ind(ProcessGroupInd.ISSUE_IND.getProcessGroupInd());
		header.setObject_handle(object_handle);
		header.setObject_handle2(null);
		header.setLog_ind(LogInd.N.name());
		header.setStarttime(null);
		header.setEndtime(null);
		header.setGuid(null);
		header.setSession_trans_count("0000001");
		header.setHost_trans_seq(null);
		header.setReturn_code(null);
		header.setRead_only_ind(null);
		header.setNum_detail(count);
		header.setRead_only_user_id(null);
		header.setLasrversion(null);

		return header;
	}

	private Header prepareHeader(String user_id, String object_handle, String count) {

		Header header = new Header();

		header.setUser_id(user_id);
		header.setProcess(Process.CS_REQUEST.getProcessCode());
		header.setTab_ind(TabInd.FOC.getTabIndCode());
		header.setProcess_group_ind(ProcessGroupInd.ISSUE_IND.getProcessGroupInd());
		header.setObject_handle(object_handle);
		header.setObject_handle2(null);
		header.setLog_ind(LogInd.N.name());
		header.setStarttime(null);
		header.setEndtime(null);
		header.setGuid(null);
		header.setSession_trans_count("0000001");
		header.setHost_trans_seq(null);
		header.setReturn_code(null);
		header.setRead_only_ind(null);
		header.setNum_detail(count);
		header.setRead_only_user_id(null);
		header.setLasrversion(null);

		return header;
	}

	private Header prepareHeader1(String user_id, String object_handle, String count) {

		Header header = new Header();

		header.setUser_id(user_id);
		header.setProcess(Process.CS_REQUEST.getProcessCode());
		header.setTab_ind(TabInd.TASK.getTabIndCode());
		header.setProcess_group_ind(ProcessGroupInd.ISSUE_IND.getProcessGroupInd());
		header.setObject_handle(object_handle);
		header.setObject_handle2(null);
		header.setLog_ind(LogInd.N.name());
		header.setStarttime(null);
		header.setEndtime(null);
		header.setGuid(null);
		header.setSession_trans_count("0000001");
		header.setHost_trans_seq(null);
		header.setReturn_code(null);
		header.setRead_only_ind(null);
		header.setNum_detail(count);
		header.setRead_only_user_id(null);
		header.setLasrversion(null);

		return header;
	}

//====================Sneha=============================
	private Header preparePostToBillHeader(String user_id, String object_handle, String count) {

		Header header = new Header();

		header.setUser_id(user_id);
		header.setProcess(Process.CS_REQUEST.getProcessCode());
		header.setTab_ind(TabInd.PostTOBill.getTabIndCode());
		header.setProcess_group_ind(ProcessGroupInd.ISSUE_IND.getProcessGroupInd());
		header.setObject_handle(object_handle);
		header.setObject_handle2(null);
		header.setLog_ind(LogInd.N.name());
		header.setStarttime(null);
		header.setEndtime(null);
		header.setGuid(null);
		header.setSession_trans_count("0000001");
		header.setHost_trans_seq(null);
		header.setReturn_code(null);
		header.setRead_only_ind(null);
		header.setNum_detail(count);
		header.setRead_only_user_id(null);
		header.setLasrversion(null);

		return header;
	}

	// ===================Sneha end Code ===================

	private Header prepareNotesHeader(String user_id, String object_handle, int count) {

		Header header = new Header();

		header.setUser_id(user_id);
		header.setProcess(Process.CS_REQUEST.getProcessCode());
		header.setTab_ind(TabInd.SAVE.getTabIndCode());
		header.setProcess_group_ind(ProcessGroupInd.SAVE_IND.getProcessGroupInd());
		header.setObject_handle(object_handle);
		header.setObject_handle2(null);
		header.setLog_ind(LogInd.N.name());
		header.setStarttime(null);
		header.setEndtime(null);
		header.setGuid(null);
		header.setSession_trans_count("0000001");
		header.setHost_trans_seq(null);
		header.setReturn_code(null);
		header.setRead_only_ind(null);
		header.setNum_detail(String.valueOf(count));
		header.setRead_only_user_id(null);
		header.setLasrversion(null);

		return header;
	}

	private SubHeader prepareNotesSubHeader(String recid, String mode) {

		// Prepare SubHeader
		SubHeader subHeader = new SubHeader();

		subHeader.setLast_ind(LastInd.Y.name());
		subHeader.setProcess_mode(mode);
		subHeader.setRecord_type(recid);
		subHeader.setReturn_code(null);
		subHeader.setDw_rownum(null);
		subHeader.setEcver(null);

		return subHeader;
	}

	private List confirmationTaskGeneral(SelectRequestData selectRequestData, Map<String, SubData> subDatas,
			HttpSession session, List treeViewList) {
		SubData subData_558Recid = subDatas.get(RecIdFor9State.CS_RECID_CONFIRM_REQORD.getRecIdValue());
		SubData subData_552Recid = subDatas.get(RecIdFor9State.CS_RECID_CONFIRM_REFNUM.getRecIdValue());
		SubData subData9_550Recid = subDatas.get(RecIdFor9State.CS_RECID_CONFIRM.getRecIdValue());
		SubData subData9_551Recid = subDatas.get(RecIdFor9State.CS_RECID_CONFIRM_HNUM.getRecIdValue());
		SubData subData_531Recid = subDatas.get(RecIdFor12State.CS_RECID_NOTES_INPUT.getRecIdValue());
		if (subData_531Recid != null && subData_531Recid.getSubHeader().getRecord_type().equals("531")) {
			List<FollowUpData9States> treeViewList_531 = new ArrayList();
			SubHeader receivedSubHeader = subData_531Recid.getSubHeader();
			String[] subDataRows = subData_531Recid.getSubDataRows();
			treeViewList.add("531");
			// int i = 0;
			for (String subDataRow : subDataRows) {
				String[] attributes = mqReadUtil.getAttributes(subDataRow, 9);
				FollowUpData9States followUp = new FollowUpData9States();
				followUp.setNotes_datetime(attributes[0]);
				followUp.setUser_id_attr(attributes[1]);
				followUp.setUser_id(attributes[2]);
				followUp.setLasr_ver_attr(attributes[3]);
				followUp.setLasr_ver(attributes[4]);
				followUp.setFollow_up_date_attr(attributes[5]);
				followUp.setFollow_up_date(attributes[6]);
				followUp.setNotes_attr(attributes[7]);
				followUp.setNotes(attributes[8]);
				treeViewList_531.add(followUp);
			}
			selectRequestData.setSubHeader(receivedSubHeader);
			// System.out.println("++++treeViewList+++before session+++"+treeViewList_543);
			session.setAttribute("treeViewList_531", treeViewList_531);
			// selectRequestData.setSelectRequestTableRows(selectRequestTableRows);
		}

		if (subData9_551Recid != null && subData9_551Recid.getSubHeader().getRecord_type().equals("551")) {
			SubHeader receivedSubHeader = subData9_551Recid.getSubHeader();
			String[] subDataRows = subData9_551Recid.getSubDataRows();
			List<ConfirmationTask_RecId_551> treeViewList_551 = new ArrayList();
			treeViewList.add("551");
			String lsrNo = "";
			String status = "";
			for (String subDataRow : subDataRows) {
				String[] attributes = mqReadUtil.getAttributes(subDataRow, 14);
				ConfirmationTask_RecId_551 noteFupData = new ConfirmationTask_RecId_551();
				noteFupData.setItem_num(attributes[0] != null && attributes[0] != "" ? attributes[0] : " ");
				noteFupData.setHnum(attributes[1] != null && attributes[1] != "" ? attributes[1] : " ");
				noteFupData.setHid_attr(attributes[2] != null && attributes[2] != "" ? attributes[2] : " "); // Not
																												// getting
																												// data...!
				noteFupData.setHid(attributes[3] != null && attributes[3] != "" ? attributes[3] : " ");
				noteFupData.setHunt_tli_attr(attributes[4] != null && attributes[4] != "" ? attributes[4] : " ");
				noteFupData.setHunt_tli(attributes[5] != null && attributes[5] != "" ? attributes[5] : " ");

				treeViewList_551.add(noteFupData);
			}
			selectRequestData.setSubHeader(receivedSubHeader);
			session.setAttribute("treeViewList_551", treeViewList_551);

		}
		if (subData_558Recid != null && subData_558Recid.getSubHeader().getRecord_type().equals("558")) {
			SubHeader receivedSubHeader = subData_558Recid.getSubHeader();
			String[] subDataRows = subData_558Recid.getSubDataRows();
			List<ConfirmationTask_RecId_558> treeViewList_558 = new ArrayList();
			treeViewList.add("558");
			String lsrNo = "";
			String status = "";
			for (String subDataRow : subDataRows) {
				String[] attributes = mqReadUtil.getAttributes(subDataRow, 14);
//					System.out.println("attributes:=558======> " + Arrays.toString(attributes));
				ConfirmationTask_RecId_558 noteFupData = new ConfirmationTask_RecId_558();
				noteFupData.setOld_dtm(attributes[0] != null && attributes[0] != "" ? attributes[0] : " ");
				noteFupData.setOld_ord(attributes[1] != null && attributes[1] != "" ? attributes[1] : " ");
				noteFupData.setOrd_attr(attributes[2] != null && attributes[2] != "" ? attributes[2] : " "); // Not
																												// getting
																												// data...!
				noteFupData.setOrd(attributes[3] != null && attributes[3] != "" ? attributes[3] : " ");
				noteFupData.setFdt_attr(attributes[4] != null && attributes[4] != "" ? attributes[4] : " ");
				noteFupData.setFdt(attributes[5] != null && attributes[5] != "" ? attributes[5] : " ");
				noteFupData.setDd_attr(attributes[6] != null && attributes[6] != "" ? attributes[6] : " ");
				noteFupData.setDd(FormatUtil
						.getMqStringToDate(attributes[7] != null && attributes[7] != "" ? attributes[7] : " "));// Rupa
																												// changes
				// noteFupData.setDd(attributes[7] != null && attributes[7] != "" ?
				// attributes[7] : " ");
				noteFupData.setComt_dt_attr(attributes[8] != null && attributes[8] != "" ? attributes[8] : " ");
				noteFupData.setComt_dt(attributes[9] != null && attributes[9] != "" ? attributes[9] : " ");
				noteFupData.setPosted_date_attr(attributes[10] != null && attributes[10] != "" ? attributes[10] : " ");
				noteFupData.setPosted_date(attributes[11] != null && attributes[11] != "" ? attributes[11] : " ");
				noteFupData.setApptime_attr(attributes[12] != null && attributes[12] != "" ? attributes[12] : " ");
				noteFupData.setApptime(attributes[13] != null && attributes[13] != "" ? attributes[13] : " ");

				treeViewList_558.add(noteFupData);
			}
			selectRequestData.setSubHeader(receivedSubHeader);
			session.setAttribute("treeViewList_558", treeViewList_558);
			// model.addAttribute("treeViewList_558", treeViewList_558);
			System.out.println("Model get Attribute  ");
		}

		if (subData_552Recid != null && subData_552Recid.getSubHeader().getRecord_type().equals("552")) {
			SubHeader receivedSubHeader = subData_552Recid.getSubHeader();
			String[] subDataRows = subData_552Recid.getSubDataRows();
			List<ConfirmationTask_RecId_552> treeViewList_552 = new ArrayList();
			treeViewList.add("552");
			String lsrNo = "";
			String status = "";
			for (String subDataRow : subDataRows) {
				String[] attributes = mqReadUtil.getAttributes(subDataRow, 42);
//					System.out.println("attributes:=552======> " + Arrays.toString(attributes));
				ConfirmationTask_RecId_552 noteFupData = new ConfirmationTask_RecId_552();
				noteFupData.setItemnum(attributes[0] != null && attributes[0] != "" ? attributes[0] : " ");
				noteFupData.setLnum(attributes[1] != null && attributes[1] != "" ? attributes[1] : " ");
				noteFupData.setNumname(attributes[2] != null && attributes[2] != "" ? attributes[2] : " "); // Not
																											// getting
																											// data...!
				noteFupData.setNum_nbr(attributes[3] != null && attributes[3] != "" ? attributes[3] : " ");
				noteFupData.setOrd_attr(attributes[4] != null && attributes[4] != "" ? attributes[4] : " ");
				noteFupData.setOrd(attributes[5] != null && attributes[5] != "" ? attributes[5] : " ");
				noteFupData.setLord_attr(attributes[6] != null && attributes[6] != "" ? attributes[6] : " ");
				noteFupData.setLord(attributes[7] != null && attributes[7] != "" ? attributes[7] : " ");

				noteFupData.setFdt_attr(attributes[8] != null && attributes[8] != "" ? attributes[8] : " ");
				noteFupData.setFdt(attributes[9] != null && attributes[9] != "" ? attributes[9] : " ");
				noteFupData.setDd_attr(attributes[10] != null && attributes[10] != "" ? attributes[10] : " ");
				noteFupData.setDd(FormatUtil
						.getMqStringToDate(attributes[11] != null && attributes[11] != "" ? attributes[11] : " "));// susheel
				noteFupData.setEcckt_attr(attributes[12] != null && attributes[12] != "" ? attributes[12] : " ");
				noteFupData.setEcckt(attributes[13] != null && attributes[13] != "" ? attributes[13] : " ");
				noteFupData.setCkr(attributes[14] != null && attributes[14] != "" ? attributes[14] : " ");
				noteFupData.setShared_nbr(attributes[15] != null && attributes[15] != "" ? attributes[15] : " ");
				noteFupData.setDisc_nbr(attributes[16] != null && attributes[16] != "" ? attributes[16] : " "); // Not
																												// getting
																												// data...!
				noteFupData.setRecckt(attributes[17] != null && attributes[17] != "" ? attributes[17] : " ");
				noteFupData.setTns_attr(attributes[18] != null && attributes[18] != "" ? attributes[18] : " ");
				noteFupData.setTns(attributes[19] != null && attributes[19] != "" ? attributes[19] : " ");
				noteFupData.setTers_attr(attributes[20] != null && attributes[20] != "" ? attributes[20] : " ");
				noteFupData.setTers(attributes[21] != null && attributes[21] != "" ? attributes[21] : " ");
				noteFupData.setCfa(attributes[22] != null && attributes[22] != "" ? attributes[22] : " ");
				noteFupData.setCcea(attributes[23] != null && attributes[23] != "" ? attributes[23] : " ");
				noteFupData.setIspid_attr(attributes[24] != null && attributes[24] != "" ? attributes[24] : " ");
				noteFupData.setIspid(attributes[25] != null && attributes[25] != "" ? attributes[25] : " ");
				noteFupData.setFecckt_attr(attributes[26] != null && attributes[26] != "" ? attributes[26] : " ");
				noteFupData.setFecckt(attributes[27] != null && attributes[27] != "" ? attributes[27] : " ");

				noteFupData.setNpord_attr(attributes[28] != null && attributes[28] != "" ? attributes[28] : " ");
				noteFupData.setNpord(attributes[29] != null && attributes[29] != "" ? attributes[29] : " ");
				noteFupData.setPorted_nbr(attributes[30] != null && attributes[30] != "" ? attributes[30] : " "); // Not
																													// getting
																													// data...!
				noteFupData.setRti_attr(attributes[31] != null && attributes[31] != "" ? attributes[31] : " ");
				noteFupData.setRti(attributes[32] != null && attributes[32] != "" ? attributes[32] : " ");
				noteFupData.setCbcid_attr(attributes[33] != null && attributes[33] != "" ? attributes[33] : " ");
				noteFupData.setCbcid(attributes[34] != null && attributes[34] != "" ? attributes[34] : " ");
				noteFupData.setCableid_attr(attributes[35] != null && attributes[35] != "" ? attributes[35] : " ");
				noteFupData.setCableid(attributes[36] != null && attributes[36] != "" ? attributes[36] : " ");
				noteFupData.setChan_pair_attr(attributes[37] != null && attributes[37] != "" ? attributes[37] : " ");
				noteFupData.setChain_pair(attributes[38] != null && attributes[38] != "" ? attributes[38] : " ");
				noteFupData.setOld_ord(attributes[39] != null && attributes[39] != "" ? attributes[39] : " ");
				noteFupData.setOld_lord(attributes[40] != null && attributes[40] != "" ? attributes[40] : " ");
				noteFupData.setOld_npord(attributes[41] != null && attributes[41] != "" ? attributes[41] : " ");
				treeViewList_552.add(noteFupData);
			}
			selectRequestData.setSubHeader(receivedSubHeader);
			session.setAttribute("treeViewList_552", treeViewList_552);

		}
		if (subData9_550Recid != null && subData9_550Recid.getSubHeader().getRecord_type().equals("550")) {

			List<ConfirmationTask_RecId12_550> treeViewList9_550 = new ArrayList<>();
			SubHeader receivedSubHeader = subData9_550Recid.getSubHeader();
			String[] subDataRows = subData9_550Recid.getSubDataRows();
			treeViewList.add("550");

			for (String subDataRow : subDataRows) {
				String[] attributes = mqReadUtil.getAttributes(subDataRow, 20);
//					System.out.println("attributes:=550:Reqid======> " + Arrays.toString(attributes));
				ConfirmationTask_RecId12_550 confirmationTask9state = new ConfirmationTask_RecId12_550();
				confirmationTask9state.setCver(attributes[0]);
				confirmationTask9state.setAtn_attr(attributes[1]);
				confirmationTask9state.setAtn(FormatUtil.getTelephoneNumberWithDashes(attributes[2] != null && attributes[2] != "" ? attributes[2] : " "));// supriya changes for date format
				confirmationTask9state.setInit(attributes[3]);
				confirmationTask9state.setRep(attributes[4]);
				confirmationTask9state.setTel_no(attributes[5]);
				confirmationTask9state.setRt(attributes[6]);
				confirmationTask9state.setEcver(attributes[7]);
				confirmationTask9state.setD_t_sent_local(attributes[8]);
				confirmationTask9state.setResponse_d_t_sent_central_time(attributes[9]);
				confirmationTask9state.setPia(attributes[10]);
				confirmationTask9state.setChc(attributes[11]);
				confirmationTask9state.setFdt_att(attributes[12]);
				confirmationTask9state.setFdt(attributes[13]);
				confirmationTask9state.setDd_attr(attributes[14]);
				confirmationTask9state.setDd(attributes[15]);
				confirmationTask9state.setApptime_attr(attributes[16]);
				confirmationTask9state.setApptime(attributes[17]);
				confirmationTask9state.setAn_attr(attributes[18]);
				confirmationTask9state.setAn(FormatUtil.getTelephoneNumberWithDashes(attributes[19] != null && attributes[19] != "" ? attributes[19] : " "));// supriya changes for date format

				treeViewList9_550.add(confirmationTask9state);
			}
			selectRequestData.setSubHeader(receivedSubHeader);
			// selectRequestData.setSelectRequestTableRows(selectRequestTableRows);
			//System.out.println("++++treeViewList_550+++before session+++" + treeViewList9_550);
			session.setAttribute("treeViewList9_550", treeViewList9_550);
		}

		return treeViewList;

	}

	public String writeSelectedRequestPopup(SelectRequestData selectRequestData, String user_id, HttpSession session,
			String object_handle) {

		Header header = prepareTreeHeader(user_id, object_handle, Process.CS_SELECT_REF.getProcessCode());
		SubHeader subHeader = prepareTreeSubHeader();

		selectRequestData.setPrevnext_cde("R");

		List<SelectRequestTableRow> selectedRequestTableRow = selectRequestData.getSelectRequestTableRows();

		String dataString = "";

		MQMessageStringBuilder mqMessageStringBuilder = new MQMessageStringBuilder();
		for (SelectRequestTableRow selectRequestTableRow : selectedRequestTableRow) {
			String tabValue = "Y";
			dataString = selectRequestTableRow.getSelectRequestTreeDataString(tabValue);
//				System.out.println("::::::dataString: popup 4th for::::"+dataString);

			mqMessageStringBuilder.addHeaderSubHeaderAndData(header, subHeader, dataString);

		}
		// boolean isWritten = false;
		boolean isWritten = mqWriteUtil.writeDataToMQ(mqMessageStringBuilder, session);

		if (isWritten) {

			MQReceivedData mqReceivedData = null;

			try {

				mqReceivedData = mqReadUtil.readSortDataFromMQ(session);
				long endTime = System.nanoTime() + TimeUnit.NANOSECONDS.convert(3L, TimeUnit.MINUTES);
				Map<String, SubData> subDatas = mqReceivedData.getSubDatas();
				// Header receivedHeader = mqReceivedData.getHeader();
				while (mqReceivedData.getHeader() == null && System.nanoTime() < endTime) {
					System.out.println("*************inside if*************** ");
					mqReceivedData = mqReadUtil.readSortDataFromMQ(session);
				}

//				  System.out.println(mqReceivedData.getHeader().toString()); 
			} catch (Exception e) {
				// TODO Auto-generated catch block
				// mqReceivedData = mqReadUtil.readDataFromMQ(session);
				e.printStackTrace();

			}
			Map<String, SubData> subDatas = mqReceivedData.getSubDatas();
			Header receivedHeader = mqReceivedData.getHeader();
			selectRequestData.setHeader(receivedHeader);
			// System.out.println("::::::receivedHeader.getReturn_code: popup 4th
			// for::::"+receivedHeader.getReturn_code());
		}
		return "success";
	}

	private List correctingConfTaskNoProd(SelectRequestData selectRequestData, Map<String, SubData> subDatas,
			HttpSession session, List treeViewList) {
		SubData subData_858Recid = subDatas.get(RecIdFor9State.CS_RECID_ISSUE_PIA_REQORD_V6.getRecIdValue());
		SubData subData_856Recid = subDatas.get(RecIdFor9State.CS_RECID_ISSUE_PIA_NOPROD_V6.getRecIdValue());
//			System.out.println("Data for RecId---->856 " + subData_856Recid);
//			System.out.println("Data for RecId---->858 " + subData_858Recid);

		if (subData_856Recid != null && subData_856Recid.getSubHeader().getRecord_type().equals("856")) {
//				System.out.println("Data for RecId---->856 " + subData_856Recid);
			SubHeader receivedSubHeader = subData_856Recid.getSubHeader();
			String[] subDataRows = subData_856Recid.getSubDataRows();
			List<Correcting_ConfirmationTask_RecId_856> treeViewList_856 = new ArrayList();
			treeViewList.add("856");
			for (String subDataRow : subDataRows) {
				String[] attributes = mqReadUtil.getAttributes(subDataRow, 14);
//					System.out.println("attributes:==856=====> " + Arrays.toString(attributes));
				Correcting_ConfirmationTask_RecId_856 corr_confrm_9state = new Correcting_ConfirmationTask_RecId_856();
				corr_confrm_9state.setCver(attributes[0] != null && attributes[0] != "" ? attributes[0] : " ");
				corr_confrm_9state.setSvc_rep(attributes[1] != null && attributes[1] != "" ? attributes[1] : " ");
				corr_confrm_9state.setSvc_rep_tn(attributes[2]);
				corr_confrm_9state.setAtn_attr(attributes[3]);
				corr_confrm_9state.setAtn(attributes[4]);
				corr_confrm_9state.setRt(attributes[5]);
				corr_confrm_9state.setEcver(attributes[6]);
				corr_confrm_9state.setD_t_sent_local(attributes[7]);
				corr_confrm_9state.setResponse_d_t_sent_central_time(attributes[8]);
				corr_confrm_9state.setDd_attr(attributes[9]);
				corr_confrm_9state.setDd(attributes[10]);
				corr_confrm_9state.setPia(attributes[11]);
				corr_confrm_9state.setAn_attr(attributes[12]);
				corr_confrm_9state.setAn(attributes[13]);

				treeViewList_856.add(corr_confrm_9state);
			}
			selectRequestData.setSubHeader(receivedSubHeader);
			session.setAttribute("treeViewList_856", treeViewList_856);
		}

		if (subData_858Recid != null && subData_858Recid.getSubHeader().getRecord_type().equals("858")) {
//				System.out.println("Data for RecId---->858 " + subData_858Recid);
			SubHeader receivedSubHeader = subData_858Recid.getSubHeader();
			String[] subDataRows = subData_858Recid.getSubDataRows();
			List<Correcting_ConfirmationTask_RecId_858> treeViewList_858 = new ArrayList();
			treeViewList.add("858");
			for (String subDataRow : subDataRows) {
				String[] attributes = mqReadUtil.getAttributes(subDataRow, 14);
//					System.out.println("attributes:==858=====> " + Arrays.toString(attributes));
				Correcting_ConfirmationTask_RecId_858 corr_confrm_9state = new Correcting_ConfirmationTask_RecId_858();
				corr_confrm_9state.setOld_dtm(attributes[0] != null && attributes[0] != "" ? attributes[0] : " ");
				corr_confrm_9state.setOld_ord(attributes[1] != null && attributes[1] != "" ? attributes[1] : " ");
				corr_confrm_9state.setOrd_attr(attributes[2] != null && attributes[2] != "" ? attributes[2] : " ");
				corr_confrm_9state.setOrd(attributes[3] != null && attributes[3] != "" ? attributes[3] : " ");
				corr_confrm_9state.setFdt_attr(attributes[4] != null && attributes[4] != "" ? attributes[4] : " ");
				corr_confrm_9state.setFdt(attributes[5] != null && attributes[5] != "" ? attributes[5] : " ");
				corr_confrm_9state.setDd_attr(attributes[6] != null && attributes[6] != "" ? attributes[6] : " ");
				corr_confrm_9state.setDd(FormatUtil
						.getMqStringToDate(attributes[7] != null && attributes[7] != "" ? attributes[7] : " "));

				corr_confrm_9state.setComt_dt_attr(attributes[8] != null && attributes[8] != "" ? attributes[8] : " ");
				corr_confrm_9state.setComt_dt(attributes[9] != null && attributes[9] != "" ? attributes[9] : " ");
				corr_confrm_9state
						.setPosted_date_attr(attributes[10] != null && attributes[10] != "" ? attributes[10] : " ");
				corr_confrm_9state
						.setPosted_date(attributes[11] != null && attributes[11] != "" ? attributes[11] : " ");
				corr_confrm_9state
						.setApptime_attr(attributes[12] != null && attributes[12] != "" ? attributes[12] : " ");
				corr_confrm_9state.setApptime(attributes[13] != null && attributes[13] != "" ? attributes[13] : " ");

				treeViewList_858.add(corr_confrm_9state);
			}
			selectRequestData.setSubHeader(receivedSubHeader);
			session.setAttribute("treeViewList_858", treeViewList_858);
		}
		return treeViewList;
	}
//kiran conf no prod
	private List confirmationTaskNoProd12(SelectRequestData selectRequestData, Map<String, SubData> subDatas,
			HttpSession session, List treeViewList) {
		SubData subData_556Recid = subDatas.get(RecIdFor12State.CS_RECID_CONFIRM_NOPROD.getRecIdValue());
		if (subData_556Recid != null && subData_556Recid.getSubHeader().getRecord_type().equals("556")) {
			SubHeader receivedSubHeader = subData_556Recid.getSubHeader();
			String[] subDataRows = subData_556Recid.getSubDataRows();
			List<ConfirmationTaskNoProd_RecId_556> treeViewList_556 = new ArrayList();
			treeViewList.add("556");
			String lsrNo = "";
			String status = "";
			for (String subDataRow : subDataRows) {
				String[] attributes = mqReadUtil.getAttributes(subDataRow, 14);
//					System.out.println("attributes:=556======> " + Arrays.toString(attributes));
				ConfirmationTaskNoProd_RecId_556 noteFupData = new ConfirmationTaskNoProd_RecId_556();
				noteFupData.setCver(attributes[0] != null && attributes[0] != "" ? attributes[0] : " ");
				noteFupData.setSvc_rep_tn(attributes[1] != null && attributes[1] != "" ? attributes[1] : " ");
				noteFupData.setSvc_rep(attributes[2] != null && attributes[2] != "" ? attributes[2] : " "); // Not
																											// getting
																											// data...!
				noteFupData.setAtn_attr(attributes[3] != null && attributes[3] != "" ? attributes[3] : " ");
				noteFupData.setAtn(attributes[4] != null && attributes[4] != "" ? attributes[4] : " ");
				noteFupData.setRt(attributes[5] != null && attributes[5] != "" ? attributes[5] : " ");
				noteFupData.setEcver(attributes[6] != null && attributes[6] != "" ? attributes[6] : " ");
				noteFupData.setD_t_sent_local(FormatUtil
						.getMqStringToDate(attributes[7] != null && attributes[7] != "" ? attributes[7] : " "));

				noteFupData.setResponse_d_t_sent_central_time(FormatUtil
						.getMqStringToDate(attributes[8] != null && attributes[8] != "" ? attributes[8] : " "));
				noteFupData.setDd_attr(attributes[9] != null && attributes[9] != "" ? attributes[9] : " ");
				noteFupData.setDd(FormatUtil
						.getMqStringToDate(attributes[10] != null && attributes[10] != "" ? attributes[10] : " "));
				noteFupData.setPia(attributes[11] != null && attributes[11] != "" ? attributes[11] : " ");
				noteFupData.setAn_attr(attributes[12] != null && attributes[12] != "" ? attributes[12] : " ");
				noteFupData.setAn(attributes[13] != null && attributes[13] != "" ? attributes[13] : " ");

				treeViewList_556.add(noteFupData);
			}
			selectRequestData.setSubHeader(receivedSubHeader);
			session.setAttribute("treeViewList_556", treeViewList_556);
			// model.addAttribute("treeViewList_558", treeViewList_558);
			System.out.println("Model get Attribute  ");
		}
		return treeViewList;
	}

	// -------------------------------------------Saurabh 12 state
	// code--------------------------------------

	// Confirmation Task No Prod 12 State
	public ConfirmationTaskNoProd9Main writeSelectedRequestConfTaskNoProd12MainData(
			ConfirmationTaskNoProd9Main confirmationTaskNoProd9Main, String user_id, String object_handle,
			HttpSession session, List<ConfirmationTask_RecId_558> updatedOrderNumberList) {

		Header header = null;
		SubHeader subHeader = null;
		StringBuilder subHeaderandData = new StringBuilder();
		System.out.println("Service:::111:inside:user_id::user_id::::" + user_id);
		String dataString556 = "";
		String dataString558 = "";
		String dataString049 = "";
		int count = 0000;
		focError.clear();
		List<ConfirmationTaskNoProd_RecId_556> correctingList_556 = confirmationTaskNoProd9Main
				.getConfirmationTaskNoProd_RecId_556();
		List<ConfirmationTask_RecId_558> correctingList_558 = updatedOrderNumberList;// Added Kiran
		// List<ConfirmationTask_RecId_558> correctingList_558 =
		// confirmationTaskNoProd9Main.getConfirmationTask_RecId_558();
		List<NotesFupBindingData12States> conformationList_049 = confirmationTaskNoProd9Main
				.getNotesFupBindingData9States();
		List<ConfirmationTask_RecId_558> conformationList_558 = (List<ConfirmationTask_RecId_558>) (session
				.getAttribute("treeViewList_558"));
		List filterRecidList = (ArrayList) session.getAttribute("treeViewList");
		MQMessageStringBuilder mqMessageStringBuilder = new MQMessageStringBuilder();
		if (session.getAttribute("showError") != null) {
			session.removeAttribute("showError");
		}
		if (filterRecidList.contains("049")) {

			for (NotesFupBindingData12States notesFupBindingData12States : conformationList_049) {
				count++;
				session.setAttribute("Lrs_No", notesFupBindingData12States.getRequest_id().substring(0, 17).trim());
//					System.out.println("::::::susheel:val 999999inside for:LrsNo:session::" + session.getAttribute("Lrs_No"));
				dataString049 = notesFupBindingData12States.getNotesFupBindingData12String();
//					System.out.println("::::::dataString: confirmationTask_RecId_049_new for::::" + dataString049);
			}
		}
		
		if(filterRecidList.contains("558")) {
			for (ConfirmationTask_RecId_558 recId_558 : correctingList_558) {
				count++;
				}
			}

		if (filterRecidList.contains("049")) {
			String countVal = "";
			System.out.println("Count:::" + count);
			if (count < 10) {
				System.out.println("less:::");
				countVal = "000" + count;
			}
			if (count >= 10) {
				System.out.println("greater:::");
				countVal = "00" + count;
			}
			header = prepareHeader(user_id, object_handle, countVal);
			subHeader = prepareSubHeader(RecIdFor9State.CS_RECID_HEADER.getRecIdValue());
			subHeaderandData.append(mqMessageStringBuilder.addHeader(header));
			subHeaderandData.append(mqMessageStringBuilder.appendSubHeaderAndData(subHeader, dataString049.toString()));
		}
		if (filterRecidList.contains("558")) {

			for (ConfirmationTask_RecId_558 recId_558 : correctingList_558) {
				recId_558.setDd(FormatUtil.getMqDateToString(recId_558.getDd()));
				System.out.println("After set Ord value------------------------------->" + recId_558);

				if (recId_558.getOrd_attr().contains("U")) {
					recId_558.setOrd_attr("Y");
				}
				if (recId_558.getDd_attr().contains("U")) {
					recId_558.setDd_attr("Y");
				}
				if (recId_558.getApptime_attr().contains("U")) {
					recId_558.setApptime_attr("Y");
				}
				if (recId_558.getApptime_attr().contains("R")) {
					recId_558.setApptime_attr("N");
				}
				if (recId_558.getPosted_date_attr().contains("R")) {
					recId_558.setPosted_date_attr("N");
				}
				if (recId_558.getComt_dt_attr().contains("R")) {
					recId_558.setComt_dt_attr("N");
				}
				if (recId_558.getDd_attr().contains("R")) {
					recId_558.setDd_attr("Y");
				}
				if (recId_558.getFdt_attr().contains("R")) {
					recId_558.setFdt_attr("N");
				}
//						recId_558.setApptime_attr("R");
//						recId_558.setOld_ord(conformationList_558.get(j).getOrd());
				dataString558 = recId_558.getSelectRequest558DataString();
				// Added kiran start
				System.out.println("::::::dataString: confirmationTask_RecId_558_new for::::" + dataString558);
				if (recId_558.getUpdateString() != null && recId_558.getUpdateString().equalsIgnoreCase("Y")) {
					subHeader = prepareSubHeader(RecIdFor9State.CS_RECID_CONFIRM_REQORD.getRecIdValue());
				} else {
					subHeader = prepareSubHeaderAdd(RecIdFor9State.CS_RECID_CONFIRM_REQORD.getRecIdValue());
				}
				// Added kiran end
//						subHeader = prepareSubHeader(RecIdFor9State.CS_RECID_CONFIRM_REQORD.getRecIdValue());
				subHeaderandData
						.append(mqMessageStringBuilder.appendSubHeaderAndData(subHeader, dataString558.toString()));
				// mqMessageStringBuilder.addHeaderSubHeaderAndData(header,subHeader,
				// dataString);
				// j++;
			}
		}

		System.out.println("::::::subHeaderandData:::: for::::" + subHeaderandData.toString());
		String mqMessageString = mqMessageStringBuilder.getMqMessageString();
		System.out.println("::::::58144444 formqMessageString::::" + mqMessageString);
		boolean isWritten = mqWriteUtil.writeDataToMQString(mqMessageString, session);
		// boolean isWritten = false;
		// String reg= (String) session.getAttribute("myReg");
		if (isWritten) {

			MQReceivedData mqReceivedData = null;

			try {

				mqReceivedData = mqReadUtil.readSortDataFromMQ(session);
				long endTime = System.nanoTime() + TimeUnit.NANOSECONDS.convert(3L, TimeUnit.MINUTES);
				Map<String, SubData> subDatas = mqReceivedData.getSubDatas();
				// Header receivedHeader = mqReceivedData.getHeader();
				while (mqReceivedData.getHeader() == null && System.nanoTime() < endTime) {
					System.out.println("*************inside if*************** ");
					mqReceivedData = mqReadUtil.readSortDataFromMQ(session);
				}

				System.out.println(mqReceivedData.getHeader().toString());
			} catch (Exception e) {
				// TODO Auto-generated catch block
				// mqReceivedData = mqReadUtil.readDataFromMQ(session);
				e.printStackTrace();

			}
//			System.out.println("::::::mqReceivedData for::::"+mqReceivedData);
			Map<String, SubData> subDatas = mqReceivedData.getSubDatas();
//			System.out.println("::::::subDatas for::::"+subDatas);
			Header receivedHeader = mqReceivedData.getHeader();
			confirmationTaskNoProd9Main.setHeader(receivedHeader);
//			System.out.println("::::::receivedHeader for::::returncode::::"+receivedHeader.getReturn_code());
			SubData subData = subDatas.get(RecIdFor12State.CS_RECID_ERROR.getRecIdValue());
//			System.out.println("subData: "+ subData);
			SubData subdata050 = subDatas.get(RecIdFor12State.CS_RECID_LSR.getRecIdValue());
			SubData subdata556 = subDatas.get(RecIdFor12State.CS_RECID_CONFIRM_NOPROD.getRecIdValue());
			SubData subdata558 = subDatas.get(RecIdFor12State.CS_RECID_CONFIRM_REQORD.getRecIdValue());
			if (subData != null) {
				String[] subDataRows = subData.getSubDataRows();

				if (receivedHeader.getReturn_code() != null && receivedHeader.getReturn_code().equals("999")) {
					for (String subDataRow : subDataRows) {
//						System.err.println("Sub data row is: " + subDataRow.toString());
						String[] attributes = mqReadUtil.getAttributes(subDataRow, 4);
						// For greater LSR versions exist error message
						if (attributes[0].equals("LG0118")) {
							String lsr_no = (String) session.getAttribute("Lrs_No");
							focError = showErrorService.getShowErrorList(subDataRow.substring(0, 6), attributes[2],
									lsr_no, "", focError);
						} else {
							focError = showErrorService.getShowErrorList(subDataRow.substring(0, 6), attributes[2], "",
									"U", focError);
						}
					}
					session.setAttribute("showError", focError);
				}
			}
			if (subdata050 != null) {
				String[] subDataRows050 = subdata050.getSubDataRows();
				String[] attributes = mqReadUtil.getAttributes(subDataRows050[0], 4);
				if (receivedHeader.getReturn_code() != null && receivedHeader.getReturn_code().equals("999")) {

					for (String subDataRow : subDataRows050) {
//							System.err.println("Sub data row is: "+subDataRow.toString());
						// For greater LSR versions exist error message
						if (attributes[0].equals("LG0118")) {
							String lsr_no = (String) session.getAttribute("Lrs_No");
							focError = showErrorService.getShowErrorList(subDataRow.substring(0, 6), attributes[2],
									lsr_no, "", focError);
						} else {
							focError = showErrorService.getShowErrorList(subDataRow.substring(0, 6), attributes[2], "",
									"U", focError);
						}
					}
					session.setAttribute("showError", focError);
				}
			}
			if (subdata556 != null) {
				String[] subDataRows556 = subdata556.getSubDataRows();
				String[] attributes = mqReadUtil.getAttributes(subDataRows556[0], 4);
				if (receivedHeader.getReturn_code() != null && receivedHeader.getReturn_code().equals("999")) {

					for (String subDataRow : subDataRows556) {
							System.err.println("Sub data row is: "+subDataRow.toString());
						// For greater LSR versions exist error message
						if (attributes[0].equals("LG0118")) {
							String lsr_no = (String) session.getAttribute("Lrs_No");
							focError = showErrorService.getShowErrorList(subDataRow.substring(0, 6), attributes[2],
									lsr_no, "", focError);
						} else {
							String lsr_no = (String) session.getAttribute("Lrs_No");
							focError = showErrorService.getShowErrorList(subDataRow.substring(0, 6), attributes[2],
									lsr_no, "", focError);
						}
					}
					session.setAttribute("showError", focError);
				}
			}
			if (subdata558 != null) {
				String[] subDataRows558 = subdata558.getSubDataRows();
				String[] attributes = mqReadUtil.getAttributes(subDataRows558[0], 4);
				if (receivedHeader.getReturn_code() != null && receivedHeader.getReturn_code().equals("999")) {

					for (String subDataRow : subDataRows558) {
//							System.err.println("Sub data row is: "+subDataRow.toString());
						// For greater LSR versions exist error message
						if (attributes[0].equals("LG0118")) {
							String lsr_no = (String) session.getAttribute("Lrs_No");
							focError = showErrorService.getShowErrorList(subDataRow.substring(0, 6), attributes[2],
									lsr_no, "", focError);
						} else {
							String lsr_no = (String) session.getAttribute("Lrs_No");
							focError = showErrorService.getShowErrorList(subDataRow.substring(0, 6), attributes[2],
									lsr_no, "", focError);
						}
					}
					session.setAttribute("showError", focError);
				}
			}

		}
		return confirmationTaskNoProd9Main;
	}

	// kiran's changes start
	public CorrectingConfTaskNoProdMain writeSelectedRequestCorrectingConfNoProdData12(
			CorrectingConfTaskNoProdMain correctingconfTaskNoProdMain, String user_id, String object_handle,
			HttpSession session, List<Correcting_ConfirmationTask_RecId_858> updatedList_858) {

		Header header = null;
		SubHeader subHeader = null;
		StringBuilder subHeaderandData = new StringBuilder();
		System.out.println("Service:::111:inside:user_id::user_id::::" + user_id);
		String dataString856 = "";
		String dataString858 = "";
		String dataString049 = "";
		int count = 0000;
		focError.clear();
		List<Correcting_ConfirmationTask_RecId_856> correctingList_856 = correctingconfTaskNoProdMain
				.getCorrecting_ConfirmationTask_RecId_856();
		// Added Kiran
		List<Correcting_ConfirmationTask_RecId_858> correctingList_858 = updatedList_858;
//		List<Correcting_ConfirmationTask_RecId_858> correctingList_858 = correctingconfTaskNoProdMain.getCorrecting_ConfirmationTask_RecId_858();
		List<NotesFupBindingData12States> conformationList_049 = correctingconfTaskNoProdMain
				.getNotesFupBindingData9States();
//		List<Correcting_ConfirmationTask_RecId_858> conformationList_858_old = (List<Correcting_ConfirmationTask_RecId_858>) (session.getAttribute("treeViewList_858"));

//		List<Correcting_ConfirmationTask_RecId_858> updatedList_858 = getUpdatedRowsForCCTNP12_858(correctingList_858, conformationList_858_old);

		List filterRecidList = (ArrayList) session.getAttribute("treeViewList");
		MQMessageStringBuilder mqMessageStringBuilder = new MQMessageStringBuilder();
		if (filterRecidList.contains("049")) {

			for (NotesFupBindingData12States notesFupBindingData12States : conformationList_049) {
				count++;
				session.setAttribute("Lrs_No", notesFupBindingData12States.getRequest_id().substring(0, 17).trim());
//					System.out.println("::::::susheel:val 999999inside for:LrsNo:session::" + session.getAttribute("Lrs_No"));
				dataString049 = notesFupBindingData12States.getNotesFupBindingData12String();
//					System.out.println("::::::dataString: confirmationTask_RecId_049_new for::::" + dataString049);

			}
		}
		System.out.println("Ord value------------------------------->" + updatedList_858.get(0).getOrd());
		int i = 0;
//			List<Correcting_ConfirmationTask_RecId_858> conformationList_858 = (List<Correcting_ConfirmationTask_RecId_858>)(session.getAttribute("treeViewList_858"));

		if (filterRecidList.contains("858")) {
//				for (Correcting_ConfirmationTask_RecId_858 correcting_confTask_RecId_858 : conformationList_858) {
//					count++;
//					}
			count = updatedList_858.size();
		}
		if (filterRecidList.contains("049")) {
			String countVal = "";
			count++;
			System.out.println("Count:::" + count);
			if (count < 10) {
				System.out.println("less:::");
				countVal = "000" + count;

			}
			if (count >= 10) {
				System.out.println("greater:::");
				countVal = "00" + count;
			}
			header = prepareHeader1(user_id, object_handle, countVal);
			subHeader = prepareSubHeader(RecIdFor12State.CS_RECID_HEADER.getRecIdValue());
			subHeaderandData.append(mqMessageStringBuilder.addHeader(header));
			subHeaderandData.append(mqMessageStringBuilder.appendSubHeaderAndData(subHeader, dataString049.toString()));
		}

		if (filterRecidList.contains("858")) {
			int j = 0;
			for (Correcting_ConfirmationTask_RecId_858 correcting_confTask_RecId_858 : updatedList_858) {

				System.out
						.println("After set Ord value------------------------------->" + correcting_confTask_RecId_858);
				dataString858 = correcting_confTask_RecId_858.getSelectRequest858DataString();
				// Added kiran start
				System.out.println("::::::dataString: correcting_confTask_RecId_858 for::::" + dataString858);
				if (correcting_confTask_RecId_858.getUpdatedString() != null
						&& correcting_confTask_RecId_858.getUpdatedString().equalsIgnoreCase("Y")) {
					subHeader = prepareSubHeader(RecIdFor12State.CS_RECID_ISSUE_PIA_REQORD_V6.getRecIdValue());
				} else {
					subHeader = prepareSubHeaderAdd(RecIdFor12State.CS_RECID_ISSUE_PIA_REQORD_V6.getRecIdValue());
				}
				// Added kiran end
//					System.out.println("::::::dataString: correcting_confTask_RecId_858 for::::"+dataString858);
//					subHeader = prepareSubHeader(RecIdFor9State.CS_RECID_ISSUE_PIA_REQORD_V6.getRecIdValue());
				subHeaderandData
						.append(mqMessageStringBuilder.appendSubHeaderAndData(subHeader, dataString858.toString()));
				j++;
				// mqMessageStringBuilder.addHeaderSubHeaderAndData(header,subHeader,
				// dataString);
			}
		}

//			System.out.println("::::::subHeaderandData:::: for::::"+subHeaderandData.toString());
		String mqMessageString = mqMessageStringBuilder.getMqMessageString();
		System.out.println("::::::58144444 formqMessageString::::" + mqMessageString);
		boolean isWritten = mqWriteUtil.writeDataToMQString(mqMessageString, session);
		// boolean isWritten = false;
		// String reg= (String) session.getAttribute("myReg");

		if (isWritten) {

			MQReceivedData mqReceivedData = null;

			try {

				mqReceivedData = mqReadUtil.readSortDataFromMQ(session);
				long endTime = System.nanoTime() + TimeUnit.NANOSECONDS.convert(3L, TimeUnit.MINUTES);
				Map<String, SubData> subDatas = mqReceivedData.getSubDatas();
				// Header receivedHeader = mqReceivedData.getHeader();
				while (mqReceivedData.getHeader() == null && System.nanoTime() < endTime) {
					System.out.println("*************inside if*************** ");
					mqReceivedData = mqReadUtil.readSortDataFromMQ(session);
				}

				System.out.println(mqReceivedData.getHeader().toString());
			} catch (Exception e) {
				// TODO Auto-generated catch block
				// mqReceivedData = mqReadUtil.readDataFromMQ(session);
				e.printStackTrace();

			}
			System.out.println("::::::mqReceivedData for::::" + mqReceivedData);
			Map<String, SubData> subDatas = mqReceivedData.getSubDatas();
//			System.out.println("::::::subDatas for::::"+subDatas);
			Header receivedHeader = mqReceivedData.getHeader();
			correctingconfTaskNoProdMain.setHeader(receivedHeader);
			System.out.println("::::::receivedHeader for::::returncode::::" + receivedHeader.getReturn_code());
			SubData subData = subDatas.get(RecIdFor9State.CS_RECID_ERROR.getRecIdValue());
			SubData subdata858 = subDatas.get(RecIdFor9State.CS_RECID_ISSUE_PIA_REQORD_V6.getRecIdValue());
			SubData subdata856 = subDatas.get(RecIdFor9State.CS_RECID_ISSUE_PIA_NOPROD_V6.getRecIdValue());
			System.out.println("subData: " + subData);

			if (subData != null) {
				String[] subDataRows = subData.getSubDataRows();

				String[] attributes = mqReadUtil.getAttributes(subDataRows[0], 4);
//				System.out.println("attributes: Aug 10 " + Arrays.toString(attributes));
				// System.out.println("recieved subheader" + receivedSubHeader.toString() );
				if (receivedHeader.getReturn_code() != null && receivedHeader.getReturn_code().equals("999")) {

					System.out.println("inside 999");
					String errorData = attributes[0];

					System.out.println("inside 999" + attributes[1]);
					System.out.println("inside 999" + attributes[2]);
					System.out.println("inside 999" + attributes[3]);
					ShowErrorService showErrorService = new ShowErrorService();
					focError = showErrorService.getErrorList(attributes[0].trim(), attributes[1], "", "U");

					session.setAttribute("showError", focError);
//				System.err.println("ERRORS CC No prod******" + focError.toString());
				}
			}
			if (subdata858 != null) {
				String[] subDataRows858 = subdata858.getSubDataRows();
				String[] attributes = mqReadUtil.getAttributes(subDataRows858[0], 4);
				if (receivedHeader.getReturn_code() != null && receivedHeader.getReturn_code().equals("999")) {
					for (String subDataRow : subDataRows858) {
//							System.err.println("Sub data row is: "+subDataRow.toString());
						// For greater LSR versions exist error message
						if (attributes[0].equals("LG0118")) {
							String lsr_no = (String) session.getAttribute("Lrs_No");
							focError = showErrorService.getShowErrorList(subDataRow.substring(0, 6), attributes[2],
									lsr_no, "", focError);
						} else {
							String lsr_no = (String) session.getAttribute("Lrs_No");
							focError = showErrorService.getShowErrorList(subDataRow.substring(0, 6), attributes[2],
									lsr_no, "", focError);
						}
					}
					session.setAttribute("showError", focError);
				}
			}
			if (subdata856 != null) {
				String[] subDataRows856 = subdata856.getSubDataRows();
				String[] attributes = mqReadUtil.getAttributes(subDataRows856[0], 4);
				if (receivedHeader.getReturn_code() != null && receivedHeader.getReturn_code().equals("999")) {
					for (String subDataRow : subDataRows856) {
//							System.err.println("Sub data row is: "+subDataRow.toString());
						// For greater LSR versions exist error message
						if (attributes[0].equals("LG0118")) {
							String lsr_no = (String) session.getAttribute("Lrs_No");
							focError = showErrorService.getShowErrorList(subDataRow.substring(0, 6), attributes[2],
									lsr_no, "", focError);
						} else {
							String lsr_no = (String) session.getAttribute("Lrs_No");
							focError = showErrorService.getShowErrorList(subDataRow.substring(0, 6), attributes[2],
									lsr_no, "", focError);
						}
					}
					session.setAttribute("showError", focError);
				}
			}

		}

		return correctingconfTaskNoProdMain;

	}

	public List<Correcting_ConfirmationTask_RecId_858> getUpdatedRowsForCCTNP12_858(
			List<Correcting_ConfirmationTask_RecId_858> newList, List<Correcting_ConfirmationTask_RecId_858> oldList) {

		List<Correcting_ConfirmationTask_RecId_858> updatedList = new ArrayList<Correcting_ConfirmationTask_RecId_858>();
		int count = 0;
		// Added by Hrushikesh - To fix backend logic for corr. conf task (logic for all
		// req types - 1/13/2022)
		for (int i = 0; i < oldList.size(); i++) {
			Correcting_ConfirmationTask_RecId_858 tableRow = newList.get(i);

			if (!tableRow.getOrd().equalsIgnoreCase(oldList.get(i).getOrd())
					|| !tableRow.getApptime().equalsIgnoreCase(oldList.get(i).getApptime())) {

				if (tableRow.getOrd_attr().contains("U")) {
					if (tableRow.getOrd().equals(oldList.get(i).getOrd()))
						tableRow.setOrd_attr("N");
					else
						tableRow.setOrd_attr("Y");
				}

				if (!tableRow.getOrd().equalsIgnoreCase(oldList.get(i).getOrd())) {
					String old_order = oldList.get(i).getOrd();
					tableRow.setOld_ord(old_order);
				}

				if (tableRow.getApptime_attr().contains("U")) {
					if (tableRow.getApptime().equalsIgnoreCase(oldList.get(i).getApptime())) {
						tableRow.setApptime_attr("N");
					} else {
						tableRow.setApptime_attr("Y");
					}
				}
				tableRow.setApptime_attr("R");

				tableRow.setUpdatedString("Y");
				updatedList.add(tableRow);
			}
			count++;
		}
		for (int j = count; j < newList.size(); j++) {
			Correcting_ConfirmationTask_RecId_858 tableRow = newList.get(j);

			if (tableRow.getOrd() != null) {
				if (!tableRow.getOrd().trim().isEmpty()) {

					if (tableRow.getOrd_attr().contains("U")) {
						tableRow.setOrd_attr("N");
					} else {
						tableRow.setOrd_attr("Y");
					}

					if (tableRow.getApptime_attr().contains("U")) {
						tableRow.setApptime_attr("N");
					} else {
						tableRow.setApptime_attr("Y");
					}

					tableRow.setUpdatedString("N");
					tableRow.setComt_dt_attr("N");
					tableRow.setApptime_attr("N");
					tableRow.setPosted_date_attr("N");
					tableRow.setDd_attr("N");
					tableRow.setFdt_attr("N");
					updatedList.add(tableRow);
				}
			}
		}
		System.err.println("Old 858 List: " + oldList.toString());
		System.err.println("new 858 List: " + newList.toString());
		System.err.println("Updated 858 List: " + updatedList.toString());
		return updatedList;
	}
	// End Y/N Functionallity for Correcting confirmation Task 12 state
	// kiran End

	// Saurabh Code End

	private List Correctingconfirmationtaskmain12states(SelectRequestData selectRequestData,
			Map<String, SubData> subDatas, HttpSession session, List treeViewList) {
		SubData subData_850Recid = subDatas.get(RecIdFor12State.CS_RECID_ISSUE_PIA_FIX_V6.getRecIdValue());
		// SubData subData_858Recid =
		// subDatas.get(RecIdFor12State.CS_RECID_ISSUE_PIA_REQORD_V6.getRecIdValue());
		SubData subData_851Recid = subDatas.get(RecIdFor12State.CS_RECID_ISSUE_PIA_HUNT_V6.getRecIdValue());
		SubData subData_852Recid = subDatas.get(RecIdFor12State.CS_RECID_ISSUE_PIA_DTL_V6.getRecIdValue());
		// Shalu-changes start done for correcting confirmation task

		if (subData_850Recid != null && subData_850Recid.getSubHeader().getRecord_type().equals("850")) {

			SubHeader receivedSubHeader = subData_850Recid.getSubHeader();
			String[] subDataRows = subData_850Recid.getSubDataRows();

			List<CorrectingConfirmationLS0G6DW1row> treeViewList_850 = new ArrayList();
			treeViewList.add("850");
			for (String subDataRow : subDataRows) {
				String[] attributes = mqReadUtil.getAttributes(subDataRow, 20);
//							System.out.println("attributes:=850======> " + Arrays.toString(attributes));
				CorrectingConfirmationLS0G6DW1row correctingconfirmationLS0G6DW1Row = new CorrectingConfirmationLS0G6DW1row();
				correctingconfirmationLS0G6DW1Row.setCver(attributes[0]);
				correctingconfirmationLS0G6DW1Row.setAtn_attr(attributes[1]);
				correctingconfirmationLS0G6DW1Row.setAtn(FormatUtil.getTelephoneNumberWithDashes(attributes[2] != null && attributes[2] != "" ? attributes[2] : " "));// supriya changes for date format
				correctingconfirmationLS0G6DW1Row.setInit(attributes[3]);
				correctingconfirmationLS0G6DW1Row.setRep(attributes[4]);
				correctingconfirmationLS0G6DW1Row.setTel_no(FormatUtil.getTelephoneNumberWithDashes(attributes[5] != null && attributes[5] != "" ? attributes[5] : " "));// supriya changes for date format
				correctingconfirmationLS0G6DW1Row.setRt(attributes[6]);
				correctingconfirmationLS0G6DW1Row.setEcver(attributes[7]);
				correctingconfirmationLS0G6DW1Row.setD_t_sent_local(FormatUtil.getMqDateTimeToViewString(attributes[8] != null && attributes[8] != "" ? attributes[8] : " "));// supriya changes for date format
				correctingconfirmationLS0G6DW1Row.setResponse_d_t_sent_central_time(FormatUtil.getMqDateTimeToViewString(attributes[9] != null && attributes[9] != "" ? attributes[9] : " "));// supriya changes for date format
				correctingconfirmationLS0G6DW1Row.setPia(attributes[10]);
				correctingconfirmationLS0G6DW1Row.setChc(attributes[11]);
				correctingconfirmationLS0G6DW1Row.setFdt_attr(attributes[12]);
				correctingconfirmationLS0G6DW1Row.setFdt(attributes[13]);
				correctingconfirmationLS0G6DW1Row.setDd_attr(attributes[14]);
				correctingconfirmationLS0G6DW1Row.setDd(FormatUtil.getMqDateAddSlash(attributes[15] != null && attributes[15] != "" ? attributes[15] : " "));// supriya changes for date format
				correctingconfirmationLS0G6DW1Row.setApptime_attr(attributes[16]);
				correctingconfirmationLS0G6DW1Row.setApptime(attributes[17]);
				correctingconfirmationLS0G6DW1Row.setAn_attr(attributes[18]);
				correctingconfirmationLS0G6DW1Row.setAn(FormatUtil.getTelephoneNumberWithDashes(attributes[19] != null && attributes[19] != "" ? attributes[19] : " "));// supriya changes for date format
				
				treeViewList_850.add(correctingconfirmationLS0G6DW1Row);
			}
			session.setAttribute("treeViewList_850", treeViewList_850);
			selectRequestData.setSubHeader(receivedSubHeader);
		}

		if (subData_851Recid != null && subData_851Recid.getSubHeader().getRecord_type().equals("851")) {

			SubHeader receivedSubHeader = subData_851Recid.getSubHeader();
			String[] subDataRows = subData_851Recid.getSubDataRows();

			List<ConfirmationLS0G6DW3Row> treeViewList_851 = new ArrayList();
			treeViewList.add("851");
			for (String subDataRow : subDataRows) {
				String[] attributes = mqReadUtil.getAttributes(subDataRow, 6);
//							System.out.println("attributes:=851======> " + Arrays.toString(attributes));
				ConfirmationLS0G6DW3Row confirmationLS0G6DW3Row = new ConfirmationLS0G6DW3Row();
				confirmationLS0G6DW3Row.setItem_num(attributes[0]);
				confirmationLS0G6DW3Row.setHnum(attributes[1]);
				confirmationLS0G6DW3Row.setHid_attr(attributes[2]);
				confirmationLS0G6DW3Row.setHid(attributes[3]);
				confirmationLS0G6DW3Row.setHunt_tli_attr(attributes[4]);
				confirmationLS0G6DW3Row.setHunt_tli(attributes[5]);

				treeViewList_851.add(confirmationLS0G6DW3Row);
			}
			session.setAttribute("treeViewList_851", treeViewList_851);
			selectRequestData.setSubHeader(receivedSubHeader);
		}
		if (subData_852Recid != null && subData_852Recid.getSubHeader().getRecord_type().equals("852")) {

			SubHeader receivedSubHeader = subData_852Recid.getSubHeader();
			String[] subDataRows = subData_852Recid.getSubDataRows();

			List<CorrectingConfirmationLS0G6DW5row> treeViewList_852 = new ArrayList();
			treeViewList.add("852");
			for (String subDataRow : subDataRows) {
				String[] attributes = mqReadUtil.getAttributes(subDataRow, 42);
//							System.out.println("attributes:=852======> " + Arrays.toString(attributes));
				CorrectingConfirmationLS0G6DW5row correctingConfirmationLS0G6DW5row = new CorrectingConfirmationLS0G6DW5row();
				correctingConfirmationLS0G6DW5row.setItemnum(attributes[0]);
				correctingConfirmationLS0G6DW5row.setLnum(attributes[1]);
				correctingConfirmationLS0G6DW5row.setNumname(attributes[2]);
				correctingConfirmationLS0G6DW5row.setNum_nbr(attributes[3]);
				correctingConfirmationLS0G6DW5row.setOrd_attr(attributes[4]);
				correctingConfirmationLS0G6DW5row.setOrd(attributes[5]);
				correctingConfirmationLS0G6DW5row.setLord_attr(attributes[6]);
				correctingConfirmationLS0G6DW5row.setLord(attributes[7]);
				correctingConfirmationLS0G6DW5row.setFdt_attr(attributes[8]);
				correctingConfirmationLS0G6DW5row.setFdt(attributes[9]);
				correctingConfirmationLS0G6DW5row.setDd_attr(attributes[10]);
				correctingConfirmationLS0G6DW5row.setDd(attributes[11]);
				correctingConfirmationLS0G6DW5row.setEcckt_attr(attributes[12]);
				correctingConfirmationLS0G6DW5row.setEcckt(attributes[13]);
				correctingConfirmationLS0G6DW5row.setCkr(attributes[14]);
				correctingConfirmationLS0G6DW5row.setShared_nbr(attributes[15]);
				correctingConfirmationLS0G6DW5row.setDisc_nbr(attributes[16]);
				correctingConfirmationLS0G6DW5row.setRecckt(attributes[17]);
				correctingConfirmationLS0G6DW5row.setTns_attr(attributes[18]);
				correctingConfirmationLS0G6DW5row.setTns(attributes[19]);
				correctingConfirmationLS0G6DW5row.setTers_attr(attributes[20]);
				correctingConfirmationLS0G6DW5row.setTers(attributes[21]);
				correctingConfirmationLS0G6DW5row.setCfa(attributes[22]);
				correctingConfirmationLS0G6DW5row.setCcea(attributes[23]);
				correctingConfirmationLS0G6DW5row.setIspid_attr(attributes[24]);
				correctingConfirmationLS0G6DW5row.setIspid(attributes[25]);
				correctingConfirmationLS0G6DW5row.setFecckt_attr(attributes[26]);
				correctingConfirmationLS0G6DW5row.setFecckt(attributes[27]);
				correctingConfirmationLS0G6DW5row.setNpord_attr(attributes[28]);
				correctingConfirmationLS0G6DW5row.setNpord(attributes[29]);
				correctingConfirmationLS0G6DW5row.setPorted_nbr(FormatUtil.getTelephoneNumberWithDashes(attributes[30] != null && attributes[30] != "" ? attributes[30] : " "));// supriya changes for date format
				correctingConfirmationLS0G6DW5row.setRti_attr(attributes[31]);
				correctingConfirmationLS0G6DW5row.setRti(attributes[32]);
				correctingConfirmationLS0G6DW5row.setCbcid_attr(attributes[33]);
				correctingConfirmationLS0G6DW5row.setCbcid(attributes[34]);
				correctingConfirmationLS0G6DW5row.setCableid_attr(attributes[35]);
				correctingConfirmationLS0G6DW5row.setCableid(attributes[36]);
				correctingConfirmationLS0G6DW5row.setChan_pair_attr(attributes[37]);
				correctingConfirmationLS0G6DW5row.setChan_pair(attributes[38]);
				correctingConfirmationLS0G6DW5row.setOld_ord(attributes[39]);
				correctingConfirmationLS0G6DW5row.setOld_lord(attributes[40]);
				correctingConfirmationLS0G6DW5row.setOld_npord(attributes[41]);

				treeViewList_852.add(correctingConfirmationLS0G6DW5row);
			}
			session.setAttribute("treeViewList_852", treeViewList_852);
			selectRequestData.setSubHeader(receivedSubHeader);
		}

		return treeViewList;
	}
	public List<Correcting_ConfirmationTask_RecId_858> getUpdatedRows858(
			List<Correcting_ConfirmationTask_RecId_858> newList, List<Correcting_ConfirmationTask_RecId_858> oldList) {
        
		List<Correcting_ConfirmationTask_RecId_858> updatedList = new ArrayList<Correcting_ConfirmationTask_RecId_858>();
		if(oldList==null) {
			return updatedList;
		}
		for (int i = 0; i < newList.size(); i++) {
			Correcting_ConfirmationTask_RecId_858 tableRow = newList.get(i);
			if (i < oldList.size()) {
				tableRow.setUpdatedString("Y");
				if (!tableRow.getOrd().equalsIgnoreCase(oldList.get(i).getOrd())
						) {

					// tableRow.setDd(oldList.get(i).getComp_dt());
					if (tableRow.getOrd().equalsIgnoreCase(oldList.get(i).getOrd())) {
						tableRow.setOrd_attr("N");
					} else {
						tableRow.setOld_ord(oldList.get(i).getOrd());

					}
					updatedList.add(tableRow);
				}
				

			} else {
				tableRow.setUpdatedString("N");
				tableRow.setComt_dt_attr("N");
				tableRow.setApptime_attr("N");
				tableRow.setPosted_date_attr("N");
				tableRow.setOrd_attr("Y");
				tableRow.setDd_attr("N");
				tableRow.setFdt_attr("N");
				if(tableRow.getOrd() != null) {
					if(tableRow.getOrd().trim() != "") {
						 updatedList.add(tableRow);
					}
				}
				     
			}
			
		}
		System.err.println("Old List1: " + oldList.toString());
		System.err.println("new List1: " + newList.toString());
		System.err.println("update List1: " + updatedList.toString());
		return updatedList;
	}
	// Ruby's changes start
	public Correctingconfirmationtaskmain12states writeSelectedRequestCorrConformationData(Correctingconfirmationtaskmain12states correctingconfirmationtaskmain12states, String user_id, String object_handle, HttpSession session,List<Correcting_ConfirmationTask_RecId_858> updatedOrderNumberList) {

		Header header = null;
		SubHeader subHeader = null;
		StringBuilder subHeaderandData = new StringBuilder();
		System.out.println("Service:::111:inside:user_id::user_id::::"+user_id);
		String dataString049 = "";
		String dataString858 = "";
		String dataString851 = "";
		String dataString852 = "";
		int count = 0000;
		focError.clear();
		//List<ConfirmationTask_RecId_558> conformationList_558 = updatedOrderNumberList;//Added susheel
		//List<Correcting_ConfirmationTask_RecId_858> conformationList_858 = updatedOrderNumberList;//Added Ruby
		List<Correcting_ConfirmationTask_RecId_858> conformationList_858 = correctingconfirmationtaskmain12states.getConfirmationTask_RecId_858();
		if(conformationList_858 == null ) {
			conformationList_858= new ArrayList<Correcting_ConfirmationTask_RecId_858>();
		}
		List<CorrectingConfirmationLS0G6DW5row> conformationList_852 = correctingconfirmationtaskmain12states.getConfirmationTask_RecId_852();
		List<NotesFupBindingData12States> conformationList_049 = correctingconfirmationtaskmain12states.getNotesFupBindingData12States();
		List<CorrectingConfirmationLS0G6DW1row> conformationList_850 = correctingconfirmationtaskmain12states.getConfirmationTask_RecId_850();
		List<ConfirmationLS0G6DW3Row> conformationList_851 = correctingconfirmationtaskmain12states.getConfirmationTask_RecId_851();
		List<CorrectingConfirmationLS0G6DW5row> list_852 = (List<CorrectingConfirmationLS0G6DW5row>)(session.getAttribute("treeViewList_852"));
		//List<CorrectingConfirmationLS0G6DW5row> conformationList_852 = (List<CorrectingConfirmationLS0G6DW5row>)(session.getAttribute("confirmationTask_RecId_852"));
		List<CorrectingConfirmationLS0G6DW5row> updateList_852=getUpdatedRows852(conformationList_852, list_852);
		
		List<Correcting_ConfirmationTask_RecId_858> updateList_858=getUpdatedRows858(conformationList_858, (List<Correcting_ConfirmationTask_RecId_858>)session.getAttribute("treeViewList_858"));
		//Shalu-changes done on 30th Sep
		List<Correcting_ConfirmationTask_RecId_858> list_858 = (List<Correcting_ConfirmationTask_RecId_858>)(session.getAttribute("treeViewList_858"));
		List<ConfirmationLS0G6DW3Row> list_851 = (List<ConfirmationLS0G6DW3Row>) (session.getAttribute("treeViewList_851"));
		//Shalu-changes end
		
		List filterRecidList = (ArrayList)session.getAttribute("treeViewList");
		MQMessageStringBuilder mqMessageStringBuilder = new MQMessageStringBuilder();
		String statesIdentity = (String)session.getAttribute("States");
		if(filterRecidList.contains("049")) {
				 for (NotesFupBindingData12States notesFupBindingData12States : conformationList_049){
		                count++;
		                session.setAttribute("Lrs_No", notesFupBindingData12States.getRequest_id().substring(0, 17).trim());
//		                System.out.println("::::::susheel:val 999999inside for:LrsNo:session::"+session.getAttribute("Lrs_No"));
		                dataString049 = notesFupBindingData12States.getNotesFupBindingData12String();
//		                System.out.println("::::::dataString: confirmationTask_RecId_049_new for::::"+dataString049);
		               
		               }
			}	
		if(filterRecidList.contains("851")) {
			System.out.println("Shalu----entering 851"+conformationList_851);
		if(CollectionUtils.isNotEmpty(conformationList_851)) {
			for (ConfirmationLS0G6DW3Row confirmationTask_RecId_851_new : conformationList_851) {
				count++;
				}}}
		if(filterRecidList.contains("858")) {
			System.out.println("Shalu----entering 858"+updateList_858);		
			for (Correcting_ConfirmationTask_RecId_858 confirmationTask_RecId_858_new : updateList_858) {
				count++;
				}
			}
		if(filterRecidList.contains("852")) {
			System.out.println("Shalu----entering 852"+updateList_852);			
			for (CorrectingConfirmationLS0G6DW5row confirmationTask_RecId_852_new : updateList_852) {
				count++;
				}
		}

		if(filterRecidList.contains("049")) {
			System.out.println("Shalu----entering 049"+filterRecidList);
			String countVal = "";
			
			System.out.println("Count:::"+count);
			if(count<10) {
				System.out.println("less:::");
				countVal= "000"+count;
			}
			if(count>=10) {
				System.out.println("greater:::");
				countVal= "00"+count;
			}
			
			header = prepareHeader1(user_id, object_handle, countVal);
			subHeader = prepareSubHeader(RecIdFor12State.CS_RECID_HEADER.getRecIdValue());
			subHeaderandData.append(mqMessageStringBuilder.addHeader(header));
			subHeaderandData.append(mqMessageStringBuilder.appendSubHeaderAndData(subHeader, dataString049.toString()));
		}
		if(filterRecidList.contains("851")) {
			//subHeader = prepareSubHeader(RecIdFor12State.CS_RECID_ISSUE_PIA_HUNT_V6.getRecIdValue());
			//Shalu-changes done on 30th Sep
			//for (ConfirmationLS0G6DW3Row confirmationLS0G6DW3Row_new : conformationList_851) {
			for(int i=0;i<conformationList_851.size();i++) {
				ConfirmationLS0G6DW3Row confirmationLS0G6DW3Row_new=conformationList_851.get(i);
				if(confirmationLS0G6DW3Row_new.getHid_attr().contains("U")) {
					if(confirmationLS0G6DW3Row_new.getHid().equals(list_851.get(i).getHid()))
						confirmationLS0G6DW3Row_new.setHid_attr("N");
					else								
						confirmationLS0G6DW3Row_new.setHid_attr("Y");
				}
				if(confirmationLS0G6DW3Row_new.getHunt_tli_attr().contains("U")) {
					if(confirmationLS0G6DW3Row_new.getHunt_tli().equals(list_851.get(i).getHunt_tli()))
						confirmationLS0G6DW3Row_new.setHunt_tli_attr("N");
					else								
						confirmationLS0G6DW3Row_new.setHunt_tli_attr("Y");
				}
			//Shalu-changes end
				
				dataString851 = confirmationLS0G6DW3Row_new.getConfirmationLS0G6DW3();
//				System.out.println("::::::dataString: confirmationLS0G6DW3Row_851_new for::::"+dataString851);
//				System.out.println("::::::header9999 for::::"+header);
//				System.out.println("::::::subHeade999r for::::"+subHeader);
			
				subHeader = prepareSubHeader(RecIdFor12State.CS_RECID_ISSUE_PIA_HUNT_V6.getRecIdValue());
				subHeaderandData.append(mqMessageStringBuilder.appendSubHeaderAndData(subHeader, dataString851.toString()));
				}
		}
		if(filterRecidList.contains("852")) {
			//Shalu-changes done on 30th Sep
			//for (CorrectingConfirmationLS0G6DW5row correctingConfirmationLS0G6DW5row_new : updateList_852) {
				for(int i=0;i<updateList_852.size();i++) {
					CorrectingConfirmationLS0G6DW5row correctingConfirmationLS0G6DW5row_new=updateList_852.get(i);
					
				
				
			    
				dataString852 = correctingConfirmationLS0G6DW5row_new.getCorrectingConfirmationLS0G6DW5();
//				System.out.println("::::::dataString: correctingConfirmationLS0G6DW5row_852_new for::::"+dataString852);
			
				subHeader = prepareSubHeader(RecIdFor12State.CS_RECID_ISSUE_PIA_DTL_V6.getRecIdValue());
				subHeaderandData.append(mqMessageStringBuilder.appendSubHeaderAndData(subHeader, dataString852.toString()));
				}
			
			}
		
		
		if(filterRecidList.contains("858")) {
			//Shalu-changes done on 30th Sep
			//for (Correcting_ConfirmationTask_RecId_858 confirmationLS0G6DW2Row_new : conformationList_858) {
			for(int i=0;i<updateList_858.size();i++) {
				Correcting_ConfirmationTask_RecId_858 confirmationLS0G6DW2Row_new=updateList_858.get(i);
				
				if(confirmationLS0G6DW2Row_new.getOrd_attr().contains("U")) {
					/*
					 * if(confirmationLS0G6DW2Row_new.getOrd().equals(updateList_858.get(i).getOrd()
					 * )) confirmationLS0G6DW2Row_new.setOrd_attr("N"); else
					 */
						confirmationLS0G6DW2Row_new.setOrd_attr("Y");
				}
				if(confirmationLS0G6DW2Row_new.getApptime_attr().contains("N")) {
					//completion_RecId_568_new.setApptime_attr("Y");
					}
					else{
						confirmationLS0G6DW2Row_new.setApptime_attr("R");
					}
                 

               //shalu:-to set old order
				
               //Shalu changes done on 25 Oct start
					if(!confirmationLS0G6DW2Row_new.getOrd().equalsIgnoreCase(updateList_858.get(i).getOrd())) {							
				    String old_order = updateList_858.get(i).getOrd();
				    if(old_order!=null)
				         confirmationLS0G6DW2Row_new.setOld_ord(old_order);
					}
				   //Shalu changes done on 25 Oct end
				    
			    
			//Shalu-changes end

				dataString858 = confirmationLS0G6DW2Row_new.getSelectRequest858DataString();
//				System.out.println("::::::dataString: confirmationLS0G6DW2Row_858_new for::::"+dataString858);
				//Added Ruby start
				System.out.println("::::::dataString: confirmationTask_RecId_558_new for::::" + dataString858);
				if(confirmationLS0G6DW2Row_new.getUpdatedString() != null && confirmationLS0G6DW2Row_new.getUpdatedString().equalsIgnoreCase("Y")) {
				subHeader = prepareSubHeader(RecIdFor12State.CS_RECID_ISSUE_PIA_REQORD_V6.getRecIdValue());
				}else {
				subHeader = prepareSubHeaderAdd(RecIdFor12State.CS_RECID_ISSUE_PIA_REQORD_V6.getRecIdValue());
				}			
				//Added Ruby end

				//subHeader = prepareSubHeader(RecIdFor12State.CS_RECID_ISSUE_PIA_REQORD_V6.getRecIdValue());
				subHeaderandData.append(mqMessageStringBuilder.appendSubHeaderAndData(subHeader, dataString858.toString()));
				}
			}
//		System.out.println("::::::subHeaderandData:::: for::::"+subHeaderandData.toString());
		String mqMessageString = mqMessageStringBuilder.getMqMessageString();
	System.out.println("::::::58144444 formqMessageString::::"+mqMessageString);
		boolean isWritten = mqWriteUtil.writeDataToMQString(mqMessageString,session);
		//boolean isWritten = false;
	//	String reg= (String) session.getAttribute("myReg");

		if (isWritten) {

			MQReceivedData mqReceivedData=null;
			
			try {

			mqReceivedData = mqReadUtil.readSortDataFromMQ(session); 
			 long endTime = System.nanoTime() + TimeUnit.NANOSECONDS.convert(3L, TimeUnit.MINUTES); 
			  Map<String, SubData> subDatas = mqReceivedData.getSubDatas(); 
		//	  Header receivedHeader = mqReceivedData.getHeader(); 
			  while(mqReceivedData.getHeader()==null&& System.nanoTime() < endTime) { 
					System.out.println("*************inside if*************** "); 
					mqReceivedData =	 mqReadUtil.readSortDataFromMQ(session); 
				} 
			  
			  
			  System.out.println(mqReceivedData.getHeader().toString()); 
		} catch (Exception e) { 
			// TODO Auto-generated catch block 
			// mqReceivedData = mqReadUtil.readDataFromMQ(session); 
			e.printStackTrace(); 


		}	
//		System.out.println("::::::mqReceivedData for::::"+mqReceivedData);
		Map<String, SubData> subDatas = mqReceivedData.getSubDatas();
//		System.out.println("::::::subDatas for::::"+subDatas);
		Header receivedHeader = mqReceivedData.getHeader();
		correctingconfirmationtaskmain12states.setHeader(receivedHeader);
//		System.out.println("::::::receivedHeader for::::returncode::::"+receivedHeader.getReturn_code());
		SubData subData = subDatas.get(RecIdFor12State.CS_RECID_ERROR.getRecIdValue());
//		System.out.println("subData: "+ subData);
		if(showError != null)
		{
			showError.clear();
		}
		
		if (subData != null) {
			String[] subDataRows = subData.getSubDataRows();

			String[] attributes = mqReadUtil.getAttributes(subDataRows[0], 4);
//			System.out.println("attributes: Aug 10 " + Arrays.toString(attributes));
		//	System.out.println("recieved subheader" + receivedSubHeader.toString() );
			if (receivedHeader.getReturn_code() != null && receivedHeader.getReturn_code().equals("999")) {
				for (String subDataRow : subDataRows) {
				// For greater LSR versions exist error message
				if (attributes[0].equals("LG0118")) {
				String lsr_no = (String) session.getAttribute("Lrs_No");
				showError = showErrorService.getShowErrorList(subDataRow.substring(0, 6), attributes[2],
				lsr_no, "", showError);
				} else {
					showError = showErrorService.getShowErrorList(subDataRow.substring(0, 6), attributes[2], "",
				"U", showError);
				}
				}
				}}
		//ruby
		SubData subdata852 = subDatas.get(RecIdFor12State.CS_RECID_ISSUE_PIA_DTL_V6.getRecIdValue());
//		
		if (subdata852 != null) {

			String[] subDataRows852 = subdata852.getSubDataRows();
			String[] attributes = mqReadUtil.getAttributes(subDataRows852[0], 4);

			if (receivedHeader.getReturn_code() != null && receivedHeader.getReturn_code().equals("999")) {
			for (String subDataRow : subDataRows852) {
			// For greater LSR versions exist error message
			if (attributes[0].equals("LG0118")) {
			String lsr_no = (String) session.getAttribute("Lrs_No");
			showError = showErrorService.getShowErrorList(subDataRow.substring(0, 6), attributes[2],
			lsr_no, "", showError);
			} else {
				showError = showErrorService.getShowErrorList(subDataRow.substring(0, 6), attributes[2], "",
			"U", showError);
			}
			}
			}
			}
		
		System.out.println("ERRORS ******" + showError.toString());
		session.setAttribute("showError", showError);
		}
		
		
		return correctingconfirmationtaskmain12states;

		}
		
	
	//Ruby
	public List<CorrectingConfirmationLS0G6DW5row> getUpdatedRows852(
			List<CorrectingConfirmationLS0G6DW5row> conformationList_852,
			List<CorrectingConfirmationLS0G6DW5row> list_852) {
		// TODO Auto-generated method stub
		
		List<CorrectingConfirmationLS0G6DW5row> updatedList=new ArrayList<CorrectingConfirmationLS0G6DW5row>();
		if(conformationList_852!=null) {  //Added By Hrushikesh- To Handle Null Pointer, when there are no rows in the table
		for(int i=0;i<conformationList_852.size();i++) {
			CorrectingConfirmationLS0G6DW5row correctingConfirmationLS0G6DW5row_new=conformationList_852.get(i);
			if (correctingConfirmationLS0G6DW5row_new.getOrd() == null) {
				correctingConfirmationLS0G6DW5row_new.setOrd("");
				}
				if (correctingConfirmationLS0G6DW5row_new.getLord() == null) {
					correctingConfirmationLS0G6DW5row_new.setLord("");
				}
				if (correctingConfirmationLS0G6DW5row_new.getNpord() == null) {
					correctingConfirmationLS0G6DW5row_new.setNpord("");
				}
			if (!correctingConfirmationLS0G6DW5row_new.getOrd().equalsIgnoreCase(list_852.get(i).getOrd())
					|| !correctingConfirmationLS0G6DW5row_new.getLord().equalsIgnoreCase(list_852.get(i).getLord())
					|| !correctingConfirmationLS0G6DW5row_new.getNpord().equalsIgnoreCase(list_852.get(i).getNpord())
					|| !correctingConfirmationLS0G6DW5row_new.getDd().equalsIgnoreCase(list_852.get(i).getDd())
					|| !correctingConfirmationLS0G6DW5row_new.getFdt().equalsIgnoreCase(list_852.get(i).getFdt())
					|| !correctingConfirmationLS0G6DW5row_new.getEcckt().equalsIgnoreCase(list_852.get(i).getEcckt())
					|| !correctingConfirmationLS0G6DW5row_new.getCkr().equalsIgnoreCase(list_852.get(i).getCkr())
					|| !correctingConfirmationLS0G6DW5row_new.getShared_nbr().equalsIgnoreCase(list_852.get(i).getShared_nbr())
					|| !correctingConfirmationLS0G6DW5row_new.getDisc_nbr().equalsIgnoreCase(list_852.get(i).getDisc_nbr())
					|| !correctingConfirmationLS0G6DW5row_new.getRecckt().equalsIgnoreCase(list_852.get(i).getRecckt())
					|| !correctingConfirmationLS0G6DW5row_new.getTns().equalsIgnoreCase(list_852.get(i).getTns())
					|| !correctingConfirmationLS0G6DW5row_new.getTers().equalsIgnoreCase(list_852.get(i).getTers())
					|| !correctingConfirmationLS0G6DW5row_new.getIspid().equalsIgnoreCase(list_852.get(i).getIspid())
					|| !correctingConfirmationLS0G6DW5row_new.getCfa().equalsIgnoreCase(list_852.get(i).getCfa())
					|| !correctingConfirmationLS0G6DW5row_new.getCcea().equalsIgnoreCase(list_852.get(i).getCcea())
					|| !correctingConfirmationLS0G6DW5row_new.getCbcid().equalsIgnoreCase(list_852.get(i).getCbcid())
					|| !correctingConfirmationLS0G6DW5row_new.getCableid().equalsIgnoreCase(list_852.get(i).getCableid())
					|| !correctingConfirmationLS0G6DW5row_new.getChan_pair().equalsIgnoreCase(list_852.get(i).getChan_pair())
					|| !correctingConfirmationLS0G6DW5row_new.getFecckt().equalsIgnoreCase(list_852.get(i).getFecckt())
					|| !correctingConfirmationLS0G6DW5row_new.getPorted_nbr().equalsIgnoreCase(list_852.get(i).getPorted_nbr())
					|| !correctingConfirmationLS0G6DW5row_new.getRti().equalsIgnoreCase(list_852.get(i).getRti()))
			{
		if(correctingConfirmationLS0G6DW5row_new.getOrd_attr().contains("U")) {
			if(correctingConfirmationLS0G6DW5row_new.getOrd().equals(list_852.get(i).getOrd()))
				correctingConfirmationLS0G6DW5row_new.setOrd_attr("N");
			else								
				correctingConfirmationLS0G6DW5row_new.setOrd_attr("Y");
		}			
		if(correctingConfirmationLS0G6DW5row_new.getEcckt_attr().contains("U")) {
			if(correctingConfirmationLS0G6DW5row_new.getEcckt().equals(list_852.get(i).getEcckt()))
				correctingConfirmationLS0G6DW5row_new.setEcckt_attr("N");
			else
				correctingConfirmationLS0G6DW5row_new.setEcckt_attr("Y");
		}
		if(correctingConfirmationLS0G6DW5row_new.getTers_attr().contains("U")) {
			if(correctingConfirmationLS0G6DW5row_new.getTers().equals(list_852.get(i).getTers()))
				correctingConfirmationLS0G6DW5row_new.setTers_attr("N");
			else
				correctingConfirmationLS0G6DW5row_new.setTers_attr("Y");
		}							
		if(correctingConfirmationLS0G6DW5row_new.getLord_attr().contains("U")) {
			if(correctingConfirmationLS0G6DW5row_new.getLord().equals(list_852.get(i).getLord()))
				correctingConfirmationLS0G6DW5row_new.setLord_attr("N");
			else
				correctingConfirmationLS0G6DW5row_new.setLord_attr("Y");
		}			
		if(correctingConfirmationLS0G6DW5row_new.getTns_attr().contains("U")) {
			if(correctingConfirmationLS0G6DW5row_new.getTns().equals(list_852.get(i).getTns()))
				correctingConfirmationLS0G6DW5row_new.setTns_attr("N");
			else
				correctingConfirmationLS0G6DW5row_new.setTns_attr("Y");
		}			
		if(correctingConfirmationLS0G6DW5row_new.getIspid_attr().contains("U")) {
			if(correctingConfirmationLS0G6DW5row_new.getIspid().equals(list_852.get(i).getIspid()))
				correctingConfirmationLS0G6DW5row_new.setIspid_attr("N");
			else
				correctingConfirmationLS0G6DW5row_new.setIspid_attr("Y");
		}
		if(correctingConfirmationLS0G6DW5row_new.getFecckt_attr().contains("U")) {
			if(correctingConfirmationLS0G6DW5row_new.getFecckt().equals(list_852.get(i).getFecckt()))
				correctingConfirmationLS0G6DW5row_new.setFecckt_attr("N");
			else
				correctingConfirmationLS0G6DW5row_new.setFecckt_attr("Y");
		}
		if(correctingConfirmationLS0G6DW5row_new.getNpord_attr().contains("U")) {
			if(correctingConfirmationLS0G6DW5row_new.getNpord().equals(list_852.get(i).getNpord()))
				correctingConfirmationLS0G6DW5row_new.setNpord_attr("N");
			else
				correctingConfirmationLS0G6DW5row_new.setNpord_attr("Y");
		}			
		if(correctingConfirmationLS0G6DW5row_new.getRti_attr().contains("U")) {
			if(correctingConfirmationLS0G6DW5row_new.getRti().equals(list_852.get(i).getRti()))
				correctingConfirmationLS0G6DW5row_new.setRti_attr("N");
			else
				correctingConfirmationLS0G6DW5row_new.setRti_attr("Y");
		}
		if(correctingConfirmationLS0G6DW5row_new.getCbcid_attr().contains("U")) {
			if(correctingConfirmationLS0G6DW5row_new.getCbcid().equals(list_852.get(i).getCbcid()))
				correctingConfirmationLS0G6DW5row_new.setCbcid_attr("N");
			else
				correctingConfirmationLS0G6DW5row_new.setCbcid_attr("Y");
		}
		if(correctingConfirmationLS0G6DW5row_new.getCableid_attr().contains("U")) {
			if(correctingConfirmationLS0G6DW5row_new.getCableid().equals(list_852.get(i).getCableid()))
				correctingConfirmationLS0G6DW5row_new.setCableid_attr("N");
			else
				correctingConfirmationLS0G6DW5row_new.setCableid_attr("Y");
		}
		if(correctingConfirmationLS0G6DW5row_new.getChan_pair_attr().contains("U")) {
			if(correctingConfirmationLS0G6DW5row_new.getChan_pair().equals(list_852.get(i).getChan_pair()))
				correctingConfirmationLS0G6DW5row_new.setChan_pair_attr("N");
			else
				correctingConfirmationLS0G6DW5row_new.setChan_pair_attr("Y");
		}
		
		
		//shalu:-to set old order
		//Shalu changes done on 25 Oct start
		//Shalu changes done on 26 Oct start
		if(correctingConfirmationLS0G6DW5row_new.getOrd()!=(list_852.get(i).getOrd())) {
			String old_order = list_852.get(i).getOrd();
			correctingConfirmationLS0G6DW5row_new.setOld_ord(old_order);
			}

		if(correctingConfirmationLS0G6DW5row_new.getLord()!=(list_852.get(i).getLord())) {
			String old_lord = list_852.get(i).getLord();
			correctingConfirmationLS0G6DW5row_new.setOld_lord(old_lord);
			}

		if(correctingConfirmationLS0G6DW5row_new.getNpord()!=(list_852.get(i).getNpord())) {
			String old_npord = list_852.get(i).getNpord();
			correctingConfirmationLS0G6DW5row_new.setOld_npord(old_npord);
			}
		
		
			updatedList.add(correctingConfirmationLS0G6DW5row_new);

			}
		  }
		}

		return updatedList;
	}
	// start code By Anj

	// start code By Anj
	// Rashmita changes start
	public List<CompletionActivityRLSOG6LscInfo> getUpdatedRows(List<CompletionActivityRLSOG6LscInfo> newList,
			List<CompletionActivityRLSOG6LscInfo> oldList) {

		List<CompletionActivityRLSOG6LscInfo> updatedList = new ArrayList<CompletionActivityRLSOG6LscInfo>();
		for (int i = 0; i < newList.size(); i++) {
			CompletionActivityRLSOG6LscInfo tableRow = newList.get(i);
			if (i < oldList.size()) {
				if (!tableRow.getOrd().equalsIgnoreCase(oldList.get(i).getOrd())
						|| (!tableRow.getComp_dt().equalsIgnoreCase(oldList.get(i).getComp_dt()))) {

					// tableRow.setDd(oldList.get(i).getComp_dt());
					if (tableRow.getOrd().equalsIgnoreCase(oldList.get(i).getOrd())) {
						tableRow.setOrd_attr("N");
					} else {
						tableRow.setOld_ord(oldList.get(i).getOrd());

					}
					tableRow.setUpdateString("Y");
					updatedList.add(tableRow);
				}
				

			} else {
				tableRow.setUpdateString("N");
				tableRow.setComp_dt_attr("Y");
				tableRow.setApptime_attr("N");
				tableRow.setPosted_date_attr("N");
				tableRow.setOrd_attr("Y");
				tableRow.setDd_attr("N");
				tableRow.setFdt_attr("N");
				updatedList.add(tableRow);
			}
			
		}
		System.err.println("Old List: " + oldList.toString());
		System.err.println("new List: " + newList.toString());
		System.err.println("update List: " + updatedList.toString());
		return updatedList;
	}


	// Rashmita's changes done
	private String getNumCount(int size) {
		String numCount = String.format("%04d", size);
		return numCount;
	}

	// Rashmita's changes Start
	public CompletionMainTask writeSelectedRequestConformationDataMethod(CompletionMainTask completionMainTask,
			String user_id, String object_handle, HttpSession session,
			List<CompletionActivityRLSOG6LscInfo> updatedOrderNumberList) {

		Header header = null;
		SubHeader subHeader = null;
		StringBuilder subHeaderandData = new StringBuilder();
		System.out.println("Service:::Anjali:inside:user_id::user_id::::" + user_id);
		String dataString049 = "";
		String dataString560 = "";
		String dataString568 = "";
		int count = 0000;
		focError.clear();

		List<CompletionProviderTask> List_560 = completionMainTask.getCompletionTask_RecID_560();
		List<CompletionActivityRLSOG6LscInfo> List_568 = completionMainTask.getCompletionTask_RecID_568();
		// List<CompletionActivityRLSOG6LscInfo> List_568 = ;
		List<NotesFupBindingData12States> List_049 = completionMainTask.getNotesFupBindingData12States();
		List filterRecidList = (ArrayList) session.getAttribute("treeViewList");
		MQMessageStringBuilder mqMessageStringBuilder = new MQMessageStringBuilder();
		List<NotesFupBindingData12States> conformationList_12States = (List<NotesFupBindingData12States>) session
				.getAttribute("treeViewList_049");
		// List<CompletionActivityRLSOG6LscInfo> updateList_568=getUpdatedRows(List_568,
		// (List<CompletionActivityRLSOG6LscInfo>)session.getAttribute("treeViewList568"));
		// Rashmita's changes done

		if (filterRecidList.contains("049")) {

			for (NotesFupBindingData12States notesFupBindingData9States : conformationList_12States) {
				count++;
				session.setAttribute("Lrs_No", notesFupBindingData9States.getRequest_id().substring(0, 17).trim());
//							System.out.println("::::::for:LrsNo:session::"+session.getAttribute("Lrs_No"));
				dataString049 = notesFupBindingData9States.getNotesFupBindingData12String();
//							System.out.println("::::::dataString: 049 for::::"+dataString049);

			}
		}

		if (filterRecidList.contains("049")) {

			String countVal = "";

			System.out.println("Count:::" + count);
			if (count < 10) {
				System.out.println("less:::");
				countVal = "000" + count;
			}
			if (count >= 10) {
				System.out.println("greater:::");
				countVal = "00" + count;// Rashmitas changes
			}

			System.out.println("Count value print " + countVal);

			System.err.println(updatedOrderNumberList.toString() + " :::::");
			countVal = getNumCount(updatedOrderNumberList.size() + 1);

			header = prepareHeader_141src(user_id, object_handle, countVal);

			subHeader = prepareSubHeader(RecIdFor12State.CS_RECID_HEADER.getRecIdValue());
			subHeaderandData.append(mqMessageStringBuilder.addHeader(header));
			subHeaderandData.append(mqMessageStringBuilder.appendSubHeaderAndData(subHeader, dataString049.toString()));

//						System.out.println("header" +header + "Sub Header Data "+subHeaderandData);
		}

		if (filterRecidList.contains("568")) {
			int i = 0;
			int j = 0;
			// List<String> ordList_558 = new ArrayList();
			for (CompletionActivityRLSOG6LscInfo completion_RecId_568_new : updatedOrderNumberList) {
				i++;
				if (completion_RecId_568_new.getApptime_attr().contains("U")) {
					completion_RecId_568_new.setApptime_attr("Y");
				}
				if (completion_RecId_568_new.getOrd_attr().contains("U")) {
					completion_RecId_568_new.setOrd_attr("Y");
				}
				if (completion_RecId_568_new.getFdt_attr().contains("U")) {
					completion_RecId_568_new.setFdt_attr("Y");
				}
				if (completion_RecId_568_new.getDd_attr().contains("U")) {
					completion_RecId_568_new.setDd_attr("Y");
				}
				if (completion_RecId_568_new.getComp_dt_attr().contains("U")) {
					completion_RecId_568_new.setComp_dt_attr("Y");
				}

				if (completion_RecId_568_new.getApptime_attr().contains("N")) {
					// completion_RecId_568_new.setApptime_attr("Y");
				} else {
					completion_RecId_568_new.setApptime_attr("R");
				}
				dataString568 = completion_RecId_568_new.getCompletionActivityRLSOG6LscInfo568();
				// Added Rashmita start 17 jan
				System.out.println("::::::dataString: confirmationTask_RecId_568_new for::::" + dataString568);
				if (completion_RecId_568_new.getUpdateString() != null
						&& completion_RecId_568_new.getUpdateString().equalsIgnoreCase("Y")) {
					subHeader = prepareSubHeader(RecIdFor12State.CS_RECID_COMPLETE_REQORD.getRecIdValue());
				} else {
					subHeader = prepareSubHeaderAdd(RecIdFor12State.CS_RECID_COMPLETE_REQORD.getRecIdValue());
				}
				// Added Rashmita end
//							System.out.println("::::::data String For : Completion Task_RecId_568_new for::::"+dataString568);

				// subHeader =
				// prepareSubHeader(RecIdFor12State.CS_RECID_COMPLETE_REQORD.getRecIdValue());
				subHeaderandData
						.append(mqMessageStringBuilder.appendSubHeaderAndData(subHeader, dataString568.toString()));
				j++;
			}
		}

		System.out.println("::::::subHeaderandData:::: for 568 for 12 state::::" + subHeaderandData.toString());
		String mqMessageString = mqMessageStringBuilder.getMqMessageString();
		System.err.println(mqMessageString);
		// boolean isWritten= false;
		boolean isWritten = mqWriteUtil.writeDataToMQString(mqMessageString, session);

		if (isWritten) {

			MQReceivedData mqReceivedData = null;

			try {

				mqReceivedData = mqReadUtil.readSortDataFromMQ(session);
				long endTime = System.nanoTime() + TimeUnit.NANOSECONDS.convert(3L, TimeUnit.MINUTES);
				Map<String, SubData> subDatas = mqReceivedData.getSubDatas();
				// Header receivedHeader = mqReceivedData.getHeader();
				while (mqReceivedData.getHeader() == null && System.nanoTime() < endTime) {
					System.out.println("*************inside if*************** ");
					mqReceivedData = mqReadUtil.readSortDataFromMQ(session);
				}

				System.out.println(mqReceivedData.getHeader().toString());
			} catch (Exception e) {
				// TODO Auto-generated catch block
				// mqReceivedData = mqReadUtil.readDataFromMQ(session);
				e.printStackTrace();

			}
//						System.out.println("::::::mqReceivedData for::::"+mqReceivedData);
			Map<String, SubData> subDatas = mqReceivedData.getSubDatas();
//						System.out.println("::::::subDatas for::::"+subDatas);
			Header receivedHeader = mqReceivedData.getHeader();
			completionMainTask.setHeader(receivedHeader);
//						System.out.println("::::::receivedHeader for::::returncode::::"+receivedHeader.getReturn_code());
			if(focError != null)
			{
				focError.clear();
			}
			
			SubData subData = subDatas.get(RecIdFor12State.CS_RECID_ERROR.getRecIdValue());

			SubData subData560 = subDatas.get(RecIdFor12State.CS_RECID_COMPLETE.getRecIdValue());
			SubData subData568 = subDatas.get(RecIdFor12State.CS_RECID_COMPLETE_REQORD.getRecIdValue());
			SubData subdata050 = subDatas.get(RecIdFor12State.CS_RECID_LSR.getRecIdValue());

			System.out.println("subData: ----->" + subData);
			// Rashmita s changes start
			if (subData != null) {
				String[] subDataRows = subData.getSubDataRows();
				// String[] attributes = mqReadUtil.getAttributes(subDataRows[0],4);
				if (receivedHeader.getReturn_code() != null && receivedHeader.getReturn_code().equals("999")) {
					for (String subDataRow : subDataRows) {
						// For greater LSR versions exist error message - Added By Hrushi
						String[] attributes = mqReadUtil.getAttributes(subDataRow, 4);
						if (attributes[0].equals("LG0118")) {
							String lsr_no = (String) session.getAttribute("Lrs_No");
							focError = showErrorService.getShowErrorList(attributes[0], attributes[2], lsr_no, "",
									focError);
						} else {
							focError = showErrorService.getShowErrorList(attributes[0], attributes[2], "", "U",
									focError);
						}
					}
				}
			}
			// Rashmitas changes done
			if (subdata050 != null) {

				String[] subDataRows = subdata050.getSubDataRows();
				if (receivedHeader.getReturn_code() != null && receivedHeader.getReturn_code().equals("999")) {
					for (String subDataRow : subDataRows) {

						String[] sentData = subDataRow.split(",");
						System.out.println("sentData after separation" + sentData);
						for (String a : sentData) {

							ShowErrorService showErrorService = new ShowErrorService();
							ReadErrorMsgsJson readErrorMsgsJson = new ReadErrorMsgsJson();
							String uon_msg = readErrorMsgsJson.getErrorMsg(a.substring(0, 6).trim());

							focError = showErrorService.getErrorListMultiple(a.substring(0, 6).trim(), uon_msg, "", "U",
									focError);

							System.err.println("ERRORS *600*****" + focError.toString());
						}
					}
				}
			}

			if (subData560 != null) {
				String[] subDataRows560 = subData560.getSubDataRows();
				if (receivedHeader.getReturn_code() != null && receivedHeader.getReturn_code().equals("999")) {
					for (String subDataRow : subDataRows560) {

						String[] sentData = subDataRow.split(",");
						System.out.println("sentData after separation" + sentData);
						for (String a : sentData) {

							ShowErrorService showErrorService = new ShowErrorService();
							ReadErrorMsgsJson readErrorMsgsJson = new ReadErrorMsgsJson();
							String uon_msg = readErrorMsgsJson.getErrorMsg(a.substring(0, 6).trim());

							focError = showErrorService.getErrorListMultiple(a.substring(0, 6).trim(), uon_msg, "", "U",
									focError);

							// focMulipleError.add(focError);
							// session.setAttribute("showError", focError);
							System.err.println("ERRORS ****** inside 560" + focError.toString());
						}
					}
				}
			}

			if (subData568 != null) {
				String[] subDataRows568 = subData568.getSubDataRows();
				if (receivedHeader.getReturn_code() != null && receivedHeader.getReturn_code().equals("999")) {
					for (String subDataRow : subDataRows568) {
//										System.err.println("Sub data row is: "+subDataRow.toString());
						String[] attributes = mqReadUtil.getAttributes(subDataRow, 4);
						// For greater LSR versions exist error message
						if (attributes[0].equals("LG0118")) {
							String lsr_no = (String) session.getAttribute("Lrs_No");
							focError = showErrorService.getShowErrorList(subDataRow.substring(0, 6), attributes[2],
									lsr_no, "", focError);
						} else {
							focError = showErrorService.getShowErrorList(subDataRow.substring(0, 6), attributes[2], "",
									"U", focError);
						}

						System.err.println("ERRORS *558*****" + focError.toString());
					}
				}
			}

			session.setAttribute("showError", focError);

		}

		return completionMainTask;

	}

	private Header prepareHeader_141src(String user_id, String object_handle, String count) {

		Header header = new Header();

		header.setUser_id(user_id);
		header.setProcess(Process.CS_REQUEST.getProcessCode());
		header.setTab_ind(TabInd.SOC.getTabIndCode());
		header.setProcess_group_ind(ProcessGroupInd.ISSUE_IND.getProcessGroupInd());
		header.setObject_handle(object_handle);
		header.setObject_handle2(null);
		header.setLog_ind(LogInd.N.name());
		header.setStarttime(null);
		header.setEndtime(null);
		header.setGuid(null);
		header.setSession_trans_count("0000001");
		header.setHost_trans_seq(null);
		header.setReturn_code(null);
		header.setRead_only_ind(null);
		header.setNum_detail(count);
		header.setRead_only_user_id(null);
		header.setLasrversion(null);

		return header;
	}

	private SubHeader prepareSubHeaderAdd(String recid) {

		// Prepare SubHeader
		SubHeader subHeader = new SubHeader();

		subHeader.setLast_ind(LastInd.Y.name());
		subHeader.setProcess_mode(ProcessMode.CS_ADD.getProcessModeCode());
		subHeader.setRecord_type(recid);
		subHeader.setReturn_code(null);
		subHeader.setDw_rownum(null);
		subHeader.setEcver(null);

		return subHeader;
	}

	public List<ShowError> getUpdatedErrorList() {
		return showError;
	}

	public List<ShowError> getErrorList() {
		return focError;
	}

	// end code By An

	private List jeopardyTaskListData(SelectRequestData selectRequestData, Map<String, SubData> subDatas,
			HttpSession session, List treeViewList) {

		SubData subData_581Recid = subDatas.get(RecIdFor12State.CS_RECID_JEOPARDY_ORDNUM.getRecIdValue());
		SubData subData_582Recid = subDatas.get(RecIdFor12State.CS_RECID_JEOPARDY_UPDATE.getRecIdValue());
		SubData subData_583Recid = subDatas.get(RecIdFor12State.CS_RECID_JEOPARDY_DETAIL.getRecIdValue());

		if (subData_581Recid != null && subData_581Recid.getSubHeader().getRecord_type().equals("581")) {

			SubHeader receivedSubHeader = subData_581Recid.getSubHeader();
			String[] subDataRows = subData_581Recid.getSubDataRows();
			List<JeopardyTask12STRechId581> treeViewList_581 = new ArrayList();
			// List<String> ordList= new ArrayList();
			treeViewList.add("581");
			int i = 0;
			for (String subDataRow : subDataRows) {

//				System.out.println( "***************** subDataRows "+ subDataRow);
				String[] attributes = mqReadUtil.getAttributes(subDataRow, 2);
//				System.out.println("attributes:=581:Reqid======> " + Arrays.toString(attributes));
				JeopardyTask12STRechId581 jeopardyTask12STRechId581 = new JeopardyTask12STRechId581();

				jeopardyTask12STRechId581.setOrd(attributes[0]);
				jeopardyTask12STRechId581.setSpeccode(attributes[1]);

//				System.out.println("jeopardyTask12STRechId581"+ jeopardyTask12STRechId581);
				treeViewList_581.add(jeopardyTask12STRechId581);

			}

			session.setAttribute("treeViewList_581", treeViewList_581);
			String test = treeViewList_581.get(0).getOrd();
			session.setAttribute("test", test);
			selectRequestData.setSubHeader(receivedSubHeader);

		}

		if (subData_583Recid != null && subData_583Recid.getSubHeader().getRecord_type().equals("583")) {

			SubHeader receivedSubHeader = subData_583Recid.getSubHeader();
			String[] subDataRows = subData_583Recid.getSubDataRows();
			List<JeopardyTask12STRechId583> treeViewList_583 = new ArrayList();
			treeViewList.add("583");
			int i = 0;
			for (String subDataRow : subDataRows) {
				String[] attributes = mqReadUtil.getAttributes(subDataRow, 20);
//				System.out.println("attributes:=583:Reqid======> " + Arrays.toString(attributes));
				JeopardyTask12STRechId583 jeopardyTask12STRechId583 = new JeopardyTask12STRechId583();

				jeopardyTask12STRechId583.setEcver_attr(attributes[0]);
				jeopardyTask12STRechId583.setEcver(attributes[1]);
				jeopardyTask12STRechId583.setJep_ecckt_attr(attributes[2]);
				jeopardyTask12STRechId583.setJep_ecckt(attributes[3]);
				jeopardyTask12STRechId583.setJep_tns_attr(attributes[4]);
				jeopardyTask12STRechId583.setJep_tns(attributes[5]);
				jeopardyTask12STRechId583.setJep_cfa_attr(attributes[6]);
				jeopardyTask12STRechId583.setJep_cfa(attributes[7]);
				jeopardyTask12STRechId583.setJep_ccea_attr(attributes[8]);
				jeopardyTask12STRechId583.setJep_ccea(attributes[9]);
				jeopardyTask12STRechId583.setCbcid_attr(attributes[10]);
				jeopardyTask12STRechId583.setCbcid(attributes[11]);
				jeopardyTask12STRechId583.setCableid_attr(attributes[12]);
				jeopardyTask12STRechId583.setCableid(attributes[13]);
				jeopardyTask12STRechId583.setChan_pair_attr(attributes[14]);
				jeopardyTask12STRechId583.setChan_pair(attributes[15]);
				jeopardyTask12STRechId583.setApptime_attr(attributes[16]);
				jeopardyTask12STRechId583.setApptime(attributes[17]);
				jeopardyTask12STRechId583.setClec_note_attr(attributes[18]);
				jeopardyTask12STRechId583.setClec_note(attributes[19]);

				treeViewList_583.add(jeopardyTask12STRechId583);
			}
			session.setAttribute("treeViewList_583", treeViewList_583);
			selectRequestData.setSubHeader(receivedSubHeader);

		}
		return treeViewList;
	}

	// Added By Hrushi- To remove existing session objects
	public void clearTreeviewSessionObjects(HttpSession session) {
		try {
			System.out.println("In Session Clear..");
			session.removeAttribute("recid_40Data");
			session.removeAttribute("confirmationReqtypRLSOG6102Rows_885");

			Enumeration<String> sessionKeys = session.getAttributeNames();

			while (sessionKeys.hasMoreElements()) {
				String key = (String) sessionKeys.nextElement();
				if (key.toLowerCase().contains("treeview") && !key.toLowerCase().contains("treeviewobjects")) {
					session.removeAttribute(key);
				}
			}

		} catch (Exception e) {
			System.out.println("In clearTreeviewSessionObjects: ");
			e.printStackTrace();
		}
	}
	
	public void clearMQResponse(HttpSession session) {
		// Start: Clear Old Response in Q if exists - Hrushi
				MQDetails mqDetFromSession = mqWriteUtil.getMqDetailsFromSession(session);
				ClearUserMQResponse readQ = new ClearUserMQResponse();
				try {
					boolean isRespCleared = readQ.read(session, mqDetFromSession);
					long endTime = System.nanoTime() + TimeUnit.NANOSECONDS.convert(1L, TimeUnit.MINUTES);
					while (isRespCleared && System.nanoTime() < endTime) {
						System.out.println("*************inside clear if************** ");
						isRespCleared = readQ.read(session, mqDetFromSession);
					}
				} catch (Exception e) {
					System.out.println(e);
				}
		// end
	}

}
