package com.att.lasr.model;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@ToString

public class TxtListDetail9 {

	private String item_num;
	private String ltxty_attr;
	private String ltxty;
	private String ltext_attr;
	private String ltext;
	private String ltxnum_attr;
	private String ltxnum;
	private String lphrase_attr;
	private String lphrase;
	private String loc_seq_num;
	
}
