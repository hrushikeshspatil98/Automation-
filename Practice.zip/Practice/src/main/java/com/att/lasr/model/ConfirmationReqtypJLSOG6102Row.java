package com.att.lasr.model;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@ToString
public class ConfirmationReqtypJLSOG6102Row {
	
	private String cver;
	private String  dor;
	private String atn;
	private String dinit;
	private String dda;
	private String rt;
	private String ecver;
	private String d_t_sent_local;	
	private String response_d_t_sent_central_time;
	private String an;

}
