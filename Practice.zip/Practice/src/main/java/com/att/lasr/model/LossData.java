package com.att.lasr.model;

import java.util.ArrayList;
import java.util.List;

import com.att.lasr.utils.Constants;
import com.att.lasr.utils.FormatUtil;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@ToString
public class LossData {
	
	private Header header;
	private SubHeader subHeader;
	private String company_code;
	private String history_date;
	private String total_record;
	private String selection;
	private String start_page;
	private String end_page;
	private String prevnext_cde;
	private String begin_time_nextptr;
	private String end_time_nextptr;
	private String begin_time_prevptr;
	private String end_time_prevptr;
	
	private List<LossTableRow> LossTableRows = new ArrayList<>();
	
	
	public String getLossDataString() {
		StringBuilder lossDataSb = new StringBuilder();
		lossDataSb.append(FormatUtil.getValueWithSpaces(company_code, 4)).append(Constants.TAB);
		lossDataSb.append(FormatUtil.getValueWithSpaces(FormatUtil.getMqDateFormatString(history_date), 8))
				.append(Constants.TAB);
		lossDataSb.append(FormatUtil.getValueWithSpaces(selection, 1)).append(Constants.TAB);
		lossDataSb.append(FormatUtil.getValueWithSpaces(total_record, 6)).append(Constants.TAB);
		lossDataSb.append(FormatUtil.getValueWithSpaces(start_page, 3)).append(Constants.TAB);
		lossDataSb.append(FormatUtil.getValueWithSpaces(end_page, 3)).append(Constants.TAB);
		lossDataSb.append(FormatUtil.getValueWithSpaces(prevnext_cde, 1)).append(Constants.TAB);
		lossDataSb.append(FormatUtil.getValueWithSpaces(begin_time_nextptr, 26)).append(Constants.TAB);
		lossDataSb.append(FormatUtil.getValueWithSpaces(end_time_nextptr, 26)).append(Constants.TAB);

		lossDataSb.append(FormatUtil.getValueWithSpaces(begin_time_prevptr, 26)).append(Constants.TAB);
		lossDataSb.append(FormatUtil.getValueWithSpaces(end_time_prevptr, 26)).append(Constants.TAB)
				.append(Constants.TAB);

		String lossDataString = FormatUtil.getValueWithSpaces(lossDataSb.toString(), 2400);
		return lossDataString;
	}

}
