package com.att.lasr.model;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@ToString
public class DirectoryDeliveryAddress9 {
	

	private String dact_attr;
	private String dact;
	private String ddapr_attr;
	private String ddapr;
	private String ddano_attr;
	private String ddano;
	private String ddasf_attr;
	private String ddasf;
	private String ddasd_attr;
	private String ddasd;
	private String ddasn_attr;
	private String ddasn;
	private String ddath_attr;
	private String ddath;
	private String ddass_attr;
	private String ddass;
	private String del_ld1_attr;
	private String ld1;
	private String del_lv1_attr;
	private String lv1;
	private String del_ld2_attr;
	private String ld2;
	private String del_lv2_attr;
	private String lv2;
	private String del_ld3_attr;
	private String ld3;
	private String del_lv3_attr;
	private String lv3;
	private String del_aai_attr;
	private String aai;
	private String del_city_attr;
	private String city;
	private String del_state_attr;
	private String state;
	private String del_zip_attr;
	private String zip;
	private String dirqty_attr;
	private String dirqty;
	private String dirtyp1_attr;
	private String dirtyp1;
	private String dirtyp2_attr;
	private String dirtyp2;
	private String dirtyp3_attr;
	private String dirtyp3;
	private String dirqtya1_attr;
	private String dirqtya1;
	private String dirqtya2_attr;
	private String dirqtya2;
	private String dirqtya3_attr;
	private String dirqtya3;
	private String dirqtync1_attr;
	private String dirqtync1;
	private String dirqtync2_attr;
	private String dirqtync2;
	private String dirqtync3_attr;
	private String dirqtync3;
	private String name_attr;
	private String name;
	
}
