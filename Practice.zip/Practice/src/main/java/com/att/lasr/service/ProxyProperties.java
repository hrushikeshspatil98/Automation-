package com.att.lasr.service;

import javax.annotation.PostConstruct;

import org.springframework.stereotype.Component;

@Component
public class ProxyProperties {
	
	@PostConstruct
	   public void setProperty() {
			
		System.out.println("inproxy properties set property method");	
			  System.setProperty("http.proxyHost", "proxy.conexus.svc.local");
			  System.setProperty("http.proxyPort", "3128");
			  System.setProperty("http.proxySet", "true");
			  System.setProperty("https.proxyHost", "proxy.conexus.svc.local");
			  System.setProperty("https.proxyPort", "3128");
			  System.setProperty("https.proxySet", "true");
			  
			 
			 
	   }
	  
}
