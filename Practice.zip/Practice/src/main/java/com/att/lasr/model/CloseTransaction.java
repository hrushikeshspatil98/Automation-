/**
 * 
 */
package com.att.lasr.model;

import com.att.lasr.utils.Constants;
import com.att.lasr.utils.FormatUtil;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

/**
 * @author mk5650
 *
 */

@Getter
@Setter
@NoArgsConstructor
@ToString
public class CloseTransaction {
	String lsr_number;
	String next;
	String user_id;
	


public String getCloseTransactionDataString() {
	StringBuilder Closedatasb = new StringBuilder();
	
	Closedatasb.append(FormatUtil.getValueWithSpaces(lsr_number, 14)).append(Constants.TAB);
	Closedatasb.append(FormatUtil.getValueWithSpaces(next, 2)).append(Constants.TAB);
	Closedatasb.append(FormatUtil.getValueWithSpaces(user_id, 7)).append(Constants.TAB).append(Constants.TAB);

	
	String CloseTransactionDataString = FormatUtil.getValueWithSpaces(Closedatasb.toString(), 2400);
	return CloseTransactionDataString;

}
}
