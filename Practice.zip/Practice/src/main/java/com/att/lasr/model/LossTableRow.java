package com.att.lasr.model;



import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@ToString
public class LossTableRow {
	

	private String company_code;
	private String deliv_meth;
	private String date_profiled;
	private String prof_def;
	private String map;
	private String trading_appl;
	private String report_date;
	private String notification_timestamp;
	private String total_record;
	private String start_page;
	private String end_page;	
	private String prevnext_cde;
	private String begin_time_nextptr;
	private String end_time_nextptr;
	private String begin_time_prevptr;
	private String end_time_prevptr;

}
