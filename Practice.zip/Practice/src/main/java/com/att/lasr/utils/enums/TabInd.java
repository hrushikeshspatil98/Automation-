package com.att.lasr.utils.enums;

public enum TabInd {

	RESALE("150"), LOOP("200"), NP("250"), LOOP_PORT("275"), LOOP_NP("300"), PORT("350"), NOTES("530"), FOC("550"),FOC_TASK9("905"),
	SOC("560"), REJECT("570"), SAVE("531"),TASK("850"), PostTOBill("585"), SORT("546"), ISSUE("603"), CONF("553"), VALIDATE_CC_CPLOSS("574"), ISSUE_CPL("560"), ECVER_ISSUE("542");
    

	private final String tabIndCode;

	TabInd(String tabIndCode) {
		this.tabIndCode = tabIndCode;
	}

	public String getTabIndCode() {
		return tabIndCode;
	}
}
