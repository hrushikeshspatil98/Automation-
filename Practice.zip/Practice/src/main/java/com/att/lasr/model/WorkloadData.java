package com.att.lasr.model;

import java.util.ArrayList;
import java.util.List;

import com.att.lasr.utils.Constants;
import com.att.lasr.utils.FormatUtil;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@ToString
public class WorkloadData {

	private Header header;
	private SubHeader subHeader;

	private String user_id;
	private String group_id;
	private String company_code;
	private String sc;
	private String status;
	private String req_type;
	private String act;
	private String sm_dttm_rcvd;
	private String sm_time;
	private String am_pm;
	private String due_date;
	private String cd;
	private String total_record;
	private String start_page;
	private String end_page;
	private String prevnext_cde;
	private String begin_time_nextptr;
	private String end_time_nextptr;
	private String begin_time_prevptr;
	private String end_time_prevptr;

	private List<WorkloadTableRow> workloadTableRows = new ArrayList<>();

	public String getWorkloadDataString() {

		StringBuilder workloadDataSb = new StringBuilder();
		workloadDataSb.append(FormatUtil.getValueWithSpaces(user_id, 7)).append(Constants.TAB);
		workloadDataSb.append(FormatUtil.getValueWithSpaces(group_id, 6)).append(Constants.TAB);
		workloadDataSb.append(FormatUtil.getValueWithSpaces(company_code, 4)).append(Constants.TAB);
		workloadDataSb.append(FormatUtil.getValueWithSpaces(sc, 2)).append(Constants.TAB);
		workloadDataSb.append(FormatUtil.getValueWithSpaces(status, 2)).append(Constants.TAB);
		workloadDataSb.append(FormatUtil.getValueWithSpaces(req_type, 1)).append(Constants.TAB);

		workloadDataSb.append(FormatUtil.getValueWithSpaces(act, 1)).append(Constants.TAB);
		workloadDataSb.append(FormatUtil.getValueWithSpaces(FormatUtil.getMqDateFormatString(sm_dttm_rcvd), 8))
				.append(Constants.TAB);
		workloadDataSb.append(FormatUtil.getValueWithSpaces(sm_time, 2)).append(Constants.TAB);
		workloadDataSb.append(FormatUtil.getValueWithSpaces(am_pm, 2)).append(Constants.TAB);
		workloadDataSb.append(FormatUtil.getValueWithSpaces(FormatUtil.getMqDateFormatString(due_date), 8))
				.append(Constants.TAB);
		workloadDataSb.append(FormatUtil.getValueWithSpaces(FormatUtil.getMqDateFormatString(cd), 8))
				.append(Constants.TAB);

		workloadDataSb.append(FormatUtil.getValueWithSpaces(total_record, 6)).append(Constants.TAB);
		workloadDataSb.append(FormatUtil.getValueWithSpaces(start_page, 3)).append(Constants.TAB);
		workloadDataSb.append(FormatUtil.getValueWithSpaces(end_page, 3)).append(Constants.TAB);
		workloadDataSb.append(FormatUtil.getValueWithSpaces(prevnext_cde, 1)).append(Constants.TAB);
		workloadDataSb.append(FormatUtil.getValueWithSpaces(begin_time_nextptr, 26)).append(Constants.TAB);
		workloadDataSb.append(FormatUtil.getValueWithSpaces(end_time_nextptr, 26)).append(Constants.TAB);
		workloadDataSb.append(FormatUtil.getValueWithSpaces(begin_time_prevptr, 26)).append(Constants.TAB);
		workloadDataSb.append(FormatUtil.getValueWithSpaces(end_time_prevptr, 26)).append(Constants.TAB)
				.append(Constants.TAB);

		String workloadDataString = FormatUtil.getValueWithSpaces(workloadDataSb.toString(), 2400);
		return workloadDataString;
	}

}
