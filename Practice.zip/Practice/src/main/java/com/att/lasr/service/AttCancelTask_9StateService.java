package com.att.lasr.service;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.att.lasr.model.AttCancelTask9;
import com.att.lasr.model.AttErrorCodeData;
import com.att.lasr.model.AttErrorCodeData9;
import com.att.lasr.model.Header;
import com.att.lasr.model.MQReceivedData;
import com.att.lasr.model.NotesFupBindingData12States;
import com.att.lasr.model.SubData;
import com.att.lasr.model.SubHeader;
import com.att.lasr.utils.Constants;
import com.att.lasr.utils.FormatUtil;
import com.att.lasr.utils.MQMessageStringBuilder;
import com.att.lasr.utils.MQReadUtil;
import com.att.lasr.utils.MQWriteUtil;
import com.att.lasr.utils.enums.LastInd;
import com.att.lasr.utils.enums.ProcessGroupInd;
import com.att.lasr.utils.enums.ProcessMode;
import com.att.lasr.utils.enums.RecIdFor9State;
@Service
public class AttCancelTask_9StateService {

		@Autowired
		private MQReadUtil mqReadUtil;

		@Autowired
		private MQWriteUtil mqWriteUtil;

		public void attCancelTask_9StateDataToMQ(ArrayList<AttCancelTask9> attcanceltask9, String user_id, HttpSession session) {
		
			Header header = prepareHeader(user_id);
			SubHeader subHeader = prepareSubHeader();
			SubHeader subHeader1 = prepareSubHeader1();

			List<NotesFupBindingData12States> treeViewList = (List<NotesFupBindingData12States>) session
					.getAttribute("treeViewList_049");
			
			String secondRecord = attcanceltask9.get(0).toString();
			//NotesFupBindingData12States notes=new NotesFupBindingData12States();
			//String final1=notes.getNotesFupBindingData12String();
			String final1 = createdataforMq(treeViewList);
			String final2 = createdataforMq1(attcanceltask9);
			MQMessageStringBuilder mqMessageStringBuilder = new MQMessageStringBuilder().addHeaderSubHeaderAndData(header,
					subHeader, final1);
			mqMessageStringBuilder.appendSubHeaderAndData(subHeader1, final2);

			System.out.println("mq message string builder response" + mqMessageStringBuilder);
			boolean isWritten = mqWriteUtil.writeDataToMQ(mqMessageStringBuilder,session);
			System.out.println(isWritten);
			AttErrorCodeData9 attErrorCodeData9 = new AttErrorCodeData9();
			String lg_code = null;
			String returncode = null;
			
			if (isWritten) {
				MQReceivedData mqReceivedData=null;
				
				try {

				mqReceivedData = mqReadUtil.readSortDataFromMQ(session); 
				 long endTime = System.nanoTime() + TimeUnit.NANOSECONDS.convert(3L, TimeUnit.MINUTES); 
				  Map<String, SubData> subDatas = mqReceivedData.getSubDatas(); 
			//	  Header receivedHeader = mqReceivedData.getHeader(); 
				  while(mqReceivedData.getHeader()==null&& System.nanoTime() < endTime) { 
						System.out.println("*************inside if*************** "); 
						mqReceivedData =	 mqReadUtil.readSortDataFromMQ(session); 
					} 
				  
				  
				  System.out.println(mqReceivedData.getHeader().toString()); 
			} catch (Exception e) { 
				// TODO Auto-generated catch block 
				// mqReceivedData = mqReadUtil.readDataFromMQ(session); 
				e.printStackTrace(); 


			}
				Map<String, SubData> subDatas = mqReceivedData.getSubDatas();
				Header receivedHeader = mqReceivedData.getHeader();
				System.out.println(receivedHeader.toString());
				attErrorCodeData9.setHeader(receivedHeader);
				attErrorCodeData9.setHeader(receivedHeader);
				System.out.println("received return code" + receivedHeader.getReturn_code());
				returncode = receivedHeader.getReturn_code();
				SubData subData = subDatas.get(RecIdFor9State.CS_RECID_DISPLAY_SBC_CANCEL.getRecIdValue());

				if (subData != null) {
					SubHeader receivedSubHeader = subData.getSubHeader();
					System.out.println(receivedSubHeader.toString());
					String[] subDataRows = subData.getSubDataRows();
					List<AttErrorCodeData9> attErrorList = new ArrayList<>();
					for (String subDataRow : subDataRows) {

						String[] attributes = mqReadUtil.getAttributes(subDataRow, 5);
						System.out.println("attributes: " + Arrays.toString(attributes));
						AttErrorCodeData9 attErrorResponse = new AttErrorCodeData9();
						attErrorResponse.setLg_code(attributes[0]);
						lg_code = attributes[0];

						attErrorResponse.setField_name(attributes[1]);
						attErrorResponse.setField_value(attributes[2]);
						attErrorResponse.setProcess_mode(attributes[3]);
						attErrorResponse.setErr_failed(attributes[4]);
						attErrorList.add(attErrorResponse);

					}
					attErrorCodeData9.setSubHeader(receivedSubHeader);
					session.setAttribute("attErrorList", attErrorList);
					

				}
				if (returncode.equals("000")) {
					ReadErrorMsgsJson readErrorMsgsJson = new ReadErrorMsgsJson();
					String errormsg = readErrorMsgsJson.getErrorMsg("LG0016");
					System.out.println("error msg: " + errormsg);
					session.setAttribute("error_msg", errormsg);
					String flag = "no";
					session.setAttribute("yes", flag);
				}

				if (returncode.equals("999")) {
					ReadErrorMsgsJson readErrorMsgsJson = new ReadErrorMsgsJson();
					String errormsg = readErrorMsgsJson.getErrorMsg(lg_code);
					System.out.println("error msg: " + errormsg);
					session.setAttribute("error_message", errormsg);
				}
				if (returncode.equals("888")) {
					ReadErrorMsgsJson readErrorMsgsJson = new ReadErrorMsgsJson();
					String errormsg = readErrorMsgsJson.getErrorMsg("LG0022");
					System.out.println("error msg: " + errormsg);
					session.setAttribute("error_message", errormsg);
				}
				if (returncode.equals("887")) {
					ReadErrorMsgsJson readErrorMsgsJson = new ReadErrorMsgsJson();
					String errormsg = readErrorMsgsJson.getErrorMsg("LG0024");
					System.out.println("error msg: " + errormsg);
					session.setAttribute("error_message", errormsg);
				}
				if (returncode.equals("889")) {
					ReadErrorMsgsJson readErrorMsgsJson = new ReadErrorMsgsJson();
					String errormsg = readErrorMsgsJson.getErrorMsg("LG0067");
					System.out.println("error msg: " + errormsg);
					session.setAttribute("error_message", errormsg);
				}

			}

		}

		private String createdataforMq1(ArrayList<AttCancelTask9> attcanceltask9) {
			StringBuilder sb = new StringBuilder();
			sb.append(attcanceltask9.get(0).getOrd()).append(Constants.TAB);
			sb.append(attcanceltask9.get(0).getOrd_status()).append(Constants.TAB);
			sb.append(attcanceltask9.get(0).getDd()).append(Constants.TAB);
			sb.append(attcanceltask9.get(0).getRcode()).append(Constants.TAB);
			sb.append(attcanceltask9.get(0).getJcode()).append(Constants.TAB);
			sb.append(attcanceltask9.get(0).getRdet()).append(Constants.TAB);
			sb.append(attcanceltask9.get(0).getDt_sent_local()).append(Constants.TAB);
			sb.append(attcanceltask9.get(0).getDt_sent_central_time()).append(Constants.TAB).append(Constants.TAB);
			String finalString1 = FormatUtil.getValueWithSpaces(sb.toString(), 2400);
			return finalString1;
		}

		private SubHeader prepareSubHeader() {

			// Prepare SubHeader
			SubHeader subHeader = new SubHeader();

			subHeader.setLast_ind(LastInd.Y.name());
			subHeader.setProcess_mode(ProcessMode.CS_UPDATE.getProcessModeCode());
			subHeader.setRecord_type(RecIdFor9State.CS_RECID_HEADER.getRecIdValue());
			subHeader.setReturn_code(null);
			subHeader.setDw_rownum(null);
			subHeader.setEcver(null);

			return subHeader;
		}

		private SubHeader prepareSubHeader1() {

			// Prepare SubHeader
			SubHeader subHeader = new SubHeader();

			subHeader.setLast_ind(LastInd.Y.name());
			subHeader.setProcess_mode(ProcessMode.CS_UPDATE.getProcessModeCode());
			subHeader.setRecord_type(RecIdFor9State.CS_RECID_DISPLAY_SBC_CANCEL.getRecIdValue());
			subHeader.setReturn_code(null);
			subHeader.setDw_rownum(null);
			subHeader.setEcver(null);

			return subHeader;
		}

		private Header prepareHeader(String user_id) {
			// Prepare Header
			Header header = new Header();

			header.setUser_id(user_id);
			header.setProcess("REQ");
			header.setTab_ind(RecIdFor9State.CS_RECID_DISPLAY_SBC_CANCEL.getRecIdValue());
			header.setProcess_group_ind(ProcessGroupInd.ISSUE_IND.getProcessGroupInd());
			header.setObject_handle("00000000");
			header.setObject_handle2(null);
			header.setLog_ind(LastInd.N.name());
			header.setStarttime(null);
			header.setEndtime(null);
			header.setGuid(null);
			header.setSession_trans_count("0000001");
			header.setHost_trans_seq(null);
			header.setReturn_code(null);
			header.setRead_only_ind(null);
			header.setNum_detail("0002");
			header.setRead_only_user_id(null);
			header.setLasrversion(null);

			return header;
		}

		
		public String createdataforMq(List<NotesFupBindingData12States> treeViewList)
		  {
		  
		  String company_code = treeViewList.get(0).getCompany_code(); 
		  String date_time_received =treeViewList.get(0).getDate_time_received(); 
		  String pon = treeViewList.get(0).getPon(); 
		  String Rver = treeViewList.get(0).getRver();
		  String request_id = treeViewList.get(0).getRequest_id(); 
		  String reqtype = treeViewList.get(0).getReqtype(); 
		  String Status = treeViewList.get(0).getStatus(); 
		  String lspauth_attr = treeViewList.get(0).getLspauth_attr(); 
		  String lspauth = treeViewList.get(0).getLspauth();
		  StringBuilder sb = new StringBuilder();
		  sb.append(FormatUtil.getValueWithSpaces(company_code, 4)).append(Constants.TAB);
		  sb.append(FormatUtil.getValueWithSpaces(date_time_received,
		  17)).append(Constants.TAB); sb.append(FormatUtil.getValueWithSpaces(pon,
		  16)).append(Constants.TAB); sb.append(FormatUtil.getValueWithSpaces(Rver,
		  5)).append(Constants.TAB); sb.append(FormatUtil.getValueWithSpaces(request_id,
		  18)).append(Constants.TAB); sb.append(FormatUtil.getValueWithSpaces(reqtype,
		  2)).append(Constants.TAB); sb.append(FormatUtil.getValueWithSpaces(Status,
		  12)).append(Constants.TAB);
		  sb.append(FormatUtil.getValueWithSpaces(lspauth_attr,
		  1)).append(Constants.TAB); sb.append(FormatUtil.getValueWithSpaces(lspauth,
		  4)).append(Constants.TAB).append(Constants.TAB);
		  
		  String finalString = FormatUtil.getValueWithSpaces(sb.toString(), 2400);
		  
		  return finalString; }
		 

}
