package com.att.lasr.utils.enums;

public enum ProcessGroupInd {
	RETRIEVE_IND("R"), SAVE_IND("S"), ISSUE_IND("I"), SPECIAL_IND("X"), CHECK_IND("C"), ECVER_IND("Z"), VERIFY_IND("V"),
	JUSTGO_IND("J"), REFRESH_IND("A"), WOW_IND("W"), SORT_IND("T");

	private final String processGroupIndCode;

	ProcessGroupInd(String processGroupIndCode) {
		this.processGroupIndCode = processGroupIndCode;
	}

	public String getProcessGroupInd() {

		return processGroupIndCode;
	}

}