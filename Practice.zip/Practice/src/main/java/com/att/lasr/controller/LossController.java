package com.att.lasr.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.SessionAttributes;

import com.att.lasr.model.EnvRegion;
import com.att.lasr.model.LossData;
import com.att.lasr.service.LossService;
import com.att.lasr.utils.MockDtoDataUtil;
import com.google.gson.Gson;

@Controller
@SessionAttributes("region")
public class LossController {

	@Autowired
	HttpSession httpSession;

	@Autowired
	public LossController lossCtrl;

	@Autowired
	public WorkloadController workloadCtrl;

	@Autowired
	private LossService lossService;
	
	@Autowired
	EnvRegionController envRegionCtrl;

//	EnvRegion e = EnvRegionController.getobj();
	
	@RequestMapping(value = "/loss", method = RequestMethod.GET)
	public String showLossPage(ModelMap model, HttpSession session) {
		System.out.println("in /loss get method");
		
		EnvRegion e = envRegionCtrl.getEnvRegion(session);
		
		String userId = (String) httpSession.getAttribute("userId");
		String environment = (String) session.getAttribute("environment");
		model.addAttribute("userId", userId);
		model.addAttribute("environment", environment);
		model.addAttribute("envregion", e);
		model.addAttribute("screenObj", workloadCtrl.screenObj);
		model.addAttribute("indicator",false)	;
		model.addAttribute("indicator1",false)	;
		model.addAttribute("indicator2",false)	;
		model.addAttribute("indicator3",false)	;
		model.addAttribute("indicator4",false) ;
		model.addAttribute("navbarArr", session.getAttribute("navBarArr"));
		String currInde = "";
		Object currInd = session.getAttribute("currentPageIndex");
		if (!(currInd == null)) {
			currInde = currInd.toString();
			System.out.println("session -->" + session.getAttribute("currentPageIndex"));
			System.out.println("currInde" + currInde);
		}

		int currIndex = 0;
		if (!checkNullString(currInde)) {
			currIndex = Integer.parseInt(currInde);
			session.setAttribute("currentPageIndex", currIndex + "");
		}
		LossData lossDto = getLossDataFromSession(session, currIndex);
		//System.out.println("data to display-->" + lossDto.getLossTableRows().size());
		model.addAttribute("lossData", lossDto);

		return "loss";
	}

//	@RequestMapping(value = "/loss", method = RequestMethod.GET)
//	public String showLossPage(ModelMap model, HttpSession session) {
//		System.out.println("in /loss get method");
//		String userId = (String) httpSession.getAttribute("userId");
//		String environment = (String) session.getAttribute("environment");
//		model.addAttribute("userId", userId);
//		model.addAttribute("environment", environment);
//		
//		EnvRegion e = envRegionCtrl.getEnvRegionFromSession(session,model);
//		model.addAttribute("envregion", e);
//		model.addAttribute("screenObj", workloadCtrl.screenObj);
//		model.addAttribute("navbarArr", session.getAttribute("navBarArr"));
//		String currInde = "";
//		Object currInd = session.getAttribute("currentPageIndex");
//		if (!(currInd == null)) {
//			currInde = currInd.toString();
//			System.out.println("session -->" + session.getAttribute("currentPageIndex"));
//			System.out.println("currInde" + currInde);
//		}
//
//		int currIndex = 0;
//		if (!checkNullString(currInde)) {
//			currIndex = Integer.parseInt(currInde);
//			session.setAttribute("currentPageIndex", currIndex + "");
//		}
//		LossData lossDto = getLossDataFromSession(session, currIndex);
//		//System.out.println("data to display-->" + lossDto.getLossTableRows().size());
//		model.addAttribute("lossData", lossDto);
//
//		return "loss";
//	}

	
	public boolean checkNullString(String val) {
		boolean flag = true;
		if ("".equals(val) || val == null) {
			flag = true;
		} else {
			flag = false;
		}
		return flag;
	}

	private LossData getLossDataFromSession(HttpSession session, int currIndex) {
		LossData myLossObj = new LossData();
		try {

			List<LossData> lossDatalist = (List<LossData>) session.getAttribute("lossDatalist");
			System.out.println("lossDatalist size-->" + lossDatalist.size());
			return lossDatalist.get(currIndex);
		} catch (Exception e) {
			System.out.println("got exception" + e.getMessage());
			return myLossObj;

		}

	}

	@RequestMapping(value = "/loss", method = RequestMethod.POST)
	public String addTabOfSamePageLS(@RequestBody String tab, ModelMap model, HttpSession session) {
		
		EnvRegion e = envRegionCtrl.getEnvRegion(session);
		
		System.out.println("in  /loss post method ->>" + tab);
		String userId = (String) httpSession.getAttribute("userId");
		String environment = (String) session.getAttribute("environment");
		System.out.println("User Id in loss POST: " + userId);

		List<String> reqData = new ArrayList<String>();
		String[] sentData = tab.split("\\$");
		System.out.println("sentData after separation" + sentData);
		for (String a : sentData) {
			reqData.add(a);
			System.out.println("send data loss-> " + a);
		}

		if ("F".equalsIgnoreCase(reqData.get(1))) {
			fetchLossData(reqData, model, session);
		} else {

			workloadCtrl.setDataToCorrespondingDTO(reqData, model, session);
			if ("Y".equalsIgnoreCase(reqData.get(1))) {
				workloadCtrl.getSameTabs(reqData, model, userId, session);
			}
		}
		
//		EnvRegion e = envRegionCtrl.getEnvRegionFromSession(session,model);

		model.addAttribute("userId", userId);
		model.addAttribute("environment", environment);
		model.addAttribute("envregion", e);
		model.addAttribute("indicator",false)	;
		model.addAttribute("indicator1",false)	;
		model.addAttribute("indicator2",false)	;
		model.addAttribute("indicator3",false)	;
		model.addAttribute("indicator4",false) ;
		return "loss";
	}

	public void fetchLossData(List<String> sentData, ModelMap model, HttpSession session) {
//		String user_id = EnvRegionController.getLoginObject().getUser_id();
		String user_id=(String) session.getAttribute("activeUser");
		user_id=user_id.toUpperCase();
		int currentIndex = Integer.parseInt(sentData.get(7));
		session.setAttribute("currentPageIndex", currentIndex);
		String objHandle = (String) session.getAttribute("objectHandle");
		int objectHandle = 0;
		if (checkNullString(objHandle)) {
			objHandle = 1 + "";
			objectHandle = Integer.parseInt(objHandle);
			session.setAttribute("objectHandle", objectHandle);
		}
		model.remove("lossData");

		LossData loss = new LossData();

		System.out.println("lossData ->>: " + sentData.get(3));
		Gson gson = new Gson();
		LossData lossData = gson.fromJson(sentData.get(3), LossData.class);
		String object_handle = workloadCtrl.getObjectHandle(objectHandle);
		System.out.println("lossData ->>: " + lossData.toString());

		loss = lossService.writeLossDataToMQ(lossData, user_id, object_handle,session);

		setLossDataObj(loss, currentIndex, session);
		System.out.println("LossDataWithMQData size-->" + loss.getLossTableRows().size());
		System.out.println("To show object handle in retrieved data w0" + loss);
		

	}

	private void setLossDataObj(LossData loss, int currentIndex, HttpSession session) {
		List<LossData> lossDatalist = (List<LossData>) session.getAttribute("lossDatalist");
		List<LossData> lossDataLst = new ArrayList<LossData>();

		if (lossDatalist == null) {

			for (int x = 0; x < 5; x++) {
				LossData lossdata = new LossData();
				lossdata = MockDtoDataUtil.getLossData();
				lossDataLst.add(lossdata);
			}
			session.setAttribute("lossDataList", lossDataLst);
			lossDatalist = (List<LossData>) session.getAttribute("lossDatalist");
			System.out.println("lossDataList from session size" + lossDatalist.size());

			lossDatalist.set(currentIndex, loss);
			session.setAttribute("lossDatalist", lossDataLst);
		} else {
			lossDatalist.set(currentIndex, loss);
			session.setAttribute("lossDatalist", lossDatalist);
		}

	}

}
