package com.att.lasr.model;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@ToString
public class ConfirmedByEsddTableRow {
	
	private String cc;
	private String request_id;
	private String status;
	private String service_order_num;
	private String dd;
	private String jep;
	private String loc;
	private String release_version;
	private String total_record;
	private String start_page;
	private String end_page;
	private String begin_time_nextptr;
	private String end_time_nextptr;
	private String begin_time_prevptr;
	private String end_time_prevptr;

}
