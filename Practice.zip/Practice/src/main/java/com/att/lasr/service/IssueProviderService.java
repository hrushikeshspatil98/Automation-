package com.att.lasr.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.att.lasr.model.Header;
import com.att.lasr.model.IssueProviderData;
import com.att.lasr.model.MQReceivedData;

import com.att.lasr.model.IssueProviderTableRow;
import com.att.lasr.model.SubData;
import com.att.lasr.model.SubHeader;
import com.att.lasr.utils.MQMessageStringBuilder;
import com.att.lasr.utils.MQReadUtil;
import com.att.lasr.utils.MQWriteUtil;
import com.att.lasr.utils.enums.LastInd;
import com.att.lasr.utils.enums.LogInd;
import com.att.lasr.utils.enums.Process;
import com.att.lasr.utils.enums.ProcessGroupInd;
import com.att.lasr.utils.enums.ProcessMode;
import com.att.lasr.utils.enums.RecIdFor12State;

@Service
public class IssueProviderService {

	@Autowired
	private MQReadUtil mqReadUtil;

	@Autowired
	private MQWriteUtil mqWriteUtil;
	
	@Autowired
	HttpSession httpSession;

	public IssueProviderData writeIssueProviderDataToMQ(IssueProviderData issueProviderData, String user_id, String object_handle,HttpSession session) {

		Header header = prepareHeader(user_id,object_handle);
		SubHeader subHeader = prepareSubHeader();

		String dataString = issueProviderData.getIssueProviderDataString();

		MQMessageStringBuilder mqMessageStringBuilder = new MQMessageStringBuilder().addHeaderSubHeaderAndData(header,
				subHeader, dataString);

		boolean isWritten = mqWriteUtil.writeDataToMQ(mqMessageStringBuilder,session);
		if (isWritten) {

			MQReceivedData mqReceivedData=null;
			
			try {

			mqReceivedData = mqReadUtil.readSortDataFromMQ(session); 
			 long endTime = System.nanoTime() + TimeUnit.NANOSECONDS.convert(3L, TimeUnit.MINUTES); 
			  Map<String, SubData> subDatas = mqReceivedData.getSubDatas(); 
		//	  Header receivedHeader = mqReceivedData.getHeader(); 
			  while(mqReceivedData.getHeader()==null&& System.nanoTime() < endTime) { 
					System.out.println("*************inside if*************** "); 
					mqReceivedData =	 mqReadUtil.readSortDataFromMQ(session); 
				} 
			  
			  
			  System.out.println(mqReceivedData.getHeader().toString()); 
		} catch (Exception e) { 
			// TODO Auto-generated catch block 
			 //mqReceivedData = mqReadUtil.readDataFromMQ(session); 
			e.printStackTrace(); 


		}
			Map<String, SubData> subDatas = mqReceivedData.getSubDatas();
			Header receivedHeader = mqReceivedData.getHeader();
			issueProviderData.setHeader(receivedHeader);
			SubData subData = subDatas.get(RecIdFor12State.CS_RECID_ISSUE_PROVIDER.getRecIdValue());
			if (subData != null) {
				SubHeader receivedSubHeader = subData.getSubHeader();
				String[] subDataRows = subData.getSubDataRows();

				List<IssueProviderTableRow> issueProviderTableRows = new ArrayList<>();
				for (String subDataRow : subDataRows) {

					String[] attributes = mqReadUtil.getAttributes(subDataRow, 4);
					System.out.println("attributes: " + Arrays.toString(attributes));
					IssueProviderTableRow issueProviderTableRow = new IssueProviderTableRow();

					issueProviderTableRow.setOrd(attributes[0]);
					issueProviderTableRow.setCvd(attributes[1]);
					issueProviderTableRow.setWtn(attributes[2]);
					issueProviderTableRow.setEcckt(attributes[3]);

					issueProviderTableRows.add(issueProviderTableRow);

				}
				issueProviderData.setSubHeader(receivedSubHeader);
				issueProviderData.setIssueProviderTableRows(issueProviderTableRows);
			}

			SubData subData2 = subDatas.get(RecIdFor12State.CS_RECID_VALIDATE_PROVIDER.getRecIdValue());
			if (subData2 != null) {
				String[] subDataRows = subData2.getSubDataRows();
				for (String subDataRow : subDataRows) {

					String[] attributes = mqReadUtil.getAttributes(subDataRow, 4);
					System.out.println("attributes: " + Arrays.toString(attributes));

					issueProviderData.setLosing_cc(attributes[0]);
					issueProviderData.setLsr_no(attributes[1]);
					issueProviderData.setGaining_cc(attributes[2]);
					issueProviderData.setMessage(attributes[3]);
				}
				
			}
		}
		return issueProviderData;
	}

	private SubHeader prepareSubHeader() {

		// Prepare SubHeader
		SubHeader subHeader = new SubHeader();

		subHeader.setLast_ind(LastInd.Y.name());
		subHeader.setProcess_mode(ProcessMode.CS_RETRIEVE.getProcessModeCode());
		subHeader.setRecord_type(RecIdFor12State.CS_RECID_VALIDATE_PROVIDER.getRecIdValue());
		subHeader.setReturn_code(null);
		subHeader.setDw_rownum(null);
		subHeader.setEcver(null);

		return subHeader;
	}

	private Header prepareHeader(String user_id, String object_handle) {
		// Prepare Header
		Header header = new Header();

		header.setUser_id(user_id);
		header.setProcess(Process.CS_ISSUE_PROVIDER.getProcessCode());
		header.setTab_ind(null);
		header.setProcess_group_ind(ProcessGroupInd.CHECK_IND.getProcessGroupInd());
		header.setObject_handle(object_handle);
		header.setObject_handle2(null);
		header.setLog_ind(LogInd.N.name());
		header.setStarttime(null);
		header.setEndtime(null);
		header.setGuid(null);
		header.setSession_trans_count("0000001");
		header.setHost_trans_seq(null);
		header.setReturn_code(null);
		header.setRead_only_ind(null);
		header.setNum_detail("0001");
		header.setRead_only_user_id(null);
		header.setLasrversion(null);

		return header;
	}

}
