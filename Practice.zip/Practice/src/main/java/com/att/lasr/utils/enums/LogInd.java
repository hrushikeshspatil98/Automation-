package com.att.lasr.utils.enums;

public enum LogInd {
	Y, N;
}
