package com.att.lasr.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.att.lasr.model.Header;
import com.att.lasr.model.MQReceivedData;
import com.att.lasr.model.NotesFupBindingData12States;
import com.att.lasr.model.ShowError;
import com.att.lasr.model.SubData;
import com.att.lasr.model.SubHeader;
import com.att.lasr.model.UpdateOrderNumberRow;
import com.att.lasr.utils.MQMessageStringBuilder;
import com.att.lasr.utils.MQReadUtil;
import com.att.lasr.utils.MQWriteUtil;
import com.att.lasr.utils.enums.LastInd;
import com.att.lasr.utils.enums.LogInd;
import com.att.lasr.utils.enums.Process;
import com.att.lasr.utils.enums.ProcessGroupInd;
import com.att.lasr.utils.enums.ProcessMode;
import com.att.lasr.utils.enums.RecIdFor12State;

@Service
public class UpdateOrderNumberService {

	@Autowired
	private MQReadUtil mqReadUtil;

	@Autowired
	private MQWriteUtil mqWriteUtil;

	@Autowired
	HttpSession httpSession;
	
	public String writeSaveUpdateOrderDataToMQ(List<UpdateOrderNumberRow> updatedOldDataRowsList, List<UpdateOrderNumberRow> updatedNewDataRowsList, String userId,
			String object_handle, HttpSession session) {
		
		String numCount = getNumCount(updatedOldDataRowsList.size() + updatedNewDataRowsList.size() + 1);
		Header header = prepareSaveHeader(userId, object_handle, numCount);
		StringBuilder subHeaderandData = new StringBuilder();
		String rc="";

		String dataString = "";

		// 049 RecId code
		@SuppressWarnings("unchecked")
		List<NotesFupBindingData12States> dataObject_049 = (List<NotesFupBindingData12States>) session
				.getAttribute("treeViewList_049");

		MQMessageStringBuilder mqMessageStringBuilder = new MQMessageStringBuilder();
		SubHeader subHeader = prepareSaveSubHeader(RecIdFor12State.CS_RECID_HEADER.getRecIdValue(),ProcessMode.CS_UPDATE.getProcessModeCode());

		for (NotesFupBindingData12States notesFupBindingData12States : dataObject_049) {
			
			session.setAttribute("Lrs_No", notesFupBindingData12States.getRequest_id().substring(0, 17).trim());
			dataString = notesFupBindingData12States.getNotesFupBindingData12String();
			subHeaderandData.append(mqMessageStringBuilder.addHeader(header));
			subHeaderandData.append(mqMessageStringBuilder.appendSubHeaderAndData(subHeader, dataString).toString());

		}

		//For Existing Data Rows 
		subHeader = prepareSaveSubHeader(RecIdFor12State.CS_RECID_UPDATE_COMPLETE_REQORD.getRecIdValue(),ProcessMode.CS_UPDATE.getProcessModeCode());
		
		for (UpdateOrderNumberRow row : updatedOldDataRowsList) {
			if(row.getOrd() == null)
			{
				row.setOrd("");
			}
			if(row.getOrd_attr().contains("U")) {
				row.setOrd_attr("Y");
			}
			if(row.getFdt_attr().contains("U")) {
				row.setFdt_attr("Y");
			}
			if(row.getDd_attr().contains("U")) {
				row.setDd_attr("Y");
			}
			if(row.getApptime_attr().contains("U")) {
				row.setApptime_attr("Y");
			}
			if(row.getApptime_attr()== null || row.getApptime_attr()=="")
			{
				row.setApptime_attr("R");
			}
			
			dataString = row.getUpdateOrderDataString();
			subHeaderandData.append(mqMessageStringBuilder.appendSubHeaderAndData(subHeader, dataString));
			
		}
		
		//For Newly Added Data Rows
		subHeader = prepareSaveSubHeader(RecIdFor12State.CS_RECID_UPDATE_COMPLETE_REQORD.getRecIdValue(),ProcessMode.CS_ADD.getProcessModeCode());
		
		for (UpdateOrderNumberRow row : updatedNewDataRowsList) {
			dataString = row.getUpdateOrderDataString();
			subHeaderandData.append(mqMessageStringBuilder.appendSubHeaderAndData(subHeader, dataString));
		}
		
		System.out.println("Update Order Number:  Input String ->"+mqMessageStringBuilder.getMqMessageString());
		
		boolean isWritten = mqWriteUtil.writeDataToMQ(mqMessageStringBuilder,session);

		if (isWritten) {

			MQReceivedData mqReceivedData=null;
			
			try {

				mqReceivedData = mqReadUtil.readSortDataFromMQ(session);
				long endTime = System.nanoTime() + TimeUnit.NANOSECONDS.convert(3L, TimeUnit.MINUTES);

				while (mqReceivedData.getHeader() == null && System.nanoTime() < endTime) {
					System.out.println("*************inside if*************** ");
					mqReceivedData = mqReadUtil.readSortDataFromMQ(session);
				}

				System.out.println(mqReceivedData.getHeader().toString());
			} catch (Exception e) {
				// mqReceivedData = mqReadUtil.readDataFromMQ(session);
				e.printStackTrace();
			}
			
			Map<String, SubData> subDatas = mqReceivedData.getSubDatas();
			Header receivedHeader = mqReceivedData.getHeader();
			rc = receivedHeader.getReturn_code() == null ? "555": receivedHeader.getReturn_code();
			System.out.println("Update Order Number: returncode ->" + rc);
			SubData subData = subDatas.get(RecIdFor12State.CS_RECID_ERROR.getRecIdValue());
			ReadErrorMsgsJson readErrorMsgsJson = new ReadErrorMsgsJson();
			ShowErrorService showErrorService = new ShowErrorService();
			List<ShowError> showUpdateErrorList = new ArrayList<ShowError>();
			if (subData != null) {

				if (rc != null && rc.equals("999")) {
					String uon_msg = readErrorMsgsJson.getErrorMsg("LG0017");
					session.setAttribute("uon_err_msg", uon_msg);

					String[] subDataRows = subData.getSubDataRows();
					int rowCount = 1;
					for (String subDataRow : subDataRows) {
						
						String[] attributes = mqReadUtil.getAttributes(subDataRows[0], 4);

						// For greater LSR versions exist error message
						if (attributes[0].equals("LG0118")) {
							String lsr_no = (String) session.getAttribute("Lrs_No");
							showUpdateErrorList = showErrorService.getShowErrorList(subDataRow.substring(0, 6),
									"", lsr_no, "", showUpdateErrorList);
						} else {
							showUpdateErrorList = showErrorService.getShowErrorList(subDataRow.substring(0, 6),
									getNumCount(rowCount), "", "U", showUpdateErrorList);
						}
						rowCount++;
					}

					session.setAttribute("showError", showUpdateErrorList);

				}

			}
			
			if (rc != null && rc.equals("000")) {
				String uon_msg = readErrorMsgsJson.getErrorMsg("LG0016");
				session.setAttribute("uon_info_msg", uon_msg);

			}
			if (rc != null && rc.equals("889")) {
				String ecckt_msg = readErrorMsgsJson.getErrorMsg("LG0067");
				session.setAttribute("ecckt_err_msg", ecckt_msg);

			}
			if (rc != null && rc.equals("888")) {
				String ecckt_msg = readErrorMsgsJson.getErrorMsg("LG0022");
				session.setAttribute("ecckt_err_msg", ecckt_msg);

			}

			
		}
		
		return rc;
	}
	
	public List<UpdateOrderNumberRow> getUpdatedNewRowsData(List<UpdateOrderNumberRow> newOrderNumberDataList) {
		// TODO Auto-generated method stub
		List<UpdateOrderNumberRow> updatedList = new ArrayList<UpdateOrderNumberRow>();
		if(newOrderNumberDataList == null)
		{
			return updatedList;
		}
		for (UpdateOrderNumberRow row : newOrderNumberDataList) {
			if(row.getOrd() == null)
			{
				row.setOrd("");
			}
			if (!row.getOrd().trim().isEmpty()) {
				row.setOrd_attr("Y");
				row.setFdt_attr("N");
				row.setDd_attr("N");
				row.setComp_dt_attr("N");
				row.setPosted_date_attr("N");
				row.setApptime_attr("N");
				updatedList.add(row);
			}
				
		}
		return updatedList;
	}

	public List<UpdateOrderNumberRow> getUpdatedRows(List<UpdateOrderNumberRow> newList,List<UpdateOrderNumberRow> oldList) {
		
		List<UpdateOrderNumberRow> updatedList= new ArrayList<UpdateOrderNumberRow>();
		if(newList == null)
		{
			return updatedList;
		}
		for(int i=0;i<oldList.size();i++)
		{
			UpdateOrderNumberRow tableRow=newList.get(i);
			if(!tableRow.getOrd().equalsIgnoreCase(oldList.get(i).getOrd()))
			{
				tableRow.setOld_ord(oldList.get(i).getOrd());
				updatedList.add(tableRow);
			}
		}
		return updatedList;
	}
	
	
	private SubHeader prepareSaveSubHeader(String recId, String processMode) {

		// Prepare SubHeader
		SubHeader subHeader = new SubHeader();

		subHeader.setLast_ind(LastInd.Y.name());
		subHeader.setProcess_mode(processMode);
		subHeader.setRecord_type(recId);
		subHeader.setReturn_code(null);
		subHeader.setDw_rownum(null);
		subHeader.setEcver(null);

		return subHeader;
	}

	private Header prepareSaveHeader(String user_id, String object_handle, String numCount) {
		// Prepare Header
		Header header = new Header();

		header.setUser_id(user_id);
		header.setProcess(Process.CS_REQUEST.getProcessCode());
		header.setTab_ind("668");
		header.setProcess_group_ind(ProcessGroupInd.SAVE_IND.getProcessGroupInd());
		header.setObject_handle(object_handle);
		header.setObject_handle2(null);
		header.setLog_ind(LogInd.N.name());
		header.setStarttime(null);
		header.setEndtime(null);
		header.setGuid(null);
		header.setSession_trans_count("0000001");
		header.setHost_trans_seq(null);
		header.setReturn_code(null);
		header.setRead_only_ind(null);
		header.setNum_detail(numCount);
		header.setRead_only_user_id(null);
		header.setLasrversion(null);

		return header;
	}
	
	

	private String getNumCount(int size) {
		String numCount = String.format("%04d", size);
		return numCount;
	}

}
