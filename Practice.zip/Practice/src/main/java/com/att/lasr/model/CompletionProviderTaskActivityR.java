package com.att.lasr.model;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@ToString
public class CompletionProviderTaskActivityR {
	
	private String cver;
	private String atn;
	private String rt;
	private String ecver;	
	private String d_t_sent_local; 
	private String response_d_t_sent_central_time; 
	private String comp_dt_attr;
	private String comp_dt; 
	private String an; 

}
