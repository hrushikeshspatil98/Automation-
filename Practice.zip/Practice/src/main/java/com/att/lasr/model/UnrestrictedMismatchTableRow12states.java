package com.att.lasr.model;

import java.util.ArrayList;
import java.util.List;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@ToString
public class UnrestrictedMismatchTableRow12states {

	private String worked_ind_attr;
	private String worked_ind;
	private String notif_typ;
	private String date_time_mismatched;
	private String request_id;
	private String company_code;
	private String pon;
	private String order_no;
	private String status;
	private String location;
	private String error_message;
	private String rcode;
	private String rdet;
	private String esdd;
	private String date;
	private String jcode;
	private String date_time_entered;
	private String order_sfx;
	private String release_version;
	private String user_id;
	private String total_record;
	private String start_page;
	private String end_page;
	
}
