package com.att.lasr.utils;

import com.att.lasr.model.ConfirmedByEsddData;
import com.att.lasr.model.EnhancedSelectData;
import com.att.lasr.model.FupRequestData;
import com.att.lasr.model.IssueProviderData;
import com.att.lasr.model.LossData;
import com.att.lasr.model.RestrictedMismatchData12states;
import com.att.lasr.model.SelectProviderData;
import com.att.lasr.model.SelectRequestData;
import com.att.lasr.model.UnrestrictedMismatchData12states;
import com.att.lasr.model.UserProfileData;
import com.att.lasr.model.WorkloadData;

public class MockDtoDataUtil {
	
	public static WorkloadData getWorkloadMockData() {
		WorkloadData mockWorkload=new WorkloadData();
		mockWorkload.setAct("");
		mockWorkload.setAm_pm("");
		mockWorkload.setBegin_time_nextptr("");
		mockWorkload.setBegin_time_prevptr("");
		mockWorkload.setCd("");
		mockWorkload.setCompany_code("");
		mockWorkload.setDue_date("");
		mockWorkload.setEnd_page("");
		mockWorkload.setEnd_time_nextptr("");
		mockWorkload.setEnd_time_prevptr("");
		mockWorkload.setGroup_id("");
		mockWorkload.setHeader(null);
		mockWorkload.setPrevnext_cde("");
		mockWorkload.setReq_type("");
		mockWorkload.setSc("");
		mockWorkload.setSm_dttm_rcvd("");
		mockWorkload.setSm_time("");
		mockWorkload.setStart_page("");
		mockWorkload.setStatus("");
		mockWorkload.setSubHeader(null);
		mockWorkload.setTotal_record("");
		mockWorkload.setUser_id("");
		mockWorkload.setWorkloadTableRows(null);
		
		return mockWorkload;
	}
	
	public static ConfirmedByEsddData getConfirmedByEsddMockData() {
		ConfirmedByEsddData confirmedByEsddMockData= new ConfirmedByEsddData();
		confirmedByEsddMockData.setHeader(null);
		confirmedByEsddMockData.setSubHeader(null);
		confirmedByEsddMockData.setCompany_code("");
		confirmedByEsddMockData.setBegindate("");
		confirmedByEsddMockData.setEnddate("");
		confirmedByEsddMockData.setSc("");
		confirmedByEsddMockData.setTotal_record("");
		confirmedByEsddMockData.setStart_page("");
		confirmedByEsddMockData.setEnd_page("");
		confirmedByEsddMockData.setPrevnext_cde("");
		confirmedByEsddMockData.setBegin_time_nextptr("");
		confirmedByEsddMockData.setEnd_time_nextptr("");
		confirmedByEsddMockData.setBegin_time_prevptr("");
		confirmedByEsddMockData.setEnd_time_prevptr("");
		confirmedByEsddMockData.setConfirmedByEsddTableRows(null);
		
		return confirmedByEsddMockData;
	}
	
	
	public static EnhancedSelectData getEnhancedMockSelectData() {
		EnhancedSelectData enhancedSelectMockData= new EnhancedSelectData();
		enhancedSelectMockData.setHeader(null);
		enhancedSelectMockData.setSubHeader(null);
		enhancedSelectMockData.setCompany_code("");
		enhancedSelectMockData.setSc("");
		enhancedSelectMockData.setTns("");
		enhancedSelectMockData.setEcckt("");
		enhancedSelectMockData.setOrd("");
		enhancedSelectMockData.setPorted_nbr("");
		enhancedSelectMockData.setOrdl("");
		enhancedSelectMockData.setOtn("");
		enhancedSelectMockData.setNpord("");
		enhancedSelectMockData.setDate_received_begin_date("");
		enhancedSelectMockData.setDate_received_end_date("");
		enhancedSelectMockData.setNc("");
		enhancedSelectMockData.setNci("");
		enhancedSelectMockData.setTotal_record("");
		enhancedSelectMockData.setStart_page("");
		enhancedSelectMockData.setEnd_page("");
		enhancedSelectMockData.setPrevnext_cde("");
		enhancedSelectMockData.setBegin_time_nextptr("");
		enhancedSelectMockData.setEnd_time_nextptr("");
		enhancedSelectMockData.setBegin_time_prevptr("");
		enhancedSelectMockData.setEnd_time_prevptr("");
		enhancedSelectMockData.setEnhancedSelectTableRows(null);
		
		return enhancedSelectMockData;
	}
	
	public static  SelectRequestData getSelectRequestMockDtoData() {
		SelectRequestData mockSelectRequest = new SelectRequestData();
		mockSelectRequest.setCompany_code("");
		mockSelectRequest.setBegin_time_nextptr("");
		mockSelectRequest.setBegin_time_prevptr("");
		mockSelectRequest.setDate_received_begin_date("");
		mockSelectRequest.setDate_received_end_date("");
		mockSelectRequest.setEnd_page("");
		mockSelectRequest.setEnd_time_nextptr("");
		mockSelectRequest.setEnd_time_prevptr("");
		mockSelectRequest.setHeader(null);
		mockSelectRequest.setPon("");
		mockSelectRequest.setPrevnext_cde("");
		mockSelectRequest.setProject("");
		mockSelectRequest.setRequest_id("");
		mockSelectRequest.setRpon("");
		mockSelectRequest.setSc("");
		mockSelectRequest.setSelectRequestTableRows(null);
		mockSelectRequest.setStart_page("");
		mockSelectRequest.setSubHeader(null);
		mockSelectRequest.setTotal_record("");
		mockSelectRequest.setVersion("");
		
		return mockSelectRequest;
		
	}
	
	public static UserProfileData getUserProfileMockData() {
		UserProfileData mockUserProfile=new UserProfileData();
		mockUserProfile.setUser_id_attr("");
		mockUserProfile.setUser_id("");
		mockUserProfile.setName_attr("");
		mockUserProfile.setName("");
		mockUserProfile.setTelephone_number_attr("");
		mockUserProfile.setTelephone_number("");
		mockUserProfile.setUser_type_attr("");
		mockUserProfile.setUser_type("");
		mockUserProfile.setSubsidiary_attr("");
		mockUserProfile.setSubsidiary("");
		mockUserProfile.setTypist_attr("");
		mockUserProfile.setTypist("");
		mockUserProfile.setSales_code_attr("");
		mockUserProfile.setSales_code("");
		mockUserProfile.setDflt_ims_region_attr("");
		mockUserProfile.setDflt_ims_region("");
		mockUserProfile.setStatus_attr("");
		mockUserProfile.setStatus("");
		mockUserProfile.setStatus("");
		mockUserProfile.setManager_attr("");
		mockUserProfile.setManager("");
		mockUserProfile.setArea_manager_attr("");
		mockUserProfile.setArea_manager("");
		mockUserProfile.setLast_updt_id("");
		mockUserProfile.setLast_updt_dttm("");
		mockUserProfile.setMulti_access_ind_attr("");
		mockUserProfile.setMulti_access_ind_attr("");
	
		mockUserProfile.setHeader(null);
		mockUserProfile.setSubHeader(null);
		
		
		return mockUserProfile;
	}
	
	public static LossData getLossData() {
		LossData mockLoss = new LossData();
		
		mockLoss.setCompany_code("");
		mockLoss.setHistory_date("");
		mockLoss.setTotal_record("");
		mockLoss.setSelection("");
		mockLoss.setStart_page("");
		mockLoss.setEnd_page("");
		mockLoss.setPrevnext_cde("");
		mockLoss.setBegin_time_nextptr("");
		mockLoss.setEnd_time_nextptr("");
		mockLoss.setBegin_time_prevptr("");
		mockLoss.setEnd_time_prevptr("");
		mockLoss.setHeader(null);
		mockLoss.setSubHeader(null);
		mockLoss.setLossTableRows(null); 
		
		return mockLoss;
	}
	

	public static RestrictedMismatchData12states getRestrictedMismatchkMockData() {
		RestrictedMismatchData12states restrictedMockData = new RestrictedMismatchData12states();
		restrictedMockData.setHeader(null);
		restrictedMockData.setSubHeader(null);
		restrictedMockData.setWorked_ind("");
		restrictedMockData.setFocsoc_ind("");
		restrictedMockData.setCompany_code("");
		restrictedMockData.setPon("");
		restrictedMockData.setBegin_date("");
		restrictedMockData.setEnd_date("");
		restrictedMockData.setRequest_id("");
		restrictedMockData.setLasr_version("");
		restrictedMockData.setRequest_type("");
		restrictedMockData.setSc("");
		restrictedMockData.setSystemm("");
		restrictedMockData.setFlowthru_ind("");
		restrictedMockData.setFoc_drop_dwn("");
		restrictedMockData.setSoc_drop_dwn("");
		restrictedMockData.setPtb_drop_dwn("");
		restrictedMockData.setRestrict_sw("");
		restrictedMockData.setRestrictedMisTableRows12states(null);
		
		return restrictedMockData;
	}
	
	public static UnrestrictedMismatchData12states getUnrestrictedMismatchMockData() {
		UnrestrictedMismatchData12states unrestrictedMockData = new UnrestrictedMismatchData12states();
		unrestrictedMockData.setHeader(null);
		unrestrictedMockData.setSubHeader(null);
		unrestrictedMockData.setWorked_ind("");
		unrestrictedMockData.setFocsoc_ind("");
		unrestrictedMockData.setCompany_code("");
		unrestrictedMockData.setPon("");
		unrestrictedMockData.setBegin_date("");
		unrestrictedMockData.setEnd_date("");
		unrestrictedMockData.setRequest_id("");
		unrestrictedMockData.setLasr_version("");
		unrestrictedMockData.setRequest_type("");
		unrestrictedMockData.setSc("");
		unrestrictedMockData.setSystemm("");
		unrestrictedMockData.setFlowthru_ind("");
		unrestrictedMockData.setDummy1("");
		unrestrictedMockData.setDummy2("");
		unrestrictedMockData.setDummy3("");
		unrestrictedMockData.setRestrict_sw("");
		unrestrictedMockData.setUnrestrictedMisTableRows12states(null);
		
		return unrestrictedMockData;
	}

	public static IssueProviderData getIssueProviderMockData() {
		IssueProviderData issueProviderMockData = new IssueProviderData();
		issueProviderMockData.setHeader(null);
		issueProviderMockData.setSubHeader(null);
		issueProviderMockData.setLosing_cc("");
		issueProviderMockData.setGaining_cc("");
		issueProviderMockData.setLsr_no("");
		issueProviderMockData.setMessage("");
		issueProviderMockData.setIssueProviderTableRows(null);
		
		return issueProviderMockData;
	}
	
	public static SelectProviderData getSelectProviderMockData() {
		SelectProviderData selectProviderMockData = new SelectProviderData();
		selectProviderMockData.setHeader(null);
		selectProviderMockData.setSubHeader(null);
		selectProviderMockData.setCompany_code("");
		selectProviderMockData.setConversion_begin_date("");
		selectProviderMockData.setConversion_end_date("");
		selectProviderMockData.setWtn("");
		selectProviderMockData.setEcckt("");
		selectProviderMockData.setSelectProviderTableRows(null);
		
		return selectProviderMockData;
	}
	
	public static FupRequestData getFupRequestDtoData() {
		FupRequestData fupRequestMockData=new FupRequestData();
		fupRequestMockData.setBegin_time_nextptr("");
		fupRequestMockData.setBegin_time_prevptr("");
		fupRequestMockData.setCompany_code("");
		fupRequestMockData.setEnd_page("");
		fupRequestMockData.setEnd_time_nextptr("");
		fupRequestMockData.setEnd_time_prevptr("");
		fupRequestMockData.setFollowup_begin_date("");
		fupRequestMockData.setFollowup_end_date("");
		fupRequestMockData.setFupRequestTableRows(null);
		fupRequestMockData.setHeader(null);
		fupRequestMockData.setPrevnext_cde("");
		fupRequestMockData.setSc("");
		fupRequestMockData.setStart_page("");
		fupRequestMockData.setSubHeader(null);
		fupRequestMockData.setTotal_record("");
		fupRequestMockData.setUser_id("");
		fupRequestMockData.setWorked_ind("");
		return fupRequestMockData;
	}
	
	
	

}
