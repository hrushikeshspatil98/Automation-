package com.att.lasr.utils;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import javax.servlet.http.HttpSession;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.att.lasr.controller.EnvRegionController;
import com.att.lasr.model.MQDetails;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ibm.mq.MQEnvironment;
import com.ibm.mq.MQException;
import com.ibm.mq.MQMessage;
import com.ibm.mq.MQPutMessageOptions;
import com.ibm.mq.MQQueue;
import com.ibm.mq.MQQueueManager;
import com.ibm.mq.constants.CMQC;

import net.minidev.json.JSONArray;
import net.minidev.json.JSONObject;
import net.minidev.json.parser.JSONParser;
import net.minidev.json.parser.ParseException;

@Component
public class MQWriteUtil {
	@Autowired
	HttpSession httpSession;
	
	@Autowired
	EnvRegionController envRegionCtrl;
	
	@Value("${KEY_STORE}")
	private String certPwd;

	@Value("${CERT_NAME}")
	private String certName;
	
	//static MQDetails mqDetails = new MQDetails();
	//private static final Logger logger = LoggerFactory.getLogger(MQWriteUtil.class);

	//private MQQueue mQQueue = null;

	public boolean writeDataToMQ(MQMessageStringBuilder mqMessageStringBuilder, HttpSession session) {
		boolean isOpen = false;
		String mqMessageString = mqMessageStringBuilder.getMqMessageString();
		MQQueue mQQueue = null;
		MQQueueManager mqQueueManager= null;
		MQDetails mqDetFromSession= getMqDetailsFromSession(session);
		try {
			
//			setSysProperty();
			String region = (String) httpSession.getAttribute("envregion");
			System.out.println("region in mqwrite -->"+region);
			

				if(mqDetFromSession != null) {
			
					MQEnvironment.hostname = mqDetFromSession.getHostName();
					MQEnvironment.channel = mqDetFromSession.getChannel();
//					MQEnvironment.sslCipherSuite = "TLS_RSA_WITH_AES_128_CBC_SHA256";
					MQEnvironment.port = mqDetFromSession.getPort();
					String Businessunit = mqDetFromSession.getBusinessUnit(); 
//					mQQueue = mqQueueManager.accessQueue(getMQDetails(region).getQueueName(), openOptions);
					httpSession.setAttribute(Businessunit, Businessunit);
					session.setAttribute(Businessunit, Businessunit);
					
				}

				 mqQueueManager = new MQQueueManager(mqDetFromSession.getQueueManager());

			int openOptions = CMQC.MQOO_BROWSE + CMQC.MQOO_FAIL_IF_QUIESCING
					+ CMQC.MQOO_OUTPUT;

			mQQueue = mqQueueManager.accessQueue(mqDetFromSession.getQueueName(), openOptions);
			session.setAttribute("mQQueueSession", mQQueue);
			httpSession.setAttribute("mQQueueSession", mQQueue);

			
			System.out.println("after");
			if (mQQueue.isOpen()) {
				System.out.println("Inside if**");
				//logger.info("Connection successful");

				System.out.println("Writing message to Queue: ");

				//prepareAndPutMqMessage(mqMessageString, session);
				MQMessage mqMessage = new MQMessage();
				mqMessage.format = CMQC.MQFMT_STRING;
				mqMessage.feedback = CMQC.MQFB_NONE;
				mqMessage.messageType = CMQC.MQMT_DATAGRAM;
				if(mqDetFromSession != null) {

					mqMessage.replyToQueueName = mqDetFromSession.getReplyToQueueName();
					mqMessage.replyToQueueManagerName = mqDetFromSession.getReplyToQueueManagerName();


				}
				
				
				
				
				MQPutMessageOptions mqPutMessageOptions = new MQPutMessageOptions();

				
				byte[] corId =  envRegionCtrl.getCorelationIfFromSession(session);
					
					
				mqMessage.correlationId = corId;
				mqMessage.clearMessage();
				mqMessage.writeString(mqMessageString);

				mQQueue.put(mqMessage, mqPutMessageOptions);
				
				//Added by YAsh to be asked from OM
//				mQQueue.close();
				System.out.println("Written Successfully..");
				isOpen = true;
			}

//			mqQueueManager.disconnect();
			System.out.println("disconnected**");

		} catch (MQException e) {
			//logger.error("MQException: " + e.toString());
			e.printStackTrace();
		} catch (Exception e) {
			//logger.error("Exception: " + e.toString());
			e.printStackTrace();
		}
		finally {
			try {
				mQQueue.close();
				mqQueueManager.disconnect();
			} catch (MQException e) {
				e.printStackTrace();
			}
			
			System.out.println("In Write 2: finally mq is closed and disconnected");
			
		}
		return isOpen;
	}

	public void prepareAndPutMqMessage(String mqMessageString ,HttpSession session) throws IOException, MQException {
		MQMessage mqMessage = new MQMessage();
		String region = (String) httpSession.getAttribute("envregion");
		mqMessage.format = CMQC.MQFMT_STRING;
		mqMessage.feedback = CMQC.MQFB_NONE;
		mqMessage.messageType = CMQC.MQMT_DATAGRAM;

		MQDetails mqDetFromSession= getMqDetailsFromSession(session);

		if(mqDetFromSession != null) {

			mqMessage.replyToQueueName = mqDetFromSession.getReplyToQueueName();
			mqMessage.replyToQueueManagerName = mqDetFromSession.getReplyToQueueManagerName();


		}
//		mqMessage.replyToQueueName = getMQDetails(region).getReplyToQueueName();
//		mqMessage.replyToQueueManagerName = getMQDetails(region).getReplyToQueueManagerName();

		MQPutMessageOptions mqPutMessageOptions = new MQPutMessageOptions();

		/* mqMessage.messageId = CMQC.MQMI_NONE; */
//		byte[] corId = EnvRegionController.getCorelationobj().getCorelationID(); 
		
		byte[] corId =  envRegionCtrl.getCorelationIfFromSession(session);
			
			
		mqMessage.correlationId = corId;
		mqMessage.clearMessage();
		mqMessage.writeString(mqMessageString);

		// Put the message on the queue
		MQQueue mQQueue = (MQQueue) session.getAttribute("mQQueueSession");
			if(mQQueue == null ) {
				mQQueue = (MQQueue) httpSession.getAttribute("mQQueueSession");
			}
		
		
		
		mQQueue.put(mqMessage, mqPutMessageOptions);
		System.out.println("Written Successfully..");
		//logger.info("Message written successfuly to Queue: "); 
	}

	
	private void setSysProperty() {
//		 System.err.println("certpwd is -> "+certPwd);
//		 System.err.println("certName is -> "+certName);	
			// for Deployments
//		String keyStoreTrust="H:\\Documents\\Non_Prod2\\"+certName;
		String keyStoreTrust="//home//site//wwwroot//"+certName;
//		System.err.println("keyStoreTrust is -> "+keyStoreTrust);
		System.setProperty("javax.net.ssl.keyStore", keyStoreTrust);
		System.setProperty("javax.net.ssl.trustStore", keyStoreTrust);
		System.setProperty("javax.net.ssl.keyStorePassword", certPwd);
		System.setProperty("com.ibm.ssl.trustStoreType", "jks");

//		System.setProperty("maxParameterCount", "-1");
//		System.setProperty("maxPostSize", "-1");
		
//		System.setProperty("javax.net.ssl.keyStore", "//home//site//wwwroot//m19086.keystore");
//		System.setProperty("javax.net.ssl.trustStore", "//home//site//wwwroot//m19086.keystore");
//		maxParameterCount="-1" maxPostSize="-1"
// for local
//		String keyStoreTrust="H:\\Documents\\Non_Prod2\\"+certName;
//		System.err.println("keyStoreTrust is -> "+keyStoreTrust);
//		System.setProperty("javax.net.ssl.keyStore", keyStoreTrust);
//		System.setProperty("javax.net.ssl.trustStore", keyStoreTrust);
//		System.setProperty("javax.net.ssl.keyStorePassword", certPwd);
//		System.setProperty("com.ibm.ssl.trustStoreType", "jks");

		
		
//		 System.setProperty("javax.net.ssl.keyStore","H:\\Documents\\Non_Prod2\\m19086.keystore");
//		System.setProperty("javax.net.ssl.trustStore","H:\\Documents\\Non_Prod2\\m19086.keystore");
//		System.setProperty("javax.net.ssl.keyStorePassword", "Mq@@lpasswordd3v");
		// System.setProperty("javax.net.ssl.keyStorePassword",certPwd);
//		System.setProperty("com.ibm.ssl.trustStoreType", "jks");

//		-Dcom.ibm.ssl.performURLHostNameVerification=true
//		-Dcom.ibm.mq.cfg.useIBMCipherMappings=false
	}


	public MQDetails getMQDetails(String selectedRegion, HttpSession session) {
		MQDetails mqDetails = new MQDetails();
		@SuppressWarnings("deprecation")
		JSONParser jsonparser = new JSONParser();
		FileReader reader;
//		File file;
		System.out.println("In MQDetails function");
		try {
//			reader = new FileReader("//usr//local//tomcat//webapps//OneLASRGUI//WEB-INF//classes//static//MQ_details.json");
			reader = new FileReader("C:\\Users\\hp959j\\eclipse-workspace\\Q4 Vuln Fix Code\\OneLASRGUI\\src\\main\\resources\\static\\MQ_details.json");

			Object obj = jsonparser.parse(reader);
			JSONArray mqdetail = new JSONArray();
			mqdetail.add(obj);
			JSONObject mqconfig = new JSONObject();
			mqconfig = (JSONObject) obj;
			if (selectedRegion == null) {
				System.out.println("object is null");
			} else {
				JSONObject mqconfigObject = (JSONObject) mqconfig.get(selectedRegion);
				// System.out.println("selected region is inside object mapper " +
				// selectedRegion);

				ObjectMapper mapper = new ObjectMapper();
				// System.out.println(mapper.toString());
				mqDetails = mapper.readValue(mqconfigObject.toString(), MQDetails.class);
				
				session.setAttribute("mqDetailsSession", mqDetails);
				httpSession.setAttribute("mqDetailsSession", mqDetails);
			}
		} catch (FileNotFoundException e) { 
			e.printStackTrace();
		} catch (JsonMappingException e) { 
			e.printStackTrace();
		} catch (JsonProcessingException e) { 
			e.printStackTrace();
		} catch (ParseException e) { 
			e.printStackTrace();
		}

		return mqDetails;

	}

//	public MQQueue getMQQueueFromSession(HttpSession session) {
//		MQQueue mqQueueFromSession = new MQQueue();
//	session.setAttribute("mQQueueSession", mQQueue);
//	httpSession.setAttribute("mQQueueSession", mQQueue);
//
//	
//	}
	public MQDetails getMqDetailsFromSession(HttpSession session) {
		MQDetails mqDet= new MQDetails();
		mqDet=(MQDetails) session.getAttribute("mqDetailsSession");
			if(mqDet == null) {
				mqDet= (MQDetails) httpSession.getAttribute("mqDetailsSession");

			}
		
		return mqDet;
	}

	
	public boolean writeDataToMQString(String mqMessageString,HttpSession session) {

		
		boolean isOpen = false;
		MQQueue mQQueue = null;
		MQQueueManager mqQueueManager= null;
		//String mqMessageString = mqMessageStringBuilder.getMqMessageString();
//		System.out.println("mqMessageString::::main::::::"+mqMessageString);
		try {
//			logger.info("mqMessageString: " + mqMessageString);

//			setSysProperty();
			String region = (String) httpSession.getAttribute("envregion");
			MQDetails mqDetFromSession= getMqDetailsFromSession(session);

			if(mqDetFromSession != null) {
		
				MQEnvironment.hostname = mqDetFromSession.getHostName();
				MQEnvironment.channel = mqDetFromSession.getChannel();
//				MQEnvironment.sslCipherSuite = "TLS_RSA_WITH_AES_128_CBC_SHA256";
				MQEnvironment.port = mqDetFromSession.getPort();
				String Businessunit = mqDetFromSession.getBusinessUnit(); 
//				mQQueue = mqQueueManager.accessQueue(getMQDetails(region).getQueueName(), openOptions);
				httpSession.setAttribute(Businessunit, Businessunit);
				session.setAttribute(Businessunit, Businessunit);
				
			}

			 mqQueueManager = new MQQueueManager(mqDetFromSession.getQueueManager());

		int openOptions = CMQC.MQOO_BROWSE + CMQC.MQOO_FAIL_IF_QUIESCING
				+ CMQC.MQOO_OUTPUT;

		mQQueue = mqQueueManager.accessQueue(mqDetFromSession.getQueueName(), openOptions);
		session.setAttribute("mQQueueSession", mQQueue);
		httpSession.setAttribute("mQQueueSession", mQQueue);

		
		System.out.println("after");
		if (mQQueue.isOpen()) {
			System.out.println("Inside if**");
		//	logger.info("Connection successful");

			System.out.println("Writing message to Queue: ");

			//prepareAndPutMqMessage(mqMessageString, session);
			MQMessage mqMessage = new MQMessage();
			mqMessage.format = CMQC.MQFMT_STRING;
			mqMessage.feedback = CMQC.MQFB_NONE;
			mqMessage.messageType = CMQC.MQMT_DATAGRAM;
			if(mqDetFromSession != null) {

				mqMessage.replyToQueueName = mqDetFromSession.getReplyToQueueName();
				mqMessage.replyToQueueManagerName = mqDetFromSession.getReplyToQueueManagerName();


			}
			
			
			MQPutMessageOptions mqPutMessageOptions = new MQPutMessageOptions();
			byte[] corId =  envRegionCtrl.getCorelationIfFromSession(session);
			
			//mqMessage.messageId = msgId; 
			mqMessage.correlationId = corId;
			mqMessage.clearMessage();
			mqMessage.writeString(mqMessageString);

			mQQueue.put(mqMessage, mqPutMessageOptions);
			
			//Added by YAsh to be asked from OM
			//mQQueue.close();
			System.out.println("Written Successfully..");
			isOpen = true;
		}

//			mqQueueManager.disconnect();
			System.out.println("disconnected**");

		} catch (MQException e) {
			//logger.error("MQException: " + e.toString());
			e.printStackTrace();
		} catch (Exception e) {
			//logger.error("Exception: " + e.toString());
			e.printStackTrace();
		}
		finally {
			try {
				mQQueue.close();
				mqQueueManager.disconnect();
				} catch (MQException e) {
				e.printStackTrace();
			}
			
			System.out.println("In Write 2: finally mq is closed and disconnected");
			
		}
		return isOpen;
	}
	
	/*public static void dataToFile(String dataString) throws IOException {

		Path fileName = Path.of("H:\\Documents\\write_mq_data.txt");
		String content = dataString;
		Files.writeString(fileName, content);

		String actual = Files.readString(fileName);
		System.out.println("actual::+++++++++++++++++++++++++++++++"+actual);
		}*/
	

}
