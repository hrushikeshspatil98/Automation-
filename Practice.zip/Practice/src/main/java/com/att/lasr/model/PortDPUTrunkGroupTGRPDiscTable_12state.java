package com.att.lasr.model;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@ToString
public class PortDPUTrunkGroupTGRPDiscTable_12state {
	private String item_num;
	private String tg_tc_id_sec_attr;
	private String tg_tc_id_sec;
	private String tg_tc_to_sec_attr;
	private String tg_tc_to_sec;
	private String tg_tc_name_sec_attr;
	private String tg_tc_name_sec;
}
