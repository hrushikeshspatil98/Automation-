package com.att.lasr.utils;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;

import com.att.lasr.model.Header;
import com.att.lasr.model.SubHeader;

public class MQMessageStringBuilder {

	private StringBuilder mqMessageSb;
	
	@Autowired
	HttpSession httpSession;

	public MQMessageStringBuilder() {
		mqMessageSb = new StringBuilder();
	}

	public MQMessageStringBuilder addHeaderSubHeaderAndData(Header header, SubHeader subHeader, String dataString) {
		String headerStringWithSpaces = header.getStringWithSpaces();
		checkBadData( header);
		char[] headerChars = FormatUtil.getHeaderCharArray(headerStringWithSpaces);
		String headerString = new String(headerChars);
		append(headerString);

		String subHeaderStringWithSpaces = subHeader.getStringWithSpaces();
		char[] subHeaderChars = FormatUtil.getSubHeaderCharArray(subHeaderStringWithSpaces);
		String subHeaderString = new String(subHeaderChars);
		append(subHeaderString);

		append(dataString);
		return this;
	}
	
	public MQMessageStringBuilder addHeader(Header header) {
		String headerStringWithSpaces = header.getStringWithSpaces();
		checkBadData( header);
		char[] headerChars = FormatUtil.getHeaderCharArray(headerStringWithSpaces);
		String headerString = new String(headerChars);
		append(headerString);
		return this;
	}

	public MQMessageStringBuilder appendSubHeaderAndData(SubHeader subHeader, String dataString) {
		String subHeaderStringWithSpaces = subHeader.getStringWithSpaces();
		char[] subHeaderChars = FormatUtil.getSubHeaderCharArray(subHeaderStringWithSpaces);
		String subHeaderString = new String(subHeaderChars);
		append(subHeaderString);
		append(dataString);
		return this;
	}
	
	public MQMessageStringBuilder appendHeaderAndSubData(Header header, String dataString) {
		String headerStringWithSpaces = header.getStringWithSpaces();
		char[] headerChars = FormatUtil.getHeaderCharArray(headerStringWithSpaces);
		String headerString = new String(headerChars);
		
		//String subHeaderStringWithSpaces = dataString.getStringWithSpaces();
	//	char[] subHeaderChars = FormatUtil.getSubHeaderCharArray(subHeaderStringWithSpaces);
	//	String subHeaderString = new String(subHeaderChars);
		append(headerString);
		append(dataString);
		return this;
	}
	 public void checkBadData(Header header) {
		 if(header.getUser_id().equals(null) || header.getUser_id().equals("")) {
				
				String activeUser= (String) httpSession.getAttribute("activeUser");
				if(activeUser !=null) {
					header.setUser_id(activeUser);
				}else {
					System.out.println("userId is null for this session id"+httpSession.getId());
					throw new NullPointerException();
				}
			}
	 }
	private void append(String value) {
		mqMessageSb.append(value);
	}

	public String getMqMessageString() {
		return mqMessageSb.toString();
	}
}
