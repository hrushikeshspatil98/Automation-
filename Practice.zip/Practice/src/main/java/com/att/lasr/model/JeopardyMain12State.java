package com.att.lasr.model;


import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Setter
@Getter
@NoArgsConstructor
@ToString
public class JeopardyMain12State implements Serializable{

	private Header header;

	private SubHeader subHeader;
	
	//private List<FollowUpData12States> followUpData12States;//rechid 531
	private List<JeopardyTask> jeopardyTask;
	private List<JeopardyTask12STRechId581> jeopardyTask12STRechId581;
	private List<JeopardyTask12STRechId583> jeopardyTask12STRechId583;
	private List<JeopardyTask12STRechId582> jeopardyTask12STRechId582;
	private List<NotesFupBindingData12States> notesFupBindingData12States;
	private List<JeopardyListRechId014> jeopardyListRows = new ArrayList<>();
	private List<JeopardyListRechId019> jeopardyListRows019 = new ArrayList<>();
}
