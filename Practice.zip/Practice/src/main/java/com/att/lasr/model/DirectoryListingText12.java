package com.att.lasr.model;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@ToString
public class DirectoryListingText12 {
	
	private String itemnum;
	private String dlnum_attr;
	private String dlnum;

}
