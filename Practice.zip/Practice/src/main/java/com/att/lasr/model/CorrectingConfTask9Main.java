package com.att.lasr.model;

import java.util.List;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

/**
 * @author sp860u
 *
 */
@Setter
@Getter
@NoArgsConstructor
@ToString
public class CorrectingConfTask9Main {

	private Header header;

	private SubHeader subHeader;
	
	private List<CorrectingConfTask9_RecId_850> CorrectingConfTask9_RecId_850 ;
	private List<CorrectingConfTask9_RecId_851> CorrectingConfTask9_RecId_851 ;
	private List<CorrectingConfTask9_RecId_852> CorrectingConfTask9_RecId_852 ;
	private List<Correcting_ConfirmationTask_RecId_858> correcting_ConfirmationTask_RecId_858;
	private List<NotesFupBindingData12States> NotesFupBindingData9States ;
}
