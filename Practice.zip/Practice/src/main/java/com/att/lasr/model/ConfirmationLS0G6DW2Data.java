package com.att.lasr.model;

import java.util.ArrayList;
import java.util.List;

import com.att.lasr.utils.Constants;
import com.att.lasr.utils.FormatUtil;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@ToString

public class ConfirmationLS0G6DW2Data {
	private Header header;
	private SubHeader subHeader;
	private String old_dtm;
	private String old_ord;
	private String old_attr;
	private String ord;
	private String fdt_attr;
	private String fdt;
	private String dd_attr;	
	private String dd;
	private String comp_dt_attr;
	private String comp_dt;
	private String posted_date_attr;
	private String posted_date;
	private String apptime_attr;	
	private String apptime;
	
	private List<ConfirmationLS0G6DW2Row> confirmationLS0G6DW2Row = new ArrayList<>();

	public String getConfirmationLS0G6DW2() {
		StringBuilder ConfirmationLS0G6DW2sb = new StringBuilder();
	
		ConfirmationLS0G6DW2sb.append(FormatUtil.getValueWithSpaces(old_dtm, 26)).append(Constants.TAB);
		ConfirmationLS0G6DW2sb.append(FormatUtil.getValueWithSpaces(old_ord, 20)).append(Constants.TAB);
		ConfirmationLS0G6DW2sb.append(FormatUtil.getValueWithSpaces(old_attr, 1)).append(Constants.TAB);
		ConfirmationLS0G6DW2sb.append(FormatUtil.getValueWithSpaces(ord, 20)).append(Constants.TAB);
		ConfirmationLS0G6DW2sb.append(FormatUtil.getValueWithSpaces(fdt_attr, 1)).append(Constants.TAB);
		ConfirmationLS0G6DW2sb.append(FormatUtil.getValueWithSpaces(fdt, 6)).append(Constants.TAB);
		ConfirmationLS0G6DW2sb.append(FormatUtil.getValueWithSpaces(dd_attr, 1)).append(Constants.TAB);
		ConfirmationLS0G6DW2sb.append(FormatUtil.getValueWithSpaces(dd, 10)).append(Constants.TAB);
		ConfirmationLS0G6DW2sb.append(FormatUtil.getValueWithSpaces(comp_dt_attr, 1)).append(Constants.TAB);
		ConfirmationLS0G6DW2sb.append(FormatUtil.getValueWithSpaces(comp_dt, 10)).append(Constants.TAB);
		ConfirmationLS0G6DW2sb.append(FormatUtil.getValueWithSpaces(posted_date_attr, 1)).append(Constants.TAB);
		ConfirmationLS0G6DW2sb.append(FormatUtil.getValueWithSpaces(posted_date, 10)).append(Constants.TAB);
		ConfirmationLS0G6DW2sb.append(FormatUtil.getValueWithSpaces(apptime_attr, 1)).append(Constants.TAB);
		ConfirmationLS0G6DW2sb.append(FormatUtil.getValueWithSpaces(apptime, 11)).append(Constants.TAB);

		String ConfirmationDataString = FormatUtil.getValueWithSpaces(ConfirmationLS0G6DW2sb.toString(), 2400);
		return ConfirmationDataString;
	}

	

}
