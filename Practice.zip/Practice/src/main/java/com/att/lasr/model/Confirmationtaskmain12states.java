/**
 * 
 */
package com.att.lasr.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

/**
 * @author SL625A
 *
 */
@Setter
@Getter
@NoArgsConstructor
@ToString

public class Confirmationtaskmain12states implements Serializable {
	private Header header;

	private SubHeader subHeader;
	
	private List<NotesFupBindingData12States> notesFupBindingData12States;
	private List<ConfirmationReqtypRLSOG6102Row> confirmationReqtypRLSOG6102Row;
	private List<ConfirmationLS0G6DW2Row> treeViewList_557;	
	
	
	

}
