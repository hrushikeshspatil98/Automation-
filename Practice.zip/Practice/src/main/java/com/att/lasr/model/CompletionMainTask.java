package com.att.lasr.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Setter
@Getter
@NoArgsConstructor
@ToString

public class CompletionMainTask implements Serializable {
	private Header header;

	private SubHeader subHeader;
	
	private List<NotesFupBindingData12States> notesFupBindingData12States; //049
	
	private List<CompletionProviderTask> completionTask_RecID_560;
	private List<CompletionActivityRLSOG6LscInfo> completionTask_RecID_568;
	
	
	
	
		
}

