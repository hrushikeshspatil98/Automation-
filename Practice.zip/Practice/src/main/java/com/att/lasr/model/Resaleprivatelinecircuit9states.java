package com.att.lasr.model;

import java.util.ArrayList;
import java.util.List;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@ToString
public class Resaleprivatelinecircuit9states {
	
	private String item_num;
	private String lnum_attr;
	private String lnum;
	private String ckta_attr;
	private String ckta;
	private String svc_cd_attr;
	private String svc_cd;
	private String ckttyp_attr;
	private String ckttyp;
	private String ecckt_attr;
	private String ecckt;
	private String mtp_attr;
	private String mtp;
	private String wire_attr;
	private String wire;
	private String disc_ecckt_attr;
	private String disc_ecckt;
	private String lc_attr;
	private String lc;
	private String frf_attr;
	private String frf;
	private String ecckt2_attr;
	private String ecckt2;
	private String dnum_attr;
	private String dnum;
	private String dqty_attr;
	private String dqty;
	private String frcktspd_attr;
	private String frcktspd;
	private String frdlcityp_attr;
	private String frdlcityp;
	private String frdlci_attr;
	private String frdlci;
	private String frrdlci_attr;
	private String frrdlci;
	private String frrcid_attr;
	private String frrcid;
	private String frcir_attr;
	private String frcir;
	private String frbex_attr;
	private String frbex;
	private String ckltype_attr;
	private String ckltype;
	private String loc_seq_num;
}
