package com.att.lasr.model;


import com.att.lasr.utils.Constants;
import com.att.lasr.utils.FormatUtil;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@ToString

public class CorrectingConfTask9_RecId_852 {
	
	private String itemnum;
	private String lnum;
	private String numname;
	private String num_nbr;
	private String ord_attr;
	private String ord;
	private String lord_attr;
	private String lord;
	private String fdt_attr;
	private String fdt;
	private String dd_attr;
	private String dd;
	private String ecckt_attr;
	private String ecckt;
	private String ckr;
	private String shared_nbr;
	private String disc_nbr;
	private String recckt; 
	private String tns_attr;
	private String tns; 
	private String ters_attr;
	private String ters;
	private String cfa;
	private String ccea;
	private String ispid_attr;
	private String ispid;
	private String fecckt_attr;
	private String fecckt;
	private String npord_attr;
	private String npord;
	private String ported_nbr;
	private String rti_attr;
	private String rti;
	private String cbcid_attr;
	private String cbcid;
	private String cableid_attr;
	private String cableid;
	private String chan_pair_attr;
	private String chan_pair;
	private String old_ord;
	private String old_lord;
	private String old_npord;
	private String loc_seq_num ;
	
	public String getCorrectingConfTask9_RecId_852() {
		StringBuilder correctingConfTask9_RecId_852 = new StringBuilder();
	
	
		correctingConfTask9_RecId_852.append(FormatUtil.getValueWithSpaces(itemnum, 4)).append(Constants.TAB);
		correctingConfTask9_RecId_852.append(FormatUtil.getValueWithSpaces(lnum, 5)).append(Constants.TAB);
		correctingConfTask9_RecId_852.append(FormatUtil.getValueWithSpaces(numname, 6)).append(Constants.TAB);
		correctingConfTask9_RecId_852.append(FormatUtil.getValueWithSpaces(num_nbr, 5)).append(Constants.TAB);
		correctingConfTask9_RecId_852.append(FormatUtil.getValueWithSpaces(ord_attr, 1)).append(Constants.TAB);
		correctingConfTask9_RecId_852.append(FormatUtil.getValueWithSpaces(ord, 20)).append(Constants.TAB);
		correctingConfTask9_RecId_852.append(FormatUtil.getValueWithSpaces(lord_attr, 1)).append(Constants.TAB);
		correctingConfTask9_RecId_852.append(FormatUtil.getValueWithSpaces(lord, 20)).append(Constants.TAB);
		correctingConfTask9_RecId_852.append(FormatUtil.getValueWithSpaces(fdt_attr, 1)).append(Constants.TAB);
		correctingConfTask9_RecId_852.append(FormatUtil.getValueWithSpaces(fdt, 6)).append(Constants.TAB);
		correctingConfTask9_RecId_852.append(FormatUtil.getValueWithSpaces(dd_attr, 1)).append(Constants.TAB);
		correctingConfTask9_RecId_852.append(FormatUtil.getValueWithSpaces(dd, 8)).append(Constants.TAB);
		correctingConfTask9_RecId_852.append(FormatUtil.getValueWithSpaces(ecckt_attr, 1)).append(Constants.TAB);
		correctingConfTask9_RecId_852.append(FormatUtil.getValueWithSpaces(ecckt, 41)).append(Constants.TAB);
		correctingConfTask9_RecId_852.append(FormatUtil.getValueWithSpaces(ckr, 41)).append(Constants.TAB);
		correctingConfTask9_RecId_852.append(FormatUtil.getValueWithSpaces(shared_nbr, 10)).append(Constants.TAB);
		correctingConfTask9_RecId_852.append(FormatUtil.getValueWithSpaces(disc_nbr, 10)).append(Constants.TAB);
		correctingConfTask9_RecId_852.append(FormatUtil.getValueWithSpaces(recckt, 41)).append(Constants.TAB);
		correctingConfTask9_RecId_852.append(FormatUtil.getValueWithSpaces(tns_attr, 1)).append(Constants.TAB);
		correctingConfTask9_RecId_852.append(FormatUtil.getValueWithSpaces(tns , 15)).append(Constants.TAB);
		correctingConfTask9_RecId_852.append(FormatUtil.getValueWithSpaces(ters_attr, 1)).append(Constants.TAB);
		correctingConfTask9_RecId_852.append(FormatUtil.getValueWithSpaces(ters, 10)).append(Constants.TAB);
		correctingConfTask9_RecId_852.append(FormatUtil.getValueWithSpaces(cfa, 42)).append(Constants.TAB);
		correctingConfTask9_RecId_852.append(FormatUtil.getValueWithSpaces(ccea, 47)).append(Constants.TAB);
		correctingConfTask9_RecId_852.append(FormatUtil.getValueWithSpaces(ispid_attr, 1)).append(Constants.TAB);
		correctingConfTask9_RecId_852.append(FormatUtil.getValueWithSpaces(ispid, 14)).append(Constants.TAB);
		correctingConfTask9_RecId_852.append(FormatUtil.getValueWithSpaces(fecckt_attr, 1)).append(Constants.TAB);
		correctingConfTask9_RecId_852.append(FormatUtil.getValueWithSpaces(fecckt, 46)).append(Constants.TAB);
		correctingConfTask9_RecId_852.append(FormatUtil.getValueWithSpaces(npord_attr, 1)).append(Constants.TAB);
		correctingConfTask9_RecId_852.append(FormatUtil.getValueWithSpaces(npord, 20)).append(Constants.TAB);
		correctingConfTask9_RecId_852.append(FormatUtil.getValueWithSpaces(ported_nbr, 17)).append(Constants.TAB);
		correctingConfTask9_RecId_852.append(FormatUtil.getValueWithSpaces(rti_attr, 1)).append(Constants.TAB);
		correctingConfTask9_RecId_852.append(FormatUtil.getValueWithSpaces(rti, 6)).append(Constants.TAB);
		correctingConfTask9_RecId_852.append(FormatUtil.getValueWithSpaces(cbcid_attr, 1)).append(Constants.TAB);
		correctingConfTask9_RecId_852.append(FormatUtil.getValueWithSpaces(cbcid, 5)).append(Constants.TAB);
		correctingConfTask9_RecId_852.append(FormatUtil.getValueWithSpaces(cableid_attr, 1)).append(Constants.TAB);
		correctingConfTask9_RecId_852.append(FormatUtil.getValueWithSpaces(cableid, 5)).append(Constants.TAB);
		correctingConfTask9_RecId_852.append(FormatUtil.getValueWithSpaces(chan_pair_attr, 1)).append(Constants.TAB);
		correctingConfTask9_RecId_852.append(FormatUtil.getValueWithSpaces(chan_pair, 5)).append(Constants.TAB);
		correctingConfTask9_RecId_852.append(FormatUtil.getValueWithSpaces(old_ord , 20)).append(Constants.TAB);
		correctingConfTask9_RecId_852.append(FormatUtil.getValueWithSpaces(old_lord, 20)).append(Constants.TAB);
		correctingConfTask9_RecId_852.append(FormatUtil.getValueWithSpaces(old_npord, 20)).append(Constants.TAB);
		correctingConfTask9_RecId_852.append(FormatUtil.getValueWithSpaces(loc_seq_num, 3)).append(Constants.TAB).append(Constants.TAB);
		

		String ConfirmationDataString = FormatUtil.getValueWithSpaces(correctingConfTask9_RecId_852.toString(), 2400);
		return ConfirmationDataString;
	}


}
