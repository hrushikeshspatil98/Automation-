package com.att.lasr.service;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.att.lasr.model.FollowUpData;
import com.att.lasr.model.FollowUpTableRow;
import com.att.lasr.model.Header;
import com.att.lasr.model.MQReceivedData;
import com.att.lasr.model.NotesFupBindingData12States;
import com.att.lasr.model.PreIssue;
import com.att.lasr.model.SubData;
import com.att.lasr.model.SubHeader;
import com.att.lasr.utils.Constants;
import com.att.lasr.utils.FormatUtil;
import com.att.lasr.utils.MQMessageStringBuilder;
import com.att.lasr.utils.MQReadUtil;
import com.att.lasr.utils.MQWriteUtil;
import com.att.lasr.utils.enums.LastInd;
import com.att.lasr.utils.enums.ProcessGroupInd;
import com.att.lasr.utils.enums.ProcessMode;
import com.att.lasr.utils.enums.RecIdFor12State;
import com.ibm.mq.MQException;

@Service
public class PreIssueService {
	

	@Autowired
	private MQReadUtil mqReadUtil;

	@Autowired
	private MQWriteUtil mqWriteUtil;
	
	public String writeResendDataToMQ( String user_id, HttpSession session) {
		List<NotesFupBindingData12States> treeViewList = (List<NotesFupBindingData12States>) session
				.getAttribute("treeViewList_049");
		MQMessageStringBuilder mqMessageStringBuilder = new MQMessageStringBuilder();
		 Header header = prepareHeaderforResend(user_id);
		 SubHeader subHeaderRecid049 = prepareSubHeader();
		 SubHeader subHeaderRecid540 = prepareSubHeaderforresend();
		 
		 String Recid_049 = createdataforMq9states(treeViewList);
		 mqMessageStringBuilder.addHeaderSubHeaderAndData(header, subHeaderRecid049, Recid_049);
		String[] Data_540= (String[]) session.getAttribute("recid_40Data");
		String Recid_540= createdatafor540(Data_540);
		mqMessageStringBuilder.appendSubHeaderAndData(subHeaderRecid540, Recid_540);
		//mqMessageStringBuilder.getMqMessageString();
		System.out.println(mqMessageStringBuilder.getMqMessageString());
		boolean isWritten = mqWriteUtil.writeDataToMQ(mqMessageStringBuilder, session);
		 String returncode = "";
		if (isWritten) {
			  MQReceivedData mqReceivedData=null;
			  
			  
		  try {
			 mqReceivedData = mqReadUtil.readSortDataFromMQ(session);
			 long endTime = System.nanoTime() + TimeUnit.NANOSECONDS.convert(3L, TimeUnit.MINUTES);
			  Map<String, SubData> subDatas = mqReceivedData.getSubDatas();
		//	  Header receivedHeader = mqReceivedData.getHeader();
			  while(mqReceivedData.getHeader()==null&& System.nanoTime() < endTime) {
				//	System.out.println("*************inside if*************** ");
					mqReceivedData =	 mqReadUtil.readSortDataFromMQ(session);
				}
			  if(mqReceivedData.getHeader()==null) {
				  
				  return "System timeout. 5 minutes exceeded. Please close window or continue to wait";
			  }
			  
			  returncode =
					  mqReceivedData.getHeader().getReturn_code(); 
			  session.setAttribute("returncode",
			  returncode); 
			  System.out.println(mqReceivedData.getHeader().toString());
		} catch (Exception e) {
			// TODO Auto-generated catch block
			// mqReceivedData = mqReadUtil.readDataFromMQ(session);
			e.printStackTrace();
			
			
		}
		  
		  Header receivedHeader = mqReceivedData.getHeader();
			if(receivedHeader == null)
			{
				receivedHeader = new Header();
				receivedHeader.setReturn_code("555");
			}
			 returncode = receivedHeader.getReturn_code();
			
			System.out.println(receivedHeader.toString());
			getResponseAsPerRC(returncode,session,"Resend");
		  }
	
		return "resend";
	}

	
	////////////////////////////////////just go function/////////////////
	
	public String writeJustGoDataToMQ( String user_id, HttpSession session) {
		List<NotesFupBindingData12States> treeViewList = (List<NotesFupBindingData12States>) session
				.getAttribute("treeViewList_049");
		MQMessageStringBuilder mqMessageStringBuilder = new MQMessageStringBuilder();
		 Header header = prepareHeaderforJustGo(user_id);
		 
		 SubHeader subHeaderRecid544 = prepareSubHeaderforJustGo();
		 PreIssue preissue= new PreIssue();
		 String[] LsrNo = treeViewList.get(0).getRequest_id().split("-");
		 String version = treeViewList.get(0).getRequest_id().substring(15, 17);
		 preissue.setVersion(version);
		 preissue.setLsr_number(LsrNo[0]);
		 String JustGoString = creatDataforPreIssue(preissue);
		// String Recid_049 = createdataforMq9states(treeViewList);
		 mqMessageStringBuilder.addHeaderSubHeaderAndData(header, subHeaderRecid544, JustGoString);
		
		//mqMessageStringBuilder.getMqMessageString();
		System.out.println(mqMessageStringBuilder.getMqMessageString());
		boolean isWritten = mqWriteUtil.writeDataToMQ(mqMessageStringBuilder, session);
		 String returncode = "";
		  
		  if (isWritten) {
			  MQReceivedData mqReceivedData=null;
			  
			  
		  try {
			 mqReceivedData = mqReadUtil.readSortDataFromMQ(session);
			 long endTime = System.nanoTime() + TimeUnit.NANOSECONDS.convert(3L, TimeUnit.MINUTES);
			  Map<String, SubData> subDatas = mqReceivedData.getSubDatas();
		//	  Header receivedHeader = mqReceivedData.getHeader();
			  while(mqReceivedData.getHeader()==null&& System.nanoTime() < endTime) {
				//	System.out.println("*************inside if*************** ");
					mqReceivedData =	 mqReadUtil.readSortDataFromMQ(session);
				}
			  if(mqReceivedData.getHeader()==null) {
				  
				  return "System timeout. 5 minutes exceeded. Please close window or continue to wait";
			  }
			  
			  returncode =
					  mqReceivedData.getHeader().getReturn_code(); 
			  session.setAttribute("returncode",
			  returncode); 
			  System.out.println(mqReceivedData.getHeader().toString());
		} catch (Exception e) {
			// TODO Auto-generated catch block
			 //mqReceivedData = mqReadUtil.readDataFromMQ(session);
			e.printStackTrace();
			
			
		}

			Header receivedHeader = mqReceivedData.getHeader();
			if(receivedHeader == null)
			{
				receivedHeader = new Header();
				receivedHeader.setReturn_code("555");
			}
			 returncode = receivedHeader.getReturn_code();
			
			System.out.println(receivedHeader.toString());

			getResponseAsPerRC(returncode,session,"Justgo");			
		  
		  }
				return "justgo";
	
	}
	
	
	
	
	
	
	
	
	
	
	private String createdatafor540(String[] data_540) {
		
	
	String user_id = data_540[0];
	String ecver = data_540[1];
	
	
	StringBuilder sb = new StringBuilder();
	//sb.append(treeViewList).append(Constants.TAB) .append(Constants.TAB);
	sb.append(FormatUtil.getValueWithSpaces(user_id, 7)).append(Constants.TAB);
	sb.append(FormatUtil.getValueWithSpaces(ecver, 3)).append(Constants.TAB).append(Constants.TAB);
	String finalString = FormatUtil.getValueWithSpaces(sb.toString(), 2400);

	return finalString;
		
	}



	public String writeResubmitDataToMQ( String user_id, HttpSession session) throws  IOException {
		
		List<NotesFupBindingData12States> treeViewList = (List<NotesFupBindingData12States>) session
				.getAttribute("treeViewList_049");
		MQMessageStringBuilder mqMessageStringBuilder = new MQMessageStringBuilder();
		SubHeader subHeaderRecid049 = prepareSubHeader();
		SubHeader subHeaderRecid547= prepareSubHeaderforResubmit();
		 String Recid_049 = createdataforMq9states(treeViewList);
		 Header header =  prepareHeaderforResubmit(user_id);
		 PreIssue preissue= new PreIssue();
		 String[] LsrNo = treeViewList.get(0).getRequest_id().split("-");
		 String version = treeViewList.get(0).getRequest_id().substring(15, 17);
		 preissue.setVersion(version);
		 preissue.setLsr_number(LsrNo[0]);
		 String preIssueString = creatDataforPreIssue(preissue);
		 mqMessageStringBuilder.addHeaderSubHeaderAndData(header, subHeaderRecid049, Recid_049);
		 mqMessageStringBuilder.appendSubHeaderAndData(subHeaderRecid547, preIssueString);
		 System.out.println(mqMessageStringBuilder.getMqMessageString());
		 
		 boolean isWritten = mqWriteUtil.writeDataToMQ(mqMessageStringBuilder, session);
		 
		 
		 
		 MQReceivedData mqReceivedData = null;
			  String returncode = "";
			  
			  if (isWritten) {
				  
			  try {
				 
				  long endTime = System.nanoTime() + TimeUnit.NANOSECONDS.convert(3L, TimeUnit.MINUTES);
				 
				 mqReceivedData = mqReadUtil.readSortDataFromMQ(session);
				
				//  Map<String, SubData> subDatas = mqReceivedData.getSubDatas();
			//	  Header receivedHeader = mqReceivedData.getHeader();
				  while(mqReceivedData.getHeader()==null && System.nanoTime() < endTime ) {
				//	System.out.println("*************inside if*************** ");
						
						mqReceivedData =mqReadUtil.readSortDataFromMQ(session);
					}
				  
				  if(mqReceivedData.getHeader()==null) {
					  
					  return "System timeout. 5 minutes exceeded. Please close window or continue to wait";
				  }
				  Header receivedHeader = mqReceivedData.getHeader();
				  returncode = receivedHeader.getReturn_code();
				  
				  System.out.println(mqReceivedData.getHeader().toString());
			} catch (Exception e) {
				// TODO Auto-generated catch block
				 //mqReceivedData = mqReadUtil.readDataFromMQ(session);
				e.printStackTrace();
				
				
			}

				Header receivedHeader = mqReceivedData.getHeader();
				if(receivedHeader == null)
				{
					receivedHeader = new Header();
					receivedHeader.setReturn_code("555");
				}
				 returncode = receivedHeader.getReturn_code();
				
				System.out.println(receivedHeader.toString());
				getResponseAsPerRC(returncode,session,"Resubmit");
			  
			  }
			return "resubmit";
					 
	}



	public String writePreIssueDataToMQ( String user_id, HttpSession session) {
	List<NotesFupBindingData12States> treeViewList = (List<NotesFupBindingData12States>) session
			.getAttribute("treeViewList_049");
	MQMessageStringBuilder mqMessageStringBuilder = new MQMessageStringBuilder();
	 Header header = prepareHeader(user_id);
	 SubHeader subHeaderRecid049 = prepareSubHeader();
	 SubHeader subHeaderpreIssue = prepareSubHeaderforpreIssue();
	 String Recid_049 = createdataforMq9states(treeViewList);
	 //////////////////for pre issue/////////////////
	 PreIssue preissue= new PreIssue();
	 
	 String[] LsrNo = treeViewList.get(0).getRequest_id().split("-");
	 String version = treeViewList.get(0).getRequest_id().substring(15, 17);
	 preissue.setVersion(version);
	 preissue.setLsr_number(LsrNo[0]);
	 String preIssueString = creatDataforPreIssue(preissue);
	 mqMessageStringBuilder.addHeaderSubHeaderAndData(header, subHeaderRecid049, Recid_049);
	 
	 mqMessageStringBuilder.appendSubHeaderAndData(subHeaderpreIssue, preIssueString);
	 System.out.println(mqMessageStringBuilder.getMqMessageString());
	 
		boolean isWritten = mqWriteUtil.writeDataToMQ(mqMessageStringBuilder, session);
		String returncode="";
		if (isWritten) {

			MQReceivedData mqReceivedData=null;
			
			try {

			mqReceivedData = mqReadUtil.readSortDataFromMQ(session); 
			 long endTime = System.nanoTime() + TimeUnit.NANOSECONDS.convert(3L, TimeUnit.MINUTES); 
			  Map<String, SubData> subDatas = mqReceivedData.getSubDatas(); 
		//	  Header receivedHeader = mqReceivedData.getHeader(); 
			  while(mqReceivedData.getHeader()==null&& System.nanoTime() < endTime) { 
					System.out.println("*************inside if*************** "); 
					mqReceivedData =	 mqReadUtil.readSortDataFromMQ(session); 
				} 
			  
			  
			  System.out.println(mqReceivedData.getHeader().toString()); 
		} catch (Exception e) { 
			// TODO Auto-generated catch block 
			// mqReceivedData = mqReadUtil.readDataFromMQ(session); 
			e.printStackTrace(); 


		}
	//preissue changes start
			Map<String, SubData> subDatas = mqReceivedData.getSubDatas();
			Header receivedHeader = mqReceivedData.getHeader();
			if(receivedHeader == null)
			{
				receivedHeader = new Header();
				receivedHeader.setReturn_code("555");
			}
			 returncode = receivedHeader.getReturn_code();
			
			System.out.println(receivedHeader.toString());
			getResponseAsPerRC(returncode,session,"PreIssue");
		}
	
		return "preissue";
	}
	

	private void getResponseAsPerRC(String returncode, HttpSession session, String button) {
		try {
			ReadErrorMsgsJson readErrorMsgsJson = new ReadErrorMsgsJson();
			if (returncode.equals("000"))
				session.setAttribute("stask_info", button + " processing completed");
			else if (returncode.equals("555"))
				session.setAttribute("stask_info", readErrorMsgsJson.getErrorMsg("LG0001"));
			else
				session.setAttribute("stask_info", button + " processing unsuccessful");
		} catch (Exception e) {
			System.out.println("Exception in getResp - " + e.getMessage());
		}
	}


	private SubHeader prepareSubHeader() {

		// Prepare SubHeader
		SubHeader subHeader = new SubHeader();

		subHeader.setLast_ind(LastInd.Y.name());
		subHeader.setProcess_mode(ProcessMode.CS_UPDATE.getProcessModeCode());
		subHeader.setRecord_type(RecIdFor12State.CS_RECID_HEADER.getRecIdValue());
		subHeader.setReturn_code(null);
		subHeader.setDw_rownum(null);
		subHeader.setEcver(null);

		return subHeader;
	}
	
	private SubHeader prepareSubHeaderforpreIssue() {

		// Prepare SubHeader
		SubHeader subHeader = new SubHeader();

		subHeader.setLast_ind(LastInd.Y.name());
		subHeader.setProcess_mode(ProcessMode.CS_UPDATE.getProcessModeCode());
		subHeader.setRecord_type(RecIdFor12State.CS_RECID_PREISSUE.getRecIdValue());
		subHeader.setReturn_code(null);
		subHeader.setDw_rownum(null);
		subHeader.setEcver(null);

		return subHeader;
	}
	
	private SubHeader prepareSubHeaderforResubmit() {

		// Prepare SubHeader
		SubHeader subHeader = new SubHeader();

		subHeader.setLast_ind(LastInd.Y.name());
		subHeader.setProcess_mode(ProcessMode.CS_UPDATE.getProcessModeCode());
		subHeader.setRecord_type("547");
		subHeader.setReturn_code(null);
		subHeader.setDw_rownum(null);
		subHeader.setEcver(null);

		return subHeader;
	}
	
	private SubHeader prepareSubHeaderforresend() {

		// Prepare SubHeader
		SubHeader subHeader = new SubHeader();

		subHeader.setLast_ind(LastInd.Y.name());
		subHeader.setProcess_mode(ProcessMode.CS_UPDATE.getProcessModeCode());
		subHeader.setRecord_type("544");
		subHeader.setReturn_code(null);
		subHeader.setDw_rownum(null);
		subHeader.setEcver(null);

		return subHeader;
	}
	
	private SubHeader prepareSubHeaderforJustGo() {

		// Prepare SubHeader
		SubHeader subHeader = new SubHeader();

		subHeader.setLast_ind(LastInd.Y.name());
		subHeader.setProcess_mode(ProcessMode.CS_UPDATE.getProcessModeCode());
		subHeader.setRecord_type("544");
		subHeader.setReturn_code(null);
		subHeader.setDw_rownum(null);
		subHeader.setEcver(null);

		return subHeader;
	}
	
	
	private Header prepareHeader(String user_id) {
		// Prepare Header
		Header header = new Header();

		header.setUser_id(user_id);
		header.setProcess("REQ");
		header.setTab_ind(RecIdFor12State.CS_RECID_PREISSUE.getRecIdValue());
		header.setProcess_group_ind("P");
		header.setObject_handle("00000000");
		header.setObject_handle2(null);
		header.setLog_ind(null);
		header.setStarttime(null);
		header.setEndtime(null);
		header.setGuid(null);
		header.setSession_trans_count("0000001");
		header.setHost_trans_seq(null);
		header.setReturn_code(null);
		header.setRead_only_ind(null);
		header.setNum_detail("0002");
		header.setRead_only_user_id(null);
		header.setLasrversion(null);

		return header;
	}
	public String createdataforMq9states(List<NotesFupBindingData12States>
	treeViewList){
	String cc = treeViewList.get(0).getCompany_code();
	String DTReceived = treeViewList.get(0).getDate_time_received();
	String pon = treeViewList.get(0).getPon();
	String Rver = treeViewList.get(0).getRver();
	String LsrNo = treeViewList.get(0).getRequest_id();
	String ReqTyp = treeViewList.get(0).getReqtype();
	String Status = treeViewList.get(0).getStatus();
	String lspauth_attr= treeViewList.get(0).getLspauth_attr();
	String lspauth = treeViewList.get(0).getLspauth();
	String cvoip = "N";
	String aan= null;
	String atn = null;
	String natn= null;
	String nan = null;
	String an = null;
	StringBuilder sb = new StringBuilder();
	//sb.append(treeViewList).append(Constants.TAB) .append(Constants.TAB);
	sb.append(FormatUtil.getValueWithSpaces(cc, 4)).append(Constants.TAB);
	sb.append(FormatUtil.getValueWithSpaces(DTReceived, 17)).append(Constants.TAB);
	sb.append(FormatUtil.getValueWithSpaces(pon, 16)).append(Constants.TAB);
	sb.append(FormatUtil.getValueWithSpaces(Rver, 5)).append(Constants.TAB);
	sb.append(FormatUtil.getValueWithSpaces(LsrNo, 18)).append(Constants.TAB);
	sb.append(FormatUtil.getValueWithSpaces(ReqTyp, 2)).append(Constants.TAB);
	sb.append(FormatUtil.getValueWithSpaces(Status, 22)).append(Constants.TAB);
	sb.append(FormatUtil.getValueWithSpaces(lspauth_attr, 1)).append(Constants.TAB);
	sb.append(FormatUtil.getValueWithSpaces(lspauth, 4)).append(Constants.TAB);
	sb.append(FormatUtil.getValueWithSpaces(cvoip, 1)).append(Constants.TAB);
	sb.append(FormatUtil.getValueWithSpaces(aan, 13)).append(Constants.TAB);
	sb.append(FormatUtil.getValueWithSpaces(atn, 10)).append(Constants.TAB);
	sb.append(FormatUtil.getValueWithSpaces(natn, 10)).append(Constants.TAB);
	sb.append(FormatUtil.getValueWithSpaces(nan, 10)).append(Constants.TAB);
	sb.append(FormatUtil.getValueWithSpaces(an, 13)).append(Constants.TAB).append(Constants.TAB);
	//sb.append(treeViewList.get(0).getLspAuth()).append(Constants.TAB);


	//sb.append(treeViewList.get(0).getStatus()).append(Constants.TAB).append(Constants.TAB);
	String finalString = FormatUtil.getValueWithSpaces(sb.toString(), 2400);

	return finalString; }
	
	public String creatDataforPreIssue(PreIssue preissue){
	
	String Lsr = preissue.getLsr_number();
	String version = preissue.getVersion();
	StringBuilder sb = new StringBuilder();
	sb.append(FormatUtil.getValueWithSpaces(Lsr, 14)).append(Constants.TAB);
	sb.append(FormatUtil.getValueWithSpaces(version, 2)).append(Constants.TAB).append(Constants.TAB);
	String finalString = FormatUtil.getValueWithSpaces(sb.toString(), 2400);
	return finalString;}
	
	
	private Header prepareHeaderforResend(String user_id) {
		// Prepare Header
		Header header = new Header();

		header.setUser_id(user_id);
		header.setProcess("REQ");
		header.setTab_ind(RecIdFor12State.CS_RECID_ISSUE_RESEND.getRecIdValue());
		header.setProcess_group_ind("I");
		header.setObject_handle("00000000");
		header.setObject_handle2(null);
		header.setLog_ind(null);
		header.setStarttime(null);
		header.setEndtime(null);
		header.setGuid(null);
		header.setSession_trans_count("0000001");
		header.setHost_trans_seq(null);
		header.setReturn_code(null);
		header.setRead_only_ind(null);
		header.setNum_detail("0002");
		header.setRead_only_user_id(null);
		header.setLasrversion(null);

		return header;
	}
	
	
	private Header prepareHeaderforJustGo(String user_id) {
		// Prepare Header
		Header header = new Header();

		header.setUser_id(user_id);
		header.setProcess("REQ");
		header.setTab_ind("544");
		header.setProcess_group_ind("J");
		header.setObject_handle("00000000");
		header.setObject_handle2(null);
		header.setLog_ind(null);
		header.setStarttime(null);
		header.setEndtime(null);
		header.setGuid(null);
		header.setSession_trans_count("0000001");
		header.setHost_trans_seq(null);
		header.setReturn_code(null);
		header.setRead_only_ind(null);
		header.setNum_detail("0001");
		header.setRead_only_user_id(null);
		header.setLasrversion(null);

		return header;
	}
	
	
	private Header prepareHeaderforResubmit(String user_id) {
		// Prepare Header
		Header header = new Header();

		header.setUser_id(user_id);
		header.setProcess("REQ");
		header.setTab_ind("547");
		header.setProcess_group_ind("M");
		header.setObject_handle("00000000");
		header.setObject_handle2(null);
		header.setLog_ind(null);
		header.setStarttime(null);
		header.setEndtime(null);
		header.setGuid(null);
		header.setSession_trans_count("0000001");
		header.setHost_trans_seq(null);
		header.setReturn_code(null);
		header.setRead_only_ind(null);
		header.setNum_detail("0002");
		header.setRead_only_user_id(null);
		header.setLasrversion(null);

		return header;
	}
}
