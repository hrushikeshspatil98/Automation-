package com.att.lasr.service;

public class LogoffService {

	public String logoffValidation(String returnCode) {
		
		ReadErrorMsgsJson readErrorMsgsJson = new ReadErrorMsgsJson();
		//String logoffResponse="000";
		String error_msg="";
		switch(returnCode) { 
		case "000" :
			error_msg = readErrorMsgsJson.getErrorMsg("LG0058");
			break;
		case "999" :
			error_msg = readErrorMsgsJson.getErrorMsg("LG0059");
			break;
		}
		return error_msg;
		
	}
}
