package com.att.lasr.model;

import java.util.ArrayList;
import java.util.List;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@ToString
public class PortDPUTrunkGroupTGRPDisc_9state {
	
	private String item_num;
	private String didnum_attr;
	private String didnum;
	private String tg_tc_opt_attr;
	private String tg_tc_opt;
	private String tg_tc_per_attr;
	private String tg_tc_per;
	private String tg_tc_to_pri_attr;
	private String tg_tc_to_pri;
	private String tg_tc_name_pri_attr;
	private String tg_tc_name_pri;
    private String tg_tc_id_attr;
	private String tg_tc_id_pri;
	private String tg_tc_fr_attr;
	private String tg_tc_fr;
	private String locnum;
	private String loc_sec_num;
   
	//List<PortDPUTrunkGroupTGRPDiscTable_9state> portDPUTrunkGroupTGRPDiscTable_9state_ReqU=new ArrayList<>();
}
