package com.att.lasr.model;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@ToString
public class CentrexResaleCommonBlockSectionDW1Data9 {
	private String cb_attr;
	private String cb;
}
