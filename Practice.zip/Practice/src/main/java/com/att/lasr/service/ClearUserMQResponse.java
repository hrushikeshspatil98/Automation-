package com.att.lasr.service;

import java.io.IOException;
import javax.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import com.att.lasr.controller.EnvRegionController;
import com.att.lasr.model.MQDetails;
import com.att.lasr.utils.MQWriteUtil;
import com.ibm.mq.MQException;
import com.ibm.mq.MQGetMessageOptions;
import com.ibm.mq.MQMessage;
import com.ibm.mq.MQQueue;
import com.ibm.mq.MQQueueManager;
import com.ibm.mq.constants.CMQC;

public class ClearUserMQResponse {

	@Autowired
	EnvRegionController envRegionCtrl;

	@Autowired
	MQWriteUtil mqWriteUtil;

	@Autowired
	HttpSession httpSession;

	MQQueueManager mqQueueManager;

	boolean read(HttpSession session, MQDetails mqDetFromSession) throws MQException {

		System.out.println("\n mqDetFromSession is: " + mqDetFromSession.toString());
		mqQueueManager = new MQQueueManager(mqDetFromSession.getQueueManager());

		int openOptions = CMQC.MQOO_INQUIRE + CMQC.MQOO_FAIL_IF_QUIESCING + CMQC.MQOO_INPUT_SHARED;
		int depth = 0;
		MQQueue queue = null;
		try {
		 queue = mqQueueManager.accessQueue(mqDetFromSession.getReadQueueName(), openOptions, null, // default q manager																					
				null, // no dynamic q name
				null); // no alternate user id
		System.out.println("MQRead v1.0 connected.");

		 depth = queue.getCurrentDepth();
		System.out.println("Current depth in clear response: " + depth + "\n");
		if (depth == 0) {
			return false;
		}

		MQGetMessageOptions getOptions = new MQGetMessageOptions();
		getOptions.options = CMQC.MQGMO_NO_WAIT + CMQC.MQGMO_FAIL_IF_QUIESCING + CMQC.MQGMO_CONVERT;
		MQMessage message = new MQMessage();
		
		
			byte[] corId = (byte[]) session.getAttribute("corelationIdSession");
			if (corId == null) {
				System.out.println("Corid is null");
				corId = (byte[]) httpSession.getAttribute("corelationIdSession");
			} else {
				System.out.println("Corid is ->" + corId);
			}
			message.correlationId = corId;
			getOptions.matchOptions = CMQC.MQMO_MATCH_CORREL_ID;

			queue.get(message, getOptions);
			byte[] b = new byte[message.getMessageLength()];
			message.readFully(b);
			message.clearMessage();

		} catch (IOException e) {
			System.out.println("IOException during GET: " + e.getMessage());
			return false;
		} catch (MQException e) {
			if (e.completionCode == 2 && e.reasonCode == CMQC.MQRC_NO_MSG_AVAILABLE) {
				if (depth > 0) {
					System.out.println("All messages read.");
				}
			} else {
				System.out.println("GET Exception: " + e);
			}
			return false;
		} finally {
			queue.close();
			mqQueueManager.disconnect();
			System.out.println("In Clear User Response : finally mq is closed and disconnected");
		}

		return true;
	}
}