package com.att.lasr.model;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@ToString

public class ConfirmationViewNonEmailCoreXMLGWHunting9StatesRow {

	private String  hnum_attr;
	private String  hnum;
	private String  ha_attr;
	private String  ha;
	private String  hid_attr;
	private String  hid;
	private String  htli_attr;
	private String  htli;
	private String  locnum;
	
}
