
package com.att.lasr.service;

import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.web.client.RestTemplate;

@Configuration
public class OAuth2SecurityConfig extends WebSecurityConfigurerAdapter {
	
//	@Bean 
//	public RestTemplate restTemplate(RestTemplateBuilder builder) { 
//		return builder.additionalCustomizers(new ProxyCustomizer()).build();
//	}
	
	@Override
	protected void configure(HttpSecurity http) throws Exception {
		
//	   http.authorizeRequests(authorizeRequests ->
//		  authorizeRequests.antMatchers("/home", "/login**", "/callback/", "/error", "/webjars/**", "/oauth2/authorization/**").permitAll()
//		  .anyRequest().authenticated() ) .oauth2Login(); 
		  
	  http.csrf().disable().authorizeRequests().antMatchers("/").permitAll();
		  
		  http.sessionManagement().sessionCreationPolicy(SessionCreationPolicy.ALWAYS)
		  .invalidSessionUrl("/login")
		  .sessionAuthenticationErrorUrl("/login");
		  
	}

}
 
