package com.att.lasr.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.ui.ModelMap;

import com.att.lasr.controller.EnvRegionController;
import com.att.lasr.model.EnvRegion;
import com.att.lasr.model.Header;
import com.att.lasr.model.LscNoteDTO;
import com.att.lasr.model.MQReceivedData;
import com.att.lasr.model.ManualRejectDTO;
import com.att.lasr.model.NotesFupBindingData12States;
import com.att.lasr.model.NotesFupBindingData9States;
import com.att.lasr.model.ShowError;
import com.att.lasr.model.SubData;
import com.att.lasr.model.SubHeader;
import com.att.lasr.utils.MQMessageStringBuilder;
import com.att.lasr.utils.MQReadUtil;
import com.att.lasr.utils.MQWriteUtil;
import com.att.lasr.utils.enums.LastInd;
import com.att.lasr.utils.enums.LogInd;
import com.att.lasr.utils.enums.Process;
import com.att.lasr.utils.enums.ProcessGroupInd;
import com.att.lasr.utils.enums.ProcessMode;
import com.att.lasr.utils.enums.RecIdFor12State;
import com.att.lasr.utils.enums.TabInd;
@Service
public class ManualRejectTransactionService {

	
	
	@Autowired
	private MQReadUtil mqReadUtil;

	@Autowired
	private MQWriteUtil mqWriteUtil;

	
	@Autowired
	private EnvRegionController envRegCtrl;
	
	
	
		public Header writeManualRejDataToMQ(LscNoteDTO lscNoteDTO,String userId,HttpSession session, ModelMap model) {
				String stateType=""; 
				 int totalRowUpdated=0;
					
				 totalRowUpdated= lscNoteDTO.getManualRejectDTOList().size()+2;
					String numVal=getNumDetailsVal(totalRowUpdated); 
					 System.out.println("numVal"+numVal+"totalRowUpdated "+totalRowUpdated);
		 EnvRegion e= envRegCtrl.getEnvRegion(session);
		 if(e != null) {
			 stateType = e.getStateType() ;
		 }
		 SubHeader subHeaderRec49 = prepareSubHeaderForRec49();
		 String dataString049Rec="";
		 if(stateType.equalsIgnoreCase("12 States")) { 
			  ArrayList<NotesFupBindingData12States> treeViewList_049 =(ArrayList) session.getAttribute("treeViewList_049");	
			 dataString049Rec=treeViewList_049.get(0).getNotesFupBindingData12String();
			 session.setAttribute("Lrs_No", treeViewList_049.get(0).getRequest_id().substring(0, 17).trim());
		 }else if(stateType.equalsIgnoreCase("9 States")){
			  ArrayList<NotesFupBindingData12States> treeViewList_049 =(ArrayList) session.getAttribute("treeViewList_049");	
			 dataString049Rec= treeViewList_049.get(0).getNotesFupBindingData9String();
			 session.setAttribute("Lrs_No", treeViewList_049.get(0).getRequest_id().substring(0, 17).trim());
		 }
		 
		 //data for rec 531
		 SubHeader subHeaderRec531 = prepareSubHeaderForRec531();
		 String dataString531Rec=lscNoteDTO.getLscNoteDTODataString();
		
		// data for rec570
		Header headerRec570 = prepareHeaderForManRejIssue(userId,numVal);
		SubHeader subHeaderRec570 = prepareSubHeaderForManRejIssue();
		 
		
		List<String> dataStringList= new ArrayList<String>();
		MQMessageStringBuilder mqMessageStringBuilder = new MQMessageStringBuilder().addHeaderSubHeaderAndData(headerRec570,
				subHeaderRec49, dataString049Rec);
		mqMessageStringBuilder.appendSubHeaderAndData(subHeaderRec531, dataString531Rec);
		
		ArrayList<ManualRejectDTO> manRejDataToUpdate= new ArrayList<ManualRejectDTO>();
		for(int i=0;i<lscNoteDTO.getManualRejectDTOList().size();i++) {
			ManualRejectDTO manRejData= new ManualRejectDTO();
			manRejData=lscNoteDTO.getManualRejectDTOList().get(i);
			
		String dataString= manRejData.getManualRejectDTODataString(stateType);

		dataStringList.add(dataString);
		mqMessageStringBuilder.appendSubHeaderAndData(subHeaderRec570, dataStringList.get(i));
			


		}
			
		

		
		boolean isWritten = mqWriteUtil.writeDataToMQ(mqMessageStringBuilder,session);
		Header receivedHeader=new Header();

		if (isWritten) {

			MQReceivedData mqReceivedData=null;
			
			try {

			mqReceivedData = mqReadUtil.readSortDataFromMQ(session); 
			 long endTime = System.nanoTime() + TimeUnit.NANOSECONDS.convert(3L, TimeUnit.MINUTES); 
			  Map<String, SubData> subDatas = mqReceivedData.getSubDatas(); 
		//	  Header receivedHeader = mqReceivedData.getHeader(); 
			  while(mqReceivedData.getHeader()==null&& System.nanoTime() < endTime) { 
					System.out.println("*************inside if*************** "); 
					mqReceivedData =	 mqReadUtil.readSortDataFromMQ(session); 
				} 
			  
			  
			  System.out.println(mqReceivedData.getHeader().toString()); 
		} catch (Exception f) { 
			// TODO Auto-generated catch block 
			// mqReceivedData = mqReadUtil.readDataFromMQ(session); 
			f.printStackTrace(); 


		}
			Map<String, SubData> subDatas = mqReceivedData.getSubDatas();
			receivedHeader = mqReceivedData.getHeader(); 
			SubData subData = subDatas.get(RecIdFor12State.CS_RECID_ERROR.getRecIdValue());
			getSuccessErrorList(receivedHeader,subData,session,model)	;		
			

			
			}
		return receivedHeader;

	}
		
		private  String getNumDetailsVal(int size) {
			String numVal = String.format("%04d", size);
			System.out.println("objHandle value is " + numVal);
			return numVal;
		}

		
public void getSuccessErrorList(Header receivedHeader, SubData subData,HttpSession session, ModelMap model) {

	List<ShowError> showUpdateErrorList = new ArrayList<ShowError>();
	ReadErrorMsgsJson readErrorMsgsJson = new ReadErrorMsgsJson(); 
	String rc="";
	if (subData != null) {
		String[] subDataRows = subData.getSubDataRows();
			
		String[] attributes = mqReadUtil.getAttributes(subDataRows[0], 4);
		
		
	if (receivedHeader.getReturn_code() != null && receivedHeader.getReturn_code().equals("999")) {

		String uon_msg = readErrorMsgsJson.getErrorMsg("LG0017");
		session.setAttribute("uon_err_msg", uon_msg);
		model.addAttribute("uon_err_msg", uon_msg);
		ShowErrorService showErrorService = new ShowErrorService();
		showUpdateErrorList = showErrorService.getErrorList(attributes[0].trim(), attributes[1],
				"", "U");
		model.addAttribute("showError", showUpdateErrorList);
		session.setAttribute("showError", showUpdateErrorList);
		System.out.println("showUpdateErrorList"+showUpdateErrorList);
	}

	

if (receivedHeader.getReturn_code() != null && receivedHeader.getReturn_code().equals("000")) {
	rc= receivedHeader.getReturn_code().trim();
	String uon_msg = readErrorMsgsJson.getErrorMsg("LG0016");
	session.setAttribute("uon_info_msg", uon_msg);
	model.addAttribute("uon_info_msg", uon_msg);
	
	System.out.println("uon_msg"+uon_msg);
}
if (receivedHeader.getReturn_code() != null && receivedHeader.getReturn_code().equals("889")) {

	String ecckt_msg = readErrorMsgsJson.getErrorMsg("LG0067");
	session.setAttribute("ecckt_err_msg", ecckt_msg);
	model.addAttribute("ecckt_err_msg", ecckt_msg);
	System.out.println("ecckt_msg"+ecckt_msg);
}
if (receivedHeader.getReturn_code() != null && receivedHeader.getReturn_code().equals("888")) {

	String ecckt_msg = readErrorMsgsJson.getErrorMsg("LG0022");
	session.setAttribute("ecckt_err_msg", ecckt_msg); 
	model.addAttribute("ecckt_err_msg", ecckt_msg);
	System.out.println("1ecckt_msg "+ecckt_msg);
}


	}

	
	
	
//	System.out.println("uon_msg"+uon_msg);





}

	private SubHeader prepareSubHeaderForRec531() {
		// Prepare SubHeader
		SubHeader subHeader = new SubHeader();

		subHeader.setLast_ind(LastInd.Y.name());
		subHeader.setProcess_mode(ProcessMode.CS_ADD.getProcessModeCode());
		subHeader.setRecord_type(RecIdFor12State.CS_RECID_NOTES_INPUT.getRecIdValue());
		subHeader.setReturn_code(null);
		subHeader.setDw_rownum(null);
		subHeader.setEcver(null);

		return subHeader;
		}

















	private SubHeader prepareSubHeaderForRec49() {
		// Prepare SubHeader
				SubHeader subHeader = new SubHeader();

				subHeader.setLast_ind(LastInd.Y.name());
				subHeader.setProcess_mode(ProcessMode.CS_UPDATE.getProcessModeCode());
				subHeader.setRecord_type(RecIdFor12State.CS_RECID_HEADER.getRecIdValue());
				subHeader.setReturn_code(null);
				subHeader.setDw_rownum(null);
				subHeader.setEcver(null);

				return subHeader;
	}

















	private SubHeader prepareSubHeaderForManRejIssue() {
		
		// Prepare SubHeader
		SubHeader subHeader = new SubHeader();

		subHeader.setLast_ind(LastInd.Y.name());
		subHeader.setProcess_mode(ProcessMode.CS_ADD.getProcessModeCode());
		subHeader.setRecord_type(RecIdFor12State.CS_RECID_REJECT_SUMM.getRecIdValue());
		subHeader.setReturn_code(null);
		subHeader.setDw_rownum(null);
		subHeader.setEcver(null);

		return subHeader;
	}

	private Header prepareHeaderForManRejIssue(String user_id, String numVal ) {
		// Prepare Header
		Header header = new Header();

		header.setUser_id(user_id);
		header.setProcess(Process.CS_REQUEST.getProcessCode());
		header.setTab_ind(TabInd.REJECT.getTabIndCode());
		header.setProcess_group_ind(ProcessGroupInd.ISSUE_IND.getProcessGroupInd());
		header.setObject_handle("00000000");
		header.setObject_handle2(null);
		header.setLog_ind(LogInd.N.name());
		header.setStarttime(null);
		header.setEndtime(null);
		header.setGuid(null);
		header.setSession_trans_count(null);
		header.setHost_trans_seq(null);
		header.setReturn_code(null);
		header.setRead_only_ind(null);
		header.setNum_detail(numVal);
		header.setRead_only_user_id(null);
		header.setLasrversion(null);
		return header;
	}


	
}
