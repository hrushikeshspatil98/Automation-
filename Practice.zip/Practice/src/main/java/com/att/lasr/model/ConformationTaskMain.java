/**
 * 
 */
package com.att.lasr.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

/**
 * @author mk5650
 *
 */
@Setter
@Getter
@NoArgsConstructor
@ToString

public class ConformationTaskMain implements Serializable {
	private Header header;

	private SubHeader subHeader;
	
	private List<NotesFupBindingData9States> notesFupBindingData9States;
	private List<ConfirmationTask_RecId_550> confirmationTask_RecId_550;
	private List<ConfirmationTask_RecId12_550> confirmationTask_RecId12_550;
	private List<ConfirmationTask_RecId_551> confirmationTask_RecId_551;
	private List<ConfirmationTask_RecId_558> treeViewList_558;
	private List<ConfirmationTask_RecId_552> confirmationTask_RecId_552List;
	private List<ConfirmationTaskNEmailXMLGW9RecId905> confirmationTaskNEmailXMLGW9RecId905;
	private List<ConfirmationTaskNEmailXMLGW9RecId906> confirmationTaskNEmailXMLGW9RecId906;
	
	private List<PostToBillTask_RecId585> postToBillTask_RecId585;
	private List<PostToBillTaskLSCInfo_588> postToBillTaskLSCInfo_588;
	private List<NotesFupBindingData12States> notesFupBindingData12States ;

}
