package com.att.lasr.model;

import com.att.lasr.utils.Constants;
import com.att.lasr.utils.FormatUtil;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@ToString

public class ConfirmationLS0G6DW2Row {
	
	private String old_dtm;
	private String old_ord;
	private String ord_attr;
	private String ord;
	private String fdt_attr;
	private String fdt;
	private String dd_attr;	
	private String dd;
	private String comp_dt_attr;
	private String comp_dt;
	private String posted_date_attr;
	private String posted_date;
	private String apptime_attr;	
	private String apptime;

	public String getConfirmationLS0G6DW2() {
		StringBuilder confirmationLS0G6DW2sb = new StringBuilder();
	
		confirmationLS0G6DW2sb.append(FormatUtil.getValueWithSpaces(old_dtm, 26)).append(Constants.TAB);
	    confirmationLS0G6DW2sb.append(FormatUtil.getValueWithSpaces(old_ord, 20)).append(Constants.TAB);
		confirmationLS0G6DW2sb.append(FormatUtil.getValueWithSpaces(ord_attr, 1)).append(Constants.TAB);
		confirmationLS0G6DW2sb.append(FormatUtil.getValueWithSpaces(ord, 20)).append(Constants.TAB);
		confirmationLS0G6DW2sb.append(FormatUtil.getValueWithSpaces(fdt_attr, 1)).append(Constants.TAB);
		confirmationLS0G6DW2sb.append(FormatUtil.getValueWithSpaces(fdt, 6)).append(Constants.TAB);
		confirmationLS0G6DW2sb.append(FormatUtil.getValueWithSpaces(dd_attr, 1)).append(Constants.TAB);
		confirmationLS0G6DW2sb.append(FormatUtil.getValueWithSpaces(FormatUtil.getMqDateFormatString(dd), 8))
		.append(Constants.TAB);
		confirmationLS0G6DW2sb.append(FormatUtil.getValueWithSpaces(comp_dt_attr, 1)).append(Constants.TAB);
		confirmationLS0G6DW2sb.append(FormatUtil.getValueWithSpaces(FormatUtil.getMqDateFormatString(comp_dt), 8))
		.append(Constants.TAB);
		confirmationLS0G6DW2sb.append(FormatUtil.getValueWithSpaces(posted_date_attr, 1)).append(Constants.TAB);
		confirmationLS0G6DW2sb.append(FormatUtil.getValueWithSpaces(FormatUtil.getMqDateFormatString(posted_date), 8))
		.append(Constants.TAB);
		confirmationLS0G6DW2sb.append(FormatUtil.getValueWithSpaces(apptime_attr, 1)).append(Constants.TAB);
		confirmationLS0G6DW2sb.append(FormatUtil.getValueWithSpaces(apptime, 11)).append(Constants.TAB);

		String confirmationDataString = FormatUtil.getValueWithSpaces(confirmationLS0G6DW2sb.toString(), 2400);
		return confirmationDataString;
	}

}
