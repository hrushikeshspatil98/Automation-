package com.att.lasr.model;

import java.util.ArrayList;
import java.util.List;

import com.att.lasr.utils.Constants;
import com.att.lasr.utils.FormatUtil;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@ToString
public class SelectRequestData {

	private Header header;

	private SubHeader subHeader;

	private String company_code;
	private String pon;
	private String project;
	private String date_received_begin_date;
	private String date_received_end_date;
	private String request_id;
	private String version;
	private String sc;
	private String rpon;

	private String total_record;
	private String start_page;
	private String end_page;
	private String prevnext_cde;
	private String begin_time_nextptr;
	private String end_time_nextptr;
	private String begin_time_prevptr;
	private String end_time_prevptr;
	private String error;
	private List<SelectRequestTableRow> selectRequestTableRows = new ArrayList<>();
	public List<SelectRequestTableRow9> selectRequestTableRows9 = new ArrayList<>();

	public String getSelectRequestDataString() {
		StringBuilder selectRequestDataSb = new StringBuilder();

		selectRequestDataSb.append(FormatUtil.getValueWithSpaces(company_code, 4)).append(Constants.TAB);
		selectRequestDataSb.append(FormatUtil.getValueWithSpaces(pon, 16)).append(Constants.TAB);
		selectRequestDataSb.append(FormatUtil.getValueWithSpaces(project, 16)).append(Constants.TAB);
		selectRequestDataSb
				.append(FormatUtil.getValueWithSpaces(FormatUtil.getMqDateFormatString(date_received_begin_date), 8))
				.append(Constants.TAB);
		selectRequestDataSb
				.append(FormatUtil.getValueWithSpaces(FormatUtil.getMqDateFormatString(date_received_end_date), 8))
				.append(Constants.TAB);
		selectRequestDataSb.append(FormatUtil.getValueWithSpaces(request_id, 14)).append(Constants.TAB);
		selectRequestDataSb.append(FormatUtil.getValueWithSpaces(version, 2)).append(Constants.TAB);
		selectRequestDataSb.append(FormatUtil.getValueWithSpaces(sc, 2)).append(Constants.TAB);
		selectRequestDataSb.append(FormatUtil.getValueWithSpaces(rpon, 16)).append(Constants.TAB);
		selectRequestDataSb.append(FormatUtil.getValueWithSpaces(total_record, 6)).append(Constants.TAB);
		selectRequestDataSb.append(FormatUtil.getValueWithSpaces(start_page, 3)).append(Constants.TAB);
		selectRequestDataSb.append(FormatUtil.getValueWithSpaces(end_page, 3)).append(Constants.TAB);
		selectRequestDataSb.append(FormatUtil.getValueWithSpaces(prevnext_cde, 1)).append(Constants.TAB);
		selectRequestDataSb.append(FormatUtil.getValueWithSpaces(begin_time_nextptr, 26)).append(Constants.TAB);
		selectRequestDataSb.append(FormatUtil.getValueWithSpaces(end_time_nextptr, 26)).append(Constants.TAB);

		selectRequestDataSb.append(FormatUtil.getValueWithSpaces(begin_time_prevptr, 26)).append(Constants.TAB);
		selectRequestDataSb.append(FormatUtil.getValueWithSpaces(end_time_prevptr, 26)).append(Constants.TAB)
				.append(Constants.TAB);

		String selectRequestDataString = FormatUtil.getValueWithSpaces(selectRequestDataSb.toString(), 2400);
		return selectRequestDataString;
	}

}
