package com.att.lasr.model;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@ToString
public class EndUserBill_9States {
	private String fbi_attr;
	private String fbi;
	private String billnm_attr;
	private String billnm;
	private String sbillnm_attr;
	private String sbillnm;
	private String street_attr;
	private String street;
	private String floor_billnm_attr;
	private String floor_billnm;
	private String room_mail_attr;
	private String room_mail;
	private String city_attr;
	private String bill_city;
	private String state_attr;
	private String bill_state;
	private String zip_attr;
	private String bill_zip;
	private String billcon_attr;
	private String billcon;
	private String tel_no_attr;
	private String bill_tel_no;
	private String locnum_attr;
	private String locnum;
	private String ean_attr;
	private String ean;
	private String eatn_attr;
	private String bill_eatn;
	private String loc_seq_num;

}
