package com.att.lasr.model;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@ToString
public class ConfirmationReqtypBandC9StatesRowDW1 {
	
private String a_cver;
private String a_atn_attr;
private String a_atn;
private String a_init_attr;
private String a_init;
private String a_rep;
private String a_tel_no;
private String a_rt;
private String a_ecver;
private String a_d_t_sent_local;
private String a_response_d_t_sent_cent_time;
private String a_pia;
private String a_chc;
private String a_fdt_attr;
private String a_fdt;
private String  a_dd_attr;
private String a_dd;
private String apptime_attr;
private String apptime;
private String ebd_attr;
private String ebd;
private String ban1_attr;
private String ban1; 
private String ban2_attr;
private String ban2;
private String a_an_attr;
private String a_an;

}
