package com.att.lasr.model;

import java.util.ArrayList;
import java.util.List;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@ToString

public class Resaleprivatelineprimarylocation_grid9states {

	private String request_prod_id;
	private String item_num;
	private String leg_itemnum;
	private String fa_attr; 
	private String fa;
	private String feature_attr; 
	private String feature;
	private String feature_detail_attr; 
	private String feature_detail;
	private String line_asgn_attr; 
	private String line_asgn;
	private String locnum;
	private String loc_seq_num; 
	
}
