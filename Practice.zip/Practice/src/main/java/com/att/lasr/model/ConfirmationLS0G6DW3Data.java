package com.att.lasr.model;
import java.util.ArrayList;
import java.util.List;

import com.att.lasr.utils.Constants;
import com.att.lasr.utils.FormatUtil;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@ToString


public class ConfirmationLS0G6DW3Data {
	private Header header;
	private SubHeader subHeader;
	private String item_num;	
	private String hnum;
	private String hid_attr;
	private String hid;
	private String hunt_tli_attr;
	private String hunt_tli;
	
	private List<ConfirmationLS0G6DW4Row> confirmationLS0G6DW3Row = new ArrayList<>();

	public String getConfirmationLS0G6DW3() {
		StringBuilder ConfirmationLS0G6DW3sb = new StringBuilder();
	
		ConfirmationLS0G6DW3sb.append(FormatUtil.getValueWithSpaces(item_num, 4)).append(Constants.TAB);
		ConfirmationLS0G6DW3sb.append(FormatUtil.getValueWithSpaces(hnum, 4)).append(Constants.TAB);
		ConfirmationLS0G6DW3sb.append(FormatUtil.getValueWithSpaces(hid_attr, 1)).append(Constants.TAB);
		ConfirmationLS0G6DW3sb.append(FormatUtil.getValueWithSpaces(hid, 4)).append(Constants.TAB);
		ConfirmationLS0G6DW3sb.append(FormatUtil.getValueWithSpaces(hunt_tli_attr, 1)).append(Constants.TAB);
		ConfirmationLS0G6DW3sb.append(FormatUtil.getValueWithSpaces(hunt_tli, 12)).append(Constants.TAB);

		String ConfirmationDataString = FormatUtil.getValueWithSpaces(ConfirmationLS0G6DW3sb.toString(), 2400);
		return ConfirmationDataString;
	}

	
}
