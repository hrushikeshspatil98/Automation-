package com.att.lasr.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.att.lasr.model.EnhancedSelectData;
import com.att.lasr.model.EnhancedSelectTableRow;
import com.att.lasr.model.Header;
import com.att.lasr.model.MQReceivedData;
import com.att.lasr.model.SubData;
import com.att.lasr.model.SubHeader;
import com.att.lasr.utils.MQMessageStringBuilder;
import com.att.lasr.utils.MQReadUtil;
import com.att.lasr.utils.MQWriteUtil;
import com.att.lasr.utils.enums.LastInd;
import com.att.lasr.utils.enums.LogInd;
import com.att.lasr.utils.enums.Process;
import com.att.lasr.utils.enums.ProcessGroupInd;
import com.att.lasr.utils.enums.ProcessMode;
import com.att.lasr.utils.enums.RecIdFor12State;

@Service
public class EnhancedSelectService {

	@Autowired
	private MQReadUtil mqReadUtil;

	@Autowired
	private MQWriteUtil mqWriteUtil;

	public EnhancedSelectData writeEnhancedSelectDataToMQ(EnhancedSelectData enhancedSelectData, String user_id, String object_handle,HttpSession session) {

		Header header = prepareHeader(user_id,object_handle);
		SubHeader subHeader = prepareSubHeader();

		enhancedSelectData.setPrevnext_cde("R");

		String dataString = enhancedSelectData.getEnhancedSelectdataString();

		MQMessageStringBuilder mqMessageStringBuilder = new MQMessageStringBuilder().addHeaderSubHeaderAndData(header,
				subHeader, dataString);

		boolean isWritten = mqWriteUtil.writeDataToMQ(mqMessageStringBuilder,session);

		if (isWritten) {

			MQReceivedData mqReceivedData=null;
			
			try {

			mqReceivedData = mqReadUtil.readSortDataFromMQ(session); 
			 long endTime = System.nanoTime() + TimeUnit.NANOSECONDS.convert(3L, TimeUnit.MINUTES); 
			  Map<String, SubData> subDatas = mqReceivedData.getSubDatas(); 
		//	  Header receivedHeader = mqReceivedData.getHeader(); 
			  while(mqReceivedData.getHeader()==null&& System.nanoTime() < endTime) { 
					System.out.println("*************inside if*************** "); 
					mqReceivedData =	 mqReadUtil.readSortDataFromMQ(session); 
				} 
			  
			  
			  System.out.println(mqReceivedData.getHeader().toString()); 
		} catch (Exception e) { 
			// TODO Auto-generated catch block 
			// mqReceivedData = mqReadUtil.readDataFromMQ(session); 
			e.printStackTrace(); 


		}
			Map<String, SubData> subDatas = mqReceivedData.getSubDatas();
			Header receivedHeader = mqReceivedData.getHeader();
			enhancedSelectData.setHeader(receivedHeader);
			SubData subData = subDatas.get(RecIdFor12State.CS_RECID_SELREQ_ENH.getRecIdValue());
			int i = 0;
			if (subData != null) {
				SubHeader receivedSubHeader = subData.getSubHeader();
				String[] subDataRows = subData.getSubDataRows();

				List<EnhancedSelectTableRow> enhancedSelectTableRows = new ArrayList<>();

				for (String subDataRow : subDataRows) {

					String[] attributes = mqReadUtil.getAttributes(subDataRow, 22);
//					System.out.println("attributes: " + Arrays.toString(attributes));
					EnhancedSelectTableRow enhancedSelectTableRow = new EnhancedSelectTableRow();

					enhancedSelectTableRow.setDate_time_received(attributes[0]);
					enhancedSelectTableRow.setCc(attributes[1]);
					enhancedSelectTableRow.setRequest_id(attributes[2]);
					enhancedSelectTableRow.setStatus(attributes[3]);
					enhancedSelectTableRow.setPon(attributes[4]);
					enhancedSelectTableRow.setDdd(attributes[5]);
					enhancedSelectTableRow.setReqtyp(attributes[6]);
					enhancedSelectTableRow.setAct(attributes[7]);
					enhancedSelectTableRow.setJep(attributes[8]);
					enhancedSelectTableRow.setCancel_ind(attributes[9]);
					enhancedSelectTableRow.setRelease_version(attributes[10]);
					enhancedSelectTableRow.setWork_group_id(attributes[11]);
					enhancedSelectTableRow.setAssigned_uid(attributes[12]);
					enhancedSelectTableRow.setRpon(attributes[13]);
					enhancedSelectTableRow.setProject(attributes[14]);
					enhancedSelectTableRow.setTotal_record(attributes[15]);
					enhancedSelectTableRow.setStart_page(attributes[16]);
					enhancedSelectTableRow.setEnd_page(attributes[17]);
					enhancedSelectTableRow.setBegin_time_nextptr(attributes[18]);
					enhancedSelectTableRow.setEnd_time_nextptr(attributes[19]);
					enhancedSelectTableRow.setBegin_time_prevptr(attributes[20]);
					enhancedSelectTableRow.setEnd_time_prevptr(attributes[21]);
					enhancedSelectTableRow.setUniqueId(i++);
					enhancedSelectTableRows.add(enhancedSelectTableRow);

				}
				enhancedSelectData.setSubHeader(receivedSubHeader);
				enhancedSelectData.setEnhancedSelectTableRows(enhancedSelectTableRows);
				System.out.println("enhancedSelectData.getEnhancedSelectTableRows size: " + enhancedSelectData.getEnhancedSelectTableRows().size());
			}
		}
		return enhancedSelectData;
	}

	private SubHeader prepareSubHeader() {

		// Prepare SubHeader
		SubHeader subHeader = new SubHeader();

		subHeader.setLast_ind(LastInd.Y.name());
		subHeader.setProcess_mode(ProcessMode.CS_RETRIEVE.getProcessModeCode());
		subHeader.setRecord_type(RecIdFor12State.CS_RECID_SELREQ_ENH.getRecIdValue());
		subHeader.setReturn_code(null);
		subHeader.setDw_rownum(null);
		subHeader.setEcver(null);

		return subHeader;
	}

	private Header prepareHeader(String user_id, String object_handle) {
		// Prepare Header
		Header header = new Header();

		header.setUser_id(user_id);
		header.setProcess(Process.CS_SELECT_REQUEST_ENH.getProcessCode());
		header.setTab_ind(null);
		header.setProcess_group_ind(ProcessGroupInd.RETRIEVE_IND.getProcessGroupInd());
		header.setObject_handle(object_handle);
		header.setObject_handle2(null);
		header.setLog_ind(LogInd.N.name());
		header.setStarttime(null);
		header.setEndtime(null);
		header.setGuid(null);
		header.setSession_trans_count("0000001");
		header.setHost_trans_seq(null);
		header.setReturn_code(null);
		header.setRead_only_ind(null);
		header.setNum_detail("0001");
		header.setRead_only_user_id(null);
		header.setLasrversion(null);

		return header;
	}

}
