package com.att.lasr.utils.enums;

public enum ProcessMode {
	CS_ADD("A"), CS_DELETE("D"), CS_RETRIEVE("R"), CS_UPDATE("U"), CS_SPECIAL("X"), CS_ARC("SRA"), CS_APR("APR");

	private final String processModeCode;

	ProcessMode(String processModeCode) {
		this.processModeCode = processModeCode;
	}

	public String getProcessModeCode() {
		return this.processModeCode;
	}

}