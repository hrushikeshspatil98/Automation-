package com.att.lasr.model;

import java.util.ArrayList;
import java.util.List;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@ToString
public class Resaleprivatelinecircuit12states {
	
	private String item_num;
	private String lnum_attr;
	private String lnum;
	private String ckta_attr;
	private String ckta;
	private String svc_cd_attr;
	private String svc_cd;
	private String ckttyp_attr;
	private String ckttyp;
	private String ecckt_attr;
	private String ecckt;
	private String mtp_attr;
	private String mtp;
	private String wire_attr;
	private String wire;
	private String disc_ecckt_attr;
	private String disc_ecckt;
}
