package com.att.lasr.utils;

public class Constants {

	private Constants() {
		super();
		// TODO Auto-generated constructor stub
	}

	public static final String TAB = "	";
	public static final String EMPTY_STRING = "";
	public static final String DASH = "-";
	public static final String Y = "Y";

}
