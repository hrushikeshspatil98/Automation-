package com.att.lasr.model;

import com.att.lasr.utils.FormatUtil;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@ToString
public class Header {

	private String user_id;
	private String process;
	private String tab_ind;
	private String process_group_ind;
	private String object_handle;
	private String object_handle2;
	private String log_ind;
	private String starttime;
	private String endtime;
	private String guid;
	private String session_trans_count;
	private String host_trans_seq;
	private String return_code;
	private String read_only_ind;
	private String num_detail;
	private String read_only_user_id;
	private String lasrversion;
	
	public String getStringWithSpaces() {

		StringBuffer headerSb = new StringBuffer();
		headerSb.append(FormatUtil.getValueWithSpaces(user_id, 7));
		headerSb.append(FormatUtil.getValueWithSpaces(process, 3));
		headerSb.append(FormatUtil.getValueWithSpaces(tab_ind, 3));
		headerSb.append(FormatUtil.getValueWithSpaces(process_group_ind, 1));
		headerSb.append(FormatUtil.getValueWithSpaces(object_handle, 8));
		headerSb.append(FormatUtil.getValueWithSpaces(object_handle2, 8));
		headerSb.append(FormatUtil.getValueWithSpaces(log_ind, 1));
		headerSb.append(FormatUtil.getValueWithSpaces(starttime, 17));
		headerSb.append(FormatUtil.getValueWithSpaces(endtime, 17));
		headerSb.append(FormatUtil.getValueWithSpaces(guid, 32));
		headerSb.append(FormatUtil.getValueWithSpaces(session_trans_count, 7));
		headerSb.append(FormatUtil.getValueWithSpaces(host_trans_seq, 2));
		headerSb.append(FormatUtil.getValueWithSpaces(return_code, 3));
		headerSb.append(FormatUtil.getValueWithSpaces(read_only_ind, 1));
		headerSb.append(FormatUtil.getValueWithSpaces(num_detail, 4));
		headerSb.append(FormatUtil.getValueWithSpaces(read_only_user_id, 7));
		headerSb.append(FormatUtil.getValueWithSpaces(lasrversion, 5));

		String headerString = FormatUtil.getValueWithSpaces(headerSb.toString(), 150);

		return headerString;

	}
}
