package com.att.lasr.model;

import java.util.List;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@ToString
public class CompletionProviderTaskWithLoss {

	private Header header;
	private SubHeader subHeader;
	
	private List<CompletionProviderTask> cploss_560;
	private List<CompletionActivityRLSOG6LscInfo> cploss_568;
	private List<CompletionProviderTaskWithLossLasrInfo> cploss_577;
	private List<CompletionProviderLoss_578> cploss_578;
	
}
