package com.att.lasr.model;

import com.att.lasr.utils.Constants;
import com.att.lasr.utils.FormatUtil;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@ToString
public class CompletionProviderLoss_578 {

	private String numname_attr;
	private String numname;
	private String numnbr_attr;
	private String numnbr;
	private String wtn_attr;
	private String wtn;
	private String ecckt_attr;
	private String ecckt;
	private String cvd_attr;
	private String cvd;
	
	public String getCompletionProviderTask578() {
		StringBuilder sb_578 = new StringBuilder();

		
		sb_578.append(FormatUtil.getValueWithSpaces(numname_attr, 1)).append(Constants.TAB);
		sb_578.append(FormatUtil.getValueWithSpaces(numname, 8)).append(Constants.TAB);
		sb_578.append(FormatUtil.getValueWithSpaces(numnbr_attr, 1)).append(Constants.TAB);
		sb_578.append(FormatUtil.getValueWithSpaces(numnbr, 4)).append(Constants.TAB);
		sb_578.append(FormatUtil.getValueWithSpaces(wtn_attr, 1)).append(Constants.TAB);
		sb_578.append(FormatUtil.getValueWithSpaces(FormatUtil.getStringWithoutDashes(wtn), 15)).append(Constants.TAB);
		sb_578.append(FormatUtil.getValueWithSpaces(ecckt_attr, 1)).append(Constants.TAB);
		sb_578.append(FormatUtil.getValueWithSpaces(ecckt, 46)).append(Constants.TAB);
		sb_578.append(FormatUtil.getValueWithSpaces(cvd_attr, 1)).append(Constants.TAB);
		sb_578.append(FormatUtil.getValueWithSpaces(FormatUtil.getMqDateFormatString(cvd), 8)).append(Constants.TAB).append(Constants.TAB);;
		
		String dataString = FormatUtil.getValueWithSpaces(sb_578.toString(), 2400);
		return dataString;
	}
	
}
