package com.att.lasr.controller;

import java.security.Principal;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class SecureController {

	@Autowired
	public WorkloadController workloadCtrl;
	
	@Autowired
	public SelectController selectCtrl;
	
	@Autowired
	public MismatchController mismatchCtrl ;
	
	@Autowired
	public ProviderController providerCtrl;
	
	@Autowired
	public LossController lossCtrl;
	
	@Autowired
	public UserProfileController userProfileCtrl;
	
	String myUserName;
	
	@GetMapping("/")
    public String getUserLogon(Principal principal, ModelMap model, HttpSession session){
//        String activeUser = principal.getName();
//        if(activeUser !=null) {
//        	activeUser=activeUser.toUpperCase();
//        	myUserName=activeUser;
//         }
		System.out.println("in secureCtrl ");
       // session.setAttribute("pricipleUserId", principal.getName().toUpperCase());
       // clearSessionStorage(session);
		String activeUser = "HP959J";
        System.out.println("userName-->"+activeUser);
        session.setAttribute("activeUser", activeUser);
        session.setAttribute("userId", activeUser);
		model.put("username", activeUser);
		
		System.out.println("in secureCtrl userId->"+activeUser+"sessionId-->"+session.getId());
		
		return "redirect:/envRegion";
    }
	
	@GetMapping("/logout")
	public String userLogout(ModelMap model, HttpSession session) {
		//session.invalidate();
		//clearSessionStorage(session);
		///return "redirect:/login";
		return "redirect:/envRegion";
	}
	
	@GetMapping("/login")
	public String redirectLoginPage(ModelMap model, HttpSession session) {
		//clearSessionStorage(session);
		return "redirect:/envRegion";
	}

	public void clearSessionStorage(HttpSession session) {

		session.invalidate();
		
	}
}
