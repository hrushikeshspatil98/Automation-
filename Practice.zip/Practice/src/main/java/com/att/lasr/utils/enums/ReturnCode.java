package com.att.lasr.utils.enums;

public enum ReturnCode {

	SUCCESS("000"), LASR_GUI_EDIT_ERROR("999"), MVS_OR_DB2_ERROR("888"), USER_LOGGED_OFF("889"),
	INVALID_GUI_DATA("887");

	private final String returnCodeValue;

	ReturnCode(String returnCodeValue) {
		this.returnCodeValue = returnCodeValue;
	}

	public String getReturnCodeValue() {
		return returnCodeValue;
	}

}
