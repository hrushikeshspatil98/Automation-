package com.att.lasr.model;

import com.att.lasr.utils.Constants;
import com.att.lasr.utils.FormatUtil;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@ToString
public class CompletionProviderLoss_574 {

	private String company_code;
	private String error_msg;
	
	public String getCompletionProviderTask574String() {
		StringBuilder DataSb = new StringBuilder();

		
		DataSb.append(FormatUtil.getValueWithSpaces(company_code, 4)).append(Constants.TAB);
		DataSb.append(FormatUtil.getValueWithSpaces(error_msg, 6)).append(Constants.TAB).append(Constants.TAB);

		String validateCCString = FormatUtil.getValueWithSpaces(DataSb.toString(), 2400);
		return validateCCString;
	}
}
