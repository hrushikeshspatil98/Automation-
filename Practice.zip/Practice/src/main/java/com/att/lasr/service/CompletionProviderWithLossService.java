package com.att.lasr.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.att.lasr.model.CompletionActivityRLSOG6LscInfo;
import com.att.lasr.model.CompletionProviderLoss_574;
import com.att.lasr.model.CompletionProviderLoss_578;
import com.att.lasr.model.CompletionProviderTask;
import com.att.lasr.model.CompletionProviderTaskWithLoss;
import com.att.lasr.model.Header;
import com.att.lasr.model.MQReceivedData;
import com.att.lasr.model.NotesFupBindingData12States;
import com.att.lasr.model.ShowError;
import com.att.lasr.model.SubData;
import com.att.lasr.model.SubHeader;
import com.att.lasr.utils.MQMessageStringBuilder;
import com.att.lasr.utils.MQReadUtil;
import com.att.lasr.utils.MQWriteUtil;
import com.att.lasr.utils.enums.LastInd;
import com.att.lasr.utils.enums.LogInd;
import com.att.lasr.utils.enums.Process;
import com.att.lasr.utils.enums.ProcessGroupInd;
import com.att.lasr.utils.enums.ProcessMode;
import com.att.lasr.utils.enums.RecIdFor12State;
import com.att.lasr.utils.enums.RecIdFor9State;
import com.att.lasr.utils.enums.TabInd;

@Service
public class CompletionProviderWithLossService {

	@Autowired
	private MQReadUtil mqReadUtil;

	@Autowired
	private MQWriteUtil mqWriteUtil;

	List<ShowError> showUpdateErrorList = new ArrayList<ShowError>();

	public void writeCPLossValidateDataToMQ(List<CompletionProviderTask> cploss_560, String userId,
			String object_handle, HttpSession session, String stateType) {
		System.out.println("In Validate cc CPL Service");
		// 049 RecId code
		@SuppressWarnings("unchecked")
		List<NotesFupBindingData12States> dataObject_049 = (List<NotesFupBindingData12States>) session
				.getAttribute("treeViewList_049");
		String numCount = getNumCount(cploss_560.size() + dataObject_049.size());
		System.out.println("numcount: " + numCount);
		Header header = prepareValidateCCHeader(userId, object_handle, numCount);
		StringBuilder subHeaderandData = new StringBuilder();

		String dataString = "";

		SubHeader subHeader = null;
		MQMessageStringBuilder mqMessageStringBuilder = new MQMessageStringBuilder();
		if (stateType.equalsIgnoreCase("12 States")) {
			subHeader = prepareValidateCCSubHeader(RecIdFor12State.CS_RECID_HEADER.getRecIdValue());

			for (NotesFupBindingData12States notesFupBindingData12States : dataObject_049) {

				session.setAttribute("Lrs_No", notesFupBindingData12States.getRequest_id().substring(0, 17).trim());
				dataString = notesFupBindingData12States.getNotesFupBindingData12String();
				subHeaderandData.append(mqMessageStringBuilder.addHeader(header));
				subHeaderandData
						.append(mqMessageStringBuilder.appendSubHeaderAndData(subHeader, dataString).toString());

			}
		} else {
			subHeader = prepareValidateCCSubHeader(RecIdFor9State.CS_RECID_HEADER.getRecIdValue());
			for (NotesFupBindingData12States notesFupBindingData9States : dataObject_049) {
				session.setAttribute("Lrs_No", notesFupBindingData9States.getRequest_id().substring(0, 17).trim());
				dataString = notesFupBindingData9States.getNotesFupBindingData9String();
				subHeaderandData.append(mqMessageStringBuilder.addHeader(header));
				subHeaderandData
						.append(mqMessageStringBuilder.appendSubHeaderAndData(subHeader, dataString).toString());

			}
		}

		subHeader = prepareValidateCCSubHeader(RecIdFor12State.CS_RECID_LOSS_CC.getRecIdValue());

		for (CompletionProviderTask row : cploss_560) {
			CompletionProviderLoss_574 loss_574 = new CompletionProviderLoss_574();
			loss_574.setCompany_code(row.getCompany_code());
			dataString = loss_574.getCompletionProviderTask574String();
			subHeaderandData.append(mqMessageStringBuilder.appendSubHeaderAndData(subHeader, dataString));
		}
		
		session.setAttribute("info_msg_574", "");
		session.setAttribute("cc_info_msg_574", "");
		session.setAttribute("err_msg_cploss", "");
		
		boolean isWritten = mqWriteUtil.writeDataToMQ(mqMessageStringBuilder, session);

		if (isWritten) {

			MQReceivedData mqReceivedData=null;
			
			try {

			mqReceivedData = mqReadUtil.readSortDataFromMQ(session); 
			 long endTime = System.nanoTime() + TimeUnit.NANOSECONDS.convert(3L, TimeUnit.MINUTES); 
			  Map<String, SubData> subDatas = mqReceivedData.getSubDatas(); 
		//	  Header receivedHeader = mqReceivedData.getHeader(); 
			  while(mqReceivedData.getHeader()==null&& System.nanoTime() < endTime) { 
					System.out.println("*************inside if*************** "); 
					mqReceivedData =	 mqReadUtil.readSortDataFromMQ(session); 
				} 
			  
			  
			  System.out.println(mqReceivedData.getHeader().toString()); 
		} catch (Exception e) { 
			// TODO Auto-generated catch block 
			 //mqReceivedData = mqReadUtil.readDataFromMQ(session); 
			e.printStackTrace(); 


		}
			Map<String, SubData> subDatas = mqReceivedData.getSubDatas();
			Header receivedHeader = mqReceivedData.getHeader();
			
			SubData subData = subDatas.get(RecIdFor12State.CS_RECID_ERROR.getRecIdValue());
			SubData subData_574 = subDatas.get(RecIdFor12State.CS_RECID_LOSS_CC.getRecIdValue());
			
			ReadErrorMsgsJson readErrorMsgsJson = new ReadErrorMsgsJson();
			ShowErrorService showErrorService = new ShowErrorService();
			if(showUpdateErrorList != null)
			{
				showUpdateErrorList.clear();
			}
			
			if (subData != null) {
				String[] subDataRows = subData.getSubDataRows();

				String[] attributes = mqReadUtil.getAttributes(subDataRows[0], 4);

				if (receivedHeader.getReturn_code() != null && receivedHeader.getReturn_code().equals("999")) {

					showUpdateErrorList = showErrorService.getShowErrorList(attributes[0], attributes[2], "",
										"U", showUpdateErrorList);
				}

			}
			
			if (receivedHeader.getReturn_code() != null && receivedHeader.getReturn_code().equals("000")
					&& subData_574 != null) {
				String[] subData_574_arr = subData_574.getSubDataRows();
				String str_574 = subData_574_arr[0];
				String[] attributes = mqReadUtil.getAttributes(str_574, 2);
				String err_code = attributes[1].trim();

				if (err_code.equals("LG0172")) {
					String err_msg = readErrorMsgsJson.getErrorMsg(err_code);
					err_msg = err_msg.replace("%PARM%", " Do you want to re-try? Y/N");
					session.setAttribute("info_msg_574", err_msg);
				}

				if (err_code.equals("LG0206")) {
					String cc_info_msg_574 = readErrorMsgsJson.getErrorMsg(err_code);
					session.setAttribute("cc_info_msg_574", cc_info_msg_574);
					String cpl_losing_cc = cploss_560.get(0).getCompany_code();
					session.setAttribute("cpl_losing_cc", cpl_losing_cc);
				}

			}
			if (receivedHeader.getReturn_code() != null && receivedHeader.getReturn_code().equals("889")) {

				String ecckt_msg = readErrorMsgsJson.getErrorMsg("LG0067");
				session.setAttribute("err_msg_cploss", ecckt_msg);

			}
			if (receivedHeader.getReturn_code() != null && receivedHeader.getReturn_code().equals("888")) {

				String ecckt_msg = readErrorMsgsJson.getErrorMsg("LG0022");
				session.setAttribute("err_msg_cploss", ecckt_msg);

			}

		}

	}

	private SubHeader prepareValidateCCSubHeader(String recId) {

		// Prepare SubHeader
		SubHeader subHeader = new SubHeader();

		subHeader.setLast_ind(LastInd.Y.name());
		subHeader.setProcess_mode(ProcessMode.CS_SPECIAL.getProcessModeCode());
		subHeader.setRecord_type(recId);
		subHeader.setReturn_code(null);
		subHeader.setDw_rownum(null);
		subHeader.setEcver(null);

		return subHeader;
	}

	private Header prepareValidateCCHeader(String user_id, String object_handle, String numCount) {
		// Prepare Header
		Header header = new Header();

		header.setUser_id(user_id);
		header.setProcess(Process.CS_REQUEST.getProcessCode());
		header.setTab_ind(TabInd.VALIDATE_CC_CPLOSS.getTabIndCode());
		header.setProcess_group_ind(ProcessGroupInd.CHECK_IND.getProcessGroupInd());
		header.setObject_handle(object_handle);
		header.setObject_handle2(null);
		header.setLog_ind(LogInd.N.name());
		header.setStarttime(null);
		header.setEndtime(null);
		header.setGuid(null);
		header.setSession_trans_count("0000001");
		header.setHost_trans_seq(null);
		header.setReturn_code(null);
		header.setRead_only_ind(null);
		header.setNum_detail(numCount);
		header.setRead_only_user_id(null);
		header.setLasrversion(null);

		return header;
	}

	private String getNumCount(int size) {
		String numCount = String.format("%04d", size);
		return numCount;
	}

	public List<CompletionProviderLoss_578> getCompletionProvider578Data(String input, HttpSession session) {
		// TODO Auto-generated method stub
		List<CompletionProviderLoss_578> editList = new ArrayList<CompletionProviderLoss_578>();
		String[] sentData = input.split("\\$,");
		
		for (String row : sentData) {
			String[] subData = row.trim().split(" ");

			CompletionProviderLoss_578 r = new CompletionProviderLoss_578();
			r.setCvd(getHashReplaceData(subData[0].trim().toUpperCase()));
			r.setWtn(getHashReplaceData(subData[1].trim().toUpperCase()));
			r.setEcckt(getHashReplaceData(subData[2].trim().toUpperCase()));
			r.setNumnbr(getHashReplaceData(subData[3].trim().toUpperCase()));
			r.setNumname(getHashReplaceData(subData[4].trim().toUpperCase()));

			editList.add(r);
		}

		return editList;
	}

	private String getHashReplaceData(String input) {

		if (input.contains("#,")) {
			return "";
		} else {
			return input;
		}
	}

	// *** issue function
	@SuppressWarnings("unchecked")
	public String writeCPLossIssueDataToMQ(CompletionProviderTaskWithLoss completionMainTask,
			String user_id, String object_handle, HttpSession session, String stateType) {

		System.out.println("In Issue CPL Service");

		List<NotesFupBindingData12States> dataObject_049 = (List<NotesFupBindingData12States>) session
				.getAttribute("treeViewList_049");
		List<CompletionActivityRLSOG6LscInfo> List_568 = completionMainTask.getCploss_568();
		List<CompletionActivityRLSOG6LscInfo> old_list_568 = (List<CompletionActivityRLSOG6LscInfo>) session
				.getAttribute("treeViewList568");
		List<CompletionActivityRLSOG6LscInfo> updateList_568 = getUpdatedRows(List_568, old_list_568);
		int newListsize = getUpdatedCount(List_568, old_list_568.size());
		String numCount = getNumCount(completionMainTask.getCploss_560().size() + updateList_568.size() + newListsize
				+ completionMainTask.getCploss_578().size() + dataObject_049.size());
		Header header = prepareIssueHeader(user_id, object_handle, numCount);
		StringBuilder subHeaderandData = new StringBuilder();

		String dataString = "";

		List<String> filterRecidList = (ArrayList<String>) session.getAttribute("treeViewList");
		SubHeader subHeader = null;
		MQMessageStringBuilder mqMessageStringBuilder = new MQMessageStringBuilder();
		if (stateType.equalsIgnoreCase("12 States")) {
			subHeader = prepareIssueSubHeader(RecIdFor12State.CS_RECID_HEADER.getRecIdValue(),ProcessMode.CS_UPDATE.getProcessModeCode());

			for (NotesFupBindingData12States notesFupBindingData12States : dataObject_049) {

				session.setAttribute("Lrs_No", notesFupBindingData12States.getRequest_id().substring(0, 17).trim());
				dataString = notesFupBindingData12States.getNotesFupBindingData12String();
				
				subHeaderandData.append(mqMessageStringBuilder.addHeader(header));
				subHeaderandData
						.append(mqMessageStringBuilder.appendSubHeaderAndData(subHeader, dataString).toString());

			}
		} else {
			subHeader = prepareIssueSubHeader(RecIdFor9State.CS_RECID_HEADER.getRecIdValue(),ProcessMode.CS_UPDATE.getProcessModeCode());
			for (NotesFupBindingData12States notesFupBindingData9States : dataObject_049) {
				session.setAttribute("Lrs_No", notesFupBindingData9States.getRequest_id().substring(0, 17).trim());
				dataString = notesFupBindingData9States.getNotesFupBindingData9String();
				
				subHeaderandData.append(mqMessageStringBuilder.addHeader(header));
				subHeaderandData
						.append(mqMessageStringBuilder.appendSubHeaderAndData(subHeader, dataString).toString());

			}
		}

		if (filterRecidList.contains("560")) {

			for (CompletionProviderTask completionProviderTask : completionMainTask.getCploss_560()) {

				if (completionProviderTask.getComp_dt_attr().contains("U")) {
					completionProviderTask.setComp_dt_attr("Y");
				}
				if (completionProviderTask.getCompany_code_attr().contains("U")) {
					completionProviderTask.setCompany_code_attr("Y");
				}

				dataString = completionProviderTask.getCompletionWithLoss560String();

				subHeader = prepareIssueSubHeader(RecIdFor12State.CS_RECID_COMPLETE.getRecIdValue(),ProcessMode.CS_UPDATE.getProcessModeCode());
				subHeaderandData
						.append(mqMessageStringBuilder.appendSubHeaderAndData(subHeader, dataString.toString()));
			}
		}

		System.out.println(updateList_568.toString() + " <- Edit Order Table");

		if (filterRecidList.contains("568")) {

			for (CompletionActivityRLSOG6LscInfo completionActivityRLSOG6LscInfo_new : updateList_568) {

				if (completionActivityRLSOG6LscInfo_new.getApptime_attr().contains("U")) {
					completionActivityRLSOG6LscInfo_new.setApptime_attr("Y");
				}
				if (completionActivityRLSOG6LscInfo_new.getOrd_attr().contains("U")) {
					completionActivityRLSOG6LscInfo_new.setOrd_attr("Y");
				}
				if (completionActivityRLSOG6LscInfo_new.getFdt_attr().contains("U")) {
					completionActivityRLSOG6LscInfo_new.setFdt_attr("Y");
				}
				if (completionActivityRLSOG6LscInfo_new.getDd_attr().contains("U")) {
					completionActivityRLSOG6LscInfo_new.setDd_attr("Y");
				}
				if (completionActivityRLSOG6LscInfo_new.getComp_dt_attr().contains("U")) {
					completionActivityRLSOG6LscInfo_new.setComp_dt_attr("Y");
				}

				completionActivityRLSOG6LscInfo_new.setApptime_attr("R");
				dataString = completionActivityRLSOG6LscInfo_new.getCompletionWithLoss568String();
				System.out.println("Data String For : Completion Task_RecId_568 is" + dataString);

				subHeader = prepareIssueSubHeader(RecIdFor12State.CS_RECID_COMPLETE_REQORD.getRecIdValue(),ProcessMode.CS_UPDATE.getProcessModeCode());
				subHeaderandData
						.append(mqMessageStringBuilder.appendSubHeaderAndData(subHeader, dataString.toString()));
			}
			
			for (int i= old_list_568.size();i<List_568.size();i++) {
				
				CompletionActivityRLSOG6LscInfo newRow= List_568.get(i);
				if(newRow.getOrd()!=null && newRow.getOrd()!="") {
				newRow.setOrd_attr("Y");
				newRow.setFdt_attr("N");
				newRow.setDd_attr("N");
				newRow.setComp_dt_attr("Y");
				newRow.setPosted_date_attr("N");
				newRow.setApptime_attr("N");
				
				dataString = newRow.getCompletionWithLoss568String();
				System.out.println("New Row : Data String For : Completion Task_RecId_568 is" + dataString);

				subHeader = prepareIssueSubHeader(RecIdFor12State.CS_RECID_COMPLETE_REQORD.getRecIdValue(),ProcessMode.CS_ADD.getProcessModeCode());
				subHeaderandData
						.append(mqMessageStringBuilder.appendSubHeaderAndData(subHeader, dataString.toString()));
				
				}
			}
		}

		if (!completionMainTask.getCploss_578().isEmpty()) {
			for (CompletionProviderLoss_578 completionProviderLoss_578 : completionMainTask.getCploss_578()) {

				completionProviderLoss_578.setNumname_attr("Y");
				completionProviderLoss_578.setNumnbr_attr("Y");
				completionProviderLoss_578.setCvd_attr("Y");
				completionProviderLoss_578.setWtn_attr("Y");
				completionProviderLoss_578.setEcckt_attr("Y");

				dataString = completionProviderLoss_578.getCompletionProviderTask578();
				System.out.println("Data String For : Completion Task_RecId_578 is" + dataString);

				subHeader = prepareIssueSubHeader1(RecIdFor12State.CS_RECID_LOSS_INFO.getRecIdValue());
				subHeaderandData
						.append(mqMessageStringBuilder.appendSubHeaderAndData(subHeader, dataString.toString()));
			}
		}

		String mqMessageString = mqMessageStringBuilder.getMqMessageString();
		//boolean isWritten= false;

		/*session.setAttribute("info_msg_574", "");
		session.setAttribute("cc_info_msg_574", "");
		session.setAttribute("info_msg_cploss", "");
		session.setAttribute("err_msg_cploss", "");*/
		
		System.out.println("MQ INPUT STRING FOR CP/TWL-> \n"+mqMessageString);
		boolean isWritten = mqWriteUtil.writeDataToMQString(mqMessageString, session);
		String rc= "";
		
		if (isWritten) {

			MQReceivedData mqReceivedData=null;
			
			try {

			mqReceivedData = mqReadUtil.readSortDataFromMQ(session); 
			 long endTime = System.nanoTime() + TimeUnit.NANOSECONDS.convert(3L, TimeUnit.MINUTES); 
			  Map<String, SubData> subDatas = mqReceivedData.getSubDatas(); 
		//	  Header receivedHeader = mqReceivedData.getHeader(); 
			  while(mqReceivedData.getHeader()==null&& System.nanoTime() < endTime) { 
					System.out.println("*************inside if*************** "); 
					mqReceivedData =	 mqReadUtil.readSortDataFromMQ(session); 
				} 
			  
			  
			  System.out.println(mqReceivedData.getHeader().toString()); 
		} catch (Exception e) { 
			// TODO Auto-generated catch block 
			// mqReceivedData = mqReadUtil.readDataFromMQ(session); 
			e.printStackTrace(); 


		}
			System.out.println("::::::mqReceivedData for::::" + mqReceivedData);
			Map<String, SubData> subDatas = mqReceivedData.getSubDatas();
			Header receivedHeader = mqReceivedData.getHeader();
			if(receivedHeader == null)
			{
				receivedHeader = new Header();
				receivedHeader.setReturn_code("555");
			}
			completionMainTask.setHeader(receivedHeader);
			SubData subData = subDatas.get(RecIdFor12State.CS_RECID_ERROR.getRecIdValue());
			SubData subData_560 = subDatas.get(RecIdFor12State.CS_RECID_COMPLETE.getRecIdValue());
			
			ReadErrorMsgsJson readErrorMsgsJson = new ReadErrorMsgsJson();
			ShowErrorService showErrorService = new ShowErrorService();
			if(showUpdateErrorList != null)
			{
				showUpdateErrorList.clear();
			}
			
			if (receivedHeader.getReturn_code() != null && receivedHeader.getReturn_code().equals("000")) {

				String err_msgc = readErrorMsgsJson.getErrorMsg("LG0016");
				session.setAttribute("info_msg_cploss", err_msgc);
				String error_msg= "Y";
				session.setAttribute("error", error_msg);
				rc= "000";
			}
			
			if (receivedHeader.getReturn_code() != null && receivedHeader.getReturn_code().equals("999")) {

			if (subData != null) {
				String[] subDataRows = subData.getSubDataRows();

				for (String subDataRow : subDataRows) {
						String[] attributes = mqReadUtil.getAttributes(subDataRow, 4);
						showUpdateErrorList = showErrorService.getShowErrorList(attributes[0], attributes[2], "",
								"U", showUpdateErrorList);

				}
			}
			
			if (subData_560 != null) {
				String[] subDataRows = subData_560.getSubDataRows();

				for (String subDataRow : subDataRows) {
					System.out.println("Sub data row is: "+subDataRow.toString());
						String[] attributes = mqReadUtil.getAttributes(subDataRow, 4);
						//For greater LSR versions exist error message
						if(attributes[0].equals("LG0118"))
						{
							String lsr_no = (String) session.getAttribute("Lrs_No");
							showUpdateErrorList = showErrorService.getShowErrorList(attributes[0], attributes[2], lsr_no, "", showUpdateErrorList);
						}
						else{
							showUpdateErrorList = showErrorService.getShowErrorList(attributes[0], attributes[2], "","U", showUpdateErrorList);
						}
					}
			}
			
			session.setAttribute("showError", showUpdateErrorList);

			String err_msgc = readErrorMsgsJson.getErrorMsg("LG0017");
			session.setAttribute("err_msg_cploss", err_msgc);
			rc = "999";

		}
			
		if (receivedHeader.getReturn_code() != null && receivedHeader.getReturn_code().equals("888")) {
			String err_msgc = readErrorMsgsJson.getErrorMsg("LG0022");
			session.setAttribute("info_msg_cploss", err_msgc);
		}
			
		if (receivedHeader.getReturn_code() != null && receivedHeader.getReturn_code().equals("889")) {
			String err_msgc = readErrorMsgsJson.getErrorMsg("LG0067");
			session.setAttribute("info_msg_cploss", err_msgc);
		}
		
		if (receivedHeader.getReturn_code() != null && receivedHeader.getReturn_code().equals("555")) {
			String err_msgc = readErrorMsgsJson.getErrorMsg("LG0001");
			session.setAttribute("info_msg_cploss", err_msgc);
		}

	}
	return rc;

}

       private int getUpdatedCount(List<CompletionActivityRLSOG6LscInfo> list_568, int size) {
    	   int rowsCount = 0;
    	   		for (int i = size; i < list_568.size(); i++) {
                     if (list_568.get(i).getOrd() != null && list_568.get(i).getOrd() != "") {
    	   				rowsCount++;
    	   			}
    	   		}
    	   	return rowsCount;
    	  }

	public List<ShowError> getUpdatedErrorList() {
		return showUpdateErrorList;
	}

	private Header prepareIssueHeader(String user_id, String object_handle, String numCount) {
		// Prepare Header
		Header header = new Header();

		header.setUser_id(user_id);
		header.setProcess(Process.CS_REQUEST.getProcessCode());
		header.setTab_ind(TabInd.ISSUE_CPL.getTabIndCode());
		header.setProcess_group_ind(ProcessGroupInd.ISSUE_IND.getProcessGroupInd());
		header.setObject_handle(object_handle);
		header.setObject_handle2(null);
		header.setLog_ind(LogInd.N.name());
		header.setStarttime(null);
		header.setEndtime(null);
		header.setGuid(null);
		header.setSession_trans_count("0000001");
		header.setHost_trans_seq(null);
		header.setReturn_code(null);
		header.setRead_only_ind(null);
		header.setNum_detail(numCount);
		header.setRead_only_user_id(null);
		header.setLasrversion(null);

		return header;
	}

	private SubHeader prepareIssueSubHeader(String recId, String processMode) {

		// Prepare SubHeader
		SubHeader subHeader = new SubHeader();

		subHeader.setLast_ind(LastInd.Y.name());
		subHeader.setProcess_mode(processMode);
		subHeader.setRecord_type(recId);
		subHeader.setReturn_code(null);
		subHeader.setDw_rownum(null);
		subHeader.setEcver(null);

		return subHeader;
	}

	private SubHeader prepareIssueSubHeader1(String recId) {

		// Prepare SubHeader
		SubHeader subHeader = new SubHeader();

		subHeader.setLast_ind(LastInd.Y.name());
		subHeader.setProcess_mode(ProcessMode.CS_ADD.getProcessModeCode());
		subHeader.setRecord_type(recId);
		subHeader.setReturn_code(null);
		subHeader.setDw_rownum(null);
		subHeader.setEcver(null);

		return subHeader;
	}

	public List<CompletionActivityRLSOG6LscInfo> getUpdatedRows(List<CompletionActivityRLSOG6LscInfo> newList,
			List<CompletionActivityRLSOG6LscInfo> oldList) {

		List<CompletionActivityRLSOG6LscInfo> updatedList = new ArrayList<CompletionActivityRLSOG6LscInfo>();
		for (int i = 0; i < oldList.size(); i++) {
			CompletionActivityRLSOG6LscInfo tableRow = newList.get(i);
			if (!tableRow.getOrd().equalsIgnoreCase(oldList.get(i).getOrd())
					|| !tableRow.getComp_dt().equalsIgnoreCase(oldList.get(i).getComp_dt())) {

				if (tableRow.getOrd().equalsIgnoreCase(oldList.get(i).getOrd())) {
					tableRow.setOrd_attr("N");
				} else {
					tableRow.setOld_ord(oldList.get(i).getOrd());
				}

				if (tableRow.getComp_dt().equalsIgnoreCase(oldList.get(i).getComp_dt())) {
					tableRow.setComp_dt_attr("N");
				}
				updatedList.add(tableRow);
			}

		}
		
		return updatedList;
	}
}
