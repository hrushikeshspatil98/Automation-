/*
Created By Hrushikesh -
	Below code refers to Copy Rec (Copy Rec Button in Toolbar) Fuctionality 
*/

var copyOrd = "";
var ordColIndex = -1;
var copyOrdl = "";
var ordlColIndex = -1;
var copyNpord = "";
var npordColIndex = -1;
var dlordColIndex = -1;
var copyDd = "";
var ddColIndex = -1;
var copyFdt = "";
var fdtColIndex = -1;
var cvdColIndex = -1;
var copyCvd = "";


var startIndex = -1;
var endIndex = -1;

const setRowAndColumnIndex = (index,ordIndex=-1,ordlIndex=-1,npordIndex=-1,ddIndex=-1,fdtIndex=-1,dlordIndex=-1) => {
	console.log("Selected Row Index: "+index);
	var table;
	if (localStorage.getItem("name") == "completionProviderWithLoss") {
		table = document.getElementById("loss_info_tbody");
		index= index.parentNode.parentElement.rowIndex -1;
		cvdColIndex = 1;
	}
	else {
		table = document.getElementById("copyRecTable");
	}
	
	if(startIndex != -1 && endIndex != -1)
	{
		startIndex = -1;
		endIndex = -1;
	}
	
	var dataTr = table.rows;
	if (dataTr[index].children[0].children[0].checked == true) {
		
		ordColIndex = ordIndex;
		ordlColIndex = ordlIndex;
		npordColIndex = npordIndex;
		ddColIndex = ddIndex;
		fdtColIndex = fdtIndex;
		dlordColIndex = dlordIndex;
		
		for (var i = 0; i < dataTr.length; i++) {
			var tr = dataTr[i];
			var child = tr.children[0].children[0];
			if (startIndex == -1) {
				if (child.checked == true) {
					startIndex = index;
					console.log("Start Index" + startIndex);
					break;
				}

			}
			else {
				if (startIndex != -1 && endIndex == -1) {
					if (child.checked == true) {
						endIndex = index;
						console.log("End Index" + endIndex);
						break;
					}
				}
			}
		}
	}
	
	if (dataTr[index].children[0].children[0].checked == false) {
		if(index == startIndex)
			startIndex = -1;
		if(index == endIndex)
			endIndex = -1;
	}
	

}

const selectAllRows = (ordIndex=-1,ordlIndex=-1,npordIndex=-1,ddIndex=-1,fdtIndex=-1,dlordIndex=-1) =>
{
	ordColIndex = ordIndex;
	ordlColIndex = ordlIndex;
	npordColIndex = npordIndex;
	ddColIndex = ddIndex;
	fdtColIndex = fdtIndex;
	dlordColIndex = dlordIndex;
		
	var table;
	if (localStorage.getItem("name") == "completionProviderWithLoss") {
		table = document.getElementById("loss_info_tbody");
		cvdColIndex = 1;
	}
	else {
		table = document.getElementById("copyRecTable");
	}
	var dataTr = table.rows;
	if (document.getElementById("selectAll").checked == true) {
		if(endIndex == -1)
		{
			endIndex =startIndex;
		}
		if(startIndex == -1 && endIndex == -1){
			startIndex = 0;
			endIndex = dataTr.length;
		}
		
		//If last index is less than first index
		var idx = startIndex;
		if(endIndex < startIndex)
		{
			startIndex = endIndex;
			endIndex = idx;
		}
		
		console.log("All Selected Rows: "+startIndex+"->"+endIndex);
		for(var i=startIndex;i<endIndex;i++)
		{
			var tr = dataTr[i];
			tr.children[0].children[0].checked = true;
		}
	}
	
	startIndex = -1;
	endIndex =-1;
	document.getElementById("selectAll").checked = false;
}

const pasteRecordIntoSelectedRows = () => {

	copyOrd = document.getElementById('copy_ord') == null ? '' : document.getElementById('copy_ord').value;
	copyOrdl = document.getElementById('copy_ordl') == null ? '' : document.getElementById('copy_ordl').value;
	copyNpord = document.getElementById('copy_npord') == null ? '' : document.getElementById('copy_npord').value;
	copyDd = document.getElementById('copy_dd') == null ? '' : document.getElementById('copy_dd').value;
	copyFdt = document.getElementById('copy_fdt') == null ? '' : document.getElementById('copy_fdt').value;
	copyCvd = document.getElementById('copy_cvd') == null ? '' : document.getElementById('copy_cvd').value;
	
	var table;
	if (localStorage.getItem("name") == "completionProviderWithLoss") {
		table = document.getElementById("loss_info_tbody");
	}
	else {
		table = document.getElementById("copyRecTable");
	}
	var dataTr = table.rows;
	
	var checkedList = getSelectedRowsIndex(dataTr);
	
	if(checkedList.length == 0)
	{
		var errMsg = getErrorMsg(jsonData.LG0010) == null ? "" : getErrorMsg(jsonData.LG0010);
		alert("Error : "+errMsg);
		return;
	}
	
	
	if (copyOrd != "" && copyOrd != null) {
	
		for(var i in checkedList)
		{
			var tr = dataTr[checkedList[i]];
			var child = tr.children[ordColIndex].children[0];
			if (child.readOnly == false)
				child.value = copyOrd;
		}
	}
	
	if (copyOrdl != "" && copyOrdl != null && dlordColIndex!=-1) {
	
		for(var i in checkedList)
		{
			var tr = dataTr[checkedList[i]];
			var child = tr.children[dlordColIndex].children[0];
			if (child.readOnly == false)
				child.value = copyOrdl;
		}
	}

	if (copyOrdl != "" && copyOrdl != null) {

		for(var i in checkedList)
		{
			var tr = dataTr[checkedList[i]];
			var child = tr.children[ordlColIndex].children[0];
			if (child.readOnly == false){
				child.value = copyOrdl;
			}
		}
	}

	if (copyNpord != "" && copyNpord != null) {

		for(var i in checkedList){
			var tr = dataTr[checkedList[i]];
			var child = tr.children[npordColIndex].children[0];
			if (child.readOnly == false)
				child.value = copyNpord;
		}
	}

	if (ddColIndex != -1) {

		for(var i in checkedList){
			var tr = dataTr[checkedList[i]];
			var child = tr.children[ddColIndex].children[0];
			if (child.readOnly == false)
				child.value = copyDd;
		}
	}

	if (copyFdt != "" && copyFdt != null) {

		for(var i in checkedList){
			var tr = dataTr[checkedList[i]];
			var child = tr.children[fdtColIndex].children[0];
			if (child.readOnly == false)
				child.value = copyFdt;
		}
	}
	
	if (cvdColIndex != -1) {

		for(var i in checkedList){
			var tr = dataTr[checkedList[i]];
			var child = tr.children[1].children[0];
			if (child.readOnly == false)
				child.value = copyCvd;
		}
	}
	
	
	
	for (var i in checkedList) {
		var child = dataTr[checkedList[i]].children[0].children[0];
		if (child.checked == true)
			child.checked = false;
	}
		
	if(document.getElementById("selectAll").checked == true)
	{
		document.getElementById("selectAll").checked = false;
	}
	startIndex= -1;
	endIndex =-1;
	

}
const getSelectedRowsIndex = (rows) =>
{
	var checkedList = [];
	for(var i=0; i<rows.length; i++)
	{
		if(rows[i].children[0].children[0].checked == true)
		{
			checkedList.push(i);
		}
	}
	return checkedList;
	
}
