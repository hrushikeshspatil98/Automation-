/*
*   Created By Hrushikesh -
*	Below code refers to Copy Ord Fuctionality (In Edit Order Table) 
*/
//Note : FDT,DD and CD data will copy if its empty or non empty
var copy_Dd = "", ddColumnIndex;
var copy_Fdt = "", fdtColumnIndex;
var copy_Cd = "", cdColumnIndex;


var firstIndex = -1;
var lastIndex = -1;
var rowIndex = -1;

const highlightSelectedRow= (index) =>
{
	var tableRows= document.getElementById("editOrderTable").rows;
	if(rowIndex != -1)
	{
		tableRows[rowIndex].style.backgroundColor = '';
	}
	rowIndex = index;
	console.log("Selected Row Index: "+index);
	
	tableRows[rowIndex].style.backgroundColor = 'skyblue';
}


const selectRecord = (ddColumnIdx = -1, fdtColumnIdx = -1, cdColumnIdx = -1) => {
	
	var tableRows = document.getElementById("editOrderTable").rows;
	
	ddColumnIndex = ddColumnIdx;
	fdtColumnIndex = fdtColumnIdx;
	cdColumnIndex = cdColumnIdx;
	
	if(ddColumnIndex != -1)
		copy_Dd = tableRows[rowIndex].children[ddColumnIndex].children[0].value;
	if(fdtColumnIndex != -1)
		copy_Fdt = tableRows[rowIndex].children[fdtColumnIndex].children[0].value;
	if(cdColumnIndex != -1)
		copy_Cd = tableRows[rowIndex].children[cdColumnIndex].children[0].value;
	
	firstIndex = -1;
	lastIndex =-1;
	
	document.getElementById("copy_ord_btn").disabled = '';
	

}

const selectAllEditOrderRows = () =>
{
	var tableRows = document.getElementById("editOrderTable").rows;
	if (document.getElementById("selectAllRec").checked == true) {
		
		if(firstIndex == -1 && lastIndex == -1){
			firstIndex = 0;
			lastIndex = tableRows.length;
		}
		
		//If last index is less than first index
		var idx = firstIndex;
		if(lastIndex < firstIndex)
		{
			firstIndex = lastIndex;
			lastIndex = idx;
		}
		
		console.log("All Selected Rows: "+firstIndex+"->"+lastIndex);
		for(var i=firstIndex;i<lastIndex;i++)
		{
			tableRows[i].children[14].children[0].checked = true;
		}
	}
	
	firstIndex = -1;
	lastIndex =-1;
	document.getElementById("selectAllRec").checked = false;

}

const copyRecordIntoSelectedRows = () =>
{
	
	var tableRows= document.getElementById("editOrderTable").rows;
	var checkedList = getSelectedEditRowsIndex(tableRows);
	
	if(checkedList.length == 0)
	{
		var errMsg = getErrorMsg(jsonData.LG0010) == null ? "" : getErrorMsg(jsonData.LG0010);
		alert("Error : "+errMsg);
		return;
	}
	
	for(var i in checkedList)
		{
			var child;
			var tr = tableRows[checkedList[i]];
			
			if(ddColumnIndex != -1)
			{
				child = tr.children[ddColumnIndex].children[0];
				if (child.readOnly == false)
					child.value = copy_Dd;
			}
			if(fdtColumnIndex != -1)
			{
				child = tr.children[fdtColumnIndex].children[0];
				if (child.readOnly == false)
					child.value = copy_Fdt;
			}
			if(cdColumnIndex != -1)
			{
				child = tr.children[cdColumnIndex].children[0];
				if (child.readOnly == false)
					child.value = copy_Cd;
			}
			
			tableRows[checkedList[i]].children[14].children[0].checked = false;
		}
		
		
		firstIndex = -1;
		lastIndex = -1;
		tableRows[rowIndex].style.backgroundColor = '';
		document.getElementById("copy_ord_btn").disabled = true;
}

const getSelectedEditRowsIndex = (rows) =>
{
	var checkedList = [];
	for(var i=0; i<rows.length; i++)
	{
		if(rows[i].children[14].children[0].checked == true)
		{
			checkedList.push(i);
		}
	}
	return checkedList;
	
}

const setFirstAndlastIndex = (index) =>
{
	console.log("Selected Row Index: "+index);
	var tableRows= document.getElementById("editOrderTable").rows;
	if((firstIndex != -1 && lastIndex != -1))
	{
		firstIndex = -1;
		lastIndex = -1;
	}
	if (tableRows[index].children[14].children[0].checked == true) {
		
		for (var i = 0; i < tableRows.length; i++) {
			var child = tableRows[i].children[14].children[0];
			if (firstIndex == -1) {
				if (child.checked == true) {
					firstIndex = index;
					console.log("First Index" + firstIndex);
					break;
				}

			}
			else {
				if (firstIndex != -1 && lastIndex == -1) {
					if (child.checked == true) {
						lastIndex = index;
						console.log("Last Index" + lastIndex);
						break;
					}
				}
			}
		}
	}
	if (tableRows[index].children[14].children[0].checked == false) {
		if(index == firstIndex)
			firstIndex = -1;
		if(index == lastIndex)
			lastIndex = -1;
	}
	
}