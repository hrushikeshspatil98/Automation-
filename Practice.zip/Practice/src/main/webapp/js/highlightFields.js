/*
Created By Hrushikesh -
	Below code refers to Highlighting of fields on SUP 
*/

const highlightFields = (data,currCount) =>
{
	
	let keys= getKeys(data);
	
	for(let attr of keys)
	{
		let attrValue = data.get(currCount).get(attr);
		
		if(attrValue == null || attrValue == undefined)
		{
			attrValue = "";
		}
		
		if(attrValue == 'E' || attrValue == 'W' || attrValue == 'V' || attrValue == 'C')
		{
			document.getElementById(attr).style.backgroundColor = "cyan";
		}
		else
		{
			document.getElementById(attr).style.backgroundColor = "#C0C0C0";
		}
	}
		
}

//Returns all keys in the page
const getKeys = (data) => data.get(0).keys();
