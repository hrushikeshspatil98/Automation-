$('form').each(function() {
	//added a validation method to check for alphanumeric along with ._
	jQuery.validator.addMethod("alphanumeric", function(value, element) {
		return this.optional(element) || /^[\w.]+$/i.test(value);
	});
	//added a validation method to check date format as dd/mm/yyyy
	jQuery.validator.addMethod("dateFormat", function(value, element) {
		//return value.match(/^(0?[1-9]|[12][0-9]|3[0-1])[/., -](0?[1-9]|1[0-2])[/., -](19|20)?\d{2}$/);
		return value.match(/^(0?[1-9]|1[0-2])[/](0?[1-9]|[12][0-9]|3[0-1])[/](19|20)?\d{2}$/);
	});
	//alphanumeric validation accepting hyphen(-) and period(.)
	jQuery.validator.addMethod("alphanumPeriodHyphen", function(value, element) {
		return value.match("^[a-zA-Z0-9.-]*$");
	});
	//alphanumeric validation accepting hyphen(-)
	jQuery.validator.addMethod("alphanumHyphen", function(value, element) {
		return value.match("^[a-zA-Z0-9-]*$");
	});
	//alphanumeric validation not accepting single quote(')
	jQuery.validator.addMethod("alphanumQuote", function(value, element) {
		return value.match("^[^']*$");
	});
	jQuery.validator.addMethod("twostring", function(value, element) {
		return value.match("([A-Za-z]+),\\s*([A-Za-z]+)\\s*([A-Za-z]+)");
	});
	jQuery.validator.addMethod("validateAmPm", function(value, element) {
		return value.match("^([AP]M$)");
	});


	//loads data in JSON file to data object
	$.get("errorMsgs.json", function(data) {
	
		//Returns Error message
		function getErrorMsg(errCode, fieldName = "", substitute = "") {

			var errMsg = errCode.Message;

			if (errMsg.includes("%FIELD_NAME%")) 
			{
				errMsg = errMsg.replace("%FIELD_NAME%", fieldName);
			}

			if (errMsg.includes("%LENGTH%"))
			{
				errMsg = errMsg.replace("%LENGTH%", substitute);
			}

			if (errMsg.includes("%FORMAT%")) 
			{
				errMsg = errMsg.replace("%FORMAT%", substitute);
			}

			return errMsg;
		}



		//Initialize form validation on respective JSP Form		  
		$("form[name='enhancedSelReqForm']").validate({
			rules: {
				company_code: {
					minlength: 4,
					alphanumeric: true
				},
				nc: {
					minlength: 4,
					alphanumHyphen: true
				},
				nci: {
					minlength: 5,
					alphanumPeriodHyphen: true
				},
			},
			messages: {
				company_code: {
					minlength: getErrorMsg(data.LG0007,"Company Code","4"),
					alphanumeric: getErrorMsg(data.LG0065,"Company Code")
				},
				nc: {
					minlength: getErrorMsg(data.LG0290),
					alphanumHyphen: getErrorMsg(data.LG0290)
				},
				nci: {
					minlength: getErrorMsg(data.LG0289),
					alphanumPeriodHyphen: getErrorMsg(data.LG0289)
				},
			},
			errorPlacement: function(error, element) {
				if (element.attr("name") == "company_code") {
					error.insertAfter("#companycodeerr");
				}
				else if (element.attr("name") == "nc") {
					error.insertAfter("#ncerr");
				}
				else if (element.attr("name") == "nci") {
					error.insertAfter("#ncierr");
				}
			},
			submitHandler: function(form) {
				form.submit();
			}
		});

		$("form[name='confirmedByDDESDD']").validate({
			rules: {
				company_code: {
					minlength: 4,
					alphanumeric: true,
					required: true
				},
				begindate: {
					required: function(){
						return ($("input[name='company_code']").val()!="" );
					}
				}
			},
			messages: {
				company_code: {
					minlength: getErrorMsg(data.LG0007,"Company Code","4"),
					alphanumeric: getErrorMsg(data.LG0065,"Company Code"),
					required: getErrorMsg(data.LG0006,"Company Code")
				},
				begindate: {
					required: getErrorMsg(data.LG0128)
				}
			},
			errorPlacement: function(error, element) {
				if (element.attr("name") == "company_code") {
					error.insertAfter("#companycodeerr");
				}
				if (element.attr("name") == "begindate") {
					error.insertAfter("#begindateerr");
				}
			},
			submitHandler: function(form) {
				form.submit();
			}
		});
		
		$("form[name='fup_req']").validate({
			rules: {
				company_code: {
					minlength: 4,
					alphanumeric: true
				}
			},
			messages: {
				company_code: {
					minlength: getErrorMsg(data.LG0007,"Company Code","4"),
					alphanumeric: getErrorMsg(data.LG0065,"Company Code")
				}
			},
			errorPlacement: function(error, element) {
				if (element.attr("name") == "company_code") {
					error.insertAfter("#companycodeerr");
				}
			},
			submitHandler: function(form) {
				form.submit();
			}
		});

		$("form[name='workload']").validate({
		
		// validation rules
			rules: {
							 
				sm_time : {
				  	number: true,
					min: 1,
					max: 12
						},

				sm_dttm_rcvd : {
					required:true
					   }		   
											
			},
			// show validation error messages
			messages: {
				 				 
					sm_time : {
						
						number: "Time must be numeric value",
						min: getErrorMsg(data.LG0265),
						max: getErrorMsg(data.LG0265)
						},
				   
				   sm_dttm_rcvd	: {
						required:getErrorMsg(data.LG0270)
						
						  }			 
								
				  			},
			
		errorPlacement: function(error, element) {
		 	
			
				 if (element.attr("name") == "sm_time") {
					error.insertAfter("#Sm_timeErr");
					}
					 
					
				 if (element.attr("name") == "sm_dttm_rcvd") {
					error.insertAfter("#Sm_DateErr");
									
					}
				

				 },
			
			submitHandler: function(form) {
				form.submit();
			}
		});
		
		$("form[name='selectRequest']").validate({
			rules: {
				company_code: {
					minlength: 4,
					required: true,
					alphanumeric: true
				},
				version: {
					minlength: 2,
					alphanumeric: true
				},
				date_received_begin_date: {
					required: function(){
						return $("input[name='date_received_end_date']").val()!="";
					}
				},
				rpon: {
      				required: function(){
						return $("input[name='company_code']").val()!="";
					}
				},
				request_id: {
					required: function(){
						return $("input[name='version']").val()!=""; 
						},
					minlength: 14,
					alphanumeric: true
				}
			},
			messages: {
				company_code: {
					required: getErrorMsg(data.LG0006,"Company Code"),
					minlength: getErrorMsg(data.LG0007,"Company Code","4"),
					alphanumeric: getErrorMsg(data.LG0065,"Company Code")
				},
				rpon: {
					required: getErrorMsg(data.LG0002)
				},
				date_received_begin_date: {
					required: getErrorMsg(data.LG0006,"Date Received Begin Date")
				},
				version: {
					minlength: getErrorMsg(data.LG0007,"Version","2"),
					alphanumeric: getErrorMsg(data.LG0065,"Version")
				},
				request_id: {
					required: getErrorMsg(data.LG0006,"LSR No"),
					minlength:  getErrorMsg(data.LG0007,"LSR NO","14"),
					alphanumeric: getErrorMsg(data.LG0065,"LSR NO")
				}
			},
			errorPlacement: function(error, element) {
				if (element.attr("name") == "company_code") {
					error.insertAfter("#companycodeerr");
				}
				if (element.attr("name") == "version") {
					error.insertAfter("#versionerr");
				}
				if (element.attr("name") == "pon") {
					 error.insertAfter("#commonMsg"); 
				}
				if (element.attr("name") == "date_received_begin_date") {
					 error.insertAfter("#bderr"); 
				}
				if (element.attr("name") == "rpon") {
					error.insertAfter("#commonMsg");  
				}
				if (element.attr("name") == "project") {
					error.insertAfter("#projecterr");  
					/* alert(error.text()); */
				}
				if (element.attr("name") == "request_id") {
					error.insertAfter("#lsrnoerr");
				} 
			},
			submitHandler: function(form) {
				form.submit();
			}
	});
	
	
	/*	$("form[name='userprofile1']").validate({
			// Specify validation rules
			rules: {
				user_id: {
					required: true,
					minlength: 4,
					alphanumeric: true
				},
				name: {
					required: true,
					twostring: true
				},
				user_type: {
					required: true
				},
				telephone_number: {
					required: true
				},
				typist_id: {
					alphanumeric: true
				},
				sales_code: {
					alphanumeric: true
				}
			},
			// Specify validation error messages
			messages: {
				user_id: {
					required: getErrorMsg(data.LG0006,"User ID"),
					minlength: getErrorMsg(data.LG0007,"User ID","4 to 7"),
					alphanumeric: getErrorMsg(data.LG0065,"User ID")
				},
				name: {
					required: getErrorMsg(data.LG0006,"Name"),
					twostring: getErrorMsg(data.LG0009,"Name","Lastname, Firstname")
				},
				user_type: {
					required: getErrorMsg(data.LG0006,"User Type")
				},
				telephone_number: {
					required: getErrorMsg(data.LG0006,"Telephone Number")
				},
				typist_id: {
					alphanumeric: getErrorMsg(data.LG0065,"Typist Id")
				},
				sales_code: {
					alphanumeric: getErrorMsg(data.LG0065,"Sales Code")
				}
			},
			errorPlacement: function(error, element) {
				if (element.attr("name") == "name") {
					error.insertAfter("#name_err");
				}
				else if (element.attr("name") == "user_id") {
					error.insertAfter("#userid_err");
				}
				else if (element.attr("name") == "user_type") {
					error.insertAfter("#usertype_err");
				}
				else if (element.attr("name") == "telephone_number") {
					error.insertAfter("#telephone_err");
				}
				else if (element.attr("name") == "typist_id") {
					error.insertAfter("#typistid_err");
				}
				else if (element.attr("name") == "sales_code") {
					error.insertAfter("#salescode_err");
				}
			},
			// Form is submitted after validation based on action attribute of form
			submitHandler: function(form) {
				form.submit();
			}
		});*/

		$("form[name='issueProviderForm']").validate({
			rules: {
				losing_cc: {
					required: true,
					minlength: 4,
					alphanumeric: true
				},
	
				lsr_no: {
					minlength: 14,
					alphanumeric: true
				}
			},
			messages: {
				losing_cc: {
					required:getErrorMsg(data.LG0006,"Losing CC"),
					minlength: getErrorMsg(data.LG0007,"Losing CC","4"),
					alphanumeric: getErrorMsg(data.LG0065,"Losing CC")
				},
	
				lsr_no: {
					minlength: getErrorMsg(data.LG0007,"LSR NO","14"),
					alphanumeric: getErrorMsg(data.LG0065,"LSR NO")
				}
	
			},
			errorPlacement: function(error, element) {
				if (element.attr("name") == "losing_cc") {					
					error.insertAfter("#losingCCErr1");
				}
	
				else if (element.attr("name") == "lsr_no") {					
					error.insertAfter("#lsrNoErr1");
				}
	
			},
			submitHandler: function(form) {
				form.submit();
			}
		});

		$("form[name='selectProviderForm']").validate({
			rules: {
				losing_cc: {
					required: true,
					minlength: 4,
					alphanumeric: true
				}
			},
			messages: {
				losing_cc: {
					required: getErrorMsg(data.LG0006,"Losing CC"),
					minlength: getErrorMsg(data.LG0007,"Losing CC","4"),
					alphanumeric: getErrorMsg(data.LG0065,"Losing CC")
				}
	
			},
			errorPlacement: function(error, element) {
				if (element.attr("name") == "losing_cc") {
					error.insertAfter("#losingCCErr");
				}
	
			},
			submitHandler: function(form) {
				form.submit();
			}
		});
		
		
		$("form[name='restrictedMismatchData12states']").validate({
			rules: {
				company_code: {
					minlength: 4,
					alphanumeric: true
				},
				request_id: {
					minlength: 14,
					alphanumeric: true
				},
				
	
				version: {
					minlength: 2,
					alphanumeric: true
				},
				pon: {
					alphanumQuote: true
				}
			},
			messages: {
				company_code: {
					minlength: getErrorMsg(data.LG0007,"Company Code","4"),
					alphanumeric: getErrorMsg(data.LG0065,"Company Code")
				},
				request_id: {
					minlength: getErrorMsg(data.LG0007,"LSR NO","14"),
					alphanumeric: getErrorMsg(data.LG0065,"LSR NO")
				},
				version: {
					minlength: getErrorMsg(data.LG0007,"Version","2"),
					alphanumeric: getErrorMsg(data.LG0065,"Version")
				},
				pon: {
					alphanumQuote: getErrorMsg(data.LG0065,"PON")
				}
	
			},
			errorPlacement: function(error, element) {
				if (element.attr("name") == "company_code") {
					error.insertAfter("#companycodeerr");
				}
				else if (element.attr("name") == "request_id") {
					error.insertAfter("#lsrerr");
				}
				else if (element.attr("name") == "version") {
					error.insertAfter("#vererr");
				}
				else if (element.attr("name") == "pon") {
					error.insertAfter("#ponerr");
				}
			},
			submitHandler: function(form) {
				form.submit();
			}
		});

		$("form[name='unrestrictedMismatchData12states']").validate({
			rules: {
				company_code: {
					minlength: 4,
					alphanumeric: true
				},
				request_id: {
					required: true,
					minlength: 14,
					alphanumeric: true
				},
	
				lasr_version: {
					minlength: 2,
					alphanumeric: true
				},
				pon: {
					alphanumQuote: true
				}
			},
			messages: {
				company_code: {
					minlength: getErrorMsg(data.LG0007,"Company Code","4"),
					alphanumeric: getErrorMsg(data.LG0065,"Company Code")
				},
				
				request_id: {
					required: getErrorMsg(data.LG0006,"LSR No"),
					minlength:  getErrorMsg(data.LG0007,"LSR NO","14"),
					alphanumeric: getErrorMsg(data.LG0065,"LSR NO")
				},
				lasr_version: {
					minlength: getErrorMsg(data.LG0007,"Version","2"),
					alphanumeric: getErrorMsg(data.LG0065,"Version")
				},
				pon: {
					alphanumQuote: getErrorMsg(data.LG0065,"PON")
				}
	
			},
			errorPlacement: function(error, element) {
				if (element.attr("name") == "company_code") {
					error.insertAfter("#companycodeerr");
				}
				else if (element.attr("name") == "request_id") {
					error.insertAfter("#lsrerr");
				}
				else if (element.attr("name") == "lasr_version") {
					error.insertAfter("#vererr");
				}
				else if (element.attr("name") == "pon") {
					error.insertAfter("#ponerr");
				}
			},
			submitHandler: function(form) {
				form.submit();
			}
		});
		
		$("form[name='follow_Up12']").validate({
		
			rules: {
				notes: {
					required:  function (element) {
if(($("#worked_ind").is(':checked'))||($("#cancel_ind").is(':checked'))){

return false;
}
else
{
return true;
}
}
					
				},
				follow_up_date: {
					required: function (element) {
if(($("#worked_ind").is(':checked'))||($("#cancel_ind").is(':checked'))){

return false;
}
else
{
return true;
}
}
				}
			},
			messages: {
				notes: {
					required: getErrorMsg(data.LG0123)
				},
				follow_up_date: {
					required: getErrorMsg(data.LG0006,"FUP DATE")
				}
		
			},
			errorPlacement: function(error, element) {
				if (element.attr("name") == "notes") {
					error.insertAfter("#noteserr");
				}
				if (element.attr("name") == "follow_up_date") {
					error.insertAfter("#follow_up_dateerr");
				}
		
			},
			submitHandler: function(form) {
				form.submit();
			}
		});
		
		$("form[name='follow_Up9']").validate({
			rules: {
				notes: {
					required: true
				},
				follow_up_date: {
					required: true
				}
			},
			messages: {
				notes: {
					required: getErrorMsg(data.LG0123)
				},
				follow_up_date: {
					required: getErrorMsg(data.LG0006,"FUP DATE")
				}
		
			},
			errorPlacement: function(error, element) {
				if (element.attr("name") == "notes") {
					error.insertAfter("#Noteserr");
				}
				if (element.attr("name") == "follow_up_date") {
					error.insertAfter("#follow_Up_dateerr");
				}
		
			},
			submitHandler: function(form) {
				form.submit();
			}
			
			});
			
			$("form[name='lossForm']").validate({                                               
			rules: {
				history_date: {
			      required: true
				} 
			},
			
			messages: {
	
				history_date: {
					required: getErrorMsg(data.LG0009,"History Date", "mm/dd/yyyy")
				}
	
			},
			errorPlacement: function(error, element) {
				
				 if (element.attr("name") == "history_date") {
					error.insertAfter("#history_dateErr");
				}
	
			},
			submitHandler: function(form) {
				form.submit();
			}
		});
		});
});