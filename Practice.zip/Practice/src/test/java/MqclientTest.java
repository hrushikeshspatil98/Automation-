/*
import com.ibm.mq.MQEnvironment;
import com.ibm.mq.MQException;
import com.ibm.mq.MQGetMessageOptions;
import com.ibm.mq.MQMessage;
import com.ibm.mq.MQQueue;
import com.ibm.mq.MQQueueManager;
import com.ibm.mq.constants.CMQC;

public class MqclientTest {
	
	private static String qMgr1 = "MQAA";
	private static String mqQ = "LASRQL.SL.LASRGUI.TO.LASRRT0";
	private static String channel  = "CL.LASR.MQAA";
	private static String hostName = "MVSMQAA.SBC.COM";
	private static int    port =1414;
	private static MQQueue m_queue = null;
	
	public static void main(String[] args) {
			mqConnection();
	}
	
public static boolean mqConnection()
{	boolean conn = false;
		   
			try {		   		
					
					
			   	MQEnvironment.hostname = hostName;
			   	MQEnvironment.channel  = channel;
			   	MQEnvironment.port     = port;
			
			   	MQQueueManager mqConfig= new MQQueueManager(qMgr1);	
						int openOptions =  CMQC.MQOO_INPUT_AS_Q_DEF + CMQC.MQOO_BROWSE + CMQC.MQOO_FAIL_IF_QUIESCING;
						m_queue = mqConfig.accessQueue(mqQ, openOptions);					
		   		
		   		if(m_queue.isOpen())
				conn = true;
				System.out.println("Connection successful : hostname: "+hostName +"   Q Manager ->"+ qMgr1+"  Data Q Name ->"+mqQ);
			} catch (MQException e) {
				e.printStackTrace();
			}catch (Exception e) {
				e.printStackTrace();
			}   
			return conn;
}
	
	
}
*/