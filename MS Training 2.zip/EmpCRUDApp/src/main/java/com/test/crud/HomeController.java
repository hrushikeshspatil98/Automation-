package com.test.crud;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class HomeController {

	@Autowired
	EmployeeRepository employeeRepository;
	
	@RequestMapping("home")
	public String home()
	{
		return "homePage";
	}
	
	@RequestMapping("register")
	public String register()
	{
		return "registration";
	}
	
	@RequestMapping("processForm")
	public String processForm(Employee employee)
	{
		employeeRepository.save(employee);
		System.out.println(employee);
		return "redirect:/getEmployees";
	}
	
	@RequestMapping("update")
	public String updatePage()
	{
		return "updateEmployee";
	}
	
	@RequestMapping("updateEmp")
	public String updateEmployee(Employee employee)
	{
		if(employeeRepository.existsById(employee.getId()))
			employeeRepository.save(employee);
		System.out.println(employee);
		return "success";
	}
	
	@RequestMapping("getEmployees")
	public String getAllEmployees(ModelMap model)
	{
		List<Employee> empList  = employeeRepository.findAll();
		System.out.println("No of employees: "+employeeRepository.count());
		model.addAttribute("empList", empList);
		return "homePage";
	}
	
	@RequestMapping("getEmployee")
	public String getEmployee()
	{
		return "employeeDetail";
	}
	
	@RequestMapping("getEmployeeDetails")
	public String getEmployeeDetails(@RequestParam("id") int id, ModelMap model)
	{
		Employee emp= employeeRepository.findById(id).orElse(null);
		model.addAttribute("employee",emp);
		return "employeeDetail";
	}
	
	@RequestMapping("delete")
	public String deletePage()
	{
		return "deleteEmployee";
	}
	
	@RequestMapping("deleteEmployee/{id}")
	public String deleteEmp(@PathVariable("id") int id)
	{
		System.out.println(id);
		if(employeeRepository.existsById(id))
			employeeRepository.deleteById(id);
		return "redirect:/getEmployees";
	}
	
	@RequestMapping("deleteForm")
	public String removeEmp(@RequestParam("id") int id)
	{
		if(employeeRepository.existsById(id))
			employeeRepository.deleteById(id);
		return "redirect:/getEmployees";
	}
	
	@RequestMapping("updateForm")
	public String updateEmpForm(@RequestParam("id") int id, ModelMap model)
	{
		Employee emp= employeeRepository.findById(id).orElse(null);
		model.addAttribute("emp",emp);
		return "updateForm";
	}
	
	
}
