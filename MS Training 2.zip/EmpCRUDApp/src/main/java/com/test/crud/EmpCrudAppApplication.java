package com.test.crud;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EmpCrudAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(EmpCrudAppApplication.class, args);
	}

}
