package com.rest.api.service;

import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import com.rest.api.entity.Product;
import com.rest.api.interfaces.ProductRepository;

@Service
public class ProductService {

		@Autowired
		private ProductRepository productRepository;
		
		@PostConstruct
		private void initDB() {
			productRepository.saveAll(Stream.of(new Product("Ice Cream", 10, 100.50), new Product("Mobile", 5, 50999), new Product("Wallet", 2, 50.25))
					.collect(Collectors.toList()));
		}

		public List<Product> findAllProducts() {
			return productRepository.findAll();
		}

		public Product getProductById(int id) {
			return productRepository.findById(id).orElse(null);
		}

		public Product getProductByName(String pname) {
			return productRepository.findByName(pname);
		}

		public Product storeProduct(Product product) {
			return productRepository.save(product);
		}
		
		public List<Product> getProductsSortByName()
		{
			return productRepository.findAll(Sort.by("name"));
		}

		public Product updateProduct(Product product) {
			
			Product existingProduct = productRepository.findById(product.getId()).orElse(null);
		    
		    if(existingProduct != null)
		    {
		        existingProduct.setName(product.getName());
		        
		        existingProduct.setQuantity(product.getQuantity());
		        
		        existingProduct.setPrice(product.getPrice());
		        
		        return productRepository.save(existingProduct); // product is alreday in DB
		    }
		    else {
		               return productRepository.save(product); // new product(not available in DB already)
		    }
		    
//		    if(productRepository.existsById(product.getId()))
//		    {
//		    	productRepository.save(product);
//		    }
//		    else
//		    {
//		    	productRepository.save(product);
//		    }
		    
		}

		public void deleteProduct(int id) {
			if(productRepository.existsById(id)) {
				productRepository.deleteById(id);
			}
		}
}
