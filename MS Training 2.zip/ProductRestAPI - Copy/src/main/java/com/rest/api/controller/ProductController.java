package com.rest.api.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.rest.api.entity.Product;
import com.rest.api.service.ProductService;

@RestController
//@RequestMapping("ProductRestAPI")  localhost:8080/ProductRestAPI/..
public class ProductController {

	@Autowired
	private ProductService productService;
	//@GetMapping("products")
	@GetMapping(value="products", produces = {MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE})
	public List<Product> getProducts()
	{
		return productService.findAllProducts();
	}
	
	@GetMapping("productById/{id}")
	public Product getProductUsingId(@PathVariable("id") int id)
	{
		return productService.getProductById(id);
	}
	
	@GetMapping("productByName/{name}")
	public Product getProductUsingName(@PathVariable("name") String pname)
	{
		return productService.getProductByName(pname);
	}
	
	@PostMapping(value="addProduct", produces = {MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE}, consumes = {MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE})
	public Product addProduct(@RequestBody Product product)
	{
		return productService.storeProduct(product);
	}
	
	@GetMapping("sortProducts")
	public List<Product> sortProducts()
	{
		return productService.getProductsSortByName();
	}
	
	@PutMapping("updateProduct")
	public Product updateAProduct(@RequestBody Product product)
	{
		return productService.updateProduct(product);
	}
	
	@DeleteMapping("deleteProduct/{id}")
	public String deleteAProduct(@PathVariable("id") int id)
	{
		productService.deleteProduct(id);
		return "Product Removed Successfully !!";
	}
	
}
