package com.rest.api.interfaces;

import org.springframework.data.jpa.repository.JpaRepository;

import com.rest.api.entity.Product;

public interface ProductRepository extends JpaRepository<Product, Integer> {

	public Product findByName(String name);
	
}
