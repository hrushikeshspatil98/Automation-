package com.ms;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class HelloService {

	@GetMapping("home")
	public String home()
	{
		return "Hello, Hrushikesh";
	}
}
