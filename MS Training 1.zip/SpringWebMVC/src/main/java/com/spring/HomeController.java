package com.spring;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
//import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller  //Specialization of Component, able to handle HTTP Request
public class HomeController {
	
	@RequestMapping("home")
	public String home()
	{
		return "home";
	}
	
	@RequestMapping("register")
	public String register()
	{
		return "registration";
	}
	
//	@RequestMapping("processForm")
//	public String processRegForm(@RequestParam int id, @RequestParam String name, @RequestParam String userName)
//	{
//		return "nextPage";
//	}
	
	@RequestMapping("processForm")
	public String processRegForm(Employee employee, Model model)
	{
		System.out.println(employee);
		model.addAttribute("emp",employee);
		return "nextPage";
	}
	
	@RequestMapping("bye") @ResponseBody // bind return type of a method with HTTP Response Body
	public String bye()
	{
		return "Bye, Hrushikesh !!";
	}

}
