package com.spring;

import java.util.ArrayList;
import java.util.List;

public class Employee {

	private int id;
	private String name;
	private String userName;
	private String gender;
	private List<String> awardName = new ArrayList<String>();
	
	public Employee() {
		super();
		System.out.println("Employee Object created");
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public List<String> getAwardName() {
		return awardName;
	}

	public void setAwardName(List<String> awardName) {
		this.awardName = awardName;
	}

	@Override
	public String toString() {
		return "Employee [id=" + id + ", name=" + name + ", userName=" + userName + ", gender=" + gender
				+ ", awardName=" + awardName + "]";
	}
	
	
}
