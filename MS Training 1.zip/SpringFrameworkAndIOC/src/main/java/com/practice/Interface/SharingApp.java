package com.practice.Interface;

public interface SharingApp {

	public void share();
	
}
