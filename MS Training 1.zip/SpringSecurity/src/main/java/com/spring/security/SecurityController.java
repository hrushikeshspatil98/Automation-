package com.spring.security;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class SecurityController {

	@GetMapping("hello")
	public String hello()
	{
		return "Hello, Everyone";
	}
	
	@GetMapping("hello-world")
	public String helloWorld()
	{
		return "Hello World";
	}
	
	@GetMapping("bye")
	public String bye()
	{
		return "Bye, Everyone !!";
	}
}
