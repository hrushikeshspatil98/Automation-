package com.test.spboot;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class Person {
    @Value("${id}")
    private int id;
    
    @Value("${name}")
    private String name;
    
    @Value("${numbers}")
    private List<String> pList = new ArrayList<String>();
    
    @Autowired
    private Address address;
    
    public int getId() {
        return id;
    }
    public void setId(int id) {
        this.id = id;
    }
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    public Person() {
        System.out.println("person object is created");
    }
    public Address getAddress() {
		return address;
	}
	public void setAddress(Address address) {
		this.address = address;
	}
	public void getPersonDetails() {
        System.out.println("ID: "+id+" , Name: "+name+" , Address: "+address+ " , Phone No's: "+pList);
    }
	public List<String> getpList() {
		return pList;
	}
	public void setpList(List<String> pList) {
		this.pList = pList;
	}
}
