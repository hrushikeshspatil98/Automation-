package com.test.spboot;

import org.springframework.stereotype.Component;

@Component
public class Student {

	public Student()
	{
		System.out.println("Student Object is created");
	}
	
	public void info()
	{
		System.out.println("Student Details are: ");
	}
}
