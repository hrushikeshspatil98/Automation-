package com.test.spboot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.annotation.Bean;

@SpringBootApplication
public class SpringBootDemoApplication {

	public static void main(String[] args) {
		ConfigurableApplicationContext context = SpringApplication.run(SpringBootDemoApplication.class, args);
		System.out.println("Hello, This is spring boot application");
		
		//Student student = context.getBean("student",Student.class);
		//student.info();
		
		Person person = context.getBean("person",Person.class);
		person.getPersonDetails();
	}
	
//	@Bean
//	public Student student()
//	{
//		return new Student();
//	}

}
