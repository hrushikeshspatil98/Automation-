package com.test.SpringAnnotations;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;

//@Component
@Component("clg")
@PropertySource("app.properties")
public class College {
	
	@Value("${collegeName}")
	private String name;
	
	@Autowired
	private Principle principle;
	
	@Autowired
	@Qualifier("javaTeacher")
	private Teacher teacher;
	
	public College()
	{
		System.out.println("Student Object is created");
	}
	
	public void testCollege() {
		System.out.println("In College: test method. College Name: "+name);
		principle.getPrincipleName();
		teacher.teach();
	}
	
}
