package com.test.SpringAnnotations;

import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Component;

@Component @Primary
public class CppTeacher implements Teacher{
	
	@Override
	public void teach() {
		System.out.println("Hello, I am Susie");
		System.out.println("I will teach you cpp");
	}

}
