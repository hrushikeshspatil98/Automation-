package com.test.SpringAnnotations;

import org.springframework.context.support.ClassPathXmlApplicationContext;

public class App 
{
    public static void main( String[] args )
    {
    	ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext("annotationsConfig.xml");
        //If bean name not specified with @Component, specify bean name same as class name just keep first letter in smaller case
        //College college = context.getBean("college",College.class);
        
        //If bean name specified with @Component
        College college = context.getBean("clg",College.class);
        college.testCollege();
        
        context.close();
        
    }
}
