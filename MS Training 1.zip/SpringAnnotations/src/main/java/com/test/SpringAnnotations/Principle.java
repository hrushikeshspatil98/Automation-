package com.test.SpringAnnotations;

import org.springframework.stereotype.Component;

@Component
public class Principle {
	
	public Principle()
	{
		System.out.println("Principle Object is created");
	}

	public void getPrincipleName()
	{
		System.out.println("Hi, I am Sam");
		System.out.println("I am the principle of the college");
	}
}
