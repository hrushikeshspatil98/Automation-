package com.test.SpringAnnotations;

import org.springframework.stereotype.Component;

@Component
public class JavaTeacher implements Teacher{

	@Override
	public void teach() {
		System.out.println("Hello, I am Sam");
		System.out.println("I will teach you Java");
	}
	

}
