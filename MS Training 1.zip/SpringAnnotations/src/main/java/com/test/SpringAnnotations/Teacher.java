package com.test.SpringAnnotations;

public interface Teacher {

	void teach();
}
