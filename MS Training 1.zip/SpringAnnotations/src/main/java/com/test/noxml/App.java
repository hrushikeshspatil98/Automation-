package com.test.noxml;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class App 
{
    public static void main( String[] args )
    {
    	
    	AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext();
    	context.scan("com.test.noxml");
    	context.register(Employee.class);
    	context.refresh();
    	
    	Employee emp = context.getBean("employee",Employee.class);
    	emp.testEmp();
    	
    	context.close();
        
    }
}
