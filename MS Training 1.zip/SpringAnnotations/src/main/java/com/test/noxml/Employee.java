package com.test.noxml;


public class Employee {

	public Employee() {
		System.out.println("Employee Object created without using bean/config xml");
	}
	
	public void testEmp() {
		System.out.println("In Emp test method");
	}
}
