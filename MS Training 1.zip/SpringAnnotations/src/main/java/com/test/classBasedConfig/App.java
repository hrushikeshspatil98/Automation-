package com.test.classBasedConfig;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class App 
{
    public static void main( String[] args )
    {
    	AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext(MyConfig.class);
        College college = context.getBean("clg",College.class);
        college.testCollege();
        context.close();
        
    }
}
