package com.test.classBasedConfig;

import org.springframework.context.annotation.PropertySource;

//@Component
@PropertySource("app.properties")
public class College {
	
	private String name;
	
	private Principle principle;
	
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	
	public Principle getPrinciple() {
		return principle;
	}

	public void setPrinciple(Principle principle) {
		this.principle = principle;
	}

	public College()
	{
		System.out.println("College Object is created");
	}
	
	public void testCollege() {
		System.out.println("In College: test method. College Name: "+name);
		principle.getPrincipleName();
	}
	
}
