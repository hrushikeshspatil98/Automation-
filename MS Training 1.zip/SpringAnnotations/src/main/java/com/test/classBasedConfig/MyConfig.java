package com.test.classBasedConfig;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class MyConfig {
	
	
	//@Bean
	@Bean(name="clg")
	public College clgBean()  // Method name will be used as bean name in case of class based configuration
	{
		//return new College();
		
		//If we want to inject object/data member dependency
		College clg = new College();
		clg.setName("IIT Mumbai");
		clg.setPrinciple(principleBean());
		return clg;
	}
	
	@Bean
	public Principle principleBean()
	{
		return new Principle();
	}

}
