package com.beans.BeanScope;

import org.springframework.context.support.ClassPathXmlApplicationContext;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext("beanScope.xml");
        //Bean Scope Example
		/*
		 * Student s1 = context.getBean("beanScope", Student.class); Student s2 =
		 * context.getBean("beanScope", Student.class);
		 * 
		 * System.out.println(s1 == s2);
		 */
        
        Student s1 = context.getBean("beanScope", Student.class);
        s1.testStudent();
        context.close();
        //context.registerShutdownHook();
        //Student s2 = context.getBean("beanScope", Student.class);
        
        
        
    }
}
    
