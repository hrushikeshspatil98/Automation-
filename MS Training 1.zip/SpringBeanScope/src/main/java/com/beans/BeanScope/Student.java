package com.beans.BeanScope;

public class Student {
	
	private int id;
	private String name;
	
	public Student()
	{
		System.out.println("Student Object is created");
	}
	
	public void myInit()
	{
		id = 101;
		name = "Hrushi";
		
	}
	
	public void testStudent() {
		System.out.println("In Student: test method. Id: "+id+ " Name: "+name );
	}
	
	public void myDestroy()
	{
		System.out.println("Clean up is done !");
	}

}
