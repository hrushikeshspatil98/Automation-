package com.spring.soapWS;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SoapWebServiceDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(SoapWebServiceDemoApplication.class, args);
	}

}
