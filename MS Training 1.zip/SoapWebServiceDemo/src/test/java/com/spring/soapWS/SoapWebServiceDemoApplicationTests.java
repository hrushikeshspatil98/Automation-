package com.spring.soapWS;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SoapWebServiceDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
